@echo off
setlocal enabledelayedexpansion
color 0A
chcp 65001 > nul
echo =========================================
echo      GitHub Auto Uploader - يا ريس
echo =========================================
echo.

:: Check if git is initialized
if not exist ".git" (
    echo [INFO] Initializing Git...
    git init
)

:: Prompt for commit message
set /p commit_msg="Enter commit message (or press enter for 'update'): "
if "!commit_msg!"=="" set commit_msg=update

:: Add and commit
echo [INFO] Adding files...
git add .
echo [INFO] Committing...
git commit -m "!commit_msg!"

:: Check if remote exists
git remote -v | find "origin" > nul
if errorlevel 1 (
    echo.
    set /p repo_url="Enter your GitHub Repository URL (ex: https://github.com/user/repo.git): "
    git remote add origin !repo_url!
    git branch -M main
)

:: Push
echo [INFO] Pushing to GitHub...
git push -u origin main

echo.
echo =========================================
echo       عاش يا وحش! الملفات اترفعـــــت!      
echo =========================================
pause
