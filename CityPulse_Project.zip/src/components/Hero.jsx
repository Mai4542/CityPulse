import React from 'react';

const Hero = () => {
  const stats = [
    { value: "١٢,٨٤٠", label: "بلاغ منذ الإطلاق", color: "text-teal-600" },
    { value: "٨٩٪", label: "معدل الحل الناجح", color: "text-emerald-600" },
    { value: "٢.٤", label: "ساعة متوسط الاستجابة", color: "text-blue-600" },
    { value: "٧", label: "مراكز مُغطّاة", color: "text-amber-600" },
  ];

  return (
    <section className="pt-24 pb-20 px-6 bg-gradient-to-br from-slate-900 via-teal-950 to-slate-900 relative overflow-hidden">
      <div className="absolute inset-0">
        <img src="/images/hero-city.png" alt="" className="w-full h-full object-cover opacity-20" />
        <div className="absolute inset-0 bg-gradient-to-b from-slate-900/60 via-teal-950/70 to-slate-900/90" />
      </div>
      <div className="absolute inset-0 opacity-5 pointer-events-none">
        <div className="absolute top-20 right-10 w-96 h-96 bg-teal-400 rounded-full blur-3xl" />
        <div className="absolute bottom-10 left-20 w-72 h-72 bg-blue-400 rounded-full blur-3xl" />
      </div>
      <div className="max-w-5xl mx-auto text-center relative">
        <div className="inline-flex items-center gap-2 bg-teal-500/20 text-teal-300 px-4 py-2 rounded-full text-sm font-bold mb-8 border border-teal-500/30">
          <div className="w-2 h-2 bg-teal-400 rounded-full animate-pulse" />
          منصة القليوبية الرقمية لإدارة البلاغات
        </div>
        <h1 className="text-4xl md:text-6xl font-black text-white mb-6 leading-tight">
          صوتك يبني
          <span className="block text-teal-400 mt-1">محافظتك</span>
        </h1>
        <p className="text-lg text-slate-300 max-w-2xl mx-auto mb-10 leading-relaxed">
          منصة ذكية تمكّن مواطني القليوبية من الإبلاغ عن مشكلات البنية التحتية، وتمنح الإدارة أدوات متطورة لمتابعة الحلول وقياس الأداء بشفافية كاملة.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
          <a href="/report" className="w-full sm:w-auto px-8 py-4 text-lg font-black text-white bg-teal-500 hover:bg-teal-400 rounded-xl transition-colors shadow-lg shadow-teal-500/25 flex items-center justify-center gap-2">
            ابدأ الإبلاغ الآن
            <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
            </svg>
          </a>
          <button className="w-full sm:w-auto px-8 py-4 text-lg font-bold text-slate-200 bg-white/10 border border-white/20 rounded-xl hover:bg-white/20 transition-colors backdrop-blur">
            شاهد كيف يعمل
          </button>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto">
          {stats.map((c) => (
            <div key={c.label} className="bg-white/5 border border-white/10 rounded-xl p-4 backdrop-blur">
              <div className={`text-3xl font-black mb-1 ${c.color}`}>{c.value}</div>
              <div className="text-xs text-slate-400 font-bold">{c.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Hero;
