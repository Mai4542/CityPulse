import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';

function App() {
  return (
    <div dir="rtl" className="min-h-screen bg-white text-slate-900">
      <Navbar />
      <Hero />
    </div>
  );
}

export default App;
