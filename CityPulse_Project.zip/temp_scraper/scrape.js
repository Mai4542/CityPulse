const puppeteer = require('puppeteer');
const fs = require('fs');

(async () => {
  try {
    const browser = await puppeteer.launch();
    const page = await browser.newPage();
    await page.goto('https://qalyubia-pulse--mailalala4542.replit.app', { waitUntil: 'networkidle2' });
    const html = await page.$eval('#root', el => el.innerHTML);
    fs.writeFileSync('page.html', html);
    await browser.close();
    console.log('SUCCESS');
  } catch (error) {
    console.error(error);
  }
})();
