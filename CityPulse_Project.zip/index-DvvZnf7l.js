function Vv(a, i) {
  for (var c = 0; c < i.length; c++) {
    const o = i[c];
    if (typeof o != "string" && !Array.isArray(o)) {
      for (const d in o)
        if (d !== "default" && !(d in a)) {
          const f = Object.getOwnPropertyDescriptor(o, d);
          f &&
            Object.defineProperty(
              a,
              d,
              f.get ? f : { enumerable: !0, get: () => o[d] },
            );
        }
    }
  }
  return Object.freeze(
    Object.defineProperty(a, Symbol.toStringTag, { value: "Module" }),
  );
}
(function () {
  const i = document.createElement("link").relList;
  if (i && i.supports && i.supports("modulepreload")) return;
  for (const d of document.querySelectorAll('link[rel="modulepreload"]')) o(d);
  new MutationObserver((d) => {
    for (const f of d)
      if (f.type === "childList")
        for (const x of f.addedNodes)
          x.tagName === "LINK" && x.rel === "modulepreload" && o(x);
  }).observe(document, { childList: !0, subtree: !0 });
  function c(d) {
    const f = {};
    return (
      d.integrity && (f.integrity = d.integrity),
      d.referrerPolicy && (f.referrerPolicy = d.referrerPolicy),
      d.crossOrigin === "use-credentials"
        ? (f.credentials = "include")
        : d.crossOrigin === "anonymous"
          ? (f.credentials = "omit")
          : (f.credentials = "same-origin"),
      f
    );
  }
  function o(d) {
    if (d.ep) return;
    d.ep = !0;
    const f = c(d);
    fetch(d.href, f);
  }
})();
function nx(a) {
  return a && a.__esModule && Object.prototype.hasOwnProperty.call(a, "default")
    ? a.default
    : a;
}
var Ko = { exports: {} },
  vs = {};
var $0;
function Xv() {
  if ($0) return vs;
  $0 = 1;
  var a = Symbol.for("react.transitional.element"),
    i = Symbol.for("react.fragment");
  function c(o, d, f) {
    var x = null;
    if (
      (f !== void 0 && (x = "" + f),
      d.key !== void 0 && (x = "" + d.key),
      "key" in d)
    ) {
      f = {};
      for (var b in d) b !== "key" && (f[b] = d[b]);
    } else f = d;
    return (
      (d = f.ref),
      { $$typeof: a, type: o, key: x, ref: d !== void 0 ? d : null, props: f }
    );
  }
  return ((vs.Fragment = i), (vs.jsx = c), (vs.jsxs = c), vs);
}
var J0;
function Qv() {
  return (J0 || ((J0 = 1), (Ko.exports = Xv())), Ko.exports);
}
var s = Qv(),
  Po = { exports: {} },
  ys = {},
  $o = { exports: {} },
  Jo = {};
var F0;
function Zv() {
  return (
    F0 ||
      ((F0 = 1),
      (function (a) {
        function i(O, G) {
          var Q = O.length;
          O.push(G);
          e: for (; 0 < Q; ) {
            var se = (Q - 1) >>> 1,
              y = O[se];
            if (0 < d(y, G)) ((O[se] = G), (O[Q] = y), (Q = se));
            else break e;
          }
        }
        function c(O) {
          return O.length === 0 ? null : O[0];
        }
        function o(O) {
          if (O.length === 0) return null;
          var G = O[0],
            Q = O.pop();
          if (Q !== G) {
            O[0] = Q;
            e: for (var se = 0, y = O.length, q = y >>> 1; se < q; ) {
              var J = 2 * (se + 1) - 1,
                P = O[J],
                ae = J + 1,
                ce = O[ae];
              if (0 > d(P, Q))
                ae < y && 0 > d(ce, P)
                  ? ((O[se] = ce), (O[ae] = Q), (se = ae))
                  : ((O[se] = P), (O[J] = Q), (se = J));
              else if (ae < y && 0 > d(ce, Q))
                ((O[se] = ce), (O[ae] = Q), (se = ae));
              else break e;
            }
          }
          return G;
        }
        function d(O, G) {
          var Q = O.sortIndex - G.sortIndex;
          return Q !== 0 ? Q : O.id - G.id;
        }
        if (
          ((a.unstable_now = void 0),
          typeof performance == "object" &&
            typeof performance.now == "function")
        ) {
          var f = performance;
          a.unstable_now = function () {
            return f.now();
          };
        } else {
          var x = Date,
            b = x.now();
          a.unstable_now = function () {
            return x.now() - b;
          };
        }
        var p = [],
          h = [],
          v = 1,
          w = null,
          E = 3,
          R = !1,
          k = !1,
          A = !1,
          _ = !1,
          B = typeof setTimeout == "function" ? setTimeout : null,
          V = typeof clearTimeout == "function" ? clearTimeout : null,
          Y = typeof setImmediate < "u" ? setImmediate : null;
        function Z(O) {
          for (var G = c(h); G !== null; ) {
            if (G.callback === null) o(h);
            else if (G.startTime <= O)
              (o(h), (G.sortIndex = G.expirationTime), i(p, G));
            else break;
            G = c(h);
          }
        }
        function X(O) {
          if (((A = !1), Z(O), !k))
            if (c(p) !== null) ((k = !0), $ || (($ = !0), he()));
            else {
              var G = c(h);
              G !== null && fe(X, G.startTime - O);
            }
        }
        var $ = !1,
          F = -1,
          K = 5,
          ue = -1;
        function ge() {
          return _ ? !0 : !(a.unstable_now() - ue < K);
        }
        function je() {
          if (((_ = !1), $)) {
            var O = a.unstable_now();
            ue = O;
            var G = !0;
            try {
              e: {
                ((k = !1), A && ((A = !1), V(F), (F = -1)), (R = !0));
                var Q = E;
                try {
                  t: {
                    for (
                      Z(O), w = c(p);
                      w !== null && !(w.expirationTime > O && ge());
                    ) {
                      var se = w.callback;
                      if (typeof se == "function") {
                        ((w.callback = null), (E = w.priorityLevel));
                        var y = se(w.expirationTime <= O);
                        if (((O = a.unstable_now()), typeof y == "function")) {
                          ((w.callback = y), Z(O), (G = !0));
                          break t;
                        }
                        (w === c(p) && o(p), Z(O));
                      } else o(p);
                      w = c(p);
                    }
                    if (w !== null) G = !0;
                    else {
                      var q = c(h);
                      (q !== null && fe(X, q.startTime - O), (G = !1));
                    }
                  }
                  break e;
                } finally {
                  ((w = null), (E = Q), (R = !1));
                }
                G = void 0;
              }
            } finally {
              G ? he() : ($ = !1);
            }
          }
        }
        var he;
        if (typeof Y == "function")
          he = function () {
            Y(je);
          };
        else if (typeof MessageChannel < "u") {
          var we = new MessageChannel(),
            W = we.port2;
          ((we.port1.onmessage = je),
            (he = function () {
              W.postMessage(null);
            }));
        } else
          he = function () {
            B(je, 0);
          };
        function fe(O, G) {
          F = B(function () {
            O(a.unstable_now());
          }, G);
        }
        ((a.unstable_IdlePriority = 5),
          (a.unstable_ImmediatePriority = 1),
          (a.unstable_LowPriority = 4),
          (a.unstable_NormalPriority = 3),
          (a.unstable_Profiling = null),
          (a.unstable_UserBlockingPriority = 2),
          (a.unstable_cancelCallback = function (O) {
            O.callback = null;
          }),
          (a.unstable_forceFrameRate = function (O) {
            0 > O || 125 < O
              ? console.error(
                  "forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported",
                )
              : (K = 0 < O ? Math.floor(1e3 / O) : 5);
          }),
          (a.unstable_getCurrentPriorityLevel = function () {
            return E;
          }),
          (a.unstable_next = function (O) {
            switch (E) {
              case 1:
              case 2:
              case 3:
                var G = 3;
                break;
              default:
                G = E;
            }
            var Q = E;
            E = G;
            try {
              return O();
            } finally {
              E = Q;
            }
          }),
          (a.unstable_requestPaint = function () {
            _ = !0;
          }),
          (a.unstable_runWithPriority = function (O, G) {
            switch (O) {
              case 1:
              case 2:
              case 3:
              case 4:
              case 5:
                break;
              default:
                O = 3;
            }
            var Q = E;
            E = O;
            try {
              return G();
            } finally {
              E = Q;
            }
          }),
          (a.unstable_scheduleCallback = function (O, G, Q) {
            var se = a.unstable_now();
            switch (
              (typeof Q == "object" && Q !== null
                ? ((Q = Q.delay),
                  (Q = typeof Q == "number" && 0 < Q ? se + Q : se))
                : (Q = se),
              O)
            ) {
              case 1:
                var y = -1;
                break;
              case 2:
                y = 250;
                break;
              case 5:
                y = 1073741823;
                break;
              case 4:
                y = 1e4;
                break;
              default:
                y = 5e3;
            }
            return (
              (y = Q + y),
              (O = {
                id: v++,
                callback: G,
                priorityLevel: O,
                startTime: Q,
                expirationTime: y,
                sortIndex: -1,
              }),
              Q > se
                ? ((O.sortIndex = Q),
                  i(h, O),
                  c(p) === null &&
                    O === c(h) &&
                    (A ? (V(F), (F = -1)) : (A = !0), fe(X, Q - se)))
                : ((O.sortIndex = y),
                  i(p, O),
                  k || R || ((k = !0), $ || (($ = !0), he()))),
              O
            );
          }),
          (a.unstable_shouldYield = ge),
          (a.unstable_wrapCallback = function (O) {
            var G = E;
            return function () {
              var Q = E;
              E = G;
              try {
                return O.apply(this, arguments);
              } finally {
                E = Q;
              }
            };
          }));
      })(Jo)),
    Jo
  );
}
var W0;
function Kv() {
  return (W0 || ((W0 = 1), ($o.exports = Zv())), $o.exports);
}
var Fo = { exports: {} },
  me = {};
var I0;
function Pv() {
  if (I0) return me;
  I0 = 1;
  var a = Symbol.for("react.transitional.element"),
    i = Symbol.for("react.portal"),
    c = Symbol.for("react.fragment"),
    o = Symbol.for("react.strict_mode"),
    d = Symbol.for("react.profiler"),
    f = Symbol.for("react.consumer"),
    x = Symbol.for("react.context"),
    b = Symbol.for("react.forward_ref"),
    p = Symbol.for("react.suspense"),
    h = Symbol.for("react.memo"),
    v = Symbol.for("react.lazy"),
    w = Symbol.iterator;
  function E(y) {
    return y === null || typeof y != "object"
      ? null
      : ((y = (w && y[w]) || y["@@iterator"]),
        typeof y == "function" ? y : null);
  }
  var R = {
      isMounted: function () {
        return !1;
      },
      enqueueForceUpdate: function () {},
      enqueueReplaceState: function () {},
      enqueueSetState: function () {},
    },
    k = Object.assign,
    A = {};
  function _(y, q, J) {
    ((this.props = y),
      (this.context = q),
      (this.refs = A),
      (this.updater = J || R));
  }
  ((_.prototype.isReactComponent = {}),
    (_.prototype.setState = function (y, q) {
      if (typeof y != "object" && typeof y != "function" && y != null)
        throw Error(
          "takes an object of state variables to update or a function which returns an object of state variables.",
        );
      this.updater.enqueueSetState(this, y, q, "setState");
    }),
    (_.prototype.forceUpdate = function (y) {
      this.updater.enqueueForceUpdate(this, y, "forceUpdate");
    }));
  function B() {}
  B.prototype = _.prototype;
  function V(y, q, J) {
    ((this.props = y),
      (this.context = q),
      (this.refs = A),
      (this.updater = J || R));
  }
  var Y = (V.prototype = new B());
  ((Y.constructor = V), k(Y, _.prototype), (Y.isPureReactComponent = !0));
  var Z = Array.isArray,
    X = { H: null, A: null, T: null, S: null, V: null },
    $ = Object.prototype.hasOwnProperty;
  function F(y, q, J, P, ae, ce) {
    return (
      (J = ce.ref),
      { $$typeof: a, type: y, key: q, ref: J !== void 0 ? J : null, props: ce }
    );
  }
  function K(y, q) {
    return F(y.type, q, void 0, void 0, void 0, y.props);
  }
  function ue(y) {
    return typeof y == "object" && y !== null && y.$$typeof === a;
  }
  function ge(y) {
    var q = { "=": "=0", ":": "=2" };
    return (
      "$" +
      y.replace(/[=:]/g, function (J) {
        return q[J];
      })
    );
  }
  var je = /\/+/g;
  function he(y, q) {
    return typeof y == "object" && y !== null && y.key != null
      ? ge("" + y.key)
      : q.toString(36);
  }
  function we() {}
  function W(y) {
    switch (y.status) {
      case "fulfilled":
        return y.value;
      case "rejected":
        throw y.reason;
      default:
        switch (
          (typeof y.status == "string"
            ? y.then(we, we)
            : ((y.status = "pending"),
              y.then(
                function (q) {
                  y.status === "pending" &&
                    ((y.status = "fulfilled"), (y.value = q));
                },
                function (q) {
                  y.status === "pending" &&
                    ((y.status = "rejected"), (y.reason = q));
                },
              )),
          y.status)
        ) {
          case "fulfilled":
            return y.value;
          case "rejected":
            throw y.reason;
        }
    }
    throw y;
  }
  function fe(y, q, J, P, ae) {
    var ce = typeof y;
    (ce === "undefined" || ce === "boolean") && (y = null);
    var le = !1;
    if (y === null) le = !0;
    else
      switch (ce) {
        case "bigint":
        case "string":
        case "number":
          le = !0;
          break;
        case "object":
          switch (y.$$typeof) {
            case a:
            case i:
              le = !0;
              break;
            case v:
              return ((le = y._init), fe(le(y._payload), q, J, P, ae));
          }
      }
    if (le)
      return (
        (ae = ae(y)),
        (le = P === "" ? "." + he(y, 0) : P),
        Z(ae)
          ? ((J = ""),
            le != null && (J = le.replace(je, "$&/") + "/"),
            fe(ae, q, J, "", function (Ae) {
              return Ae;
            }))
          : ae != null &&
            (ue(ae) &&
              (ae = K(
                ae,
                J +
                  (ae.key == null || (y && y.key === ae.key)
                    ? ""
                    : ("" + ae.key).replace(je, "$&/") + "/") +
                  le,
              )),
            q.push(ae)),
        1
      );
    le = 0;
    var ze = P === "" ? "." : P + ":";
    if (Z(y))
      for (var Te = 0; Te < y.length; Te++)
        ((P = y[Te]), (ce = ze + he(P, Te)), (le += fe(P, q, J, ce, ae)));
    else if (((Te = E(y)), typeof Te == "function"))
      for (y = Te.call(y), Te = 0; !(P = y.next()).done; )
        ((P = P.value), (ce = ze + he(P, Te++)), (le += fe(P, q, J, ce, ae)));
    else if (ce === "object") {
      if (typeof y.then == "function") return fe(W(y), q, J, P, ae);
      throw (
        (q = String(y)),
        Error(
          "Objects are not valid as a React child (found: " +
            (q === "[object Object]"
              ? "object with keys {" + Object.keys(y).join(", ") + "}"
              : q) +
            "). If you meant to render a collection of children, use an array instead.",
        )
      );
    }
    return le;
  }
  function O(y, q, J) {
    if (y == null) return y;
    var P = [],
      ae = 0;
    return (
      fe(y, P, "", "", function (ce) {
        return q.call(J, ce, ae++);
      }),
      P
    );
  }
  function G(y) {
    if (y._status === -1) {
      var q = y._result;
      ((q = q()),
        q.then(
          function (J) {
            (y._status === 0 || y._status === -1) &&
              ((y._status = 1), (y._result = J));
          },
          function (J) {
            (y._status === 0 || y._status === -1) &&
              ((y._status = 2), (y._result = J));
          },
        ),
        y._status === -1 && ((y._status = 0), (y._result = q)));
    }
    if (y._status === 1) return y._result.default;
    throw y._result;
  }
  var Q =
    typeof reportError == "function"
      ? reportError
      : function (y) {
          if (
            typeof window == "object" &&
            typeof window.ErrorEvent == "function"
          ) {
            var q = new window.ErrorEvent("error", {
              bubbles: !0,
              cancelable: !0,
              message:
                typeof y == "object" &&
                y !== null &&
                typeof y.message == "string"
                  ? String(y.message)
                  : String(y),
              error: y,
            });
            if (!window.dispatchEvent(q)) return;
          } else if (
            typeof process == "object" &&
            typeof process.emit == "function"
          ) {
            process.emit("uncaughtException", y);
            return;
          }
          console.error(y);
        };
  function se() {}
  return (
    (me.Children = {
      map: O,
      forEach: function (y, q, J) {
        O(
          y,
          function () {
            q.apply(this, arguments);
          },
          J,
        );
      },
      count: function (y) {
        var q = 0;
        return (
          O(y, function () {
            q++;
          }),
          q
        );
      },
      toArray: function (y) {
        return (
          O(y, function (q) {
            return q;
          }) || []
        );
      },
      only: function (y) {
        if (!ue(y))
          throw Error(
            "React.Children.only expected to receive a single React element child.",
          );
        return y;
      },
    }),
    (me.Component = _),
    (me.Fragment = c),
    (me.Profiler = d),
    (me.PureComponent = V),
    (me.StrictMode = o),
    (me.Suspense = p),
    (me.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = X),
    (me.__COMPILER_RUNTIME = {
      __proto__: null,
      c: function (y) {
        return X.H.useMemoCache(y);
      },
    }),
    (me.cache = function (y) {
      return function () {
        return y.apply(null, arguments);
      };
    }),
    (me.cloneElement = function (y, q, J) {
      if (y == null)
        throw Error(
          "The argument must be a React element, but you passed " + y + ".",
        );
      var P = k({}, y.props),
        ae = y.key,
        ce = void 0;
      if (q != null)
        for (le in (q.ref !== void 0 && (ce = void 0),
        q.key !== void 0 && (ae = "" + q.key),
        q))
          !$.call(q, le) ||
            le === "key" ||
            le === "__self" ||
            le === "__source" ||
            (le === "ref" && q.ref === void 0) ||
            (P[le] = q[le]);
      var le = arguments.length - 2;
      if (le === 1) P.children = J;
      else if (1 < le) {
        for (var ze = Array(le), Te = 0; Te < le; Te++)
          ze[Te] = arguments[Te + 2];
        P.children = ze;
      }
      return F(y.type, ae, void 0, void 0, ce, P);
    }),
    (me.createContext = function (y) {
      return (
        (y = {
          $$typeof: x,
          _currentValue: y,
          _currentValue2: y,
          _threadCount: 0,
          Provider: null,
          Consumer: null,
        }),
        (y.Provider = y),
        (y.Consumer = { $$typeof: f, _context: y }),
        y
      );
    }),
    (me.createElement = function (y, q, J) {
      var P,
        ae = {},
        ce = null;
      if (q != null)
        for (P in (q.key !== void 0 && (ce = "" + q.key), q))
          $.call(q, P) &&
            P !== "key" &&
            P !== "__self" &&
            P !== "__source" &&
            (ae[P] = q[P]);
      var le = arguments.length - 2;
      if (le === 1) ae.children = J;
      else if (1 < le) {
        for (var ze = Array(le), Te = 0; Te < le; Te++)
          ze[Te] = arguments[Te + 2];
        ae.children = ze;
      }
      if (y && y.defaultProps)
        for (P in ((le = y.defaultProps), le))
          ae[P] === void 0 && (ae[P] = le[P]);
      return F(y, ce, void 0, void 0, null, ae);
    }),
    (me.createRef = function () {
      return { current: null };
    }),
    (me.forwardRef = function (y) {
      return { $$typeof: b, render: y };
    }),
    (me.isValidElement = ue),
    (me.lazy = function (y) {
      return { $$typeof: v, _payload: { _status: -1, _result: y }, _init: G };
    }),
    (me.memo = function (y, q) {
      return { $$typeof: h, type: y, compare: q === void 0 ? null : q };
    }),
    (me.startTransition = function (y) {
      var q = X.T,
        J = {};
      X.T = J;
      try {
        var P = y(),
          ae = X.S;
        (ae !== null && ae(J, P),
          typeof P == "object" &&
            P !== null &&
            typeof P.then == "function" &&
            P.then(se, Q));
      } catch (ce) {
        Q(ce);
      } finally {
        X.T = q;
      }
    }),
    (me.unstable_useCacheRefresh = function () {
      return X.H.useCacheRefresh();
    }),
    (me.use = function (y) {
      return X.H.use(y);
    }),
    (me.useActionState = function (y, q, J) {
      return X.H.useActionState(y, q, J);
    }),
    (me.useCallback = function (y, q) {
      return X.H.useCallback(y, q);
    }),
    (me.useContext = function (y) {
      return X.H.useContext(y);
    }),
    (me.useDebugValue = function () {}),
    (me.useDeferredValue = function (y, q) {
      return X.H.useDeferredValue(y, q);
    }),
    (me.useEffect = function (y, q, J) {
      var P = X.H;
      if (typeof J == "function")
        throw Error(
          "useEffect CRUD overload is not enabled in this build of React.",
        );
      return P.useEffect(y, q);
    }),
    (me.useId = function () {
      return X.H.useId();
    }),
    (me.useImperativeHandle = function (y, q, J) {
      return X.H.useImperativeHandle(y, q, J);
    }),
    (me.useInsertionEffect = function (y, q) {
      return X.H.useInsertionEffect(y, q);
    }),
    (me.useLayoutEffect = function (y, q) {
      return X.H.useLayoutEffect(y, q);
    }),
    (me.useMemo = function (y, q) {
      return X.H.useMemo(y, q);
    }),
    (me.useOptimistic = function (y, q) {
      return X.H.useOptimistic(y, q);
    }),
    (me.useReducer = function (y, q, J) {
      return X.H.useReducer(y, q, J);
    }),
    (me.useRef = function (y) {
      return X.H.useRef(y);
    }),
    (me.useState = function (y) {
      return X.H.useState(y);
    }),
    (me.useSyncExternalStore = function (y, q, J) {
      return X.H.useSyncExternalStore(y, q, J);
    }),
    (me.useTransition = function () {
      return X.H.useTransition();
    }),
    (me.version = "19.1.0"),
    me
  );
}
var em;
function br() {
  return (em || ((em = 1), (Fo.exports = Pv())), Fo.exports);
}
var Wo = { exports: {} },
  st = {};
var tm;
function $v() {
  if (tm) return st;
  tm = 1;
  var a = br();
  function i(p) {
    var h = "https://react.dev/errors/" + p;
    if (1 < arguments.length) {
      h += "?args[]=" + encodeURIComponent(arguments[1]);
      for (var v = 2; v < arguments.length; v++)
        h += "&args[]=" + encodeURIComponent(arguments[v]);
    }
    return (
      "Minified React error #" +
      p +
      "; visit " +
      h +
      " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
    );
  }
  function c() {}
  var o = {
      d: {
        f: c,
        r: function () {
          throw Error(i(522));
        },
        D: c,
        C: c,
        L: c,
        m: c,
        X: c,
        S: c,
        M: c,
      },
      p: 0,
      findDOMNode: null,
    },
    d = Symbol.for("react.portal");
  function f(p, h, v) {
    var w =
      3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
    return {
      $$typeof: d,
      key: w == null ? null : "" + w,
      children: p,
      containerInfo: h,
      implementation: v,
    };
  }
  var x = a.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;
  function b(p, h) {
    if (p === "font") return "";
    if (typeof h == "string") return h === "use-credentials" ? h : "";
  }
  return (
    (st.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = o),
    (st.createPortal = function (p, h) {
      var v =
        2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
      if (!h || (h.nodeType !== 1 && h.nodeType !== 9 && h.nodeType !== 11))
        throw Error(i(299));
      return f(p, h, null, v);
    }),
    (st.flushSync = function (p) {
      var h = x.T,
        v = o.p;
      try {
        if (((x.T = null), (o.p = 2), p)) return p();
      } finally {
        ((x.T = h), (o.p = v), o.d.f());
      }
    }),
    (st.preconnect = function (p, h) {
      typeof p == "string" &&
        (h
          ? ((h = h.crossOrigin),
            (h =
              typeof h == "string"
                ? h === "use-credentials"
                  ? h
                  : ""
                : void 0))
          : (h = null),
        o.d.C(p, h));
    }),
    (st.prefetchDNS = function (p) {
      typeof p == "string" && o.d.D(p);
    }),
    (st.preinit = function (p, h) {
      if (typeof p == "string" && h && typeof h.as == "string") {
        var v = h.as,
          w = b(v, h.crossOrigin),
          E = typeof h.integrity == "string" ? h.integrity : void 0,
          R = typeof h.fetchPriority == "string" ? h.fetchPriority : void 0;
        v === "style"
          ? o.d.S(p, typeof h.precedence == "string" ? h.precedence : void 0, {
              crossOrigin: w,
              integrity: E,
              fetchPriority: R,
            })
          : v === "script" &&
            o.d.X(p, {
              crossOrigin: w,
              integrity: E,
              fetchPriority: R,
              nonce: typeof h.nonce == "string" ? h.nonce : void 0,
            });
      }
    }),
    (st.preinitModule = function (p, h) {
      if (typeof p == "string")
        if (typeof h == "object" && h !== null) {
          if (h.as == null || h.as === "script") {
            var v = b(h.as, h.crossOrigin);
            o.d.M(p, {
              crossOrigin: v,
              integrity: typeof h.integrity == "string" ? h.integrity : void 0,
              nonce: typeof h.nonce == "string" ? h.nonce : void 0,
            });
          }
        } else h == null && o.d.M(p);
    }),
    (st.preload = function (p, h) {
      if (
        typeof p == "string" &&
        typeof h == "object" &&
        h !== null &&
        typeof h.as == "string"
      ) {
        var v = h.as,
          w = b(v, h.crossOrigin);
        o.d.L(p, v, {
          crossOrigin: w,
          integrity: typeof h.integrity == "string" ? h.integrity : void 0,
          nonce: typeof h.nonce == "string" ? h.nonce : void 0,
          type: typeof h.type == "string" ? h.type : void 0,
          fetchPriority:
            typeof h.fetchPriority == "string" ? h.fetchPriority : void 0,
          referrerPolicy:
            typeof h.referrerPolicy == "string" ? h.referrerPolicy : void 0,
          imageSrcSet:
            typeof h.imageSrcSet == "string" ? h.imageSrcSet : void 0,
          imageSizes: typeof h.imageSizes == "string" ? h.imageSizes : void 0,
          media: typeof h.media == "string" ? h.media : void 0,
        });
      }
    }),
    (st.preloadModule = function (p, h) {
      if (typeof p == "string")
        if (h) {
          var v = b(h.as, h.crossOrigin);
          o.d.m(p, {
            as: typeof h.as == "string" && h.as !== "script" ? h.as : void 0,
            crossOrigin: v,
            integrity: typeof h.integrity == "string" ? h.integrity : void 0,
          });
        } else o.d.m(p);
    }),
    (st.requestFormReset = function (p) {
      o.d.r(p);
    }),
    (st.unstable_batchedUpdates = function (p, h) {
      return p(h);
    }),
    (st.useFormState = function (p, h, v) {
      return x.H.useFormState(p, h, v);
    }),
    (st.useFormStatus = function () {
      return x.H.useHostTransitionStatus();
    }),
    (st.version = "19.1.0"),
    st
  );
}
var lm;
function sx() {
  if (lm) return Wo.exports;
  lm = 1;
  function a() {
    if (
      !(
        typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" ||
        typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"
      )
    )
      try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(a);
      } catch (i) {
        console.error(i);
      }
  }
  return (a(), (Wo.exports = $v()), Wo.exports);
}
var am;
function Jv() {
  if (am) return ys;
  am = 1;
  var a = Kv(),
    i = br(),
    c = sx();
  function o(e) {
    var t = "https://react.dev/errors/" + e;
    if (1 < arguments.length) {
      t += "?args[]=" + encodeURIComponent(arguments[1]);
      for (var l = 2; l < arguments.length; l++)
        t += "&args[]=" + encodeURIComponent(arguments[l]);
    }
    return (
      "Minified React error #" +
      e +
      "; visit " +
      t +
      " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
    );
  }
  function d(e) {
    return !(!e || (e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11));
  }
  function f(e) {
    var t = e,
      l = e;
    if (e.alternate) for (; t.return; ) t = t.return;
    else {
      e = t;
      do ((t = e), (t.flags & 4098) !== 0 && (l = t.return), (e = t.return));
      while (e);
    }
    return t.tag === 3 ? l : null;
  }
  function x(e) {
    if (e.tag === 13) {
      var t = e.memoizedState;
      if (
        (t === null && ((e = e.alternate), e !== null && (t = e.memoizedState)),
        t !== null)
      )
        return t.dehydrated;
    }
    return null;
  }
  function b(e) {
    if (f(e) !== e) throw Error(o(188));
  }
  function p(e) {
    var t = e.alternate;
    if (!t) {
      if (((t = f(e)), t === null)) throw Error(o(188));
      return t !== e ? null : e;
    }
    for (var l = e, n = t; ; ) {
      var r = l.return;
      if (r === null) break;
      var u = r.alternate;
      if (u === null) {
        if (((n = r.return), n !== null)) {
          l = n;
          continue;
        }
        break;
      }
      if (r.child === u.child) {
        for (u = r.child; u; ) {
          if (u === l) return (b(r), e);
          if (u === n) return (b(r), t);
          u = u.sibling;
        }
        throw Error(o(188));
      }
      if (l.return !== n.return) ((l = r), (n = u));
      else {
        for (var m = !1, g = r.child; g; ) {
          if (g === l) {
            ((m = !0), (l = r), (n = u));
            break;
          }
          if (g === n) {
            ((m = !0), (n = r), (l = u));
            break;
          }
          g = g.sibling;
        }
        if (!m) {
          for (g = u.child; g; ) {
            if (g === l) {
              ((m = !0), (l = u), (n = r));
              break;
            }
            if (g === n) {
              ((m = !0), (n = u), (l = r));
              break;
            }
            g = g.sibling;
          }
          if (!m) throw Error(o(189));
        }
      }
      if (l.alternate !== n) throw Error(o(190));
    }
    if (l.tag !== 3) throw Error(o(188));
    return l.stateNode.current === l ? e : t;
  }
  function h(e) {
    var t = e.tag;
    if (t === 5 || t === 26 || t === 27 || t === 6) return e;
    for (e = e.child; e !== null; ) {
      if (((t = h(e)), t !== null)) return t;
      e = e.sibling;
    }
    return null;
  }
  var v = Object.assign,
    w = Symbol.for("react.element"),
    E = Symbol.for("react.transitional.element"),
    R = Symbol.for("react.portal"),
    k = Symbol.for("react.fragment"),
    A = Symbol.for("react.strict_mode"),
    _ = Symbol.for("react.profiler"),
    B = Symbol.for("react.provider"),
    V = Symbol.for("react.consumer"),
    Y = Symbol.for("react.context"),
    Z = Symbol.for("react.forward_ref"),
    X = Symbol.for("react.suspense"),
    $ = Symbol.for("react.suspense_list"),
    F = Symbol.for("react.memo"),
    K = Symbol.for("react.lazy"),
    ue = Symbol.for("react.activity"),
    ge = Symbol.for("react.memo_cache_sentinel"),
    je = Symbol.iterator;
  function he(e) {
    return e === null || typeof e != "object"
      ? null
      : ((e = (je && e[je]) || e["@@iterator"]),
        typeof e == "function" ? e : null);
  }
  var we = Symbol.for("react.client.reference");
  function W(e) {
    if (e == null) return null;
    if (typeof e == "function")
      return e.$$typeof === we ? null : e.displayName || e.name || null;
    if (typeof e == "string") return e;
    switch (e) {
      case k:
        return "Fragment";
      case _:
        return "Profiler";
      case A:
        return "StrictMode";
      case X:
        return "Suspense";
      case $:
        return "SuspenseList";
      case ue:
        return "Activity";
    }
    if (typeof e == "object")
      switch (e.$$typeof) {
        case R:
          return "Portal";
        case Y:
          return (e.displayName || "Context") + ".Provider";
        case V:
          return (e._context.displayName || "Context") + ".Consumer";
        case Z:
          var t = e.render;
          return (
            (e = e.displayName),
            e ||
              ((e = t.displayName || t.name || ""),
              (e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef")),
            e
          );
        case F:
          return (
            (t = e.displayName || null),
            t !== null ? t : W(e.type) || "Memo"
          );
        case K:
          ((t = e._payload), (e = e._init));
          try {
            return W(e(t));
          } catch {}
      }
    return null;
  }
  var fe = Array.isArray,
    O = i.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
    G = c.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
    Q = { pending: !1, data: null, method: null, action: null },
    se = [],
    y = -1;
  function q(e) {
    return { current: e };
  }
  function J(e) {
    0 > y || ((e.current = se[y]), (se[y] = null), y--);
  }
  function P(e, t) {
    (y++, (se[y] = e.current), (e.current = t));
  }
  var ae = q(null),
    ce = q(null),
    le = q(null),
    ze = q(null);
  function Te(e, t) {
    switch ((P(le, t), P(ce, e), P(ae, null), t.nodeType)) {
      case 9:
      case 11:
        e = (e = t.documentElement) && (e = e.namespaceURI) ? w0(e) : 0;
        break;
      default:
        if (((e = t.tagName), (t = t.namespaceURI)))
          ((t = w0(t)), (e = S0(t, e)));
        else
          switch (e) {
            case "svg":
              e = 1;
              break;
            case "math":
              e = 2;
              break;
            default:
              e = 0;
          }
    }
    (J(ae), P(ae, e));
  }
  function Ae() {
    (J(ae), J(ce), J(le));
  }
  function Nl(e) {
    e.memoizedState !== null && P(ze, e);
    var t = ae.current,
      l = S0(t, e.type);
    t !== l && (P(ce, e), P(ae, l));
  }
  function zt(e) {
    (ce.current === e && (J(ae), J(ce)),
      ze.current === e && (J(ze), (ms._currentValue = Q)));
  }
  var Xt = Object.prototype.hasOwnProperty,
    Et = a.unstable_scheduleCallback,
    wl = a.unstable_cancelCallback,
    jb = a.unstable_shouldYield,
    Nb = a.unstable_requestPaint,
    Qt = a.unstable_now,
    wb = a.unstable_getCurrentPriorityLevel,
    ld = a.unstable_ImmediatePriority,
    ad = a.unstable_UserBlockingPriority,
    zs = a.unstable_NormalPriority,
    Sb = a.unstable_LowPriority,
    nd = a.unstable_IdlePriority,
    Eb = a.log,
    Tb = a.unstable_setDisableYieldValue,
    Nn = null,
    mt = null;
  function Sl(e) {
    if (
      (typeof Eb == "function" && Tb(e),
      mt && typeof mt.setStrictMode == "function")
    )
      try {
        mt.setStrictMode(Nn, e);
      } catch {}
  }
  var xt = Math.clz32 ? Math.clz32 : Ob,
    Ab = Math.log,
    Cb = Math.LN2;
  function Ob(e) {
    return ((e >>>= 0), e === 0 ? 32 : (31 - ((Ab(e) / Cb) | 0)) | 0);
  }
  var Us = 256,
    Hs = 4194304;
  function la(e) {
    var t = e & 42;
    if (t !== 0) return t;
    switch (e & -e) {
      case 1:
        return 1;
      case 2:
        return 2;
      case 4:
        return 4;
      case 8:
        return 8;
      case 16:
        return 16;
      case 32:
        return 32;
      case 64:
        return 64;
      case 128:
        return 128;
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return e & 4194048;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        return e & 62914560;
      case 67108864:
        return 67108864;
      case 134217728:
        return 134217728;
      case 268435456:
        return 268435456;
      case 536870912:
        return 536870912;
      case 1073741824:
        return 0;
      default:
        return e;
    }
  }
  function Ls(e, t, l) {
    var n = e.pendingLanes;
    if (n === 0) return 0;
    var r = 0,
      u = e.suspendedLanes,
      m = e.pingedLanes;
    e = e.warmLanes;
    var g = n & 134217727;
    return (
      g !== 0
        ? ((n = g & ~u),
          n !== 0
            ? (r = la(n))
            : ((m &= g),
              m !== 0
                ? (r = la(m))
                : l || ((l = g & ~e), l !== 0 && (r = la(l)))))
        : ((g = n & ~u),
          g !== 0
            ? (r = la(g))
            : m !== 0
              ? (r = la(m))
              : l || ((l = n & ~e), l !== 0 && (r = la(l)))),
      r === 0
        ? 0
        : t !== 0 &&
            t !== r &&
            (t & u) === 0 &&
            ((u = r & -r),
            (l = t & -t),
            u >= l || (u === 32 && (l & 4194048) !== 0))
          ? t
          : r
    );
  }
  function wn(e, t) {
    return (e.pendingLanes & ~(e.suspendedLanes & ~e.pingedLanes) & t) === 0;
  }
  function Rb(e, t) {
    switch (e) {
      case 1:
      case 2:
      case 4:
      case 8:
      case 64:
        return t + 250;
      case 16:
      case 32:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return t + 5e3;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        return -1;
      case 67108864:
      case 134217728:
      case 268435456:
      case 536870912:
      case 1073741824:
        return -1;
      default:
        return -1;
    }
  }
  function sd() {
    var e = Us;
    return ((Us <<= 1), (Us & 4194048) === 0 && (Us = 256), e);
  }
  function id() {
    var e = Hs;
    return ((Hs <<= 1), (Hs & 62914560) === 0 && (Hs = 4194304), e);
  }
  function zr(e) {
    for (var t = [], l = 0; 31 > l; l++) t.push(e);
    return t;
  }
  function Sn(e, t) {
    ((e.pendingLanes |= t),
      t !== 268435456 &&
        ((e.suspendedLanes = 0), (e.pingedLanes = 0), (e.warmLanes = 0)));
  }
  function Mb(e, t, l, n, r, u) {
    var m = e.pendingLanes;
    ((e.pendingLanes = l),
      (e.suspendedLanes = 0),
      (e.pingedLanes = 0),
      (e.warmLanes = 0),
      (e.expiredLanes &= l),
      (e.entangledLanes &= l),
      (e.errorRecoveryDisabledLanes &= l),
      (e.shellSuspendCounter = 0));
    var g = e.entanglements,
      N = e.expirationTimes,
      M = e.hiddenUpdates;
    for (l = m & ~l; 0 < l; ) {
      var U = 31 - xt(l),
        L = 1 << U;
      ((g[U] = 0), (N[U] = -1));
      var D = M[U];
      if (D !== null)
        for (M[U] = null, U = 0; U < D.length; U++) {
          var z = D[U];
          z !== null && (z.lane &= -536870913);
        }
      l &= ~L;
    }
    (n !== 0 && rd(e, n, 0),
      u !== 0 && r === 0 && e.tag !== 0 && (e.suspendedLanes |= u & ~(m & ~t)));
  }
  function rd(e, t, l) {
    ((e.pendingLanes |= t), (e.suspendedLanes &= ~t));
    var n = 31 - xt(t);
    ((e.entangledLanes |= t),
      (e.entanglements[n] = e.entanglements[n] | 1073741824 | (l & 4194090)));
  }
  function cd(e, t) {
    var l = (e.entangledLanes |= t);
    for (e = e.entanglements; l; ) {
      var n = 31 - xt(l),
        r = 1 << n;
      ((r & t) | (e[n] & t) && (e[n] |= t), (l &= ~r));
    }
  }
  function Ur(e) {
    switch (e) {
      case 2:
        e = 1;
        break;
      case 8:
        e = 4;
        break;
      case 32:
        e = 16;
        break;
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        e = 128;
        break;
      case 268435456:
        e = 134217728;
        break;
      default:
        e = 0;
    }
    return e;
  }
  function Hr(e) {
    return (
      (e &= -e),
      2 < e ? (8 < e ? ((e & 134217727) !== 0 ? 32 : 268435456) : 8) : 2
    );
  }
  function od() {
    var e = G.p;
    return e !== 0 ? e : ((e = window.event), e === void 0 ? 32 : V0(e.type));
  }
  function _b(e, t) {
    var l = G.p;
    try {
      return ((G.p = e), t());
    } finally {
      G.p = l;
    }
  }
  var El = Math.random().toString(36).slice(2),
    at = "__reactFiber$" + El,
    ct = "__reactProps$" + El,
    Ta = "__reactContainer$" + El,
    Lr = "__reactEvents$" + El,
    kb = "__reactListeners$" + El,
    Db = "__reactHandles$" + El,
    ud = "__reactResources$" + El,
    En = "__reactMarker$" + El;
  function qr(e) {
    (delete e[at], delete e[ct], delete e[Lr], delete e[kb], delete e[Db]);
  }
  function Aa(e) {
    var t = e[at];
    if (t) return t;
    for (var l = e.parentNode; l; ) {
      if ((t = l[Ta] || l[at])) {
        if (
          ((l = t.alternate),
          t.child !== null || (l !== null && l.child !== null))
        )
          for (e = C0(e); e !== null; ) {
            if ((l = e[at])) return l;
            e = C0(e);
          }
        return t;
      }
      ((e = l), (l = e.parentNode));
    }
    return null;
  }
  function Ca(e) {
    if ((e = e[at] || e[Ta])) {
      var t = e.tag;
      if (t === 5 || t === 6 || t === 13 || t === 26 || t === 27 || t === 3)
        return e;
    }
    return null;
  }
  function Tn(e) {
    var t = e.tag;
    if (t === 5 || t === 26 || t === 27 || t === 6) return e.stateNode;
    throw Error(o(33));
  }
  function Oa(e) {
    var t = e[ud];
    return (
      t ||
        (t = e[ud] =
          { hoistableStyles: new Map(), hoistableScripts: new Map() }),
      t
    );
  }
  function Je(e) {
    e[En] = !0;
  }
  var dd = new Set(),
    fd = {};
  function aa(e, t) {
    (Ra(e, t), Ra(e + "Capture", t));
  }
  function Ra(e, t) {
    for (fd[e] = t, e = 0; e < t.length; e++) dd.add(t[e]);
  }
  var zb = RegExp(
      "^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$",
    ),
    hd = {},
    md = {};
  function Ub(e) {
    return Xt.call(md, e)
      ? !0
      : Xt.call(hd, e)
        ? !1
        : zb.test(e)
          ? (md[e] = !0)
          : ((hd[e] = !0), !1);
  }
  function qs(e, t, l) {
    if (Ub(t))
      if (l === null) e.removeAttribute(t);
      else {
        switch (typeof l) {
          case "undefined":
          case "function":
          case "symbol":
            e.removeAttribute(t);
            return;
          case "boolean":
            var n = t.toLowerCase().slice(0, 5);
            if (n !== "data-" && n !== "aria-") {
              e.removeAttribute(t);
              return;
            }
        }
        e.setAttribute(t, "" + l);
      }
  }
  function Bs(e, t, l) {
    if (l === null) e.removeAttribute(t);
    else {
      switch (typeof l) {
        case "undefined":
        case "function":
        case "symbol":
        case "boolean":
          e.removeAttribute(t);
          return;
      }
      e.setAttribute(t, "" + l);
    }
  }
  function el(e, t, l, n) {
    if (n === null) e.removeAttribute(l);
    else {
      switch (typeof n) {
        case "undefined":
        case "function":
        case "symbol":
        case "boolean":
          e.removeAttribute(l);
          return;
      }
      e.setAttributeNS(t, l, "" + n);
    }
  }
  var Br, xd;
  function Ma(e) {
    if (Br === void 0)
      try {
        throw Error();
      } catch (l) {
        var t = l.stack.trim().match(/\n( *(at )?)/);
        ((Br = (t && t[1]) || ""),
          (xd =
            -1 <
            l.stack.indexOf(`
    at`)
              ? " (<anonymous>)"
              : -1 < l.stack.indexOf("@")
                ? "@unknown:0:0"
                : ""));
      }
    return (
      `
` +
      Br +
      e +
      xd
    );
  }
  var Gr = !1;
  function Yr(e, t) {
    if (!e || Gr) return "";
    Gr = !0;
    var l = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
      var n = {
        DetermineComponentFrameRoot: function () {
          try {
            if (t) {
              var L = function () {
                throw Error();
              };
              if (
                (Object.defineProperty(L.prototype, "props", {
                  set: function () {
                    throw Error();
                  },
                }),
                typeof Reflect == "object" && Reflect.construct)
              ) {
                try {
                  Reflect.construct(L, []);
                } catch (z) {
                  var D = z;
                }
                Reflect.construct(e, [], L);
              } else {
                try {
                  L.call();
                } catch (z) {
                  D = z;
                }
                e.call(L.prototype);
              }
            } else {
              try {
                throw Error();
              } catch (z) {
                D = z;
              }
              (L = e()) &&
                typeof L.catch == "function" &&
                L.catch(function () {});
            }
          } catch (z) {
            if (z && D && typeof z.stack == "string") return [z.stack, D.stack];
          }
          return [null, null];
        },
      };
      n.DetermineComponentFrameRoot.displayName = "DetermineComponentFrameRoot";
      var r = Object.getOwnPropertyDescriptor(
        n.DetermineComponentFrameRoot,
        "name",
      );
      r &&
        r.configurable &&
        Object.defineProperty(n.DetermineComponentFrameRoot, "name", {
          value: "DetermineComponentFrameRoot",
        });
      var u = n.DetermineComponentFrameRoot(),
        m = u[0],
        g = u[1];
      if (m && g) {
        var N = m.split(`
`),
          M = g.split(`
`);
        for (
          r = n = 0;
          n < N.length && !N[n].includes("DetermineComponentFrameRoot");
        )
          n++;
        for (; r < M.length && !M[r].includes("DetermineComponentFrameRoot"); )
          r++;
        if (n === N.length || r === M.length)
          for (
            n = N.length - 1, r = M.length - 1;
            1 <= n && 0 <= r && N[n] !== M[r];
          )
            r--;
        for (; 1 <= n && 0 <= r; n--, r--)
          if (N[n] !== M[r]) {
            if (n !== 1 || r !== 1)
              do
                if ((n--, r--, 0 > r || N[n] !== M[r])) {
                  var U =
                    `
` + N[n].replace(" at new ", " at ");
                  return (
                    e.displayName &&
                      U.includes("<anonymous>") &&
                      (U = U.replace("<anonymous>", e.displayName)),
                    U
                  );
                }
              while (1 <= n && 0 <= r);
            break;
          }
      }
    } finally {
      ((Gr = !1), (Error.prepareStackTrace = l));
    }
    return (l = e ? e.displayName || e.name : "") ? Ma(l) : "";
  }
  function Hb(e) {
    switch (e.tag) {
      case 26:
      case 27:
      case 5:
        return Ma(e.type);
      case 16:
        return Ma("Lazy");
      case 13:
        return Ma("Suspense");
      case 19:
        return Ma("SuspenseList");
      case 0:
      case 15:
        return Yr(e.type, !1);
      case 11:
        return Yr(e.type.render, !1);
      case 1:
        return Yr(e.type, !0);
      case 31:
        return Ma("Activity");
      default:
        return "";
    }
  }
  function pd(e) {
    try {
      var t = "";
      do ((t += Hb(e)), (e = e.return));
      while (e);
      return t;
    } catch (l) {
      return (
        `
Error generating stack: ` +
        l.message +
        `
` +
        l.stack
      );
    }
  }
  function Tt(e) {
    switch (typeof e) {
      case "bigint":
      case "boolean":
      case "number":
      case "string":
      case "undefined":
        return e;
      case "object":
        return e;
      default:
        return "";
    }
  }
  function bd(e) {
    var t = e.type;
    return (
      (e = e.nodeName) &&
      e.toLowerCase() === "input" &&
      (t === "checkbox" || t === "radio")
    );
  }
  function Lb(e) {
    var t = bd(e) ? "checked" : "value",
      l = Object.getOwnPropertyDescriptor(e.constructor.prototype, t),
      n = "" + e[t];
    if (
      !e.hasOwnProperty(t) &&
      typeof l < "u" &&
      typeof l.get == "function" &&
      typeof l.set == "function"
    ) {
      var r = l.get,
        u = l.set;
      return (
        Object.defineProperty(e, t, {
          configurable: !0,
          get: function () {
            return r.call(this);
          },
          set: function (m) {
            ((n = "" + m), u.call(this, m));
          },
        }),
        Object.defineProperty(e, t, { enumerable: l.enumerable }),
        {
          getValue: function () {
            return n;
          },
          setValue: function (m) {
            n = "" + m;
          },
          stopTracking: function () {
            ((e._valueTracker = null), delete e[t]);
          },
        }
      );
    }
  }
  function Gs(e) {
    e._valueTracker || (e._valueTracker = Lb(e));
  }
  function gd(e) {
    if (!e) return !1;
    var t = e._valueTracker;
    if (!t) return !0;
    var l = t.getValue(),
      n = "";
    return (
      e && (n = bd(e) ? (e.checked ? "true" : "false") : e.value),
      (e = n),
      e !== l ? (t.setValue(e), !0) : !1
    );
  }
  function Ys(e) {
    if (
      ((e = e || (typeof document < "u" ? document : void 0)), typeof e > "u")
    )
      return null;
    try {
      return e.activeElement || e.body;
    } catch {
      return e.body;
    }
  }
  var qb = /[\n"\\]/g;
  function At(e) {
    return e.replace(qb, function (t) {
      return "\\" + t.charCodeAt(0).toString(16) + " ";
    });
  }
  function Vr(e, t, l, n, r, u, m, g) {
    ((e.name = ""),
      m != null &&
      typeof m != "function" &&
      typeof m != "symbol" &&
      typeof m != "boolean"
        ? (e.type = m)
        : e.removeAttribute("type"),
      t != null
        ? m === "number"
          ? ((t === 0 && e.value === "") || e.value != t) &&
            (e.value = "" + Tt(t))
          : e.value !== "" + Tt(t) && (e.value = "" + Tt(t))
        : (m !== "submit" && m !== "reset") || e.removeAttribute("value"),
      t != null
        ? Xr(e, m, Tt(t))
        : l != null
          ? Xr(e, m, Tt(l))
          : n != null && e.removeAttribute("value"),
      r == null && u != null && (e.defaultChecked = !!u),
      r != null &&
        (e.checked = r && typeof r != "function" && typeof r != "symbol"),
      g != null &&
      typeof g != "function" &&
      typeof g != "symbol" &&
      typeof g != "boolean"
        ? (e.name = "" + Tt(g))
        : e.removeAttribute("name"));
  }
  function vd(e, t, l, n, r, u, m, g) {
    if (
      (u != null &&
        typeof u != "function" &&
        typeof u != "symbol" &&
        typeof u != "boolean" &&
        (e.type = u),
      t != null || l != null)
    ) {
      if (!((u !== "submit" && u !== "reset") || t != null)) return;
      ((l = l != null ? "" + Tt(l) : ""),
        (t = t != null ? "" + Tt(t) : l),
        g || t === e.value || (e.value = t),
        (e.defaultValue = t));
    }
    ((n = n ?? r),
      (n = typeof n != "function" && typeof n != "symbol" && !!n),
      (e.checked = g ? e.checked : !!n),
      (e.defaultChecked = !!n),
      m != null &&
        typeof m != "function" &&
        typeof m != "symbol" &&
        typeof m != "boolean" &&
        (e.name = m));
  }
  function Xr(e, t, l) {
    (t === "number" && Ys(e.ownerDocument) === e) ||
      e.defaultValue === "" + l ||
      (e.defaultValue = "" + l);
  }
  function _a(e, t, l, n) {
    if (((e = e.options), t)) {
      t = {};
      for (var r = 0; r < l.length; r++) t["$" + l[r]] = !0;
      for (l = 0; l < e.length; l++)
        ((r = t.hasOwnProperty("$" + e[l].value)),
          e[l].selected !== r && (e[l].selected = r),
          r && n && (e[l].defaultSelected = !0));
    } else {
      for (l = "" + Tt(l), t = null, r = 0; r < e.length; r++) {
        if (e[r].value === l) {
          ((e[r].selected = !0), n && (e[r].defaultSelected = !0));
          return;
        }
        t !== null || e[r].disabled || (t = e[r]);
      }
      t !== null && (t.selected = !0);
    }
  }
  function yd(e, t, l) {
    if (
      t != null &&
      ((t = "" + Tt(t)), t !== e.value && (e.value = t), l == null)
    ) {
      e.defaultValue !== t && (e.defaultValue = t);
      return;
    }
    e.defaultValue = l != null ? "" + Tt(l) : "";
  }
  function jd(e, t, l, n) {
    if (t == null) {
      if (n != null) {
        if (l != null) throw Error(o(92));
        if (fe(n)) {
          if (1 < n.length) throw Error(o(93));
          n = n[0];
        }
        l = n;
      }
      (l == null && (l = ""), (t = l));
    }
    ((l = Tt(t)),
      (e.defaultValue = l),
      (n = e.textContent),
      n === l && n !== "" && n !== null && (e.value = n));
  }
  function ka(e, t) {
    if (t) {
      var l = e.firstChild;
      if (l && l === e.lastChild && l.nodeType === 3) {
        l.nodeValue = t;
        return;
      }
    }
    e.textContent = t;
  }
  var Bb = new Set(
    "animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(
      " ",
    ),
  );
  function Nd(e, t, l) {
    var n = t.indexOf("--") === 0;
    l == null || typeof l == "boolean" || l === ""
      ? n
        ? e.setProperty(t, "")
        : t === "float"
          ? (e.cssFloat = "")
          : (e[t] = "")
      : n
        ? e.setProperty(t, l)
        : typeof l != "number" || l === 0 || Bb.has(t)
          ? t === "float"
            ? (e.cssFloat = l)
            : (e[t] = ("" + l).trim())
          : (e[t] = l + "px");
  }
  function wd(e, t, l) {
    if (t != null && typeof t != "object") throw Error(o(62));
    if (((e = e.style), l != null)) {
      for (var n in l)
        !l.hasOwnProperty(n) ||
          (t != null && t.hasOwnProperty(n)) ||
          (n.indexOf("--") === 0
            ? e.setProperty(n, "")
            : n === "float"
              ? (e.cssFloat = "")
              : (e[n] = ""));
      for (var r in t)
        ((n = t[r]), t.hasOwnProperty(r) && l[r] !== n && Nd(e, r, n));
    } else for (var u in t) t.hasOwnProperty(u) && Nd(e, u, t[u]);
  }
  function Qr(e) {
    if (e.indexOf("-") === -1) return !1;
    switch (e) {
      case "annotation-xml":
      case "color-profile":
      case "font-face":
      case "font-face-src":
      case "font-face-uri":
      case "font-face-format":
      case "font-face-name":
      case "missing-glyph":
        return !1;
      default:
        return !0;
    }
  }
  var Gb = new Map([
      ["acceptCharset", "accept-charset"],
      ["htmlFor", "for"],
      ["httpEquiv", "http-equiv"],
      ["crossOrigin", "crossorigin"],
      ["accentHeight", "accent-height"],
      ["alignmentBaseline", "alignment-baseline"],
      ["arabicForm", "arabic-form"],
      ["baselineShift", "baseline-shift"],
      ["capHeight", "cap-height"],
      ["clipPath", "clip-path"],
      ["clipRule", "clip-rule"],
      ["colorInterpolation", "color-interpolation"],
      ["colorInterpolationFilters", "color-interpolation-filters"],
      ["colorProfile", "color-profile"],
      ["colorRendering", "color-rendering"],
      ["dominantBaseline", "dominant-baseline"],
      ["enableBackground", "enable-background"],
      ["fillOpacity", "fill-opacity"],
      ["fillRule", "fill-rule"],
      ["floodColor", "flood-color"],
      ["floodOpacity", "flood-opacity"],
      ["fontFamily", "font-family"],
      ["fontSize", "font-size"],
      ["fontSizeAdjust", "font-size-adjust"],
      ["fontStretch", "font-stretch"],
      ["fontStyle", "font-style"],
      ["fontVariant", "font-variant"],
      ["fontWeight", "font-weight"],
      ["glyphName", "glyph-name"],
      ["glyphOrientationHorizontal", "glyph-orientation-horizontal"],
      ["glyphOrientationVertical", "glyph-orientation-vertical"],
      ["horizAdvX", "horiz-adv-x"],
      ["horizOriginX", "horiz-origin-x"],
      ["imageRendering", "image-rendering"],
      ["letterSpacing", "letter-spacing"],
      ["lightingColor", "lighting-color"],
      ["markerEnd", "marker-end"],
      ["markerMid", "marker-mid"],
      ["markerStart", "marker-start"],
      ["overlinePosition", "overline-position"],
      ["overlineThickness", "overline-thickness"],
      ["paintOrder", "paint-order"],
      ["panose-1", "panose-1"],
      ["pointerEvents", "pointer-events"],
      ["renderingIntent", "rendering-intent"],
      ["shapeRendering", "shape-rendering"],
      ["stopColor", "stop-color"],
      ["stopOpacity", "stop-opacity"],
      ["strikethroughPosition", "strikethrough-position"],
      ["strikethroughThickness", "strikethrough-thickness"],
      ["strokeDasharray", "stroke-dasharray"],
      ["strokeDashoffset", "stroke-dashoffset"],
      ["strokeLinecap", "stroke-linecap"],
      ["strokeLinejoin", "stroke-linejoin"],
      ["strokeMiterlimit", "stroke-miterlimit"],
      ["strokeOpacity", "stroke-opacity"],
      ["strokeWidth", "stroke-width"],
      ["textAnchor", "text-anchor"],
      ["textDecoration", "text-decoration"],
      ["textRendering", "text-rendering"],
      ["transformOrigin", "transform-origin"],
      ["underlinePosition", "underline-position"],
      ["underlineThickness", "underline-thickness"],
      ["unicodeBidi", "unicode-bidi"],
      ["unicodeRange", "unicode-range"],
      ["unitsPerEm", "units-per-em"],
      ["vAlphabetic", "v-alphabetic"],
      ["vHanging", "v-hanging"],
      ["vIdeographic", "v-ideographic"],
      ["vMathematical", "v-mathematical"],
      ["vectorEffect", "vector-effect"],
      ["vertAdvY", "vert-adv-y"],
      ["vertOriginX", "vert-origin-x"],
      ["vertOriginY", "vert-origin-y"],
      ["wordSpacing", "word-spacing"],
      ["writingMode", "writing-mode"],
      ["xmlnsXlink", "xmlns:xlink"],
      ["xHeight", "x-height"],
    ]),
    Yb =
      /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;
  function Vs(e) {
    return Yb.test("" + e)
      ? "javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')"
      : e;
  }
  var Zr = null;
  function Kr(e) {
    return (
      (e = e.target || e.srcElement || window),
      e.correspondingUseElement && (e = e.correspondingUseElement),
      e.nodeType === 3 ? e.parentNode : e
    );
  }
  var Da = null,
    za = null;
  function Sd(e) {
    var t = Ca(e);
    if (t && (e = t.stateNode)) {
      var l = e[ct] || null;
      e: switch (((e = t.stateNode), t.type)) {
        case "input":
          if (
            (Vr(
              e,
              l.value,
              l.defaultValue,
              l.defaultValue,
              l.checked,
              l.defaultChecked,
              l.type,
              l.name,
            ),
            (t = l.name),
            l.type === "radio" && t != null)
          ) {
            for (l = e; l.parentNode; ) l = l.parentNode;
            for (
              l = l.querySelectorAll(
                'input[name="' + At("" + t) + '"][type="radio"]',
              ),
                t = 0;
              t < l.length;
              t++
            ) {
              var n = l[t];
              if (n !== e && n.form === e.form) {
                var r = n[ct] || null;
                if (!r) throw Error(o(90));
                Vr(
                  n,
                  r.value,
                  r.defaultValue,
                  r.defaultValue,
                  r.checked,
                  r.defaultChecked,
                  r.type,
                  r.name,
                );
              }
            }
            for (t = 0; t < l.length; t++)
              ((n = l[t]), n.form === e.form && gd(n));
          }
          break e;
        case "textarea":
          yd(e, l.value, l.defaultValue);
          break e;
        case "select":
          ((t = l.value), t != null && _a(e, !!l.multiple, t, !1));
      }
    }
  }
  var Pr = !1;
  function Ed(e, t, l) {
    if (Pr) return e(t, l);
    Pr = !0;
    try {
      var n = e(t);
      return n;
    } finally {
      if (
        ((Pr = !1),
        (Da !== null || za !== null) &&
          (Ci(), Da && ((t = Da), (e = za), (za = Da = null), Sd(t), e)))
      )
        for (t = 0; t < e.length; t++) Sd(e[t]);
    }
  }
  function An(e, t) {
    var l = e.stateNode;
    if (l === null) return null;
    var n = l[ct] || null;
    if (n === null) return null;
    l = n[t];
    e: switch (t) {
      case "onClick":
      case "onClickCapture":
      case "onDoubleClick":
      case "onDoubleClickCapture":
      case "onMouseDown":
      case "onMouseDownCapture":
      case "onMouseMove":
      case "onMouseMoveCapture":
      case "onMouseUp":
      case "onMouseUpCapture":
      case "onMouseEnter":
        ((n = !n.disabled) ||
          ((e = e.type),
          (n = !(
            e === "button" ||
            e === "input" ||
            e === "select" ||
            e === "textarea"
          ))),
          (e = !n));
        break e;
      default:
        e = !1;
    }
    if (e) return null;
    if (l && typeof l != "function") throw Error(o(231, t, typeof l));
    return l;
  }
  var tl = !(
      typeof window > "u" ||
      typeof window.document > "u" ||
      typeof window.document.createElement > "u"
    ),
    $r = !1;
  if (tl)
    try {
      var Cn = {};
      (Object.defineProperty(Cn, "passive", {
        get: function () {
          $r = !0;
        },
      }),
        window.addEventListener("test", Cn, Cn),
        window.removeEventListener("test", Cn, Cn));
    } catch {
      $r = !1;
    }
  var Tl = null,
    Jr = null,
    Xs = null;
  function Td() {
    if (Xs) return Xs;
    var e,
      t = Jr,
      l = t.length,
      n,
      r = "value" in Tl ? Tl.value : Tl.textContent,
      u = r.length;
    for (e = 0; e < l && t[e] === r[e]; e++);
    var m = l - e;
    for (n = 1; n <= m && t[l - n] === r[u - n]; n++);
    return (Xs = r.slice(e, 1 < n ? 1 - n : void 0));
  }
  function Qs(e) {
    var t = e.keyCode;
    return (
      "charCode" in e
        ? ((e = e.charCode), e === 0 && t === 13 && (e = 13))
        : (e = t),
      e === 10 && (e = 13),
      32 <= e || e === 13 ? e : 0
    );
  }
  function Zs() {
    return !0;
  }
  function Ad() {
    return !1;
  }
  function ot(e) {
    function t(l, n, r, u, m) {
      ((this._reactName = l),
        (this._targetInst = r),
        (this.type = n),
        (this.nativeEvent = u),
        (this.target = m),
        (this.currentTarget = null));
      for (var g in e)
        e.hasOwnProperty(g) && ((l = e[g]), (this[g] = l ? l(u) : u[g]));
      return (
        (this.isDefaultPrevented = (
          u.defaultPrevented != null ? u.defaultPrevented : u.returnValue === !1
        )
          ? Zs
          : Ad),
        (this.isPropagationStopped = Ad),
        this
      );
    }
    return (
      v(t.prototype, {
        preventDefault: function () {
          this.defaultPrevented = !0;
          var l = this.nativeEvent;
          l &&
            (l.preventDefault
              ? l.preventDefault()
              : typeof l.returnValue != "unknown" && (l.returnValue = !1),
            (this.isDefaultPrevented = Zs));
        },
        stopPropagation: function () {
          var l = this.nativeEvent;
          l &&
            (l.stopPropagation
              ? l.stopPropagation()
              : typeof l.cancelBubble != "unknown" && (l.cancelBubble = !0),
            (this.isPropagationStopped = Zs));
        },
        persist: function () {},
        isPersistent: Zs,
      }),
      t
    );
  }
  var na = {
      eventPhase: 0,
      bubbles: 0,
      cancelable: 0,
      timeStamp: function (e) {
        return e.timeStamp || Date.now();
      },
      defaultPrevented: 0,
      isTrusted: 0,
    },
    Ks = ot(na),
    On = v({}, na, { view: 0, detail: 0 }),
    Vb = ot(On),
    Fr,
    Wr,
    Rn,
    Ps = v({}, On, {
      screenX: 0,
      screenY: 0,
      clientX: 0,
      clientY: 0,
      pageX: 0,
      pageY: 0,
      ctrlKey: 0,
      shiftKey: 0,
      altKey: 0,
      metaKey: 0,
      getModifierState: ec,
      button: 0,
      buttons: 0,
      relatedTarget: function (e) {
        return e.relatedTarget === void 0
          ? e.fromElement === e.srcElement
            ? e.toElement
            : e.fromElement
          : e.relatedTarget;
      },
      movementX: function (e) {
        return "movementX" in e
          ? e.movementX
          : (e !== Rn &&
              (Rn && e.type === "mousemove"
                ? ((Fr = e.screenX - Rn.screenX), (Wr = e.screenY - Rn.screenY))
                : (Wr = Fr = 0),
              (Rn = e)),
            Fr);
      },
      movementY: function (e) {
        return "movementY" in e ? e.movementY : Wr;
      },
    }),
    Cd = ot(Ps),
    Xb = v({}, Ps, { dataTransfer: 0 }),
    Qb = ot(Xb),
    Zb = v({}, On, { relatedTarget: 0 }),
    Ir = ot(Zb),
    Kb = v({}, na, { animationName: 0, elapsedTime: 0, pseudoElement: 0 }),
    Pb = ot(Kb),
    $b = v({}, na, {
      clipboardData: function (e) {
        return "clipboardData" in e ? e.clipboardData : window.clipboardData;
      },
    }),
    Jb = ot($b),
    Fb = v({}, na, { data: 0 }),
    Od = ot(Fb),
    Wb = {
      Esc: "Escape",
      Spacebar: " ",
      Left: "ArrowLeft",
      Up: "ArrowUp",
      Right: "ArrowRight",
      Down: "ArrowDown",
      Del: "Delete",
      Win: "OS",
      Menu: "ContextMenu",
      Apps: "ContextMenu",
      Scroll: "ScrollLock",
      MozPrintableKey: "Unidentified",
    },
    Ib = {
      8: "Backspace",
      9: "Tab",
      12: "Clear",
      13: "Enter",
      16: "Shift",
      17: "Control",
      18: "Alt",
      19: "Pause",
      20: "CapsLock",
      27: "Escape",
      32: " ",
      33: "PageUp",
      34: "PageDown",
      35: "End",
      36: "Home",
      37: "ArrowLeft",
      38: "ArrowUp",
      39: "ArrowRight",
      40: "ArrowDown",
      45: "Insert",
      46: "Delete",
      112: "F1",
      113: "F2",
      114: "F3",
      115: "F4",
      116: "F5",
      117: "F6",
      118: "F7",
      119: "F8",
      120: "F9",
      121: "F10",
      122: "F11",
      123: "F12",
      144: "NumLock",
      145: "ScrollLock",
      224: "Meta",
    },
    eg = {
      Alt: "altKey",
      Control: "ctrlKey",
      Meta: "metaKey",
      Shift: "shiftKey",
    };
  function tg(e) {
    var t = this.nativeEvent;
    return t.getModifierState
      ? t.getModifierState(e)
      : (e = eg[e])
        ? !!t[e]
        : !1;
  }
  function ec() {
    return tg;
  }
  var lg = v({}, On, {
      key: function (e) {
        if (e.key) {
          var t = Wb[e.key] || e.key;
          if (t !== "Unidentified") return t;
        }
        return e.type === "keypress"
          ? ((e = Qs(e)), e === 13 ? "Enter" : String.fromCharCode(e))
          : e.type === "keydown" || e.type === "keyup"
            ? Ib[e.keyCode] || "Unidentified"
            : "";
      },
      code: 0,
      location: 0,
      ctrlKey: 0,
      shiftKey: 0,
      altKey: 0,
      metaKey: 0,
      repeat: 0,
      locale: 0,
      getModifierState: ec,
      charCode: function (e) {
        return e.type === "keypress" ? Qs(e) : 0;
      },
      keyCode: function (e) {
        return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
      },
      which: function (e) {
        return e.type === "keypress"
          ? Qs(e)
          : e.type === "keydown" || e.type === "keyup"
            ? e.keyCode
            : 0;
      },
    }),
    ag = ot(lg),
    ng = v({}, Ps, {
      pointerId: 0,
      width: 0,
      height: 0,
      pressure: 0,
      tangentialPressure: 0,
      tiltX: 0,
      tiltY: 0,
      twist: 0,
      pointerType: 0,
      isPrimary: 0,
    }),
    Rd = ot(ng),
    sg = v({}, On, {
      touches: 0,
      targetTouches: 0,
      changedTouches: 0,
      altKey: 0,
      metaKey: 0,
      ctrlKey: 0,
      shiftKey: 0,
      getModifierState: ec,
    }),
    ig = ot(sg),
    rg = v({}, na, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 }),
    cg = ot(rg),
    og = v({}, Ps, {
      deltaX: function (e) {
        return "deltaX" in e
          ? e.deltaX
          : "wheelDeltaX" in e
            ? -e.wheelDeltaX
            : 0;
      },
      deltaY: function (e) {
        return "deltaY" in e
          ? e.deltaY
          : "wheelDeltaY" in e
            ? -e.wheelDeltaY
            : "wheelDelta" in e
              ? -e.wheelDelta
              : 0;
      },
      deltaZ: 0,
      deltaMode: 0,
    }),
    ug = ot(og),
    dg = v({}, na, { newState: 0, oldState: 0 }),
    fg = ot(dg),
    hg = [9, 13, 27, 32],
    tc = tl && "CompositionEvent" in window,
    Mn = null;
  tl && "documentMode" in document && (Mn = document.documentMode);
  var mg = tl && "TextEvent" in window && !Mn,
    Md = tl && (!tc || (Mn && 8 < Mn && 11 >= Mn)),
    _d = " ",
    kd = !1;
  function Dd(e, t) {
    switch (e) {
      case "keyup":
        return hg.indexOf(t.keyCode) !== -1;
      case "keydown":
        return t.keyCode !== 229;
      case "keypress":
      case "mousedown":
      case "focusout":
        return !0;
      default:
        return !1;
    }
  }
  function zd(e) {
    return (
      (e = e.detail),
      typeof e == "object" && "data" in e ? e.data : null
    );
  }
  var Ua = !1;
  function xg(e, t) {
    switch (e) {
      case "compositionend":
        return zd(t);
      case "keypress":
        return t.which !== 32 ? null : ((kd = !0), _d);
      case "textInput":
        return ((e = t.data), e === _d && kd ? null : e);
      default:
        return null;
    }
  }
  function pg(e, t) {
    if (Ua)
      return e === "compositionend" || (!tc && Dd(e, t))
        ? ((e = Td()), (Xs = Jr = Tl = null), (Ua = !1), e)
        : null;
    switch (e) {
      case "paste":
        return null;
      case "keypress":
        if (!(t.ctrlKey || t.altKey || t.metaKey) || (t.ctrlKey && t.altKey)) {
          if (t.char && 1 < t.char.length) return t.char;
          if (t.which) return String.fromCharCode(t.which);
        }
        return null;
      case "compositionend":
        return Md && t.locale !== "ko" ? null : t.data;
      default:
        return null;
    }
  }
  var bg = {
    color: !0,
    date: !0,
    datetime: !0,
    "datetime-local": !0,
    email: !0,
    month: !0,
    number: !0,
    password: !0,
    range: !0,
    search: !0,
    tel: !0,
    text: !0,
    time: !0,
    url: !0,
    week: !0,
  };
  function Ud(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t === "input" ? !!bg[e.type] : t === "textarea";
  }
  function Hd(e, t, l, n) {
    (Da ? (za ? za.push(n) : (za = [n])) : (Da = n),
      (t = Di(t, "onChange")),
      0 < t.length &&
        ((l = new Ks("onChange", "change", null, l, n)),
        e.push({ event: l, listeners: t })));
  }
  var _n = null,
    kn = null;
  function gg(e) {
    g0(e, 0);
  }
  function $s(e) {
    var t = Tn(e);
    if (gd(t)) return e;
  }
  function Ld(e, t) {
    if (e === "change") return t;
  }
  var qd = !1;
  if (tl) {
    var lc;
    if (tl) {
      var ac = "oninput" in document;
      if (!ac) {
        var Bd = document.createElement("div");
        (Bd.setAttribute("oninput", "return;"),
          (ac = typeof Bd.oninput == "function"));
      }
      lc = ac;
    } else lc = !1;
    qd = lc && (!document.documentMode || 9 < document.documentMode);
  }
  function Gd() {
    _n && (_n.detachEvent("onpropertychange", Yd), (kn = _n = null));
  }
  function Yd(e) {
    if (e.propertyName === "value" && $s(kn)) {
      var t = [];
      (Hd(t, kn, e, Kr(e)), Ed(gg, t));
    }
  }
  function vg(e, t, l) {
    e === "focusin"
      ? (Gd(), (_n = t), (kn = l), _n.attachEvent("onpropertychange", Yd))
      : e === "focusout" && Gd();
  }
  function yg(e) {
    if (e === "selectionchange" || e === "keyup" || e === "keydown")
      return $s(kn);
  }
  function jg(e, t) {
    if (e === "click") return $s(t);
  }
  function Ng(e, t) {
    if (e === "input" || e === "change") return $s(t);
  }
  function wg(e, t) {
    return (e === t && (e !== 0 || 1 / e === 1 / t)) || (e !== e && t !== t);
  }
  var pt = typeof Object.is == "function" ? Object.is : wg;
  function Dn(e, t) {
    if (pt(e, t)) return !0;
    if (
      typeof e != "object" ||
      e === null ||
      typeof t != "object" ||
      t === null
    )
      return !1;
    var l = Object.keys(e),
      n = Object.keys(t);
    if (l.length !== n.length) return !1;
    for (n = 0; n < l.length; n++) {
      var r = l[n];
      if (!Xt.call(t, r) || !pt(e[r], t[r])) return !1;
    }
    return !0;
  }
  function Vd(e) {
    for (; e && e.firstChild; ) e = e.firstChild;
    return e;
  }
  function Xd(e, t) {
    var l = Vd(e);
    e = 0;
    for (var n; l; ) {
      if (l.nodeType === 3) {
        if (((n = e + l.textContent.length), e <= t && n >= t))
          return { node: l, offset: t - e };
        e = n;
      }
      e: {
        for (; l; ) {
          if (l.nextSibling) {
            l = l.nextSibling;
            break e;
          }
          l = l.parentNode;
        }
        l = void 0;
      }
      l = Vd(l);
    }
  }
  function Qd(e, t) {
    return e && t
      ? e === t
        ? !0
        : e && e.nodeType === 3
          ? !1
          : t && t.nodeType === 3
            ? Qd(e, t.parentNode)
            : "contains" in e
              ? e.contains(t)
              : e.compareDocumentPosition
                ? !!(e.compareDocumentPosition(t) & 16)
                : !1
      : !1;
  }
  function Zd(e) {
    e =
      e != null &&
      e.ownerDocument != null &&
      e.ownerDocument.defaultView != null
        ? e.ownerDocument.defaultView
        : window;
    for (var t = Ys(e.document); t instanceof e.HTMLIFrameElement; ) {
      try {
        var l = typeof t.contentWindow.location.href == "string";
      } catch {
        l = !1;
      }
      if (l) e = t.contentWindow;
      else break;
      t = Ys(e.document);
    }
    return t;
  }
  function nc(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return (
      t &&
      ((t === "input" &&
        (e.type === "text" ||
          e.type === "search" ||
          e.type === "tel" ||
          e.type === "url" ||
          e.type === "password")) ||
        t === "textarea" ||
        e.contentEditable === "true")
    );
  }
  var Sg = tl && "documentMode" in document && 11 >= document.documentMode,
    Ha = null,
    sc = null,
    zn = null,
    ic = !1;
  function Kd(e, t, l) {
    var n =
      l.window === l ? l.document : l.nodeType === 9 ? l : l.ownerDocument;
    ic ||
      Ha == null ||
      Ha !== Ys(n) ||
      ((n = Ha),
      "selectionStart" in n && nc(n)
        ? (n = { start: n.selectionStart, end: n.selectionEnd })
        : ((n = (
            (n.ownerDocument && n.ownerDocument.defaultView) ||
            window
          ).getSelection()),
          (n = {
            anchorNode: n.anchorNode,
            anchorOffset: n.anchorOffset,
            focusNode: n.focusNode,
            focusOffset: n.focusOffset,
          })),
      (zn && Dn(zn, n)) ||
        ((zn = n),
        (n = Di(sc, "onSelect")),
        0 < n.length &&
          ((t = new Ks("onSelect", "select", null, t, l)),
          e.push({ event: t, listeners: n }),
          (t.target = Ha))));
  }
  function sa(e, t) {
    var l = {};
    return (
      (l[e.toLowerCase()] = t.toLowerCase()),
      (l["Webkit" + e] = "webkit" + t),
      (l["Moz" + e] = "moz" + t),
      l
    );
  }
  var La = {
      animationend: sa("Animation", "AnimationEnd"),
      animationiteration: sa("Animation", "AnimationIteration"),
      animationstart: sa("Animation", "AnimationStart"),
      transitionrun: sa("Transition", "TransitionRun"),
      transitionstart: sa("Transition", "TransitionStart"),
      transitioncancel: sa("Transition", "TransitionCancel"),
      transitionend: sa("Transition", "TransitionEnd"),
    },
    rc = {},
    Pd = {};
  tl &&
    ((Pd = document.createElement("div").style),
    "AnimationEvent" in window ||
      (delete La.animationend.animation,
      delete La.animationiteration.animation,
      delete La.animationstart.animation),
    "TransitionEvent" in window || delete La.transitionend.transition);
  function ia(e) {
    if (rc[e]) return rc[e];
    if (!La[e]) return e;
    var t = La[e],
      l;
    for (l in t) if (t.hasOwnProperty(l) && l in Pd) return (rc[e] = t[l]);
    return e;
  }
  var $d = ia("animationend"),
    Jd = ia("animationiteration"),
    Fd = ia("animationstart"),
    Eg = ia("transitionrun"),
    Tg = ia("transitionstart"),
    Ag = ia("transitioncancel"),
    Wd = ia("transitionend"),
    Id = new Map(),
    cc =
      "abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(
        " ",
      );
  cc.push("scrollEnd");
  function Ut(e, t) {
    (Id.set(e, t), aa(t, [e]));
  }
  var ef = new WeakMap();
  function Ct(e, t) {
    if (typeof e == "object" && e !== null) {
      var l = ef.get(e);
      return l !== void 0
        ? l
        : ((t = { value: e, source: t, stack: pd(t) }), ef.set(e, t), t);
    }
    return { value: e, source: t, stack: pd(t) };
  }
  var Ot = [],
    qa = 0,
    oc = 0;
  function Js() {
    for (var e = qa, t = (oc = qa = 0); t < e; ) {
      var l = Ot[t];
      Ot[t++] = null;
      var n = Ot[t];
      Ot[t++] = null;
      var r = Ot[t];
      Ot[t++] = null;
      var u = Ot[t];
      if (((Ot[t++] = null), n !== null && r !== null)) {
        var m = n.pending;
        (m === null ? (r.next = r) : ((r.next = m.next), (m.next = r)),
          (n.pending = r));
      }
      u !== 0 && tf(l, r, u);
    }
  }
  function Fs(e, t, l, n) {
    ((Ot[qa++] = e),
      (Ot[qa++] = t),
      (Ot[qa++] = l),
      (Ot[qa++] = n),
      (oc |= n),
      (e.lanes |= n),
      (e = e.alternate),
      e !== null && (e.lanes |= n));
  }
  function uc(e, t, l, n) {
    return (Fs(e, t, l, n), Ws(e));
  }
  function Ba(e, t) {
    return (Fs(e, null, null, t), Ws(e));
  }
  function tf(e, t, l) {
    e.lanes |= l;
    var n = e.alternate;
    n !== null && (n.lanes |= l);
    for (var r = !1, u = e.return; u !== null; )
      ((u.childLanes |= l),
        (n = u.alternate),
        n !== null && (n.childLanes |= l),
        u.tag === 22 &&
          ((e = u.stateNode), e === null || e._visibility & 1 || (r = !0)),
        (e = u),
        (u = u.return));
    return e.tag === 3
      ? ((u = e.stateNode),
        r &&
          t !== null &&
          ((r = 31 - xt(l)),
          (e = u.hiddenUpdates),
          (n = e[r]),
          n === null ? (e[r] = [t]) : n.push(t),
          (t.lane = l | 536870912)),
        u)
      : null;
  }
  function Ws(e) {
    if (50 < is) throw ((is = 0), (bo = null), Error(o(185)));
    for (var t = e.return; t !== null; ) ((e = t), (t = e.return));
    return e.tag === 3 ? e.stateNode : null;
  }
  var Ga = {};
  function Cg(e, t, l, n) {
    ((this.tag = e),
      (this.key = l),
      (this.sibling =
        this.child =
        this.return =
        this.stateNode =
        this.type =
        this.elementType =
          null),
      (this.index = 0),
      (this.refCleanup = this.ref = null),
      (this.pendingProps = t),
      (this.dependencies =
        this.memoizedState =
        this.updateQueue =
        this.memoizedProps =
          null),
      (this.mode = n),
      (this.subtreeFlags = this.flags = 0),
      (this.deletions = null),
      (this.childLanes = this.lanes = 0),
      (this.alternate = null));
  }
  function bt(e, t, l, n) {
    return new Cg(e, t, l, n);
  }
  function dc(e) {
    return ((e = e.prototype), !(!e || !e.isReactComponent));
  }
  function ll(e, t) {
    var l = e.alternate;
    return (
      l === null
        ? ((l = bt(e.tag, t, e.key, e.mode)),
          (l.elementType = e.elementType),
          (l.type = e.type),
          (l.stateNode = e.stateNode),
          (l.alternate = e),
          (e.alternate = l))
        : ((l.pendingProps = t),
          (l.type = e.type),
          (l.flags = 0),
          (l.subtreeFlags = 0),
          (l.deletions = null)),
      (l.flags = e.flags & 65011712),
      (l.childLanes = e.childLanes),
      (l.lanes = e.lanes),
      (l.child = e.child),
      (l.memoizedProps = e.memoizedProps),
      (l.memoizedState = e.memoizedState),
      (l.updateQueue = e.updateQueue),
      (t = e.dependencies),
      (l.dependencies =
        t === null ? null : { lanes: t.lanes, firstContext: t.firstContext }),
      (l.sibling = e.sibling),
      (l.index = e.index),
      (l.ref = e.ref),
      (l.refCleanup = e.refCleanup),
      l
    );
  }
  function lf(e, t) {
    e.flags &= 65011714;
    var l = e.alternate;
    return (
      l === null
        ? ((e.childLanes = 0),
          (e.lanes = t),
          (e.child = null),
          (e.subtreeFlags = 0),
          (e.memoizedProps = null),
          (e.memoizedState = null),
          (e.updateQueue = null),
          (e.dependencies = null),
          (e.stateNode = null))
        : ((e.childLanes = l.childLanes),
          (e.lanes = l.lanes),
          (e.child = l.child),
          (e.subtreeFlags = 0),
          (e.deletions = null),
          (e.memoizedProps = l.memoizedProps),
          (e.memoizedState = l.memoizedState),
          (e.updateQueue = l.updateQueue),
          (e.type = l.type),
          (t = l.dependencies),
          (e.dependencies =
            t === null
              ? null
              : { lanes: t.lanes, firstContext: t.firstContext })),
      e
    );
  }
  function Is(e, t, l, n, r, u) {
    var m = 0;
    if (((n = e), typeof e == "function")) dc(e) && (m = 1);
    else if (typeof e == "string")
      m = Rv(e, l, ae.current)
        ? 26
        : e === "html" || e === "head" || e === "body"
          ? 27
          : 5;
    else
      e: switch (e) {
        case ue:
          return (
            (e = bt(31, l, t, r)),
            (e.elementType = ue),
            (e.lanes = u),
            e
          );
        case k:
          return ra(l.children, r, u, t);
        case A:
          ((m = 8), (r |= 24));
          break;
        case _:
          return (
            (e = bt(12, l, t, r | 2)),
            (e.elementType = _),
            (e.lanes = u),
            e
          );
        case X:
          return ((e = bt(13, l, t, r)), (e.elementType = X), (e.lanes = u), e);
        case $:
          return ((e = bt(19, l, t, r)), (e.elementType = $), (e.lanes = u), e);
        default:
          if (typeof e == "object" && e !== null)
            switch (e.$$typeof) {
              case B:
              case Y:
                m = 10;
                break e;
              case V:
                m = 9;
                break e;
              case Z:
                m = 11;
                break e;
              case F:
                m = 14;
                break e;
              case K:
                ((m = 16), (n = null));
                break e;
            }
          ((m = 29),
            (l = Error(o(130, e === null ? "null" : typeof e, ""))),
            (n = null));
      }
    return (
      (t = bt(m, l, t, r)),
      (t.elementType = e),
      (t.type = n),
      (t.lanes = u),
      t
    );
  }
  function ra(e, t, l, n) {
    return ((e = bt(7, e, n, t)), (e.lanes = l), e);
  }
  function fc(e, t, l) {
    return ((e = bt(6, e, null, t)), (e.lanes = l), e);
  }
  function hc(e, t, l) {
    return (
      (t = bt(4, e.children !== null ? e.children : [], e.key, t)),
      (t.lanes = l),
      (t.stateNode = {
        containerInfo: e.containerInfo,
        pendingChildren: null,
        implementation: e.implementation,
      }),
      t
    );
  }
  var Ya = [],
    Va = 0,
    ei = null,
    ti = 0,
    Rt = [],
    Mt = 0,
    ca = null,
    al = 1,
    nl = "";
  function oa(e, t) {
    ((Ya[Va++] = ti), (Ya[Va++] = ei), (ei = e), (ti = t));
  }
  function af(e, t, l) {
    ((Rt[Mt++] = al), (Rt[Mt++] = nl), (Rt[Mt++] = ca), (ca = e));
    var n = al;
    e = nl;
    var r = 32 - xt(n) - 1;
    ((n &= ~(1 << r)), (l += 1));
    var u = 32 - xt(t) + r;
    if (30 < u) {
      var m = r - (r % 5);
      ((u = (n & ((1 << m) - 1)).toString(32)),
        (n >>= m),
        (r -= m),
        (al = (1 << (32 - xt(t) + r)) | (l << r) | n),
        (nl = u + e));
    } else ((al = (1 << u) | (l << r) | n), (nl = e));
  }
  function mc(e) {
    e.return !== null && (oa(e, 1), af(e, 1, 0));
  }
  function xc(e) {
    for (; e === ei; )
      ((ei = Ya[--Va]), (Ya[Va] = null), (ti = Ya[--Va]), (Ya[Va] = null));
    for (; e === ca; )
      ((ca = Rt[--Mt]),
        (Rt[Mt] = null),
        (nl = Rt[--Mt]),
        (Rt[Mt] = null),
        (al = Rt[--Mt]),
        (Rt[Mt] = null));
  }
  var it = null,
    Le = null,
    Ee = !1,
    ua = null,
    Zt = !1,
    pc = Error(o(519));
  function da(e) {
    var t = Error(o(418, ""));
    throw (Ln(Ct(t, e)), pc);
  }
  function nf(e) {
    var t = e.stateNode,
      l = e.type,
      n = e.memoizedProps;
    switch (((t[at] = e), (t[ct] = n), l)) {
      case "dialog":
        (ye("cancel", t), ye("close", t));
        break;
      case "iframe":
      case "object":
      case "embed":
        ye("load", t);
        break;
      case "video":
      case "audio":
        for (l = 0; l < cs.length; l++) ye(cs[l], t);
        break;
      case "source":
        ye("error", t);
        break;
      case "img":
      case "image":
      case "link":
        (ye("error", t), ye("load", t));
        break;
      case "details":
        ye("toggle", t);
        break;
      case "input":
        (ye("invalid", t),
          vd(
            t,
            n.value,
            n.defaultValue,
            n.checked,
            n.defaultChecked,
            n.type,
            n.name,
            !0,
          ),
          Gs(t));
        break;
      case "select":
        ye("invalid", t);
        break;
      case "textarea":
        (ye("invalid", t), jd(t, n.value, n.defaultValue, n.children), Gs(t));
    }
    ((l = n.children),
      (typeof l != "string" && typeof l != "number" && typeof l != "bigint") ||
      t.textContent === "" + l ||
      n.suppressHydrationWarning === !0 ||
      N0(t.textContent, l)
        ? (n.popover != null && (ye("beforetoggle", t), ye("toggle", t)),
          n.onScroll != null && ye("scroll", t),
          n.onScrollEnd != null && ye("scrollend", t),
          n.onClick != null && (t.onclick = zi),
          (t = !0))
        : (t = !1),
      t || da(e));
  }
  function sf(e) {
    for (it = e.return; it; )
      switch (it.tag) {
        case 5:
        case 13:
          Zt = !1;
          return;
        case 27:
        case 3:
          Zt = !0;
          return;
        default:
          it = it.return;
      }
  }
  function Un(e) {
    if (e !== it) return !1;
    if (!Ee) return (sf(e), (Ee = !0), !1);
    var t = e.tag,
      l;
    if (
      ((l = t !== 3 && t !== 27) &&
        ((l = t === 5) &&
          ((l = e.type),
          (l =
            !(l !== "form" && l !== "button") || ko(e.type, e.memoizedProps))),
        (l = !l)),
      l && Le && da(e),
      sf(e),
      t === 13)
    ) {
      if (((e = e.memoizedState), (e = e !== null ? e.dehydrated : null), !e))
        throw Error(o(317));
      e: {
        for (e = e.nextSibling, t = 0; e; ) {
          if (e.nodeType === 8)
            if (((l = e.data), l === "/$")) {
              if (t === 0) {
                Le = Lt(e.nextSibling);
                break e;
              }
              t--;
            } else (l !== "$" && l !== "$!" && l !== "$?") || t++;
          e = e.nextSibling;
        }
        Le = null;
      }
    } else
      t === 27
        ? ((t = Le), Yl(e.type) ? ((e = Ho), (Ho = null), (Le = e)) : (Le = t))
        : (Le = it ? Lt(e.stateNode.nextSibling) : null);
    return !0;
  }
  function Hn() {
    ((Le = it = null), (Ee = !1));
  }
  function rf() {
    var e = ua;
    return (
      e !== null &&
        (ft === null ? (ft = e) : ft.push.apply(ft, e), (ua = null)),
      e
    );
  }
  function Ln(e) {
    ua === null ? (ua = [e]) : ua.push(e);
  }
  var bc = q(null),
    fa = null,
    sl = null;
  function Al(e, t, l) {
    (P(bc, t._currentValue), (t._currentValue = l));
  }
  function il(e) {
    ((e._currentValue = bc.current), J(bc));
  }
  function gc(e, t, l) {
    for (; e !== null; ) {
      var n = e.alternate;
      if (
        ((e.childLanes & t) !== t
          ? ((e.childLanes |= t), n !== null && (n.childLanes |= t))
          : n !== null && (n.childLanes & t) !== t && (n.childLanes |= t),
        e === l)
      )
        break;
      e = e.return;
    }
  }
  function vc(e, t, l, n) {
    var r = e.child;
    for (r !== null && (r.return = e); r !== null; ) {
      var u = r.dependencies;
      if (u !== null) {
        var m = r.child;
        u = u.firstContext;
        e: for (; u !== null; ) {
          var g = u;
          u = r;
          for (var N = 0; N < t.length; N++)
            if (g.context === t[N]) {
              ((u.lanes |= l),
                (g = u.alternate),
                g !== null && (g.lanes |= l),
                gc(u.return, l, e),
                n || (m = null));
              break e;
            }
          u = g.next;
        }
      } else if (r.tag === 18) {
        if (((m = r.return), m === null)) throw Error(o(341));
        ((m.lanes |= l),
          (u = m.alternate),
          u !== null && (u.lanes |= l),
          gc(m, l, e),
          (m = null));
      } else m = r.child;
      if (m !== null) m.return = r;
      else
        for (m = r; m !== null; ) {
          if (m === e) {
            m = null;
            break;
          }
          if (((r = m.sibling), r !== null)) {
            ((r.return = m.return), (m = r));
            break;
          }
          m = m.return;
        }
      r = m;
    }
  }
  function qn(e, t, l, n) {
    e = null;
    for (var r = t, u = !1; r !== null; ) {
      if (!u) {
        if ((r.flags & 524288) !== 0) u = !0;
        else if ((r.flags & 262144) !== 0) break;
      }
      if (r.tag === 10) {
        var m = r.alternate;
        if (m === null) throw Error(o(387));
        if (((m = m.memoizedProps), m !== null)) {
          var g = r.type;
          pt(r.pendingProps.value, m.value) ||
            (e !== null ? e.push(g) : (e = [g]));
        }
      } else if (r === ze.current) {
        if (((m = r.alternate), m === null)) throw Error(o(387));
        m.memoizedState.memoizedState !== r.memoizedState.memoizedState &&
          (e !== null ? e.push(ms) : (e = [ms]));
      }
      r = r.return;
    }
    (e !== null && vc(t, e, l, n), (t.flags |= 262144));
  }
  function li(e) {
    for (e = e.firstContext; e !== null; ) {
      if (!pt(e.context._currentValue, e.memoizedValue)) return !0;
      e = e.next;
    }
    return !1;
  }
  function ha(e) {
    ((fa = e),
      (sl = null),
      (e = e.dependencies),
      e !== null && (e.firstContext = null));
  }
  function nt(e) {
    return cf(fa, e);
  }
  function ai(e, t) {
    return (fa === null && ha(e), cf(e, t));
  }
  function cf(e, t) {
    var l = t._currentValue;
    if (((t = { context: t, memoizedValue: l, next: null }), sl === null)) {
      if (e === null) throw Error(o(308));
      ((sl = t),
        (e.dependencies = { lanes: 0, firstContext: t }),
        (e.flags |= 524288));
    } else sl = sl.next = t;
    return l;
  }
  var Og =
      typeof AbortController < "u"
        ? AbortController
        : function () {
            var e = [],
              t = (this.signal = {
                aborted: !1,
                addEventListener: function (l, n) {
                  e.push(n);
                },
              });
            this.abort = function () {
              ((t.aborted = !0),
                e.forEach(function (l) {
                  return l();
                }));
            };
          },
    Rg = a.unstable_scheduleCallback,
    Mg = a.unstable_NormalPriority,
    Qe = {
      $$typeof: Y,
      Consumer: null,
      Provider: null,
      _currentValue: null,
      _currentValue2: null,
      _threadCount: 0,
    };
  function yc() {
    return { controller: new Og(), data: new Map(), refCount: 0 };
  }
  function Bn(e) {
    (e.refCount--,
      e.refCount === 0 &&
        Rg(Mg, function () {
          e.controller.abort();
        }));
  }
  var Gn = null,
    jc = 0,
    Xa = 0,
    Qa = null;
  function _g(e, t) {
    if (Gn === null) {
      var l = (Gn = []);
      ((jc = 0),
        (Xa = So()),
        (Qa = {
          status: "pending",
          value: void 0,
          then: function (n) {
            l.push(n);
          },
        }));
    }
    return (jc++, t.then(of, of), t);
  }
  function of() {
    if (--jc === 0 && Gn !== null) {
      Qa !== null && (Qa.status = "fulfilled");
      var e = Gn;
      ((Gn = null), (Xa = 0), (Qa = null));
      for (var t = 0; t < e.length; t++) (0, e[t])();
    }
  }
  function kg(e, t) {
    var l = [],
      n = {
        status: "pending",
        value: null,
        reason: null,
        then: function (r) {
          l.push(r);
        },
      };
    return (
      e.then(
        function () {
          ((n.status = "fulfilled"), (n.value = t));
          for (var r = 0; r < l.length; r++) (0, l[r])(t);
        },
        function (r) {
          for (n.status = "rejected", n.reason = r, r = 0; r < l.length; r++)
            (0, l[r])(void 0);
        },
      ),
      n
    );
  }
  var uf = O.S;
  O.S = function (e, t) {
    (typeof t == "object" &&
      t !== null &&
      typeof t.then == "function" &&
      _g(e, t),
      uf !== null && uf(e, t));
  };
  var ma = q(null);
  function Nc() {
    var e = ma.current;
    return e !== null ? e : De.pooledCache;
  }
  function ni(e, t) {
    t === null ? P(ma, ma.current) : P(ma, t.pool);
  }
  function df() {
    var e = Nc();
    return e === null ? null : { parent: Qe._currentValue, pool: e };
  }
  var Yn = Error(o(460)),
    ff = Error(o(474)),
    si = Error(o(542)),
    wc = { then: function () {} };
  function hf(e) {
    return ((e = e.status), e === "fulfilled" || e === "rejected");
  }
  function ii() {}
  function mf(e, t, l) {
    switch (
      ((l = e[l]),
      l === void 0 ? e.push(t) : l !== t && (t.then(ii, ii), (t = l)),
      t.status)
    ) {
      case "fulfilled":
        return t.value;
      case "rejected":
        throw ((e = t.reason), pf(e), e);
      default:
        if (typeof t.status == "string") t.then(ii, ii);
        else {
          if (((e = De), e !== null && 100 < e.shellSuspendCounter))
            throw Error(o(482));
          ((e = t),
            (e.status = "pending"),
            e.then(
              function (n) {
                if (t.status === "pending") {
                  var r = t;
                  ((r.status = "fulfilled"), (r.value = n));
                }
              },
              function (n) {
                if (t.status === "pending") {
                  var r = t;
                  ((r.status = "rejected"), (r.reason = n));
                }
              },
            ));
        }
        switch (t.status) {
          case "fulfilled":
            return t.value;
          case "rejected":
            throw ((e = t.reason), pf(e), e);
        }
        throw ((Vn = t), Yn);
    }
  }
  var Vn = null;
  function xf() {
    if (Vn === null) throw Error(o(459));
    var e = Vn;
    return ((Vn = null), e);
  }
  function pf(e) {
    if (e === Yn || e === si) throw Error(o(483));
  }
  var Cl = !1;
  function Sc(e) {
    e.updateQueue = {
      baseState: e.memoizedState,
      firstBaseUpdate: null,
      lastBaseUpdate: null,
      shared: { pending: null, lanes: 0, hiddenCallbacks: null },
      callbacks: null,
    };
  }
  function Ec(e, t) {
    ((e = e.updateQueue),
      t.updateQueue === e &&
        (t.updateQueue = {
          baseState: e.baseState,
          firstBaseUpdate: e.firstBaseUpdate,
          lastBaseUpdate: e.lastBaseUpdate,
          shared: e.shared,
          callbacks: null,
        }));
  }
  function Ol(e) {
    return { lane: e, tag: 0, payload: null, callback: null, next: null };
  }
  function Rl(e, t, l) {
    var n = e.updateQueue;
    if (n === null) return null;
    if (((n = n.shared), (Ce & 2) !== 0)) {
      var r = n.pending;
      return (
        r === null ? (t.next = t) : ((t.next = r.next), (r.next = t)),
        (n.pending = t),
        (t = Ws(e)),
        tf(e, null, l),
        t
      );
    }
    return (Fs(e, n, t, l), Ws(e));
  }
  function Xn(e, t, l) {
    if (
      ((t = t.updateQueue), t !== null && ((t = t.shared), (l & 4194048) !== 0))
    ) {
      var n = t.lanes;
      ((n &= e.pendingLanes), (l |= n), (t.lanes = l), cd(e, l));
    }
  }
  function Tc(e, t) {
    var l = e.updateQueue,
      n = e.alternate;
    if (n !== null && ((n = n.updateQueue), l === n)) {
      var r = null,
        u = null;
      if (((l = l.firstBaseUpdate), l !== null)) {
        do {
          var m = {
            lane: l.lane,
            tag: l.tag,
            payload: l.payload,
            callback: null,
            next: null,
          };
          (u === null ? (r = u = m) : (u = u.next = m), (l = l.next));
        } while (l !== null);
        u === null ? (r = u = t) : (u = u.next = t);
      } else r = u = t;
      ((l = {
        baseState: n.baseState,
        firstBaseUpdate: r,
        lastBaseUpdate: u,
        shared: n.shared,
        callbacks: n.callbacks,
      }),
        (e.updateQueue = l));
      return;
    }
    ((e = l.lastBaseUpdate),
      e === null ? (l.firstBaseUpdate = t) : (e.next = t),
      (l.lastBaseUpdate = t));
  }
  var Ac = !1;
  function Qn() {
    if (Ac) {
      var e = Qa;
      if (e !== null) throw e;
    }
  }
  function Zn(e, t, l, n) {
    Ac = !1;
    var r = e.updateQueue;
    Cl = !1;
    var u = r.firstBaseUpdate,
      m = r.lastBaseUpdate,
      g = r.shared.pending;
    if (g !== null) {
      r.shared.pending = null;
      var N = g,
        M = N.next;
      ((N.next = null), m === null ? (u = M) : (m.next = M), (m = N));
      var U = e.alternate;
      U !== null &&
        ((U = U.updateQueue),
        (g = U.lastBaseUpdate),
        g !== m &&
          (g === null ? (U.firstBaseUpdate = M) : (g.next = M),
          (U.lastBaseUpdate = N)));
    }
    if (u !== null) {
      var L = r.baseState;
      ((m = 0), (U = M = N = null), (g = u));
      do {
        var D = g.lane & -536870913,
          z = D !== g.lane;
        if (z ? (Ne & D) === D : (n & D) === D) {
          (D !== 0 && D === Xa && (Ac = !0),
            U !== null &&
              (U = U.next =
                {
                  lane: 0,
                  tag: g.tag,
                  payload: g.payload,
                  callback: null,
                  next: null,
                }));
          e: {
            var de = e,
              re = g;
            D = t;
            var _e = l;
            switch (re.tag) {
              case 1:
                if (((de = re.payload), typeof de == "function")) {
                  L = de.call(_e, L, D);
                  break e;
                }
                L = de;
                break e;
              case 3:
                de.flags = (de.flags & -65537) | 128;
              case 0:
                if (
                  ((de = re.payload),
                  (D = typeof de == "function" ? de.call(_e, L, D) : de),
                  D == null)
                )
                  break e;
                L = v({}, L, D);
                break e;
              case 2:
                Cl = !0;
            }
          }
          ((D = g.callback),
            D !== null &&
              ((e.flags |= 64),
              z && (e.flags |= 8192),
              (z = r.callbacks),
              z === null ? (r.callbacks = [D]) : z.push(D)));
        } else
          ((z = {
            lane: D,
            tag: g.tag,
            payload: g.payload,
            callback: g.callback,
            next: null,
          }),
            U === null ? ((M = U = z), (N = L)) : (U = U.next = z),
            (m |= D));
        if (((g = g.next), g === null)) {
          if (((g = r.shared.pending), g === null)) break;
          ((z = g),
            (g = z.next),
            (z.next = null),
            (r.lastBaseUpdate = z),
            (r.shared.pending = null));
        }
      } while (!0);
      (U === null && (N = L),
        (r.baseState = N),
        (r.firstBaseUpdate = M),
        (r.lastBaseUpdate = U),
        u === null && (r.shared.lanes = 0),
        (Ll |= m),
        (e.lanes = m),
        (e.memoizedState = L));
    }
  }
  function bf(e, t) {
    if (typeof e != "function") throw Error(o(191, e));
    e.call(t);
  }
  function gf(e, t) {
    var l = e.callbacks;
    if (l !== null)
      for (e.callbacks = null, e = 0; e < l.length; e++) bf(l[e], t);
  }
  var Za = q(null),
    ri = q(0);
  function vf(e, t) {
    ((e = hl), P(ri, e), P(Za, t), (hl = e | t.baseLanes));
  }
  function Cc() {
    (P(ri, hl), P(Za, Za.current));
  }
  function Oc() {
    ((hl = ri.current), J(Za), J(ri));
  }
  var Ml = 0,
    xe = null,
    Re = null,
    Ve = null,
    ci = !1,
    Ka = !1,
    xa = !1,
    oi = 0,
    Kn = 0,
    Pa = null,
    Dg = 0;
  function Be() {
    throw Error(o(321));
  }
  function Rc(e, t) {
    if (t === null) return !1;
    for (var l = 0; l < t.length && l < e.length; l++)
      if (!pt(e[l], t[l])) return !1;
    return !0;
  }
  function Mc(e, t, l, n, r, u) {
    return (
      (Ml = u),
      (xe = t),
      (t.memoizedState = null),
      (t.updateQueue = null),
      (t.lanes = 0),
      (O.H = e === null || e.memoizedState === null ? lh : ah),
      (xa = !1),
      (u = l(n, r)),
      (xa = !1),
      Ka && (u = jf(t, l, n, r)),
      yf(e),
      u
    );
  }
  function yf(e) {
    O.H = xi;
    var t = Re !== null && Re.next !== null;
    if (((Ml = 0), (Ve = Re = xe = null), (ci = !1), (Kn = 0), (Pa = null), t))
      throw Error(o(300));
    e === null ||
      Fe ||
      ((e = e.dependencies), e !== null && li(e) && (Fe = !0));
  }
  function jf(e, t, l, n) {
    xe = e;
    var r = 0;
    do {
      if ((Ka && (Pa = null), (Kn = 0), (Ka = !1), 25 <= r))
        throw Error(o(301));
      if (((r += 1), (Ve = Re = null), e.updateQueue != null)) {
        var u = e.updateQueue;
        ((u.lastEffect = null),
          (u.events = null),
          (u.stores = null),
          u.memoCache != null && (u.memoCache.index = 0));
      }
      ((O.H = Gg), (u = t(l, n)));
    } while (Ka);
    return u;
  }
  function zg() {
    var e = O.H,
      t = e.useState()[0];
    return (
      (t = typeof t.then == "function" ? Pn(t) : t),
      (e = e.useState()[0]),
      (Re !== null ? Re.memoizedState : null) !== e && (xe.flags |= 1024),
      t
    );
  }
  function _c() {
    var e = oi !== 0;
    return ((oi = 0), e);
  }
  function kc(e, t, l) {
    ((t.updateQueue = e.updateQueue), (t.flags &= -2053), (e.lanes &= ~l));
  }
  function Dc(e) {
    if (ci) {
      for (e = e.memoizedState; e !== null; ) {
        var t = e.queue;
        (t !== null && (t.pending = null), (e = e.next));
      }
      ci = !1;
    }
    ((Ml = 0), (Ve = Re = xe = null), (Ka = !1), (Kn = oi = 0), (Pa = null));
  }
  function ut() {
    var e = {
      memoizedState: null,
      baseState: null,
      baseQueue: null,
      queue: null,
      next: null,
    };
    return (Ve === null ? (xe.memoizedState = Ve = e) : (Ve = Ve.next = e), Ve);
  }
  function Xe() {
    if (Re === null) {
      var e = xe.alternate;
      e = e !== null ? e.memoizedState : null;
    } else e = Re.next;
    var t = Ve === null ? xe.memoizedState : Ve.next;
    if (t !== null) ((Ve = t), (Re = e));
    else {
      if (e === null)
        throw xe.alternate === null ? Error(o(467)) : Error(o(310));
      ((Re = e),
        (e = {
          memoizedState: Re.memoizedState,
          baseState: Re.baseState,
          baseQueue: Re.baseQueue,
          queue: Re.queue,
          next: null,
        }),
        Ve === null ? (xe.memoizedState = Ve = e) : (Ve = Ve.next = e));
    }
    return Ve;
  }
  function zc() {
    return { lastEffect: null, events: null, stores: null, memoCache: null };
  }
  function Pn(e) {
    var t = Kn;
    return (
      (Kn += 1),
      Pa === null && (Pa = []),
      (e = mf(Pa, e, t)),
      (t = xe),
      (Ve === null ? t.memoizedState : Ve.next) === null &&
        ((t = t.alternate),
        (O.H = t === null || t.memoizedState === null ? lh : ah)),
      e
    );
  }
  function ui(e) {
    if (e !== null && typeof e == "object") {
      if (typeof e.then == "function") return Pn(e);
      if (e.$$typeof === Y) return nt(e);
    }
    throw Error(o(438, String(e)));
  }
  function Uc(e) {
    var t = null,
      l = xe.updateQueue;
    if ((l !== null && (t = l.memoCache), t == null)) {
      var n = xe.alternate;
      n !== null &&
        ((n = n.updateQueue),
        n !== null &&
          ((n = n.memoCache),
          n != null &&
            (t = {
              data: n.data.map(function (r) {
                return r.slice();
              }),
              index: 0,
            })));
    }
    if (
      (t == null && (t = { data: [], index: 0 }),
      l === null && ((l = zc()), (xe.updateQueue = l)),
      (l.memoCache = t),
      (l = t.data[t.index]),
      l === void 0)
    )
      for (l = t.data[t.index] = Array(e), n = 0; n < e; n++) l[n] = ge;
    return (t.index++, l);
  }
  function rl(e, t) {
    return typeof t == "function" ? t(e) : t;
  }
  function di(e) {
    var t = Xe();
    return Hc(t, Re, e);
  }
  function Hc(e, t, l) {
    var n = e.queue;
    if (n === null) throw Error(o(311));
    n.lastRenderedReducer = l;
    var r = e.baseQueue,
      u = n.pending;
    if (u !== null) {
      if (r !== null) {
        var m = r.next;
        ((r.next = u.next), (u.next = m));
      }
      ((t.baseQueue = r = u), (n.pending = null));
    }
    if (((u = e.baseState), r === null)) e.memoizedState = u;
    else {
      t = r.next;
      var g = (m = null),
        N = null,
        M = t,
        U = !1;
      do {
        var L = M.lane & -536870913;
        if (L !== M.lane ? (Ne & L) === L : (Ml & L) === L) {
          var D = M.revertLane;
          if (D === 0)
            (N !== null &&
              (N = N.next =
                {
                  lane: 0,
                  revertLane: 0,
                  action: M.action,
                  hasEagerState: M.hasEagerState,
                  eagerState: M.eagerState,
                  next: null,
                }),
              L === Xa && (U = !0));
          else if ((Ml & D) === D) {
            ((M = M.next), D === Xa && (U = !0));
            continue;
          } else
            ((L = {
              lane: 0,
              revertLane: M.revertLane,
              action: M.action,
              hasEagerState: M.hasEagerState,
              eagerState: M.eagerState,
              next: null,
            }),
              N === null ? ((g = N = L), (m = u)) : (N = N.next = L),
              (xe.lanes |= D),
              (Ll |= D));
          ((L = M.action),
            xa && l(u, L),
            (u = M.hasEagerState ? M.eagerState : l(u, L)));
        } else
          ((D = {
            lane: L,
            revertLane: M.revertLane,
            action: M.action,
            hasEagerState: M.hasEagerState,
            eagerState: M.eagerState,
            next: null,
          }),
            N === null ? ((g = N = D), (m = u)) : (N = N.next = D),
            (xe.lanes |= L),
            (Ll |= L));
        M = M.next;
      } while (M !== null && M !== t);
      if (
        (N === null ? (m = u) : (N.next = g),
        !pt(u, e.memoizedState) && ((Fe = !0), U && ((l = Qa), l !== null)))
      )
        throw l;
      ((e.memoizedState = u),
        (e.baseState = m),
        (e.baseQueue = N),
        (n.lastRenderedState = u));
    }
    return (r === null && (n.lanes = 0), [e.memoizedState, n.dispatch]);
  }
  function Lc(e) {
    var t = Xe(),
      l = t.queue;
    if (l === null) throw Error(o(311));
    l.lastRenderedReducer = e;
    var n = l.dispatch,
      r = l.pending,
      u = t.memoizedState;
    if (r !== null) {
      l.pending = null;
      var m = (r = r.next);
      do ((u = e(u, m.action)), (m = m.next));
      while (m !== r);
      (pt(u, t.memoizedState) || (Fe = !0),
        (t.memoizedState = u),
        t.baseQueue === null && (t.baseState = u),
        (l.lastRenderedState = u));
    }
    return [u, n];
  }
  function Nf(e, t, l) {
    var n = xe,
      r = Xe(),
      u = Ee;
    if (u) {
      if (l === void 0) throw Error(o(407));
      l = l();
    } else l = t();
    var m = !pt((Re || r).memoizedState, l);
    (m && ((r.memoizedState = l), (Fe = !0)), (r = r.queue));
    var g = Ef.bind(null, n, r, e);
    if (
      ($n(2048, 8, g, [e]),
      r.getSnapshot !== t || m || (Ve !== null && Ve.memoizedState.tag & 1))
    ) {
      if (
        ((n.flags |= 2048),
        $a(9, fi(), Sf.bind(null, n, r, l, t), null),
        De === null)
      )
        throw Error(o(349));
      u || (Ml & 124) !== 0 || wf(n, t, l);
    }
    return l;
  }
  function wf(e, t, l) {
    ((e.flags |= 16384),
      (e = { getSnapshot: t, value: l }),
      (t = xe.updateQueue),
      t === null
        ? ((t = zc()), (xe.updateQueue = t), (t.stores = [e]))
        : ((l = t.stores), l === null ? (t.stores = [e]) : l.push(e)));
  }
  function Sf(e, t, l, n) {
    ((t.value = l), (t.getSnapshot = n), Tf(t) && Af(e));
  }
  function Ef(e, t, l) {
    return l(function () {
      Tf(t) && Af(e);
    });
  }
  function Tf(e) {
    var t = e.getSnapshot;
    e = e.value;
    try {
      var l = t();
      return !pt(e, l);
    } catch {
      return !0;
    }
  }
  function Af(e) {
    var t = Ba(e, 2);
    t !== null && Nt(t, e, 2);
  }
  function qc(e) {
    var t = ut();
    if (typeof e == "function") {
      var l = e;
      if (((e = l()), xa)) {
        Sl(!0);
        try {
          l();
        } finally {
          Sl(!1);
        }
      }
    }
    return (
      (t.memoizedState = t.baseState = e),
      (t.queue = {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: rl,
        lastRenderedState: e,
      }),
      t
    );
  }
  function Cf(e, t, l, n) {
    return ((e.baseState = l), Hc(e, Re, typeof n == "function" ? n : rl));
  }
  function Ug(e, t, l, n, r) {
    if (mi(e)) throw Error(o(485));
    if (((e = t.action), e !== null)) {
      var u = {
        payload: r,
        action: e,
        next: null,
        isTransition: !0,
        status: "pending",
        value: null,
        reason: null,
        listeners: [],
        then: function (m) {
          u.listeners.push(m);
        },
      };
      (O.T !== null ? l(!0) : (u.isTransition = !1),
        n(u),
        (l = t.pending),
        l === null
          ? ((u.next = t.pending = u), Of(t, u))
          : ((u.next = l.next), (t.pending = l.next = u)));
    }
  }
  function Of(e, t) {
    var l = t.action,
      n = t.payload,
      r = e.state;
    if (t.isTransition) {
      var u = O.T,
        m = {};
      O.T = m;
      try {
        var g = l(r, n),
          N = O.S;
        (N !== null && N(m, g), Rf(e, t, g));
      } catch (M) {
        Bc(e, t, M);
      } finally {
        O.T = u;
      }
    } else
      try {
        ((u = l(r, n)), Rf(e, t, u));
      } catch (M) {
        Bc(e, t, M);
      }
  }
  function Rf(e, t, l) {
    l !== null && typeof l == "object" && typeof l.then == "function"
      ? l.then(
          function (n) {
            Mf(e, t, n);
          },
          function (n) {
            return Bc(e, t, n);
          },
        )
      : Mf(e, t, l);
  }
  function Mf(e, t, l) {
    ((t.status = "fulfilled"),
      (t.value = l),
      _f(t),
      (e.state = l),
      (t = e.pending),
      t !== null &&
        ((l = t.next),
        l === t ? (e.pending = null) : ((l = l.next), (t.next = l), Of(e, l))));
  }
  function Bc(e, t, l) {
    var n = e.pending;
    if (((e.pending = null), n !== null)) {
      n = n.next;
      do ((t.status = "rejected"), (t.reason = l), _f(t), (t = t.next));
      while (t !== n);
    }
    e.action = null;
  }
  function _f(e) {
    e = e.listeners;
    for (var t = 0; t < e.length; t++) (0, e[t])();
  }
  function kf(e, t) {
    return t;
  }
  function Df(e, t) {
    if (Ee) {
      var l = De.formState;
      if (l !== null) {
        e: {
          var n = xe;
          if (Ee) {
            if (Le) {
              t: {
                for (var r = Le, u = Zt; r.nodeType !== 8; ) {
                  if (!u) {
                    r = null;
                    break t;
                  }
                  if (((r = Lt(r.nextSibling)), r === null)) {
                    r = null;
                    break t;
                  }
                }
                ((u = r.data), (r = u === "F!" || u === "F" ? r : null));
              }
              if (r) {
                ((Le = Lt(r.nextSibling)), (n = r.data === "F!"));
                break e;
              }
            }
            da(n);
          }
          n = !1;
        }
        n && (t = l[0]);
      }
    }
    return (
      (l = ut()),
      (l.memoizedState = l.baseState = t),
      (n = {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: kf,
        lastRenderedState: t,
      }),
      (l.queue = n),
      (l = If.bind(null, xe, n)),
      (n.dispatch = l),
      (n = qc(!1)),
      (u = Qc.bind(null, xe, !1, n.queue)),
      (n = ut()),
      (r = { state: t, dispatch: null, action: e, pending: null }),
      (n.queue = r),
      (l = Ug.bind(null, xe, r, u, l)),
      (r.dispatch = l),
      (n.memoizedState = e),
      [t, l, !1]
    );
  }
  function zf(e) {
    var t = Xe();
    return Uf(t, Re, e);
  }
  function Uf(e, t, l) {
    if (
      ((t = Hc(e, t, kf)[0]),
      (e = di(rl)[0]),
      typeof t == "object" && t !== null && typeof t.then == "function")
    )
      try {
        var n = Pn(t);
      } catch (m) {
        throw m === Yn ? si : m;
      }
    else n = t;
    t = Xe();
    var r = t.queue,
      u = r.dispatch;
    return (
      l !== t.memoizedState &&
        ((xe.flags |= 2048), $a(9, fi(), Hg.bind(null, r, l), null)),
      [n, u, e]
    );
  }
  function Hg(e, t) {
    e.action = t;
  }
  function Hf(e) {
    var t = Xe(),
      l = Re;
    if (l !== null) return Uf(t, l, e);
    (Xe(), (t = t.memoizedState), (l = Xe()));
    var n = l.queue.dispatch;
    return ((l.memoizedState = e), [t, n, !1]);
  }
  function $a(e, t, l, n) {
    return (
      (e = { tag: e, create: l, deps: n, inst: t, next: null }),
      (t = xe.updateQueue),
      t === null && ((t = zc()), (xe.updateQueue = t)),
      (l = t.lastEffect),
      l === null
        ? (t.lastEffect = e.next = e)
        : ((n = l.next), (l.next = e), (e.next = n), (t.lastEffect = e)),
      e
    );
  }
  function fi() {
    return { destroy: void 0, resource: void 0 };
  }
  function Lf() {
    return Xe().memoizedState;
  }
  function hi(e, t, l, n) {
    var r = ut();
    ((n = n === void 0 ? null : n),
      (xe.flags |= e),
      (r.memoizedState = $a(1 | t, fi(), l, n)));
  }
  function $n(e, t, l, n) {
    var r = Xe();
    n = n === void 0 ? null : n;
    var u = r.memoizedState.inst;
    Re !== null && n !== null && Rc(n, Re.memoizedState.deps)
      ? (r.memoizedState = $a(t, u, l, n))
      : ((xe.flags |= e), (r.memoizedState = $a(1 | t, u, l, n)));
  }
  function qf(e, t) {
    hi(8390656, 8, e, t);
  }
  function Bf(e, t) {
    $n(2048, 8, e, t);
  }
  function Gf(e, t) {
    return $n(4, 2, e, t);
  }
  function Yf(e, t) {
    return $n(4, 4, e, t);
  }
  function Vf(e, t) {
    if (typeof t == "function") {
      e = e();
      var l = t(e);
      return function () {
        typeof l == "function" ? l() : t(null);
      };
    }
    if (t != null)
      return (
        (e = e()),
        (t.current = e),
        function () {
          t.current = null;
        }
      );
  }
  function Xf(e, t, l) {
    ((l = l != null ? l.concat([e]) : null), $n(4, 4, Vf.bind(null, t, e), l));
  }
  function Gc() {}
  function Qf(e, t) {
    var l = Xe();
    t = t === void 0 ? null : t;
    var n = l.memoizedState;
    return t !== null && Rc(t, n[1]) ? n[0] : ((l.memoizedState = [e, t]), e);
  }
  function Zf(e, t) {
    var l = Xe();
    t = t === void 0 ? null : t;
    var n = l.memoizedState;
    if (t !== null && Rc(t, n[1])) return n[0];
    if (((n = e()), xa)) {
      Sl(!0);
      try {
        e();
      } finally {
        Sl(!1);
      }
    }
    return ((l.memoizedState = [n, t]), n);
  }
  function Yc(e, t, l) {
    return l === void 0 || (Ml & 1073741824) !== 0
      ? (e.memoizedState = t)
      : ((e.memoizedState = l), (e = $h()), (xe.lanes |= e), (Ll |= e), l);
  }
  function Kf(e, t, l, n) {
    return pt(l, t)
      ? l
      : Za.current !== null
        ? ((e = Yc(e, l, n)), pt(e, t) || (Fe = !0), e)
        : (Ml & 42) === 0
          ? ((Fe = !0), (e.memoizedState = l))
          : ((e = $h()), (xe.lanes |= e), (Ll |= e), t);
  }
  function Pf(e, t, l, n, r) {
    var u = G.p;
    G.p = u !== 0 && 8 > u ? u : 8;
    var m = O.T,
      g = {};
    ((O.T = g), Qc(e, !1, t, l));
    try {
      var N = r(),
        M = O.S;
      if (
        (M !== null && M(g, N),
        N !== null && typeof N == "object" && typeof N.then == "function")
      ) {
        var U = kg(N, n);
        Jn(e, t, U, jt(e));
      } else Jn(e, t, n, jt(e));
    } catch (L) {
      Jn(e, t, { then: function () {}, status: "rejected", reason: L }, jt());
    } finally {
      ((G.p = u), (O.T = m));
    }
  }
  function Lg() {}
  function Vc(e, t, l, n) {
    if (e.tag !== 5) throw Error(o(476));
    var r = $f(e).queue;
    Pf(
      e,
      r,
      t,
      Q,
      l === null
        ? Lg
        : function () {
            return (Jf(e), l(n));
          },
    );
  }
  function $f(e) {
    var t = e.memoizedState;
    if (t !== null) return t;
    t = {
      memoizedState: Q,
      baseState: Q,
      baseQueue: null,
      queue: {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: rl,
        lastRenderedState: Q,
      },
      next: null,
    };
    var l = {};
    return (
      (t.next = {
        memoizedState: l,
        baseState: l,
        baseQueue: null,
        queue: {
          pending: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: rl,
          lastRenderedState: l,
        },
        next: null,
      }),
      (e.memoizedState = t),
      (e = e.alternate),
      e !== null && (e.memoizedState = t),
      t
    );
  }
  function Jf(e) {
    var t = $f(e).next.queue;
    Jn(e, t, {}, jt());
  }
  function Xc() {
    return nt(ms);
  }
  function Ff() {
    return Xe().memoizedState;
  }
  function Wf() {
    return Xe().memoizedState;
  }
  function qg(e) {
    for (var t = e.return; t !== null; ) {
      switch (t.tag) {
        case 24:
        case 3:
          var l = jt();
          e = Ol(l);
          var n = Rl(t, e, l);
          (n !== null && (Nt(n, t, l), Xn(n, t, l)),
            (t = { cache: yc() }),
            (e.payload = t));
          return;
      }
      t = t.return;
    }
  }
  function Bg(e, t, l) {
    var n = jt();
    ((l = {
      lane: n,
      revertLane: 0,
      action: l,
      hasEagerState: !1,
      eagerState: null,
      next: null,
    }),
      mi(e)
        ? eh(t, l)
        : ((l = uc(e, t, l, n)), l !== null && (Nt(l, e, n), th(l, t, n))));
  }
  function If(e, t, l) {
    var n = jt();
    Jn(e, t, l, n);
  }
  function Jn(e, t, l, n) {
    var r = {
      lane: n,
      revertLane: 0,
      action: l,
      hasEagerState: !1,
      eagerState: null,
      next: null,
    };
    if (mi(e)) eh(t, r);
    else {
      var u = e.alternate;
      if (
        e.lanes === 0 &&
        (u === null || u.lanes === 0) &&
        ((u = t.lastRenderedReducer), u !== null)
      )
        try {
          var m = t.lastRenderedState,
            g = u(m, l);
          if (((r.hasEagerState = !0), (r.eagerState = g), pt(g, m)))
            return (Fs(e, t, r, 0), De === null && Js(), !1);
        } catch {}
      if (((l = uc(e, t, r, n)), l !== null))
        return (Nt(l, e, n), th(l, t, n), !0);
    }
    return !1;
  }
  function Qc(e, t, l, n) {
    if (
      ((n = {
        lane: 2,
        revertLane: So(),
        action: n,
        hasEagerState: !1,
        eagerState: null,
        next: null,
      }),
      mi(e))
    ) {
      if (t) throw Error(o(479));
    } else ((t = uc(e, l, n, 2)), t !== null && Nt(t, e, 2));
  }
  function mi(e) {
    var t = e.alternate;
    return e === xe || (t !== null && t === xe);
  }
  function eh(e, t) {
    Ka = ci = !0;
    var l = e.pending;
    (l === null ? (t.next = t) : ((t.next = l.next), (l.next = t)),
      (e.pending = t));
  }
  function th(e, t, l) {
    if ((l & 4194048) !== 0) {
      var n = t.lanes;
      ((n &= e.pendingLanes), (l |= n), (t.lanes = l), cd(e, l));
    }
  }
  var xi = {
      readContext: nt,
      use: ui,
      useCallback: Be,
      useContext: Be,
      useEffect: Be,
      useImperativeHandle: Be,
      useLayoutEffect: Be,
      useInsertionEffect: Be,
      useMemo: Be,
      useReducer: Be,
      useRef: Be,
      useState: Be,
      useDebugValue: Be,
      useDeferredValue: Be,
      useTransition: Be,
      useSyncExternalStore: Be,
      useId: Be,
      useHostTransitionStatus: Be,
      useFormState: Be,
      useActionState: Be,
      useOptimistic: Be,
      useMemoCache: Be,
      useCacheRefresh: Be,
    },
    lh = {
      readContext: nt,
      use: ui,
      useCallback: function (e, t) {
        return ((ut().memoizedState = [e, t === void 0 ? null : t]), e);
      },
      useContext: nt,
      useEffect: qf,
      useImperativeHandle: function (e, t, l) {
        ((l = l != null ? l.concat([e]) : null),
          hi(4194308, 4, Vf.bind(null, t, e), l));
      },
      useLayoutEffect: function (e, t) {
        return hi(4194308, 4, e, t);
      },
      useInsertionEffect: function (e, t) {
        hi(4, 2, e, t);
      },
      useMemo: function (e, t) {
        var l = ut();
        t = t === void 0 ? null : t;
        var n = e();
        if (xa) {
          Sl(!0);
          try {
            e();
          } finally {
            Sl(!1);
          }
        }
        return ((l.memoizedState = [n, t]), n);
      },
      useReducer: function (e, t, l) {
        var n = ut();
        if (l !== void 0) {
          var r = l(t);
          if (xa) {
            Sl(!0);
            try {
              l(t);
            } finally {
              Sl(!1);
            }
          }
        } else r = t;
        return (
          (n.memoizedState = n.baseState = r),
          (e = {
            pending: null,
            lanes: 0,
            dispatch: null,
            lastRenderedReducer: e,
            lastRenderedState: r,
          }),
          (n.queue = e),
          (e = e.dispatch = Bg.bind(null, xe, e)),
          [n.memoizedState, e]
        );
      },
      useRef: function (e) {
        var t = ut();
        return ((e = { current: e }), (t.memoizedState = e));
      },
      useState: function (e) {
        e = qc(e);
        var t = e.queue,
          l = If.bind(null, xe, t);
        return ((t.dispatch = l), [e.memoizedState, l]);
      },
      useDebugValue: Gc,
      useDeferredValue: function (e, t) {
        var l = ut();
        return Yc(l, e, t);
      },
      useTransition: function () {
        var e = qc(!1);
        return (
          (e = Pf.bind(null, xe, e.queue, !0, !1)),
          (ut().memoizedState = e),
          [!1, e]
        );
      },
      useSyncExternalStore: function (e, t, l) {
        var n = xe,
          r = ut();
        if (Ee) {
          if (l === void 0) throw Error(o(407));
          l = l();
        } else {
          if (((l = t()), De === null)) throw Error(o(349));
          (Ne & 124) !== 0 || wf(n, t, l);
        }
        r.memoizedState = l;
        var u = { value: l, getSnapshot: t };
        return (
          (r.queue = u),
          qf(Ef.bind(null, n, u, e), [e]),
          (n.flags |= 2048),
          $a(9, fi(), Sf.bind(null, n, u, l, t), null),
          l
        );
      },
      useId: function () {
        var e = ut(),
          t = De.identifierPrefix;
        if (Ee) {
          var l = nl,
            n = al;
          ((l = (n & ~(1 << (32 - xt(n) - 1))).toString(32) + l),
            (t = "«" + t + "R" + l),
            (l = oi++),
            0 < l && (t += "H" + l.toString(32)),
            (t += "»"));
        } else ((l = Dg++), (t = "«" + t + "r" + l.toString(32) + "»"));
        return (e.memoizedState = t);
      },
      useHostTransitionStatus: Xc,
      useFormState: Df,
      useActionState: Df,
      useOptimistic: function (e) {
        var t = ut();
        t.memoizedState = t.baseState = e;
        var l = {
          pending: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: null,
          lastRenderedState: null,
        };
        return (
          (t.queue = l),
          (t = Qc.bind(null, xe, !0, l)),
          (l.dispatch = t),
          [e, t]
        );
      },
      useMemoCache: Uc,
      useCacheRefresh: function () {
        return (ut().memoizedState = qg.bind(null, xe));
      },
    },
    ah = {
      readContext: nt,
      use: ui,
      useCallback: Qf,
      useContext: nt,
      useEffect: Bf,
      useImperativeHandle: Xf,
      useInsertionEffect: Gf,
      useLayoutEffect: Yf,
      useMemo: Zf,
      useReducer: di,
      useRef: Lf,
      useState: function () {
        return di(rl);
      },
      useDebugValue: Gc,
      useDeferredValue: function (e, t) {
        var l = Xe();
        return Kf(l, Re.memoizedState, e, t);
      },
      useTransition: function () {
        var e = di(rl)[0],
          t = Xe().memoizedState;
        return [typeof e == "boolean" ? e : Pn(e), t];
      },
      useSyncExternalStore: Nf,
      useId: Ff,
      useHostTransitionStatus: Xc,
      useFormState: zf,
      useActionState: zf,
      useOptimistic: function (e, t) {
        var l = Xe();
        return Cf(l, Re, e, t);
      },
      useMemoCache: Uc,
      useCacheRefresh: Wf,
    },
    Gg = {
      readContext: nt,
      use: ui,
      useCallback: Qf,
      useContext: nt,
      useEffect: Bf,
      useImperativeHandle: Xf,
      useInsertionEffect: Gf,
      useLayoutEffect: Yf,
      useMemo: Zf,
      useReducer: Lc,
      useRef: Lf,
      useState: function () {
        return Lc(rl);
      },
      useDebugValue: Gc,
      useDeferredValue: function (e, t) {
        var l = Xe();
        return Re === null ? Yc(l, e, t) : Kf(l, Re.memoizedState, e, t);
      },
      useTransition: function () {
        var e = Lc(rl)[0],
          t = Xe().memoizedState;
        return [typeof e == "boolean" ? e : Pn(e), t];
      },
      useSyncExternalStore: Nf,
      useId: Ff,
      useHostTransitionStatus: Xc,
      useFormState: Hf,
      useActionState: Hf,
      useOptimistic: function (e, t) {
        var l = Xe();
        return Re !== null
          ? Cf(l, Re, e, t)
          : ((l.baseState = e), [e, l.queue.dispatch]);
      },
      useMemoCache: Uc,
      useCacheRefresh: Wf,
    },
    Ja = null,
    Fn = 0;
  function pi(e) {
    var t = Fn;
    return ((Fn += 1), Ja === null && (Ja = []), mf(Ja, e, t));
  }
  function Wn(e, t) {
    ((t = t.props.ref), (e.ref = t !== void 0 ? t : null));
  }
  function bi(e, t) {
    throw t.$$typeof === w
      ? Error(o(525))
      : ((e = Object.prototype.toString.call(t)),
        Error(
          o(
            31,
            e === "[object Object]"
              ? "object with keys {" + Object.keys(t).join(", ") + "}"
              : e,
          ),
        ));
  }
  function nh(e) {
    var t = e._init;
    return t(e._payload);
  }
  function sh(e) {
    function t(T, S) {
      if (e) {
        var C = T.deletions;
        C === null ? ((T.deletions = [S]), (T.flags |= 16)) : C.push(S);
      }
    }
    function l(T, S) {
      if (!e) return null;
      for (; S !== null; ) (t(T, S), (S = S.sibling));
      return null;
    }
    function n(T) {
      for (var S = new Map(); T !== null; )
        (T.key !== null ? S.set(T.key, T) : S.set(T.index, T), (T = T.sibling));
      return S;
    }
    function r(T, S) {
      return ((T = ll(T, S)), (T.index = 0), (T.sibling = null), T);
    }
    function u(T, S, C) {
      return (
        (T.index = C),
        e
          ? ((C = T.alternate),
            C !== null
              ? ((C = C.index), C < S ? ((T.flags |= 67108866), S) : C)
              : ((T.flags |= 67108866), S))
          : ((T.flags |= 1048576), S)
      );
    }
    function m(T) {
      return (e && T.alternate === null && (T.flags |= 67108866), T);
    }
    function g(T, S, C, H) {
      return S === null || S.tag !== 6
        ? ((S = fc(C, T.mode, H)), (S.return = T), S)
        : ((S = r(S, C)), (S.return = T), S);
    }
    function N(T, S, C, H) {
      var I = C.type;
      return I === k
        ? U(T, S, C.props.children, H, C.key)
        : S !== null &&
            (S.elementType === I ||
              (typeof I == "object" &&
                I !== null &&
                I.$$typeof === K &&
                nh(I) === S.type))
          ? ((S = r(S, C.props)), Wn(S, C), (S.return = T), S)
          : ((S = Is(C.type, C.key, C.props, null, T.mode, H)),
            Wn(S, C),
            (S.return = T),
            S);
    }
    function M(T, S, C, H) {
      return S === null ||
        S.tag !== 4 ||
        S.stateNode.containerInfo !== C.containerInfo ||
        S.stateNode.implementation !== C.implementation
        ? ((S = hc(C, T.mode, H)), (S.return = T), S)
        : ((S = r(S, C.children || [])), (S.return = T), S);
    }
    function U(T, S, C, H, I) {
      return S === null || S.tag !== 7
        ? ((S = ra(C, T.mode, H, I)), (S.return = T), S)
        : ((S = r(S, C)), (S.return = T), S);
    }
    function L(T, S, C) {
      if (
        (typeof S == "string" && S !== "") ||
        typeof S == "number" ||
        typeof S == "bigint"
      )
        return ((S = fc("" + S, T.mode, C)), (S.return = T), S);
      if (typeof S == "object" && S !== null) {
        switch (S.$$typeof) {
          case E:
            return (
              (C = Is(S.type, S.key, S.props, null, T.mode, C)),
              Wn(C, S),
              (C.return = T),
              C
            );
          case R:
            return ((S = hc(S, T.mode, C)), (S.return = T), S);
          case K:
            var H = S._init;
            return ((S = H(S._payload)), L(T, S, C));
        }
        if (fe(S) || he(S))
          return ((S = ra(S, T.mode, C, null)), (S.return = T), S);
        if (typeof S.then == "function") return L(T, pi(S), C);
        if (S.$$typeof === Y) return L(T, ai(T, S), C);
        bi(T, S);
      }
      return null;
    }
    function D(T, S, C, H) {
      var I = S !== null ? S.key : null;
      if (
        (typeof C == "string" && C !== "") ||
        typeof C == "number" ||
        typeof C == "bigint"
      )
        return I !== null ? null : g(T, S, "" + C, H);
      if (typeof C == "object" && C !== null) {
        switch (C.$$typeof) {
          case E:
            return C.key === I ? N(T, S, C, H) : null;
          case R:
            return C.key === I ? M(T, S, C, H) : null;
          case K:
            return ((I = C._init), (C = I(C._payload)), D(T, S, C, H));
        }
        if (fe(C) || he(C)) return I !== null ? null : U(T, S, C, H, null);
        if (typeof C.then == "function") return D(T, S, pi(C), H);
        if (C.$$typeof === Y) return D(T, S, ai(T, C), H);
        bi(T, C);
      }
      return null;
    }
    function z(T, S, C, H, I) {
      if (
        (typeof H == "string" && H !== "") ||
        typeof H == "number" ||
        typeof H == "bigint"
      )
        return ((T = T.get(C) || null), g(S, T, "" + H, I));
      if (typeof H == "object" && H !== null) {
        switch (H.$$typeof) {
          case E:
            return (
              (T = T.get(H.key === null ? C : H.key) || null),
              N(S, T, H, I)
            );
          case R:
            return (
              (T = T.get(H.key === null ? C : H.key) || null),
              M(S, T, H, I)
            );
          case K:
            var be = H._init;
            return ((H = be(H._payload)), z(T, S, C, H, I));
        }
        if (fe(H) || he(H))
          return ((T = T.get(C) || null), U(S, T, H, I, null));
        if (typeof H.then == "function") return z(T, S, C, pi(H), I);
        if (H.$$typeof === Y) return z(T, S, C, ai(S, H), I);
        bi(S, H);
      }
      return null;
    }
    function de(T, S, C, H) {
      for (
        var I = null, be = null, ne = S, oe = (S = 0), Ie = null;
        ne !== null && oe < C.length;
        oe++
      ) {
        ne.index > oe ? ((Ie = ne), (ne = null)) : (Ie = ne.sibling);
        var Se = D(T, ne, C[oe], H);
        if (Se === null) {
          ne === null && (ne = Ie);
          break;
        }
        (e && ne && Se.alternate === null && t(T, ne),
          (S = u(Se, S, oe)),
          be === null ? (I = Se) : (be.sibling = Se),
          (be = Se),
          (ne = Ie));
      }
      if (oe === C.length) return (l(T, ne), Ee && oa(T, oe), I);
      if (ne === null) {
        for (; oe < C.length; oe++)
          ((ne = L(T, C[oe], H)),
            ne !== null &&
              ((S = u(ne, S, oe)),
              be === null ? (I = ne) : (be.sibling = ne),
              (be = ne)));
        return (Ee && oa(T, oe), I);
      }
      for (ne = n(ne); oe < C.length; oe++)
        ((Ie = z(ne, T, oe, C[oe], H)),
          Ie !== null &&
            (e &&
              Ie.alternate !== null &&
              ne.delete(Ie.key === null ? oe : Ie.key),
            (S = u(Ie, S, oe)),
            be === null ? (I = Ie) : (be.sibling = Ie),
            (be = Ie)));
      return (
        e &&
          ne.forEach(function (Kl) {
            return t(T, Kl);
          }),
        Ee && oa(T, oe),
        I
      );
    }
    function re(T, S, C, H) {
      if (C == null) throw Error(o(151));
      for (
        var I = null, be = null, ne = S, oe = (S = 0), Ie = null, Se = C.next();
        ne !== null && !Se.done;
        oe++, Se = C.next()
      ) {
        ne.index > oe ? ((Ie = ne), (ne = null)) : (Ie = ne.sibling);
        var Kl = D(T, ne, Se.value, H);
        if (Kl === null) {
          ne === null && (ne = Ie);
          break;
        }
        (e && ne && Kl.alternate === null && t(T, ne),
          (S = u(Kl, S, oe)),
          be === null ? (I = Kl) : (be.sibling = Kl),
          (be = Kl),
          (ne = Ie));
      }
      if (Se.done) return (l(T, ne), Ee && oa(T, oe), I);
      if (ne === null) {
        for (; !Se.done; oe++, Se = C.next())
          ((Se = L(T, Se.value, H)),
            Se !== null &&
              ((S = u(Se, S, oe)),
              be === null ? (I = Se) : (be.sibling = Se),
              (be = Se)));
        return (Ee && oa(T, oe), I);
      }
      for (ne = n(ne); !Se.done; oe++, Se = C.next())
        ((Se = z(ne, T, oe, Se.value, H)),
          Se !== null &&
            (e &&
              Se.alternate !== null &&
              ne.delete(Se.key === null ? oe : Se.key),
            (S = u(Se, S, oe)),
            be === null ? (I = Se) : (be.sibling = Se),
            (be = Se)));
      return (
        e &&
          ne.forEach(function (Yv) {
            return t(T, Yv);
          }),
        Ee && oa(T, oe),
        I
      );
    }
    function _e(T, S, C, H) {
      if (
        (typeof C == "object" &&
          C !== null &&
          C.type === k &&
          C.key === null &&
          (C = C.props.children),
        typeof C == "object" && C !== null)
      ) {
        switch (C.$$typeof) {
          case E:
            e: {
              for (var I = C.key; S !== null; ) {
                if (S.key === I) {
                  if (((I = C.type), I === k)) {
                    if (S.tag === 7) {
                      (l(T, S.sibling),
                        (H = r(S, C.props.children)),
                        (H.return = T),
                        (T = H));
                      break e;
                    }
                  } else if (
                    S.elementType === I ||
                    (typeof I == "object" &&
                      I !== null &&
                      I.$$typeof === K &&
                      nh(I) === S.type)
                  ) {
                    (l(T, S.sibling),
                      (H = r(S, C.props)),
                      Wn(H, C),
                      (H.return = T),
                      (T = H));
                    break e;
                  }
                  l(T, S);
                  break;
                } else t(T, S);
                S = S.sibling;
              }
              C.type === k
                ? ((H = ra(C.props.children, T.mode, H, C.key)),
                  (H.return = T),
                  (T = H))
                : ((H = Is(C.type, C.key, C.props, null, T.mode, H)),
                  Wn(H, C),
                  (H.return = T),
                  (T = H));
            }
            return m(T);
          case R:
            e: {
              for (I = C.key; S !== null; ) {
                if (S.key === I)
                  if (
                    S.tag === 4 &&
                    S.stateNode.containerInfo === C.containerInfo &&
                    S.stateNode.implementation === C.implementation
                  ) {
                    (l(T, S.sibling),
                      (H = r(S, C.children || [])),
                      (H.return = T),
                      (T = H));
                    break e;
                  } else {
                    l(T, S);
                    break;
                  }
                else t(T, S);
                S = S.sibling;
              }
              ((H = hc(C, T.mode, H)), (H.return = T), (T = H));
            }
            return m(T);
          case K:
            return ((I = C._init), (C = I(C._payload)), _e(T, S, C, H));
        }
        if (fe(C)) return de(T, S, C, H);
        if (he(C)) {
          if (((I = he(C)), typeof I != "function")) throw Error(o(150));
          return ((C = I.call(C)), re(T, S, C, H));
        }
        if (typeof C.then == "function") return _e(T, S, pi(C), H);
        if (C.$$typeof === Y) return _e(T, S, ai(T, C), H);
        bi(T, C);
      }
      return (typeof C == "string" && C !== "") ||
        typeof C == "number" ||
        typeof C == "bigint"
        ? ((C = "" + C),
          S !== null && S.tag === 6
            ? (l(T, S.sibling), (H = r(S, C)), (H.return = T), (T = H))
            : (l(T, S), (H = fc(C, T.mode, H)), (H.return = T), (T = H)),
          m(T))
        : l(T, S);
    }
    return function (T, S, C, H) {
      try {
        Fn = 0;
        var I = _e(T, S, C, H);
        return ((Ja = null), I);
      } catch (ne) {
        if (ne === Yn || ne === si) throw ne;
        var be = bt(29, ne, null, T.mode);
        return ((be.lanes = H), (be.return = T), be);
      }
    };
  }
  var Fa = sh(!0),
    ih = sh(!1),
    _t = q(null),
    Kt = null;
  function _l(e) {
    var t = e.alternate;
    (P(Ze, Ze.current & 1),
      P(_t, e),
      Kt === null &&
        (t === null || Za.current !== null || t.memoizedState !== null) &&
        (Kt = e));
  }
  function rh(e) {
    if (e.tag === 22) {
      if ((P(Ze, Ze.current), P(_t, e), Kt === null)) {
        var t = e.alternate;
        t !== null && t.memoizedState !== null && (Kt = e);
      }
    } else kl();
  }
  function kl() {
    (P(Ze, Ze.current), P(_t, _t.current));
  }
  function cl(e) {
    (J(_t), Kt === e && (Kt = null), J(Ze));
  }
  var Ze = q(0);
  function gi(e) {
    for (var t = e; t !== null; ) {
      if (t.tag === 13) {
        var l = t.memoizedState;
        if (
          l !== null &&
          ((l = l.dehydrated), l === null || l.data === "$?" || Uo(l))
        )
          return t;
      } else if (t.tag === 19 && t.memoizedProps.revealOrder !== void 0) {
        if ((t.flags & 128) !== 0) return t;
      } else if (t.child !== null) {
        ((t.child.return = t), (t = t.child));
        continue;
      }
      if (t === e) break;
      for (; t.sibling === null; ) {
        if (t.return === null || t.return === e) return null;
        t = t.return;
      }
      ((t.sibling.return = t.return), (t = t.sibling));
    }
    return null;
  }
  function Zc(e, t, l, n) {
    ((t = e.memoizedState),
      (l = l(n, t)),
      (l = l == null ? t : v({}, t, l)),
      (e.memoizedState = l),
      e.lanes === 0 && (e.updateQueue.baseState = l));
  }
  var Kc = {
    enqueueSetState: function (e, t, l) {
      e = e._reactInternals;
      var n = jt(),
        r = Ol(n);
      ((r.payload = t),
        l != null && (r.callback = l),
        (t = Rl(e, r, n)),
        t !== null && (Nt(t, e, n), Xn(t, e, n)));
    },
    enqueueReplaceState: function (e, t, l) {
      e = e._reactInternals;
      var n = jt(),
        r = Ol(n);
      ((r.tag = 1),
        (r.payload = t),
        l != null && (r.callback = l),
        (t = Rl(e, r, n)),
        t !== null && (Nt(t, e, n), Xn(t, e, n)));
    },
    enqueueForceUpdate: function (e, t) {
      e = e._reactInternals;
      var l = jt(),
        n = Ol(l);
      ((n.tag = 2),
        t != null && (n.callback = t),
        (t = Rl(e, n, l)),
        t !== null && (Nt(t, e, l), Xn(t, e, l)));
    },
  };
  function ch(e, t, l, n, r, u, m) {
    return (
      (e = e.stateNode),
      typeof e.shouldComponentUpdate == "function"
        ? e.shouldComponentUpdate(n, u, m)
        : t.prototype && t.prototype.isPureReactComponent
          ? !Dn(l, n) || !Dn(r, u)
          : !0
    );
  }
  function oh(e, t, l, n) {
    ((e = t.state),
      typeof t.componentWillReceiveProps == "function" &&
        t.componentWillReceiveProps(l, n),
      typeof t.UNSAFE_componentWillReceiveProps == "function" &&
        t.UNSAFE_componentWillReceiveProps(l, n),
      t.state !== e && Kc.enqueueReplaceState(t, t.state, null));
  }
  function pa(e, t) {
    var l = t;
    if ("ref" in t) {
      l = {};
      for (var n in t) n !== "ref" && (l[n] = t[n]);
    }
    if ((e = e.defaultProps)) {
      l === t && (l = v({}, l));
      for (var r in e) l[r] === void 0 && (l[r] = e[r]);
    }
    return l;
  }
  var vi =
    typeof reportError == "function"
      ? reportError
      : function (e) {
          if (
            typeof window == "object" &&
            typeof window.ErrorEvent == "function"
          ) {
            var t = new window.ErrorEvent("error", {
              bubbles: !0,
              cancelable: !0,
              message:
                typeof e == "object" &&
                e !== null &&
                typeof e.message == "string"
                  ? String(e.message)
                  : String(e),
              error: e,
            });
            if (!window.dispatchEvent(t)) return;
          } else if (
            typeof process == "object" &&
            typeof process.emit == "function"
          ) {
            process.emit("uncaughtException", e);
            return;
          }
          console.error(e);
        };
  function uh(e) {
    vi(e);
  }
  function dh(e) {
    console.error(e);
  }
  function fh(e) {
    vi(e);
  }
  function yi(e, t) {
    try {
      var l = e.onUncaughtError;
      l(t.value, { componentStack: t.stack });
    } catch (n) {
      setTimeout(function () {
        throw n;
      });
    }
  }
  function hh(e, t, l) {
    try {
      var n = e.onCaughtError;
      n(l.value, {
        componentStack: l.stack,
        errorBoundary: t.tag === 1 ? t.stateNode : null,
      });
    } catch (r) {
      setTimeout(function () {
        throw r;
      });
    }
  }
  function Pc(e, t, l) {
    return (
      (l = Ol(l)),
      (l.tag = 3),
      (l.payload = { element: null }),
      (l.callback = function () {
        yi(e, t);
      }),
      l
    );
  }
  function mh(e) {
    return ((e = Ol(e)), (e.tag = 3), e);
  }
  function xh(e, t, l, n) {
    var r = l.type.getDerivedStateFromError;
    if (typeof r == "function") {
      var u = n.value;
      ((e.payload = function () {
        return r(u);
      }),
        (e.callback = function () {
          hh(t, l, n);
        }));
    }
    var m = l.stateNode;
    m !== null &&
      typeof m.componentDidCatch == "function" &&
      (e.callback = function () {
        (hh(t, l, n),
          typeof r != "function" &&
            (ql === null ? (ql = new Set([this])) : ql.add(this)));
        var g = n.stack;
        this.componentDidCatch(n.value, {
          componentStack: g !== null ? g : "",
        });
      });
  }
  function Yg(e, t, l, n, r) {
    if (
      ((l.flags |= 32768),
      n !== null && typeof n == "object" && typeof n.then == "function")
    ) {
      if (
        ((t = l.alternate),
        t !== null && qn(t, l, r, !0),
        (l = _t.current),
        l !== null)
      ) {
        switch (l.tag) {
          case 13:
            return (
              Kt === null ? vo() : l.alternate === null && qe === 0 && (qe = 3),
              (l.flags &= -257),
              (l.flags |= 65536),
              (l.lanes = r),
              n === wc
                ? (l.flags |= 16384)
                : ((t = l.updateQueue),
                  t === null ? (l.updateQueue = new Set([n])) : t.add(n),
                  jo(e, n, r)),
              !1
            );
          case 22:
            return (
              (l.flags |= 65536),
              n === wc
                ? (l.flags |= 16384)
                : ((t = l.updateQueue),
                  t === null
                    ? ((t = {
                        transitions: null,
                        markerInstances: null,
                        retryQueue: new Set([n]),
                      }),
                      (l.updateQueue = t))
                    : ((l = t.retryQueue),
                      l === null ? (t.retryQueue = new Set([n])) : l.add(n)),
                  jo(e, n, r)),
              !1
            );
        }
        throw Error(o(435, l.tag));
      }
      return (jo(e, n, r), vo(), !1);
    }
    if (Ee)
      return (
        (t = _t.current),
        t !== null
          ? ((t.flags & 65536) === 0 && (t.flags |= 256),
            (t.flags |= 65536),
            (t.lanes = r),
            n !== pc && ((e = Error(o(422), { cause: n })), Ln(Ct(e, l))))
          : (n !== pc && ((t = Error(o(423), { cause: n })), Ln(Ct(t, l))),
            (e = e.current.alternate),
            (e.flags |= 65536),
            (r &= -r),
            (e.lanes |= r),
            (n = Ct(n, l)),
            (r = Pc(e.stateNode, n, r)),
            Tc(e, r),
            qe !== 4 && (qe = 2)),
        !1
      );
    var u = Error(o(520), { cause: n });
    if (
      ((u = Ct(u, l)),
      ss === null ? (ss = [u]) : ss.push(u),
      qe !== 4 && (qe = 2),
      t === null)
    )
      return !0;
    ((n = Ct(n, l)), (l = t));
    do {
      switch (l.tag) {
        case 3:
          return (
            (l.flags |= 65536),
            (e = r & -r),
            (l.lanes |= e),
            (e = Pc(l.stateNode, n, e)),
            Tc(l, e),
            !1
          );
        case 1:
          if (
            ((t = l.type),
            (u = l.stateNode),
            (l.flags & 128) === 0 &&
              (typeof t.getDerivedStateFromError == "function" ||
                (u !== null &&
                  typeof u.componentDidCatch == "function" &&
                  (ql === null || !ql.has(u)))))
          )
            return (
              (l.flags |= 65536),
              (r &= -r),
              (l.lanes |= r),
              (r = mh(r)),
              xh(r, e, l, n),
              Tc(l, r),
              !1
            );
      }
      l = l.return;
    } while (l !== null);
    return !1;
  }
  var ph = Error(o(461)),
    Fe = !1;
  function et(e, t, l, n) {
    t.child = e === null ? ih(t, null, l, n) : Fa(t, e.child, l, n);
  }
  function bh(e, t, l, n, r) {
    l = l.render;
    var u = t.ref;
    if ("ref" in n) {
      var m = {};
      for (var g in n) g !== "ref" && (m[g] = n[g]);
    } else m = n;
    return (
      ha(t),
      (n = Mc(e, t, l, m, u, r)),
      (g = _c()),
      e !== null && !Fe
        ? (kc(e, t, r), ol(e, t, r))
        : (Ee && g && mc(t), (t.flags |= 1), et(e, t, n, r), t.child)
    );
  }
  function gh(e, t, l, n, r) {
    if (e === null) {
      var u = l.type;
      return typeof u == "function" &&
        !dc(u) &&
        u.defaultProps === void 0 &&
        l.compare === null
        ? ((t.tag = 15), (t.type = u), vh(e, t, u, n, r))
        : ((e = Is(l.type, null, n, t, t.mode, r)),
          (e.ref = t.ref),
          (e.return = t),
          (t.child = e));
    }
    if (((u = e.child), !lo(e, r))) {
      var m = u.memoizedProps;
      if (
        ((l = l.compare), (l = l !== null ? l : Dn), l(m, n) && e.ref === t.ref)
      )
        return ol(e, t, r);
    }
    return (
      (t.flags |= 1),
      (e = ll(u, n)),
      (e.ref = t.ref),
      (e.return = t),
      (t.child = e)
    );
  }
  function vh(e, t, l, n, r) {
    if (e !== null) {
      var u = e.memoizedProps;
      if (Dn(u, n) && e.ref === t.ref)
        if (((Fe = !1), (t.pendingProps = n = u), lo(e, r)))
          (e.flags & 131072) !== 0 && (Fe = !0);
        else return ((t.lanes = e.lanes), ol(e, t, r));
    }
    return $c(e, t, l, n, r);
  }
  function yh(e, t, l) {
    var n = t.pendingProps,
      r = n.children,
      u = e !== null ? e.memoizedState : null;
    if (n.mode === "hidden") {
      if ((t.flags & 128) !== 0) {
        if (((n = u !== null ? u.baseLanes | l : l), e !== null)) {
          for (r = t.child = e.child, u = 0; r !== null; )
            ((u = u | r.lanes | r.childLanes), (r = r.sibling));
          t.childLanes = u & ~n;
        } else ((t.childLanes = 0), (t.child = null));
        return jh(e, t, n, l);
      }
      if ((l & 536870912) !== 0)
        ((t.memoizedState = { baseLanes: 0, cachePool: null }),
          e !== null && ni(t, u !== null ? u.cachePool : null),
          u !== null ? vf(t, u) : Cc(),
          rh(t));
      else
        return (
          (t.lanes = t.childLanes = 536870912),
          jh(e, t, u !== null ? u.baseLanes | l : l, l)
        );
    } else
      u !== null
        ? (ni(t, u.cachePool), vf(t, u), kl(), (t.memoizedState = null))
        : (e !== null && ni(t, null), Cc(), kl());
    return (et(e, t, r, l), t.child);
  }
  function jh(e, t, l, n) {
    var r = Nc();
    return (
      (r = r === null ? null : { parent: Qe._currentValue, pool: r }),
      (t.memoizedState = { baseLanes: l, cachePool: r }),
      e !== null && ni(t, null),
      Cc(),
      rh(t),
      e !== null && qn(e, t, n, !0),
      null
    );
  }
  function ji(e, t) {
    var l = t.ref;
    if (l === null) e !== null && e.ref !== null && (t.flags |= 4194816);
    else {
      if (typeof l != "function" && typeof l != "object") throw Error(o(284));
      (e === null || e.ref !== l) && (t.flags |= 4194816);
    }
  }
  function $c(e, t, l, n, r) {
    return (
      ha(t),
      (l = Mc(e, t, l, n, void 0, r)),
      (n = _c()),
      e !== null && !Fe
        ? (kc(e, t, r), ol(e, t, r))
        : (Ee && n && mc(t), (t.flags |= 1), et(e, t, l, r), t.child)
    );
  }
  function Nh(e, t, l, n, r, u) {
    return (
      ha(t),
      (t.updateQueue = null),
      (l = jf(t, n, l, r)),
      yf(e),
      (n = _c()),
      e !== null && !Fe
        ? (kc(e, t, u), ol(e, t, u))
        : (Ee && n && mc(t), (t.flags |= 1), et(e, t, l, u), t.child)
    );
  }
  function wh(e, t, l, n, r) {
    if ((ha(t), t.stateNode === null)) {
      var u = Ga,
        m = l.contextType;
      (typeof m == "object" && m !== null && (u = nt(m)),
        (u = new l(n, u)),
        (t.memoizedState =
          u.state !== null && u.state !== void 0 ? u.state : null),
        (u.updater = Kc),
        (t.stateNode = u),
        (u._reactInternals = t),
        (u = t.stateNode),
        (u.props = n),
        (u.state = t.memoizedState),
        (u.refs = {}),
        Sc(t),
        (m = l.contextType),
        (u.context = typeof m == "object" && m !== null ? nt(m) : Ga),
        (u.state = t.memoizedState),
        (m = l.getDerivedStateFromProps),
        typeof m == "function" && (Zc(t, l, m, n), (u.state = t.memoizedState)),
        typeof l.getDerivedStateFromProps == "function" ||
          typeof u.getSnapshotBeforeUpdate == "function" ||
          (typeof u.UNSAFE_componentWillMount != "function" &&
            typeof u.componentWillMount != "function") ||
          ((m = u.state),
          typeof u.componentWillMount == "function" && u.componentWillMount(),
          typeof u.UNSAFE_componentWillMount == "function" &&
            u.UNSAFE_componentWillMount(),
          m !== u.state && Kc.enqueueReplaceState(u, u.state, null),
          Zn(t, n, u, r),
          Qn(),
          (u.state = t.memoizedState)),
        typeof u.componentDidMount == "function" && (t.flags |= 4194308),
        (n = !0));
    } else if (e === null) {
      u = t.stateNode;
      var g = t.memoizedProps,
        N = pa(l, g);
      u.props = N;
      var M = u.context,
        U = l.contextType;
      ((m = Ga), typeof U == "object" && U !== null && (m = nt(U)));
      var L = l.getDerivedStateFromProps;
      ((U =
        typeof L == "function" ||
        typeof u.getSnapshotBeforeUpdate == "function"),
        (g = t.pendingProps !== g),
        U ||
          (typeof u.UNSAFE_componentWillReceiveProps != "function" &&
            typeof u.componentWillReceiveProps != "function") ||
          ((g || M !== m) && oh(t, u, n, m)),
        (Cl = !1));
      var D = t.memoizedState;
      ((u.state = D),
        Zn(t, n, u, r),
        Qn(),
        (M = t.memoizedState),
        g || D !== M || Cl
          ? (typeof L == "function" && (Zc(t, l, L, n), (M = t.memoizedState)),
            (N = Cl || ch(t, l, N, n, D, M, m))
              ? (U ||
                  (typeof u.UNSAFE_componentWillMount != "function" &&
                    typeof u.componentWillMount != "function") ||
                  (typeof u.componentWillMount == "function" &&
                    u.componentWillMount(),
                  typeof u.UNSAFE_componentWillMount == "function" &&
                    u.UNSAFE_componentWillMount()),
                typeof u.componentDidMount == "function" &&
                  (t.flags |= 4194308))
              : (typeof u.componentDidMount == "function" &&
                  (t.flags |= 4194308),
                (t.memoizedProps = n),
                (t.memoizedState = M)),
            (u.props = n),
            (u.state = M),
            (u.context = m),
            (n = N))
          : (typeof u.componentDidMount == "function" && (t.flags |= 4194308),
            (n = !1)));
    } else {
      ((u = t.stateNode),
        Ec(e, t),
        (m = t.memoizedProps),
        (U = pa(l, m)),
        (u.props = U),
        (L = t.pendingProps),
        (D = u.context),
        (M = l.contextType),
        (N = Ga),
        typeof M == "object" && M !== null && (N = nt(M)),
        (g = l.getDerivedStateFromProps),
        (M =
          typeof g == "function" ||
          typeof u.getSnapshotBeforeUpdate == "function") ||
          (typeof u.UNSAFE_componentWillReceiveProps != "function" &&
            typeof u.componentWillReceiveProps != "function") ||
          ((m !== L || D !== N) && oh(t, u, n, N)),
        (Cl = !1),
        (D = t.memoizedState),
        (u.state = D),
        Zn(t, n, u, r),
        Qn());
      var z = t.memoizedState;
      m !== L ||
      D !== z ||
      Cl ||
      (e !== null && e.dependencies !== null && li(e.dependencies))
        ? (typeof g == "function" && (Zc(t, l, g, n), (z = t.memoizedState)),
          (U =
            Cl ||
            ch(t, l, U, n, D, z, N) ||
            (e !== null && e.dependencies !== null && li(e.dependencies)))
            ? (M ||
                (typeof u.UNSAFE_componentWillUpdate != "function" &&
                  typeof u.componentWillUpdate != "function") ||
                (typeof u.componentWillUpdate == "function" &&
                  u.componentWillUpdate(n, z, N),
                typeof u.UNSAFE_componentWillUpdate == "function" &&
                  u.UNSAFE_componentWillUpdate(n, z, N)),
              typeof u.componentDidUpdate == "function" && (t.flags |= 4),
              typeof u.getSnapshotBeforeUpdate == "function" &&
                (t.flags |= 1024))
            : (typeof u.componentDidUpdate != "function" ||
                (m === e.memoizedProps && D === e.memoizedState) ||
                (t.flags |= 4),
              typeof u.getSnapshotBeforeUpdate != "function" ||
                (m === e.memoizedProps && D === e.memoizedState) ||
                (t.flags |= 1024),
              (t.memoizedProps = n),
              (t.memoizedState = z)),
          (u.props = n),
          (u.state = z),
          (u.context = N),
          (n = U))
        : (typeof u.componentDidUpdate != "function" ||
            (m === e.memoizedProps && D === e.memoizedState) ||
            (t.flags |= 4),
          typeof u.getSnapshotBeforeUpdate != "function" ||
            (m === e.memoizedProps && D === e.memoizedState) ||
            (t.flags |= 1024),
          (n = !1));
    }
    return (
      (u = n),
      ji(e, t),
      (n = (t.flags & 128) !== 0),
      u || n
        ? ((u = t.stateNode),
          (l =
            n && typeof l.getDerivedStateFromError != "function"
              ? null
              : u.render()),
          (t.flags |= 1),
          e !== null && n
            ? ((t.child = Fa(t, e.child, null, r)),
              (t.child = Fa(t, null, l, r)))
            : et(e, t, l, r),
          (t.memoizedState = u.state),
          (e = t.child))
        : (e = ol(e, t, r)),
      e
    );
  }
  function Sh(e, t, l, n) {
    return (Hn(), (t.flags |= 256), et(e, t, l, n), t.child);
  }
  var Jc = {
    dehydrated: null,
    treeContext: null,
    retryLane: 0,
    hydrationErrors: null,
  };
  function Fc(e) {
    return { baseLanes: e, cachePool: df() };
  }
  function Wc(e, t, l) {
    return ((e = e !== null ? e.childLanes & ~l : 0), t && (e |= kt), e);
  }
  function Eh(e, t, l) {
    var n = t.pendingProps,
      r = !1,
      u = (t.flags & 128) !== 0,
      m;
    if (
      ((m = u) ||
        (m =
          e !== null && e.memoizedState === null ? !1 : (Ze.current & 2) !== 0),
      m && ((r = !0), (t.flags &= -129)),
      (m = (t.flags & 32) !== 0),
      (t.flags &= -33),
      e === null)
    ) {
      if (Ee) {
        if ((r ? _l(t) : kl(), Ee)) {
          var g = Le,
            N;
          if ((N = g)) {
            e: {
              for (N = g, g = Zt; N.nodeType !== 8; ) {
                if (!g) {
                  g = null;
                  break e;
                }
                if (((N = Lt(N.nextSibling)), N === null)) {
                  g = null;
                  break e;
                }
              }
              g = N;
            }
            g !== null
              ? ((t.memoizedState = {
                  dehydrated: g,
                  treeContext: ca !== null ? { id: al, overflow: nl } : null,
                  retryLane: 536870912,
                  hydrationErrors: null,
                }),
                (N = bt(18, null, null, 0)),
                (N.stateNode = g),
                (N.return = t),
                (t.child = N),
                (it = t),
                (Le = null),
                (N = !0))
              : (N = !1);
          }
          N || da(t);
        }
        if (
          ((g = t.memoizedState),
          g !== null && ((g = g.dehydrated), g !== null))
        )
          return (Uo(g) ? (t.lanes = 32) : (t.lanes = 536870912), null);
        cl(t);
      }
      return (
        (g = n.children),
        (n = n.fallback),
        r
          ? (kl(),
            (r = t.mode),
            (g = Ni({ mode: "hidden", children: g }, r)),
            (n = ra(n, r, l, null)),
            (g.return = t),
            (n.return = t),
            (g.sibling = n),
            (t.child = g),
            (r = t.child),
            (r.memoizedState = Fc(l)),
            (r.childLanes = Wc(e, m, l)),
            (t.memoizedState = Jc),
            n)
          : (_l(t), Ic(t, g))
      );
    }
    if (
      ((N = e.memoizedState), N !== null && ((g = N.dehydrated), g !== null))
    ) {
      if (u)
        t.flags & 256
          ? (_l(t), (t.flags &= -257), (t = eo(e, t, l)))
          : t.memoizedState !== null
            ? (kl(), (t.child = e.child), (t.flags |= 128), (t = null))
            : (kl(),
              (r = n.fallback),
              (g = t.mode),
              (n = Ni({ mode: "visible", children: n.children }, g)),
              (r = ra(r, g, l, null)),
              (r.flags |= 2),
              (n.return = t),
              (r.return = t),
              (n.sibling = r),
              (t.child = n),
              Fa(t, e.child, null, l),
              (n = t.child),
              (n.memoizedState = Fc(l)),
              (n.childLanes = Wc(e, m, l)),
              (t.memoizedState = Jc),
              (t = r));
      else if ((_l(t), Uo(g))) {
        if (((m = g.nextSibling && g.nextSibling.dataset), m)) var M = m.dgst;
        ((m = M),
          (n = Error(o(419))),
          (n.stack = ""),
          (n.digest = m),
          Ln({ value: n, source: null, stack: null }),
          (t = eo(e, t, l)));
      } else if (
        (Fe || qn(e, t, l, !1), (m = (l & e.childLanes) !== 0), Fe || m)
      ) {
        if (
          ((m = De),
          m !== null &&
            ((n = l & -l),
            (n = (n & 42) !== 0 ? 1 : Ur(n)),
            (n = (n & (m.suspendedLanes | l)) !== 0 ? 0 : n),
            n !== 0 && n !== N.retryLane))
        )
          throw ((N.retryLane = n), Ba(e, n), Nt(m, e, n), ph);
        (g.data === "$?" || vo(), (t = eo(e, t, l)));
      } else
        g.data === "$?"
          ? ((t.flags |= 192), (t.child = e.child), (t = null))
          : ((e = N.treeContext),
            (Le = Lt(g.nextSibling)),
            (it = t),
            (Ee = !0),
            (ua = null),
            (Zt = !1),
            e !== null &&
              ((Rt[Mt++] = al),
              (Rt[Mt++] = nl),
              (Rt[Mt++] = ca),
              (al = e.id),
              (nl = e.overflow),
              (ca = t)),
            (t = Ic(t, n.children)),
            (t.flags |= 4096));
      return t;
    }
    return r
      ? (kl(),
        (r = n.fallback),
        (g = t.mode),
        (N = e.child),
        (M = N.sibling),
        (n = ll(N, { mode: "hidden", children: n.children })),
        (n.subtreeFlags = N.subtreeFlags & 65011712),
        M !== null ? (r = ll(M, r)) : ((r = ra(r, g, l, null)), (r.flags |= 2)),
        (r.return = t),
        (n.return = t),
        (n.sibling = r),
        (t.child = n),
        (n = r),
        (r = t.child),
        (g = e.child.memoizedState),
        g === null
          ? (g = Fc(l))
          : ((N = g.cachePool),
            N !== null
              ? ((M = Qe._currentValue),
                (N = N.parent !== M ? { parent: M, pool: M } : N))
              : (N = df()),
            (g = { baseLanes: g.baseLanes | l, cachePool: N })),
        (r.memoizedState = g),
        (r.childLanes = Wc(e, m, l)),
        (t.memoizedState = Jc),
        n)
      : (_l(t),
        (l = e.child),
        (e = l.sibling),
        (l = ll(l, { mode: "visible", children: n.children })),
        (l.return = t),
        (l.sibling = null),
        e !== null &&
          ((m = t.deletions),
          m === null ? ((t.deletions = [e]), (t.flags |= 16)) : m.push(e)),
        (t.child = l),
        (t.memoizedState = null),
        l);
  }
  function Ic(e, t) {
    return (
      (t = Ni({ mode: "visible", children: t }, e.mode)),
      (t.return = e),
      (e.child = t)
    );
  }
  function Ni(e, t) {
    return (
      (e = bt(22, e, null, t)),
      (e.lanes = 0),
      (e.stateNode = {
        _visibility: 1,
        _pendingMarkers: null,
        _retryCache: null,
        _transitions: null,
      }),
      e
    );
  }
  function eo(e, t, l) {
    return (
      Fa(t, e.child, null, l),
      (e = Ic(t, t.pendingProps.children)),
      (e.flags |= 2),
      (t.memoizedState = null),
      e
    );
  }
  function Th(e, t, l) {
    e.lanes |= t;
    var n = e.alternate;
    (n !== null && (n.lanes |= t), gc(e.return, t, l));
  }
  function to(e, t, l, n, r) {
    var u = e.memoizedState;
    u === null
      ? (e.memoizedState = {
          isBackwards: t,
          rendering: null,
          renderingStartTime: 0,
          last: n,
          tail: l,
          tailMode: r,
        })
      : ((u.isBackwards = t),
        (u.rendering = null),
        (u.renderingStartTime = 0),
        (u.last = n),
        (u.tail = l),
        (u.tailMode = r));
  }
  function Ah(e, t, l) {
    var n = t.pendingProps,
      r = n.revealOrder,
      u = n.tail;
    if ((et(e, t, n.children, l), (n = Ze.current), (n & 2) !== 0))
      ((n = (n & 1) | 2), (t.flags |= 128));
    else {
      if (e !== null && (e.flags & 128) !== 0)
        e: for (e = t.child; e !== null; ) {
          if (e.tag === 13) e.memoizedState !== null && Th(e, l, t);
          else if (e.tag === 19) Th(e, l, t);
          else if (e.child !== null) {
            ((e.child.return = e), (e = e.child));
            continue;
          }
          if (e === t) break e;
          for (; e.sibling === null; ) {
            if (e.return === null || e.return === t) break e;
            e = e.return;
          }
          ((e.sibling.return = e.return), (e = e.sibling));
        }
      n &= 1;
    }
    switch ((P(Ze, n), r)) {
      case "forwards":
        for (l = t.child, r = null; l !== null; )
          ((e = l.alternate),
            e !== null && gi(e) === null && (r = l),
            (l = l.sibling));
        ((l = r),
          l === null
            ? ((r = t.child), (t.child = null))
            : ((r = l.sibling), (l.sibling = null)),
          to(t, !1, r, l, u));
        break;
      case "backwards":
        for (l = null, r = t.child, t.child = null; r !== null; ) {
          if (((e = r.alternate), e !== null && gi(e) === null)) {
            t.child = r;
            break;
          }
          ((e = r.sibling), (r.sibling = l), (l = r), (r = e));
        }
        to(t, !0, l, null, u);
        break;
      case "together":
        to(t, !1, null, null, void 0);
        break;
      default:
        t.memoizedState = null;
    }
    return t.child;
  }
  function ol(e, t, l) {
    if (
      (e !== null && (t.dependencies = e.dependencies),
      (Ll |= t.lanes),
      (l & t.childLanes) === 0)
    )
      if (e !== null) {
        if ((qn(e, t, l, !1), (l & t.childLanes) === 0)) return null;
      } else return null;
    if (e !== null && t.child !== e.child) throw Error(o(153));
    if (t.child !== null) {
      for (
        e = t.child, l = ll(e, e.pendingProps), t.child = l, l.return = t;
        e.sibling !== null;
      )
        ((e = e.sibling),
          (l = l.sibling = ll(e, e.pendingProps)),
          (l.return = t));
      l.sibling = null;
    }
    return t.child;
  }
  function lo(e, t) {
    return (e.lanes & t) !== 0
      ? !0
      : ((e = e.dependencies), !!(e !== null && li(e)));
  }
  function Vg(e, t, l) {
    switch (t.tag) {
      case 3:
        (Te(t, t.stateNode.containerInfo),
          Al(t, Qe, e.memoizedState.cache),
          Hn());
        break;
      case 27:
      case 5:
        Nl(t);
        break;
      case 4:
        Te(t, t.stateNode.containerInfo);
        break;
      case 10:
        Al(t, t.type, t.memoizedProps.value);
        break;
      case 13:
        var n = t.memoizedState;
        if (n !== null)
          return n.dehydrated !== null
            ? (_l(t), (t.flags |= 128), null)
            : (l & t.child.childLanes) !== 0
              ? Eh(e, t, l)
              : (_l(t), (e = ol(e, t, l)), e !== null ? e.sibling : null);
        _l(t);
        break;
      case 19:
        var r = (e.flags & 128) !== 0;
        if (
          ((n = (l & t.childLanes) !== 0),
          n || (qn(e, t, l, !1), (n = (l & t.childLanes) !== 0)),
          r)
        ) {
          if (n) return Ah(e, t, l);
          t.flags |= 128;
        }
        if (
          ((r = t.memoizedState),
          r !== null &&
            ((r.rendering = null), (r.tail = null), (r.lastEffect = null)),
          P(Ze, Ze.current),
          n)
        )
          break;
        return null;
      case 22:
      case 23:
        return ((t.lanes = 0), yh(e, t, l));
      case 24:
        Al(t, Qe, e.memoizedState.cache);
    }
    return ol(e, t, l);
  }
  function Ch(e, t, l) {
    if (e !== null)
      if (e.memoizedProps !== t.pendingProps) Fe = !0;
      else {
        if (!lo(e, l) && (t.flags & 128) === 0) return ((Fe = !1), Vg(e, t, l));
        Fe = (e.flags & 131072) !== 0;
      }
    else ((Fe = !1), Ee && (t.flags & 1048576) !== 0 && af(t, ti, t.index));
    switch (((t.lanes = 0), t.tag)) {
      case 16:
        e: {
          e = t.pendingProps;
          var n = t.elementType,
            r = n._init;
          if (((n = r(n._payload)), (t.type = n), typeof n == "function"))
            dc(n)
              ? ((e = pa(n, e)), (t.tag = 1), (t = wh(null, t, n, e, l)))
              : ((t.tag = 0), (t = $c(null, t, n, e, l)));
          else {
            if (n != null) {
              if (((r = n.$$typeof), r === Z)) {
                ((t.tag = 11), (t = bh(null, t, n, e, l)));
                break e;
              } else if (r === F) {
                ((t.tag = 14), (t = gh(null, t, n, e, l)));
                break e;
              }
            }
            throw ((t = W(n) || n), Error(o(306, t, "")));
          }
        }
        return t;
      case 0:
        return $c(e, t, t.type, t.pendingProps, l);
      case 1:
        return ((n = t.type), (r = pa(n, t.pendingProps)), wh(e, t, n, r, l));
      case 3:
        e: {
          if ((Te(t, t.stateNode.containerInfo), e === null))
            throw Error(o(387));
          n = t.pendingProps;
          var u = t.memoizedState;
          ((r = u.element), Ec(e, t), Zn(t, n, null, l));
          var m = t.memoizedState;
          if (
            ((n = m.cache),
            Al(t, Qe, n),
            n !== u.cache && vc(t, [Qe], l, !0),
            Qn(),
            (n = m.element),
            u.isDehydrated)
          )
            if (
              ((u = { element: n, isDehydrated: !1, cache: m.cache }),
              (t.updateQueue.baseState = u),
              (t.memoizedState = u),
              t.flags & 256)
            ) {
              t = Sh(e, t, n, l);
              break e;
            } else if (n !== r) {
              ((r = Ct(Error(o(424)), t)), Ln(r), (t = Sh(e, t, n, l)));
              break e;
            } else
              for (
                e = t.stateNode.containerInfo,
                  e.nodeType === 9
                    ? (e = e.body)
                    : (e = e.nodeName === "HTML" ? e.ownerDocument.body : e),
                  Le = Lt(e.firstChild),
                  it = t,
                  Ee = !0,
                  ua = null,
                  Zt = !0,
                  l = ih(t, null, n, l),
                  t.child = l;
                l;
              )
                ((l.flags = (l.flags & -3) | 4096), (l = l.sibling));
          else {
            if ((Hn(), n === r)) {
              t = ol(e, t, l);
              break e;
            }
            et(e, t, n, l);
          }
          t = t.child;
        }
        return t;
      case 26:
        return (
          ji(e, t),
          e === null
            ? (l = _0(t.type, null, t.pendingProps, null))
              ? (t.memoizedState = l)
              : Ee ||
                ((l = t.type),
                (e = t.pendingProps),
                (n = Ui(le.current).createElement(l)),
                (n[at] = t),
                (n[ct] = e),
                lt(n, l, e),
                Je(n),
                (t.stateNode = n))
            : (t.memoizedState = _0(
                t.type,
                e.memoizedProps,
                t.pendingProps,
                e.memoizedState,
              )),
          null
        );
      case 27:
        return (
          Nl(t),
          e === null &&
            Ee &&
            ((n = t.stateNode = O0(t.type, t.pendingProps, le.current)),
            (it = t),
            (Zt = !0),
            (r = Le),
            Yl(t.type) ? ((Ho = r), (Le = Lt(n.firstChild))) : (Le = r)),
          et(e, t, t.pendingProps.children, l),
          ji(e, t),
          e === null && (t.flags |= 4194304),
          t.child
        );
      case 5:
        return (
          e === null &&
            Ee &&
            ((r = n = Le) &&
              ((n = bv(n, t.type, t.pendingProps, Zt)),
              n !== null
                ? ((t.stateNode = n),
                  (it = t),
                  (Le = Lt(n.firstChild)),
                  (Zt = !1),
                  (r = !0))
                : (r = !1)),
            r || da(t)),
          Nl(t),
          (r = t.type),
          (u = t.pendingProps),
          (m = e !== null ? e.memoizedProps : null),
          (n = u.children),
          ko(r, u) ? (n = null) : m !== null && ko(r, m) && (t.flags |= 32),
          t.memoizedState !== null &&
            ((r = Mc(e, t, zg, null, null, l)), (ms._currentValue = r)),
          ji(e, t),
          et(e, t, n, l),
          t.child
        );
      case 6:
        return (
          e === null &&
            Ee &&
            ((e = l = Le) &&
              ((l = gv(l, t.pendingProps, Zt)),
              l !== null
                ? ((t.stateNode = l), (it = t), (Le = null), (e = !0))
                : (e = !1)),
            e || da(t)),
          null
        );
      case 13:
        return Eh(e, t, l);
      case 4:
        return (
          Te(t, t.stateNode.containerInfo),
          (n = t.pendingProps),
          e === null ? (t.child = Fa(t, null, n, l)) : et(e, t, n, l),
          t.child
        );
      case 11:
        return bh(e, t, t.type, t.pendingProps, l);
      case 7:
        return (et(e, t, t.pendingProps, l), t.child);
      case 8:
        return (et(e, t, t.pendingProps.children, l), t.child);
      case 12:
        return (et(e, t, t.pendingProps.children, l), t.child);
      case 10:
        return (
          (n = t.pendingProps),
          Al(t, t.type, n.value),
          et(e, t, n.children, l),
          t.child
        );
      case 9:
        return (
          (r = t.type._context),
          (n = t.pendingProps.children),
          ha(t),
          (r = nt(r)),
          (n = n(r)),
          (t.flags |= 1),
          et(e, t, n, l),
          t.child
        );
      case 14:
        return gh(e, t, t.type, t.pendingProps, l);
      case 15:
        return vh(e, t, t.type, t.pendingProps, l);
      case 19:
        return Ah(e, t, l);
      case 31:
        return (
          (n = t.pendingProps),
          (l = t.mode),
          (n = { mode: n.mode, children: n.children }),
          e === null
            ? ((l = Ni(n, l)),
              (l.ref = t.ref),
              (t.child = l),
              (l.return = t),
              (t = l))
            : ((l = ll(e.child, n)),
              (l.ref = t.ref),
              (t.child = l),
              (l.return = t),
              (t = l)),
          t
        );
      case 22:
        return yh(e, t, l);
      case 24:
        return (
          ha(t),
          (n = nt(Qe)),
          e === null
            ? ((r = Nc()),
              r === null &&
                ((r = De),
                (u = yc()),
                (r.pooledCache = u),
                u.refCount++,
                u !== null && (r.pooledCacheLanes |= l),
                (r = u)),
              (t.memoizedState = { parent: n, cache: r }),
              Sc(t),
              Al(t, Qe, r))
            : ((e.lanes & l) !== 0 && (Ec(e, t), Zn(t, null, null, l), Qn()),
              (r = e.memoizedState),
              (u = t.memoizedState),
              r.parent !== n
                ? ((r = { parent: n, cache: n }),
                  (t.memoizedState = r),
                  t.lanes === 0 &&
                    (t.memoizedState = t.updateQueue.baseState = r),
                  Al(t, Qe, n))
                : ((n = u.cache),
                  Al(t, Qe, n),
                  n !== r.cache && vc(t, [Qe], l, !0))),
          et(e, t, t.pendingProps.children, l),
          t.child
        );
      case 29:
        throw t.pendingProps;
    }
    throw Error(o(156, t.tag));
  }
  function ul(e) {
    e.flags |= 4;
  }
  function Oh(e, t) {
    if (t.type !== "stylesheet" || (t.state.loading & 4) !== 0)
      e.flags &= -16777217;
    else if (((e.flags |= 16777216), !H0(t))) {
      if (
        ((t = _t.current),
        t !== null &&
          ((Ne & 4194048) === Ne
            ? Kt !== null
            : ((Ne & 62914560) !== Ne && (Ne & 536870912) === 0) || t !== Kt))
      )
        throw ((Vn = wc), ff);
      e.flags |= 8192;
    }
  }
  function wi(e, t) {
    (t !== null && (e.flags |= 4),
      e.flags & 16384 &&
        ((t = e.tag !== 22 ? id() : 536870912), (e.lanes |= t), (tn |= t)));
  }
  function In(e, t) {
    if (!Ee)
      switch (e.tailMode) {
        case "hidden":
          t = e.tail;
          for (var l = null; t !== null; )
            (t.alternate !== null && (l = t), (t = t.sibling));
          l === null ? (e.tail = null) : (l.sibling = null);
          break;
        case "collapsed":
          l = e.tail;
          for (var n = null; l !== null; )
            (l.alternate !== null && (n = l), (l = l.sibling));
          n === null
            ? t || e.tail === null
              ? (e.tail = null)
              : (e.tail.sibling = null)
            : (n.sibling = null);
      }
  }
  function He(e) {
    var t = e.alternate !== null && e.alternate.child === e.child,
      l = 0,
      n = 0;
    if (t)
      for (var r = e.child; r !== null; )
        ((l |= r.lanes | r.childLanes),
          (n |= r.subtreeFlags & 65011712),
          (n |= r.flags & 65011712),
          (r.return = e),
          (r = r.sibling));
    else
      for (r = e.child; r !== null; )
        ((l |= r.lanes | r.childLanes),
          (n |= r.subtreeFlags),
          (n |= r.flags),
          (r.return = e),
          (r = r.sibling));
    return ((e.subtreeFlags |= n), (e.childLanes = l), t);
  }
  function Xg(e, t, l) {
    var n = t.pendingProps;
    switch ((xc(t), t.tag)) {
      case 31:
      case 16:
      case 15:
      case 0:
      case 11:
      case 7:
      case 8:
      case 12:
      case 9:
      case 14:
        return (He(t), null);
      case 1:
        return (He(t), null);
      case 3:
        return (
          (l = t.stateNode),
          (n = null),
          e !== null && (n = e.memoizedState.cache),
          t.memoizedState.cache !== n && (t.flags |= 2048),
          il(Qe),
          Ae(),
          l.pendingContext &&
            ((l.context = l.pendingContext), (l.pendingContext = null)),
          (e === null || e.child === null) &&
            (Un(t)
              ? ul(t)
              : e === null ||
                (e.memoizedState.isDehydrated && (t.flags & 256) === 0) ||
                ((t.flags |= 1024), rf())),
          He(t),
          null
        );
      case 26:
        return (
          (l = t.memoizedState),
          e === null
            ? (ul(t),
              l !== null ? (He(t), Oh(t, l)) : (He(t), (t.flags &= -16777217)))
            : l
              ? l !== e.memoizedState
                ? (ul(t), He(t), Oh(t, l))
                : (He(t), (t.flags &= -16777217))
              : (e.memoizedProps !== n && ul(t), He(t), (t.flags &= -16777217)),
          null
        );
      case 27:
        (zt(t), (l = le.current));
        var r = t.type;
        if (e !== null && t.stateNode != null) e.memoizedProps !== n && ul(t);
        else {
          if (!n) {
            if (t.stateNode === null) throw Error(o(166));
            return (He(t), null);
          }
          ((e = ae.current),
            Un(t) ? nf(t) : ((e = O0(r, n, l)), (t.stateNode = e), ul(t)));
        }
        return (He(t), null);
      case 5:
        if ((zt(t), (l = t.type), e !== null && t.stateNode != null))
          e.memoizedProps !== n && ul(t);
        else {
          if (!n) {
            if (t.stateNode === null) throw Error(o(166));
            return (He(t), null);
          }
          if (((e = ae.current), Un(t))) nf(t);
          else {
            switch (((r = Ui(le.current)), e)) {
              case 1:
                e = r.createElementNS("http://www.w3.org/2000/svg", l);
                break;
              case 2:
                e = r.createElementNS("http://www.w3.org/1998/Math/MathML", l);
                break;
              default:
                switch (l) {
                  case "svg":
                    e = r.createElementNS("http://www.w3.org/2000/svg", l);
                    break;
                  case "math":
                    e = r.createElementNS(
                      "http://www.w3.org/1998/Math/MathML",
                      l,
                    );
                    break;
                  case "script":
                    ((e = r.createElement("div")),
                      (e.innerHTML = "<script><\/script>"),
                      (e = e.removeChild(e.firstChild)));
                    break;
                  case "select":
                    ((e =
                      typeof n.is == "string"
                        ? r.createElement("select", { is: n.is })
                        : r.createElement("select")),
                      n.multiple
                        ? (e.multiple = !0)
                        : n.size && (e.size = n.size));
                    break;
                  default:
                    e =
                      typeof n.is == "string"
                        ? r.createElement(l, { is: n.is })
                        : r.createElement(l);
                }
            }
            ((e[at] = t), (e[ct] = n));
            e: for (r = t.child; r !== null; ) {
              if (r.tag === 5 || r.tag === 6) e.appendChild(r.stateNode);
              else if (r.tag !== 4 && r.tag !== 27 && r.child !== null) {
                ((r.child.return = r), (r = r.child));
                continue;
              }
              if (r === t) break e;
              for (; r.sibling === null; ) {
                if (r.return === null || r.return === t) break e;
                r = r.return;
              }
              ((r.sibling.return = r.return), (r = r.sibling));
            }
            t.stateNode = e;
            e: switch ((lt(e, l, n), l)) {
              case "button":
              case "input":
              case "select":
              case "textarea":
                e = !!n.autoFocus;
                break e;
              case "img":
                e = !0;
                break e;
              default:
                e = !1;
            }
            e && ul(t);
          }
        }
        return (He(t), (t.flags &= -16777217), null);
      case 6:
        if (e && t.stateNode != null) e.memoizedProps !== n && ul(t);
        else {
          if (typeof n != "string" && t.stateNode === null) throw Error(o(166));
          if (((e = le.current), Un(t))) {
            if (
              ((e = t.stateNode),
              (l = t.memoizedProps),
              (n = null),
              (r = it),
              r !== null)
            )
              switch (r.tag) {
                case 27:
                case 5:
                  n = r.memoizedProps;
              }
            ((e[at] = t),
              (e = !!(
                e.nodeValue === l ||
                (n !== null && n.suppressHydrationWarning === !0) ||
                N0(e.nodeValue, l)
              )),
              e || da(t));
          } else
            ((e = Ui(e).createTextNode(n)), (e[at] = t), (t.stateNode = e));
        }
        return (He(t), null);
      case 13:
        if (
          ((n = t.memoizedState),
          e === null ||
            (e.memoizedState !== null && e.memoizedState.dehydrated !== null))
        ) {
          if (((r = Un(t)), n !== null && n.dehydrated !== null)) {
            if (e === null) {
              if (!r) throw Error(o(318));
              if (
                ((r = t.memoizedState),
                (r = r !== null ? r.dehydrated : null),
                !r)
              )
                throw Error(o(317));
              r[at] = t;
            } else
              (Hn(),
                (t.flags & 128) === 0 && (t.memoizedState = null),
                (t.flags |= 4));
            (He(t), (r = !1));
          } else
            ((r = rf()),
              e !== null &&
                e.memoizedState !== null &&
                (e.memoizedState.hydrationErrors = r),
              (r = !0));
          if (!r) return t.flags & 256 ? (cl(t), t) : (cl(t), null);
        }
        if ((cl(t), (t.flags & 128) !== 0)) return ((t.lanes = l), t);
        if (
          ((l = n !== null), (e = e !== null && e.memoizedState !== null), l)
        ) {
          ((n = t.child),
            (r = null),
            n.alternate !== null &&
              n.alternate.memoizedState !== null &&
              n.alternate.memoizedState.cachePool !== null &&
              (r = n.alternate.memoizedState.cachePool.pool));
          var u = null;
          (n.memoizedState !== null &&
            n.memoizedState.cachePool !== null &&
            (u = n.memoizedState.cachePool.pool),
            u !== r && (n.flags |= 2048));
        }
        return (
          l !== e && l && (t.child.flags |= 8192),
          wi(t, t.updateQueue),
          He(t),
          null
        );
      case 4:
        return (Ae(), e === null && Co(t.stateNode.containerInfo), He(t), null);
      case 10:
        return (il(t.type), He(t), null);
      case 19:
        if ((J(Ze), (r = t.memoizedState), r === null)) return (He(t), null);
        if (((n = (t.flags & 128) !== 0), (u = r.rendering), u === null))
          if (n) In(r, !1);
          else {
            if (qe !== 0 || (e !== null && (e.flags & 128) !== 0))
              for (e = t.child; e !== null; ) {
                if (((u = gi(e)), u !== null)) {
                  for (
                    t.flags |= 128,
                      In(r, !1),
                      e = u.updateQueue,
                      t.updateQueue = e,
                      wi(t, e),
                      t.subtreeFlags = 0,
                      e = l,
                      l = t.child;
                    l !== null;
                  )
                    (lf(l, e), (l = l.sibling));
                  return (P(Ze, (Ze.current & 1) | 2), t.child);
                }
                e = e.sibling;
              }
            r.tail !== null &&
              Qt() > Ti &&
              ((t.flags |= 128), (n = !0), In(r, !1), (t.lanes = 4194304));
          }
        else {
          if (!n)
            if (((e = gi(u)), e !== null)) {
              if (
                ((t.flags |= 128),
                (n = !0),
                (e = e.updateQueue),
                (t.updateQueue = e),
                wi(t, e),
                In(r, !0),
                r.tail === null &&
                  r.tailMode === "hidden" &&
                  !u.alternate &&
                  !Ee)
              )
                return (He(t), null);
            } else
              2 * Qt() - r.renderingStartTime > Ti &&
                l !== 536870912 &&
                ((t.flags |= 128), (n = !0), In(r, !1), (t.lanes = 4194304));
          r.isBackwards
            ? ((u.sibling = t.child), (t.child = u))
            : ((e = r.last),
              e !== null ? (e.sibling = u) : (t.child = u),
              (r.last = u));
        }
        return r.tail !== null
          ? ((t = r.tail),
            (r.rendering = t),
            (r.tail = t.sibling),
            (r.renderingStartTime = Qt()),
            (t.sibling = null),
            (e = Ze.current),
            P(Ze, n ? (e & 1) | 2 : e & 1),
            t)
          : (He(t), null);
      case 22:
      case 23:
        return (
          cl(t),
          Oc(),
          (n = t.memoizedState !== null),
          e !== null
            ? (e.memoizedState !== null) !== n && (t.flags |= 8192)
            : n && (t.flags |= 8192),
          n
            ? (l & 536870912) !== 0 &&
              (t.flags & 128) === 0 &&
              (He(t), t.subtreeFlags & 6 && (t.flags |= 8192))
            : He(t),
          (l = t.updateQueue),
          l !== null && wi(t, l.retryQueue),
          (l = null),
          e !== null &&
            e.memoizedState !== null &&
            e.memoizedState.cachePool !== null &&
            (l = e.memoizedState.cachePool.pool),
          (n = null),
          t.memoizedState !== null &&
            t.memoizedState.cachePool !== null &&
            (n = t.memoizedState.cachePool.pool),
          n !== l && (t.flags |= 2048),
          e !== null && J(ma),
          null
        );
      case 24:
        return (
          (l = null),
          e !== null && (l = e.memoizedState.cache),
          t.memoizedState.cache !== l && (t.flags |= 2048),
          il(Qe),
          He(t),
          null
        );
      case 25:
        return null;
      case 30:
        return null;
    }
    throw Error(o(156, t.tag));
  }
  function Qg(e, t) {
    switch ((xc(t), t.tag)) {
      case 1:
        return (
          (e = t.flags),
          e & 65536 ? ((t.flags = (e & -65537) | 128), t) : null
        );
      case 3:
        return (
          il(Qe),
          Ae(),
          (e = t.flags),
          (e & 65536) !== 0 && (e & 128) === 0
            ? ((t.flags = (e & -65537) | 128), t)
            : null
        );
      case 26:
      case 27:
      case 5:
        return (zt(t), null);
      case 13:
        if (
          (cl(t), (e = t.memoizedState), e !== null && e.dehydrated !== null)
        ) {
          if (t.alternate === null) throw Error(o(340));
          Hn();
        }
        return (
          (e = t.flags),
          e & 65536 ? ((t.flags = (e & -65537) | 128), t) : null
        );
      case 19:
        return (J(Ze), null);
      case 4:
        return (Ae(), null);
      case 10:
        return (il(t.type), null);
      case 22:
      case 23:
        return (
          cl(t),
          Oc(),
          e !== null && J(ma),
          (e = t.flags),
          e & 65536 ? ((t.flags = (e & -65537) | 128), t) : null
        );
      case 24:
        return (il(Qe), null);
      case 25:
        return null;
      default:
        return null;
    }
  }
  function Rh(e, t) {
    switch ((xc(t), t.tag)) {
      case 3:
        (il(Qe), Ae());
        break;
      case 26:
      case 27:
      case 5:
        zt(t);
        break;
      case 4:
        Ae();
        break;
      case 13:
        cl(t);
        break;
      case 19:
        J(Ze);
        break;
      case 10:
        il(t.type);
        break;
      case 22:
      case 23:
        (cl(t), Oc(), e !== null && J(ma));
        break;
      case 24:
        il(Qe);
    }
  }
  function es(e, t) {
    try {
      var l = t.updateQueue,
        n = l !== null ? l.lastEffect : null;
      if (n !== null) {
        var r = n.next;
        l = r;
        do {
          if ((l.tag & e) === e) {
            n = void 0;
            var u = l.create,
              m = l.inst;
            ((n = u()), (m.destroy = n));
          }
          l = l.next;
        } while (l !== r);
      }
    } catch (g) {
      ke(t, t.return, g);
    }
  }
  function Dl(e, t, l) {
    try {
      var n = t.updateQueue,
        r = n !== null ? n.lastEffect : null;
      if (r !== null) {
        var u = r.next;
        n = u;
        do {
          if ((n.tag & e) === e) {
            var m = n.inst,
              g = m.destroy;
            if (g !== void 0) {
              ((m.destroy = void 0), (r = t));
              var N = l,
                M = g;
              try {
                M();
              } catch (U) {
                ke(r, N, U);
              }
            }
          }
          n = n.next;
        } while (n !== u);
      }
    } catch (U) {
      ke(t, t.return, U);
    }
  }
  function Mh(e) {
    var t = e.updateQueue;
    if (t !== null) {
      var l = e.stateNode;
      try {
        gf(t, l);
      } catch (n) {
        ke(e, e.return, n);
      }
    }
  }
  function _h(e, t, l) {
    ((l.props = pa(e.type, e.memoizedProps)), (l.state = e.memoizedState));
    try {
      l.componentWillUnmount();
    } catch (n) {
      ke(e, t, n);
    }
  }
  function ts(e, t) {
    try {
      var l = e.ref;
      if (l !== null) {
        switch (e.tag) {
          case 26:
          case 27:
          case 5:
            var n = e.stateNode;
            break;
          case 30:
            n = e.stateNode;
            break;
          default:
            n = e.stateNode;
        }
        typeof l == "function" ? (e.refCleanup = l(n)) : (l.current = n);
      }
    } catch (r) {
      ke(e, t, r);
    }
  }
  function Pt(e, t) {
    var l = e.ref,
      n = e.refCleanup;
    if (l !== null)
      if (typeof n == "function")
        try {
          n();
        } catch (r) {
          ke(e, t, r);
        } finally {
          ((e.refCleanup = null),
            (e = e.alternate),
            e != null && (e.refCleanup = null));
        }
      else if (typeof l == "function")
        try {
          l(null);
        } catch (r) {
          ke(e, t, r);
        }
      else l.current = null;
  }
  function kh(e) {
    var t = e.type,
      l = e.memoizedProps,
      n = e.stateNode;
    try {
      e: switch (t) {
        case "button":
        case "input":
        case "select":
        case "textarea":
          l.autoFocus && n.focus();
          break e;
        case "img":
          l.src ? (n.src = l.src) : l.srcSet && (n.srcset = l.srcSet);
      }
    } catch (r) {
      ke(e, e.return, r);
    }
  }
  function ao(e, t, l) {
    try {
      var n = e.stateNode;
      (fv(n, e.type, l, t), (n[ct] = t));
    } catch (r) {
      ke(e, e.return, r);
    }
  }
  function Dh(e) {
    return (
      e.tag === 5 ||
      e.tag === 3 ||
      e.tag === 26 ||
      (e.tag === 27 && Yl(e.type)) ||
      e.tag === 4
    );
  }
  function no(e) {
    e: for (;;) {
      for (; e.sibling === null; ) {
        if (e.return === null || Dh(e.return)) return null;
        e = e.return;
      }
      for (
        e.sibling.return = e.return, e = e.sibling;
        e.tag !== 5 && e.tag !== 6 && e.tag !== 18;
      ) {
        if (
          (e.tag === 27 && Yl(e.type)) ||
          e.flags & 2 ||
          e.child === null ||
          e.tag === 4
        )
          continue e;
        ((e.child.return = e), (e = e.child));
      }
      if (!(e.flags & 2)) return e.stateNode;
    }
  }
  function so(e, t, l) {
    var n = e.tag;
    if (n === 5 || n === 6)
      ((e = e.stateNode),
        t
          ? (l.nodeType === 9
              ? l.body
              : l.nodeName === "HTML"
                ? l.ownerDocument.body
                : l
            ).insertBefore(e, t)
          : ((t =
              l.nodeType === 9
                ? l.body
                : l.nodeName === "HTML"
                  ? l.ownerDocument.body
                  : l),
            t.appendChild(e),
            (l = l._reactRootContainer),
            l != null || t.onclick !== null || (t.onclick = zi)));
    else if (
      n !== 4 &&
      (n === 27 && Yl(e.type) && ((l = e.stateNode), (t = null)),
      (e = e.child),
      e !== null)
    )
      for (so(e, t, l), e = e.sibling; e !== null; )
        (so(e, t, l), (e = e.sibling));
  }
  function Si(e, t, l) {
    var n = e.tag;
    if (n === 5 || n === 6)
      ((e = e.stateNode), t ? l.insertBefore(e, t) : l.appendChild(e));
    else if (
      n !== 4 &&
      (n === 27 && Yl(e.type) && (l = e.stateNode), (e = e.child), e !== null)
    )
      for (Si(e, t, l), e = e.sibling; e !== null; )
        (Si(e, t, l), (e = e.sibling));
  }
  function zh(e) {
    var t = e.stateNode,
      l = e.memoizedProps;
    try {
      for (var n = e.type, r = t.attributes; r.length; )
        t.removeAttributeNode(r[0]);
      (lt(t, n, l), (t[at] = e), (t[ct] = l));
    } catch (u) {
      ke(e, e.return, u);
    }
  }
  var dl = !1,
    Ge = !1,
    io = !1,
    Uh = typeof WeakSet == "function" ? WeakSet : Set,
    We = null;
  function Zg(e, t) {
    if (((e = e.containerInfo), (Mo = Yi), (e = Zd(e)), nc(e))) {
      if ("selectionStart" in e)
        var l = { start: e.selectionStart, end: e.selectionEnd };
      else
        e: {
          l = ((l = e.ownerDocument) && l.defaultView) || window;
          var n = l.getSelection && l.getSelection();
          if (n && n.rangeCount !== 0) {
            l = n.anchorNode;
            var r = n.anchorOffset,
              u = n.focusNode;
            n = n.focusOffset;
            try {
              (l.nodeType, u.nodeType);
            } catch {
              l = null;
              break e;
            }
            var m = 0,
              g = -1,
              N = -1,
              M = 0,
              U = 0,
              L = e,
              D = null;
            t: for (;;) {
              for (
                var z;
                L !== l || (r !== 0 && L.nodeType !== 3) || (g = m + r),
                  L !== u || (n !== 0 && L.nodeType !== 3) || (N = m + n),
                  L.nodeType === 3 && (m += L.nodeValue.length),
                  (z = L.firstChild) !== null;
              )
                ((D = L), (L = z));
              for (;;) {
                if (L === e) break t;
                if (
                  (D === l && ++M === r && (g = m),
                  D === u && ++U === n && (N = m),
                  (z = L.nextSibling) !== null)
                )
                  break;
                ((L = D), (D = L.parentNode));
              }
              L = z;
            }
            l = g === -1 || N === -1 ? null : { start: g, end: N };
          } else l = null;
        }
      l = l || { start: 0, end: 0 };
    } else l = null;
    for (
      _o = { focusedElem: e, selectionRange: l }, Yi = !1, We = t;
      We !== null;
    )
      if (
        ((t = We), (e = t.child), (t.subtreeFlags & 1024) !== 0 && e !== null)
      )
        ((e.return = t), (We = e));
      else
        for (; We !== null; ) {
          switch (((t = We), (u = t.alternate), (e = t.flags), t.tag)) {
            case 0:
              break;
            case 11:
            case 15:
              break;
            case 1:
              if ((e & 1024) !== 0 && u !== null) {
                ((e = void 0),
                  (l = t),
                  (r = u.memoizedProps),
                  (u = u.memoizedState),
                  (n = l.stateNode));
                try {
                  var de = pa(l.type, r, l.elementType === l.type);
                  ((e = n.getSnapshotBeforeUpdate(de, u)),
                    (n.__reactInternalSnapshotBeforeUpdate = e));
                } catch (re) {
                  ke(l, l.return, re);
                }
              }
              break;
            case 3:
              if ((e & 1024) !== 0) {
                if (
                  ((e = t.stateNode.containerInfo), (l = e.nodeType), l === 9)
                )
                  zo(e);
                else if (l === 1)
                  switch (e.nodeName) {
                    case "HEAD":
                    case "HTML":
                    case "BODY":
                      zo(e);
                      break;
                    default:
                      e.textContent = "";
                  }
              }
              break;
            case 5:
            case 26:
            case 27:
            case 6:
            case 4:
            case 17:
              break;
            default:
              if ((e & 1024) !== 0) throw Error(o(163));
          }
          if (((e = t.sibling), e !== null)) {
            ((e.return = t.return), (We = e));
            break;
          }
          We = t.return;
        }
  }
  function Hh(e, t, l) {
    var n = l.flags;
    switch (l.tag) {
      case 0:
      case 11:
      case 15:
        (zl(e, l), n & 4 && es(5, l));
        break;
      case 1:
        if ((zl(e, l), n & 4))
          if (((e = l.stateNode), t === null))
            try {
              e.componentDidMount();
            } catch (m) {
              ke(l, l.return, m);
            }
          else {
            var r = pa(l.type, t.memoizedProps);
            t = t.memoizedState;
            try {
              e.componentDidUpdate(r, t, e.__reactInternalSnapshotBeforeUpdate);
            } catch (m) {
              ke(l, l.return, m);
            }
          }
        (n & 64 && Mh(l), n & 512 && ts(l, l.return));
        break;
      case 3:
        if ((zl(e, l), n & 64 && ((e = l.updateQueue), e !== null))) {
          if (((t = null), l.child !== null))
            switch (l.child.tag) {
              case 27:
              case 5:
                t = l.child.stateNode;
                break;
              case 1:
                t = l.child.stateNode;
            }
          try {
            gf(e, t);
          } catch (m) {
            ke(l, l.return, m);
          }
        }
        break;
      case 27:
        t === null && n & 4 && zh(l);
      case 26:
      case 5:
        (zl(e, l), t === null && n & 4 && kh(l), n & 512 && ts(l, l.return));
        break;
      case 12:
        zl(e, l);
        break;
      case 13:
        (zl(e, l),
          n & 4 && Bh(e, l),
          n & 64 &&
            ((e = l.memoizedState),
            e !== null &&
              ((e = e.dehydrated),
              e !== null && ((l = tv.bind(null, l)), vv(e, l)))));
        break;
      case 22:
        if (((n = l.memoizedState !== null || dl), !n)) {
          ((t = (t !== null && t.memoizedState !== null) || Ge), (r = dl));
          var u = Ge;
          ((dl = n),
            (Ge = t) && !u ? Ul(e, l, (l.subtreeFlags & 8772) !== 0) : zl(e, l),
            (dl = r),
            (Ge = u));
        }
        break;
      case 30:
        break;
      default:
        zl(e, l);
    }
  }
  function Lh(e) {
    var t = e.alternate;
    (t !== null && ((e.alternate = null), Lh(t)),
      (e.child = null),
      (e.deletions = null),
      (e.sibling = null),
      e.tag === 5 && ((t = e.stateNode), t !== null && qr(t)),
      (e.stateNode = null),
      (e.return = null),
      (e.dependencies = null),
      (e.memoizedProps = null),
      (e.memoizedState = null),
      (e.pendingProps = null),
      (e.stateNode = null),
      (e.updateQueue = null));
  }
  var Ue = null,
    dt = !1;
  function fl(e, t, l) {
    for (l = l.child; l !== null; ) (qh(e, t, l), (l = l.sibling));
  }
  function qh(e, t, l) {
    if (mt && typeof mt.onCommitFiberUnmount == "function")
      try {
        mt.onCommitFiberUnmount(Nn, l);
      } catch {}
    switch (l.tag) {
      case 26:
        (Ge || Pt(l, t),
          fl(e, t, l),
          l.memoizedState
            ? l.memoizedState.count--
            : l.stateNode && ((l = l.stateNode), l.parentNode.removeChild(l)));
        break;
      case 27:
        Ge || Pt(l, t);
        var n = Ue,
          r = dt;
        (Yl(l.type) && ((Ue = l.stateNode), (dt = !1)),
          fl(e, t, l),
          us(l.stateNode),
          (Ue = n),
          (dt = r));
        break;
      case 5:
        Ge || Pt(l, t);
      case 6:
        if (
          ((n = Ue),
          (r = dt),
          (Ue = null),
          fl(e, t, l),
          (Ue = n),
          (dt = r),
          Ue !== null)
        )
          if (dt)
            try {
              (Ue.nodeType === 9
                ? Ue.body
                : Ue.nodeName === "HTML"
                  ? Ue.ownerDocument.body
                  : Ue
              ).removeChild(l.stateNode);
            } catch (u) {
              ke(l, t, u);
            }
          else
            try {
              Ue.removeChild(l.stateNode);
            } catch (u) {
              ke(l, t, u);
            }
        break;
      case 18:
        Ue !== null &&
          (dt
            ? ((e = Ue),
              A0(
                e.nodeType === 9
                  ? e.body
                  : e.nodeName === "HTML"
                    ? e.ownerDocument.body
                    : e,
                l.stateNode,
              ),
              gs(e))
            : A0(Ue, l.stateNode));
        break;
      case 4:
        ((n = Ue),
          (r = dt),
          (Ue = l.stateNode.containerInfo),
          (dt = !0),
          fl(e, t, l),
          (Ue = n),
          (dt = r));
        break;
      case 0:
      case 11:
      case 14:
      case 15:
        (Ge || Dl(2, l, t), Ge || Dl(4, l, t), fl(e, t, l));
        break;
      case 1:
        (Ge ||
          (Pt(l, t),
          (n = l.stateNode),
          typeof n.componentWillUnmount == "function" && _h(l, t, n)),
          fl(e, t, l));
        break;
      case 21:
        fl(e, t, l);
        break;
      case 22:
        ((Ge = (n = Ge) || l.memoizedState !== null), fl(e, t, l), (Ge = n));
        break;
      default:
        fl(e, t, l);
    }
  }
  function Bh(e, t) {
    if (
      t.memoizedState === null &&
      ((e = t.alternate),
      e !== null &&
        ((e = e.memoizedState), e !== null && ((e = e.dehydrated), e !== null)))
    )
      try {
        gs(e);
      } catch (l) {
        ke(t, t.return, l);
      }
  }
  function Kg(e) {
    switch (e.tag) {
      case 13:
      case 19:
        var t = e.stateNode;
        return (t === null && (t = e.stateNode = new Uh()), t);
      case 22:
        return (
          (e = e.stateNode),
          (t = e._retryCache),
          t === null && (t = e._retryCache = new Uh()),
          t
        );
      default:
        throw Error(o(435, e.tag));
    }
  }
  function ro(e, t) {
    var l = Kg(e);
    t.forEach(function (n) {
      var r = lv.bind(null, e, n);
      l.has(n) || (l.add(n), n.then(r, r));
    });
  }
  function gt(e, t) {
    var l = t.deletions;
    if (l !== null)
      for (var n = 0; n < l.length; n++) {
        var r = l[n],
          u = e,
          m = t,
          g = m;
        e: for (; g !== null; ) {
          switch (g.tag) {
            case 27:
              if (Yl(g.type)) {
                ((Ue = g.stateNode), (dt = !1));
                break e;
              }
              break;
            case 5:
              ((Ue = g.stateNode), (dt = !1));
              break e;
            case 3:
            case 4:
              ((Ue = g.stateNode.containerInfo), (dt = !0));
              break e;
          }
          g = g.return;
        }
        if (Ue === null) throw Error(o(160));
        (qh(u, m, r),
          (Ue = null),
          (dt = !1),
          (u = r.alternate),
          u !== null && (u.return = null),
          (r.return = null));
      }
    if (t.subtreeFlags & 13878)
      for (t = t.child; t !== null; ) (Gh(t, e), (t = t.sibling));
  }
  var Ht = null;
  function Gh(e, t) {
    var l = e.alternate,
      n = e.flags;
    switch (e.tag) {
      case 0:
      case 11:
      case 14:
      case 15:
        (gt(t, e),
          vt(e),
          n & 4 && (Dl(3, e, e.return), es(3, e), Dl(5, e, e.return)));
        break;
      case 1:
        (gt(t, e),
          vt(e),
          n & 512 && (Ge || l === null || Pt(l, l.return)),
          n & 64 &&
            dl &&
            ((e = e.updateQueue),
            e !== null &&
              ((n = e.callbacks),
              n !== null &&
                ((l = e.shared.hiddenCallbacks),
                (e.shared.hiddenCallbacks = l === null ? n : l.concat(n))))));
        break;
      case 26:
        var r = Ht;
        if (
          (gt(t, e),
          vt(e),
          n & 512 && (Ge || l === null || Pt(l, l.return)),
          n & 4)
        ) {
          var u = l !== null ? l.memoizedState : null;
          if (((n = e.memoizedState), l === null))
            if (n === null)
              if (e.stateNode === null) {
                e: {
                  ((n = e.type),
                    (l = e.memoizedProps),
                    (r = r.ownerDocument || r));
                  t: switch (n) {
                    case "title":
                      ((u = r.getElementsByTagName("title")[0]),
                        (!u ||
                          u[En] ||
                          u[at] ||
                          u.namespaceURI === "http://www.w3.org/2000/svg" ||
                          u.hasAttribute("itemprop")) &&
                          ((u = r.createElement(n)),
                          r.head.insertBefore(
                            u,
                            r.querySelector("head > title"),
                          )),
                        lt(u, n, l),
                        (u[at] = e),
                        Je(u),
                        (n = u));
                      break e;
                    case "link":
                      var m = z0("link", "href", r).get(n + (l.href || ""));
                      if (m) {
                        for (var g = 0; g < m.length; g++)
                          if (
                            ((u = m[g]),
                            u.getAttribute("href") ===
                              (l.href == null || l.href === ""
                                ? null
                                : l.href) &&
                              u.getAttribute("rel") ===
                                (l.rel == null ? null : l.rel) &&
                              u.getAttribute("title") ===
                                (l.title == null ? null : l.title) &&
                              u.getAttribute("crossorigin") ===
                                (l.crossOrigin == null ? null : l.crossOrigin))
                          ) {
                            m.splice(g, 1);
                            break t;
                          }
                      }
                      ((u = r.createElement(n)),
                        lt(u, n, l),
                        r.head.appendChild(u));
                      break;
                    case "meta":
                      if (
                        (m = z0("meta", "content", r).get(
                          n + (l.content || ""),
                        ))
                      ) {
                        for (g = 0; g < m.length; g++)
                          if (
                            ((u = m[g]),
                            u.getAttribute("content") ===
                              (l.content == null ? null : "" + l.content) &&
                              u.getAttribute("name") ===
                                (l.name == null ? null : l.name) &&
                              u.getAttribute("property") ===
                                (l.property == null ? null : l.property) &&
                              u.getAttribute("http-equiv") ===
                                (l.httpEquiv == null ? null : l.httpEquiv) &&
                              u.getAttribute("charset") ===
                                (l.charSet == null ? null : l.charSet))
                          ) {
                            m.splice(g, 1);
                            break t;
                          }
                      }
                      ((u = r.createElement(n)),
                        lt(u, n, l),
                        r.head.appendChild(u));
                      break;
                    default:
                      throw Error(o(468, n));
                  }
                  ((u[at] = e), Je(u), (n = u));
                }
                e.stateNode = n;
              } else U0(r, e.type, e.stateNode);
            else e.stateNode = D0(r, n, e.memoizedProps);
          else
            u !== n
              ? (u === null
                  ? l.stateNode !== null &&
                    ((l = l.stateNode), l.parentNode.removeChild(l))
                  : u.count--,
                n === null
                  ? U0(r, e.type, e.stateNode)
                  : D0(r, n, e.memoizedProps))
              : n === null &&
                e.stateNode !== null &&
                ao(e, e.memoizedProps, l.memoizedProps);
        }
        break;
      case 27:
        (gt(t, e),
          vt(e),
          n & 512 && (Ge || l === null || Pt(l, l.return)),
          l !== null && n & 4 && ao(e, e.memoizedProps, l.memoizedProps));
        break;
      case 5:
        if (
          (gt(t, e),
          vt(e),
          n & 512 && (Ge || l === null || Pt(l, l.return)),
          e.flags & 32)
        ) {
          r = e.stateNode;
          try {
            ka(r, "");
          } catch (z) {
            ke(e, e.return, z);
          }
        }
        (n & 4 &&
          e.stateNode != null &&
          ((r = e.memoizedProps), ao(e, r, l !== null ? l.memoizedProps : r)),
          n & 1024 && (io = !0));
        break;
      case 6:
        if ((gt(t, e), vt(e), n & 4)) {
          if (e.stateNode === null) throw Error(o(162));
          ((n = e.memoizedProps), (l = e.stateNode));
          try {
            l.nodeValue = n;
          } catch (z) {
            ke(e, e.return, z);
          }
        }
        break;
      case 3:
        if (
          ((qi = null),
          (r = Ht),
          (Ht = Hi(t.containerInfo)),
          gt(t, e),
          (Ht = r),
          vt(e),
          n & 4 && l !== null && l.memoizedState.isDehydrated)
        )
          try {
            gs(t.containerInfo);
          } catch (z) {
            ke(e, e.return, z);
          }
        io && ((io = !1), Yh(e));
        break;
      case 4:
        ((n = Ht),
          (Ht = Hi(e.stateNode.containerInfo)),
          gt(t, e),
          vt(e),
          (Ht = n));
        break;
      case 12:
        (gt(t, e), vt(e));
        break;
      case 13:
        (gt(t, e),
          vt(e),
          e.child.flags & 8192 &&
            (e.memoizedState !== null) !=
              (l !== null && l.memoizedState !== null) &&
            (mo = Qt()),
          n & 4 &&
            ((n = e.updateQueue),
            n !== null && ((e.updateQueue = null), ro(e, n))));
        break;
      case 22:
        r = e.memoizedState !== null;
        var N = l !== null && l.memoizedState !== null,
          M = dl,
          U = Ge;
        if (
          ((dl = M || r),
          (Ge = U || N),
          gt(t, e),
          (Ge = U),
          (dl = M),
          vt(e),
          n & 8192)
        )
          e: for (
            t = e.stateNode,
              t._visibility = r ? t._visibility & -2 : t._visibility | 1,
              r && (l === null || N || dl || Ge || ba(e)),
              l = null,
              t = e;
            ;
          ) {
            if (t.tag === 5 || t.tag === 26) {
              if (l === null) {
                N = l = t;
                try {
                  if (((u = N.stateNode), r))
                    ((m = u.style),
                      typeof m.setProperty == "function"
                        ? m.setProperty("display", "none", "important")
                        : (m.display = "none"));
                  else {
                    g = N.stateNode;
                    var L = N.memoizedProps.style,
                      D =
                        L != null && L.hasOwnProperty("display")
                          ? L.display
                          : null;
                    g.style.display =
                      D == null || typeof D == "boolean" ? "" : ("" + D).trim();
                  }
                } catch (z) {
                  ke(N, N.return, z);
                }
              }
            } else if (t.tag === 6) {
              if (l === null) {
                N = t;
                try {
                  N.stateNode.nodeValue = r ? "" : N.memoizedProps;
                } catch (z) {
                  ke(N, N.return, z);
                }
              }
            } else if (
              ((t.tag !== 22 && t.tag !== 23) ||
                t.memoizedState === null ||
                t === e) &&
              t.child !== null
            ) {
              ((t.child.return = t), (t = t.child));
              continue;
            }
            if (t === e) break e;
            for (; t.sibling === null; ) {
              if (t.return === null || t.return === e) break e;
              (l === t && (l = null), (t = t.return));
            }
            (l === t && (l = null),
              (t.sibling.return = t.return),
              (t = t.sibling));
          }
        n & 4 &&
          ((n = e.updateQueue),
          n !== null &&
            ((l = n.retryQueue),
            l !== null && ((n.retryQueue = null), ro(e, l))));
        break;
      case 19:
        (gt(t, e),
          vt(e),
          n & 4 &&
            ((n = e.updateQueue),
            n !== null && ((e.updateQueue = null), ro(e, n))));
        break;
      case 30:
        break;
      case 21:
        break;
      default:
        (gt(t, e), vt(e));
    }
  }
  function vt(e) {
    var t = e.flags;
    if (t & 2) {
      try {
        for (var l, n = e.return; n !== null; ) {
          if (Dh(n)) {
            l = n;
            break;
          }
          n = n.return;
        }
        if (l == null) throw Error(o(160));
        switch (l.tag) {
          case 27:
            var r = l.stateNode,
              u = no(e);
            Si(e, u, r);
            break;
          case 5:
            var m = l.stateNode;
            l.flags & 32 && (ka(m, ""), (l.flags &= -33));
            var g = no(e);
            Si(e, g, m);
            break;
          case 3:
          case 4:
            var N = l.stateNode.containerInfo,
              M = no(e);
            so(e, M, N);
            break;
          default:
            throw Error(o(161));
        }
      } catch (U) {
        ke(e, e.return, U);
      }
      e.flags &= -3;
    }
    t & 4096 && (e.flags &= -4097);
  }
  function Yh(e) {
    if (e.subtreeFlags & 1024)
      for (e = e.child; e !== null; ) {
        var t = e;
        (Yh(t),
          t.tag === 5 && t.flags & 1024 && t.stateNode.reset(),
          (e = e.sibling));
      }
  }
  function zl(e, t) {
    if (t.subtreeFlags & 8772)
      for (t = t.child; t !== null; ) (Hh(e, t.alternate, t), (t = t.sibling));
  }
  function ba(e) {
    for (e = e.child; e !== null; ) {
      var t = e;
      switch (t.tag) {
        case 0:
        case 11:
        case 14:
        case 15:
          (Dl(4, t, t.return), ba(t));
          break;
        case 1:
          Pt(t, t.return);
          var l = t.stateNode;
          (typeof l.componentWillUnmount == "function" && _h(t, t.return, l),
            ba(t));
          break;
        case 27:
          us(t.stateNode);
        case 26:
        case 5:
          (Pt(t, t.return), ba(t));
          break;
        case 22:
          t.memoizedState === null && ba(t);
          break;
        case 30:
          ba(t);
          break;
        default:
          ba(t);
      }
      e = e.sibling;
    }
  }
  function Ul(e, t, l) {
    for (l = l && (t.subtreeFlags & 8772) !== 0, t = t.child; t !== null; ) {
      var n = t.alternate,
        r = e,
        u = t,
        m = u.flags;
      switch (u.tag) {
        case 0:
        case 11:
        case 15:
          (Ul(r, u, l), es(4, u));
          break;
        case 1:
          if (
            (Ul(r, u, l),
            (n = u),
            (r = n.stateNode),
            typeof r.componentDidMount == "function")
          )
            try {
              r.componentDidMount();
            } catch (M) {
              ke(n, n.return, M);
            }
          if (((n = u), (r = n.updateQueue), r !== null)) {
            var g = n.stateNode;
            try {
              var N = r.shared.hiddenCallbacks;
              if (N !== null)
                for (r.shared.hiddenCallbacks = null, r = 0; r < N.length; r++)
                  bf(N[r], g);
            } catch (M) {
              ke(n, n.return, M);
            }
          }
          (l && m & 64 && Mh(u), ts(u, u.return));
          break;
        case 27:
          zh(u);
        case 26:
        case 5:
          (Ul(r, u, l), l && n === null && m & 4 && kh(u), ts(u, u.return));
          break;
        case 12:
          Ul(r, u, l);
          break;
        case 13:
          (Ul(r, u, l), l && m & 4 && Bh(r, u));
          break;
        case 22:
          (u.memoizedState === null && Ul(r, u, l), ts(u, u.return));
          break;
        case 30:
          break;
        default:
          Ul(r, u, l);
      }
      t = t.sibling;
    }
  }
  function co(e, t) {
    var l = null;
    (e !== null &&
      e.memoizedState !== null &&
      e.memoizedState.cachePool !== null &&
      (l = e.memoizedState.cachePool.pool),
      (e = null),
      t.memoizedState !== null &&
        t.memoizedState.cachePool !== null &&
        (e = t.memoizedState.cachePool.pool),
      e !== l && (e != null && e.refCount++, l != null && Bn(l)));
  }
  function oo(e, t) {
    ((e = null),
      t.alternate !== null && (e = t.alternate.memoizedState.cache),
      (t = t.memoizedState.cache),
      t !== e && (t.refCount++, e != null && Bn(e)));
  }
  function $t(e, t, l, n) {
    if (t.subtreeFlags & 10256)
      for (t = t.child; t !== null; ) (Vh(e, t, l, n), (t = t.sibling));
  }
  function Vh(e, t, l, n) {
    var r = t.flags;
    switch (t.tag) {
      case 0:
      case 11:
      case 15:
        ($t(e, t, l, n), r & 2048 && es(9, t));
        break;
      case 1:
        $t(e, t, l, n);
        break;
      case 3:
        ($t(e, t, l, n),
          r & 2048 &&
            ((e = null),
            t.alternate !== null && (e = t.alternate.memoizedState.cache),
            (t = t.memoizedState.cache),
            t !== e && (t.refCount++, e != null && Bn(e))));
        break;
      case 12:
        if (r & 2048) {
          ($t(e, t, l, n), (e = t.stateNode));
          try {
            var u = t.memoizedProps,
              m = u.id,
              g = u.onPostCommit;
            typeof g == "function" &&
              g(
                m,
                t.alternate === null ? "mount" : "update",
                e.passiveEffectDuration,
                -0,
              );
          } catch (N) {
            ke(t, t.return, N);
          }
        } else $t(e, t, l, n);
        break;
      case 13:
        $t(e, t, l, n);
        break;
      case 23:
        break;
      case 22:
        ((u = t.stateNode),
          (m = t.alternate),
          t.memoizedState !== null
            ? u._visibility & 2
              ? $t(e, t, l, n)
              : ls(e, t)
            : u._visibility & 2
              ? $t(e, t, l, n)
              : ((u._visibility |= 2),
                Wa(e, t, l, n, (t.subtreeFlags & 10256) !== 0)),
          r & 2048 && co(m, t));
        break;
      case 24:
        ($t(e, t, l, n), r & 2048 && oo(t.alternate, t));
        break;
      default:
        $t(e, t, l, n);
    }
  }
  function Wa(e, t, l, n, r) {
    for (r = r && (t.subtreeFlags & 10256) !== 0, t = t.child; t !== null; ) {
      var u = e,
        m = t,
        g = l,
        N = n,
        M = m.flags;
      switch (m.tag) {
        case 0:
        case 11:
        case 15:
          (Wa(u, m, g, N, r), es(8, m));
          break;
        case 23:
          break;
        case 22:
          var U = m.stateNode;
          (m.memoizedState !== null
            ? U._visibility & 2
              ? Wa(u, m, g, N, r)
              : ls(u, m)
            : ((U._visibility |= 2), Wa(u, m, g, N, r)),
            r && M & 2048 && co(m.alternate, m));
          break;
        case 24:
          (Wa(u, m, g, N, r), r && M & 2048 && oo(m.alternate, m));
          break;
        default:
          Wa(u, m, g, N, r);
      }
      t = t.sibling;
    }
  }
  function ls(e, t) {
    if (t.subtreeFlags & 10256)
      for (t = t.child; t !== null; ) {
        var l = e,
          n = t,
          r = n.flags;
        switch (n.tag) {
          case 22:
            (ls(l, n), r & 2048 && co(n.alternate, n));
            break;
          case 24:
            (ls(l, n), r & 2048 && oo(n.alternate, n));
            break;
          default:
            ls(l, n);
        }
        t = t.sibling;
      }
  }
  var as = 8192;
  function Ia(e) {
    if (e.subtreeFlags & as)
      for (e = e.child; e !== null; ) (Xh(e), (e = e.sibling));
  }
  function Xh(e) {
    switch (e.tag) {
      case 26:
        (Ia(e),
          e.flags & as &&
            e.memoizedState !== null &&
            _v(Ht, e.memoizedState, e.memoizedProps));
        break;
      case 5:
        Ia(e);
        break;
      case 3:
      case 4:
        var t = Ht;
        ((Ht = Hi(e.stateNode.containerInfo)), Ia(e), (Ht = t));
        break;
      case 22:
        e.memoizedState === null &&
          ((t = e.alternate),
          t !== null && t.memoizedState !== null
            ? ((t = as), (as = 16777216), Ia(e), (as = t))
            : Ia(e));
        break;
      default:
        Ia(e);
    }
  }
  function Qh(e) {
    var t = e.alternate;
    if (t !== null && ((e = t.child), e !== null)) {
      t.child = null;
      do ((t = e.sibling), (e.sibling = null), (e = t));
      while (e !== null);
    }
  }
  function ns(e) {
    var t = e.deletions;
    if ((e.flags & 16) !== 0) {
      if (t !== null)
        for (var l = 0; l < t.length; l++) {
          var n = t[l];
          ((We = n), Kh(n, e));
        }
      Qh(e);
    }
    if (e.subtreeFlags & 10256)
      for (e = e.child; e !== null; ) (Zh(e), (e = e.sibling));
  }
  function Zh(e) {
    switch (e.tag) {
      case 0:
      case 11:
      case 15:
        (ns(e), e.flags & 2048 && Dl(9, e, e.return));
        break;
      case 3:
        ns(e);
        break;
      case 12:
        ns(e);
        break;
      case 22:
        var t = e.stateNode;
        e.memoizedState !== null &&
        t._visibility & 2 &&
        (e.return === null || e.return.tag !== 13)
          ? ((t._visibility &= -3), Ei(e))
          : ns(e);
        break;
      default:
        ns(e);
    }
  }
  function Ei(e) {
    var t = e.deletions;
    if ((e.flags & 16) !== 0) {
      if (t !== null)
        for (var l = 0; l < t.length; l++) {
          var n = t[l];
          ((We = n), Kh(n, e));
        }
      Qh(e);
    }
    for (e = e.child; e !== null; ) {
      switch (((t = e), t.tag)) {
        case 0:
        case 11:
        case 15:
          (Dl(8, t, t.return), Ei(t));
          break;
        case 22:
          ((l = t.stateNode),
            l._visibility & 2 && ((l._visibility &= -3), Ei(t)));
          break;
        default:
          Ei(t);
      }
      e = e.sibling;
    }
  }
  function Kh(e, t) {
    for (; We !== null; ) {
      var l = We;
      switch (l.tag) {
        case 0:
        case 11:
        case 15:
          Dl(8, l, t);
          break;
        case 23:
        case 22:
          if (l.memoizedState !== null && l.memoizedState.cachePool !== null) {
            var n = l.memoizedState.cachePool.pool;
            n != null && n.refCount++;
          }
          break;
        case 24:
          Bn(l.memoizedState.cache);
      }
      if (((n = l.child), n !== null)) ((n.return = l), (We = n));
      else
        e: for (l = e; We !== null; ) {
          n = We;
          var r = n.sibling,
            u = n.return;
          if ((Lh(n), n === l)) {
            We = null;
            break e;
          }
          if (r !== null) {
            ((r.return = u), (We = r));
            break e;
          }
          We = u;
        }
    }
  }
  var Pg = {
      getCacheForType: function (e) {
        var t = nt(Qe),
          l = t.data.get(e);
        return (l === void 0 && ((l = e()), t.data.set(e, l)), l);
      },
    },
    $g = typeof WeakMap == "function" ? WeakMap : Map,
    Ce = 0,
    De = null,
    ve = null,
    Ne = 0,
    Oe = 0,
    yt = null,
    Hl = !1,
    en = !1,
    uo = !1,
    hl = 0,
    qe = 0,
    Ll = 0,
    ga = 0,
    fo = 0,
    kt = 0,
    tn = 0,
    ss = null,
    ft = null,
    ho = !1,
    mo = 0,
    Ti = 1 / 0,
    Ai = null,
    ql = null,
    tt = 0,
    Bl = null,
    ln = null,
    an = 0,
    xo = 0,
    po = null,
    Ph = null,
    is = 0,
    bo = null;
  function jt() {
    if ((Ce & 2) !== 0 && Ne !== 0) return Ne & -Ne;
    if (O.T !== null) {
      var e = Xa;
      return e !== 0 ? e : So();
    }
    return od();
  }
  function $h() {
    kt === 0 && (kt = (Ne & 536870912) === 0 || Ee ? sd() : 536870912);
    var e = _t.current;
    return (e !== null && (e.flags |= 32), kt);
  }
  function Nt(e, t, l) {
    (((e === De && (Oe === 2 || Oe === 9)) || e.cancelPendingCommit !== null) &&
      (nn(e, 0), Gl(e, Ne, kt, !1)),
      Sn(e, l),
      ((Ce & 2) === 0 || e !== De) &&
        (e === De &&
          ((Ce & 2) === 0 && (ga |= l), qe === 4 && Gl(e, Ne, kt, !1)),
        Jt(e)));
  }
  function Jh(e, t, l) {
    if ((Ce & 6) !== 0) throw Error(o(327));
    var n = (!l && (t & 124) === 0 && (t & e.expiredLanes) === 0) || wn(e, t),
      r = n ? Wg(e, t) : yo(e, t, !0),
      u = n;
    do {
      if (r === 0) {
        en && !n && Gl(e, t, 0, !1);
        break;
      } else {
        if (((l = e.current.alternate), u && !Jg(l))) {
          ((r = yo(e, t, !1)), (u = !1));
          continue;
        }
        if (r === 2) {
          if (((u = t), e.errorRecoveryDisabledLanes & u)) var m = 0;
          else
            ((m = e.pendingLanes & -536870913),
              (m = m !== 0 ? m : m & 536870912 ? 536870912 : 0));
          if (m !== 0) {
            t = m;
            e: {
              var g = e;
              r = ss;
              var N = g.current.memoizedState.isDehydrated;
              if ((N && (nn(g, m).flags |= 256), (m = yo(g, m, !1)), m !== 2)) {
                if (uo && !N) {
                  ((g.errorRecoveryDisabledLanes |= u), (ga |= u), (r = 4));
                  break e;
                }
                ((u = ft),
                  (ft = r),
                  u !== null &&
                    (ft === null ? (ft = u) : ft.push.apply(ft, u)));
              }
              r = m;
            }
            if (((u = !1), r !== 2)) continue;
          }
        }
        if (r === 1) {
          (nn(e, 0), Gl(e, t, 0, !0));
          break;
        }
        e: {
          switch (((n = e), (u = r), u)) {
            case 0:
            case 1:
              throw Error(o(345));
            case 4:
              if ((t & 4194048) !== t) break;
            case 6:
              Gl(n, t, kt, !Hl);
              break e;
            case 2:
              ft = null;
              break;
            case 3:
            case 5:
              break;
            default:
              throw Error(o(329));
          }
          if ((t & 62914560) === t && ((r = mo + 300 - Qt()), 10 < r)) {
            if ((Gl(n, t, kt, !Hl), Ls(n, 0, !0) !== 0)) break e;
            n.timeoutHandle = E0(
              Fh.bind(null, n, l, ft, Ai, ho, t, kt, ga, tn, Hl, u, 2, -0, 0),
              r,
            );
            break e;
          }
          Fh(n, l, ft, Ai, ho, t, kt, ga, tn, Hl, u, 0, -0, 0);
        }
      }
      break;
    } while (!0);
    Jt(e);
  }
  function Fh(e, t, l, n, r, u, m, g, N, M, U, L, D, z) {
    if (
      ((e.timeoutHandle = -1),
      (L = t.subtreeFlags),
      (L & 8192 || (L & 16785408) === 16785408) &&
        ((hs = { stylesheets: null, count: 0, unsuspend: Mv }),
        Xh(t),
        (L = kv()),
        L !== null))
    ) {
      ((e.cancelPendingCommit = L(
        n0.bind(null, e, t, u, l, n, r, m, g, N, U, 1, D, z),
      )),
        Gl(e, u, m, !M));
      return;
    }
    n0(e, t, u, l, n, r, m, g, N);
  }
  function Jg(e) {
    for (var t = e; ; ) {
      var l = t.tag;
      if (
        (l === 0 || l === 11 || l === 15) &&
        t.flags & 16384 &&
        ((l = t.updateQueue), l !== null && ((l = l.stores), l !== null))
      )
        for (var n = 0; n < l.length; n++) {
          var r = l[n],
            u = r.getSnapshot;
          r = r.value;
          try {
            if (!pt(u(), r)) return !1;
          } catch {
            return !1;
          }
        }
      if (((l = t.child), t.subtreeFlags & 16384 && l !== null))
        ((l.return = t), (t = l));
      else {
        if (t === e) break;
        for (; t.sibling === null; ) {
          if (t.return === null || t.return === e) return !0;
          t = t.return;
        }
        ((t.sibling.return = t.return), (t = t.sibling));
      }
    }
    return !0;
  }
  function Gl(e, t, l, n) {
    ((t &= ~fo),
      (t &= ~ga),
      (e.suspendedLanes |= t),
      (e.pingedLanes &= ~t),
      n && (e.warmLanes |= t),
      (n = e.expirationTimes));
    for (var r = t; 0 < r; ) {
      var u = 31 - xt(r),
        m = 1 << u;
      ((n[u] = -1), (r &= ~m));
    }
    l !== 0 && rd(e, l, t);
  }
  function Ci() {
    return (Ce & 6) === 0 ? (rs(0), !1) : !0;
  }
  function go() {
    if (ve !== null) {
      if (Oe === 0) var e = ve.return;
      else ((e = ve), (sl = fa = null), Dc(e), (Ja = null), (Fn = 0), (e = ve));
      for (; e !== null; ) (Rh(e.alternate, e), (e = e.return));
      ve = null;
    }
  }
  function nn(e, t) {
    var l = e.timeoutHandle;
    (l !== -1 && ((e.timeoutHandle = -1), mv(l)),
      (l = e.cancelPendingCommit),
      l !== null && ((e.cancelPendingCommit = null), l()),
      go(),
      (De = e),
      (ve = l = ll(e.current, null)),
      (Ne = t),
      (Oe = 0),
      (yt = null),
      (Hl = !1),
      (en = wn(e, t)),
      (uo = !1),
      (tn = kt = fo = ga = Ll = qe = 0),
      (ft = ss = null),
      (ho = !1),
      (t & 8) !== 0 && (t |= t & 32));
    var n = e.entangledLanes;
    if (n !== 0)
      for (e = e.entanglements, n &= t; 0 < n; ) {
        var r = 31 - xt(n),
          u = 1 << r;
        ((t |= e[r]), (n &= ~u));
      }
    return ((hl = t), Js(), l);
  }
  function Wh(e, t) {
    ((xe = null),
      (O.H = xi),
      t === Yn || t === si
        ? ((t = xf()), (Oe = 3))
        : t === ff
          ? ((t = xf()), (Oe = 4))
          : (Oe =
              t === ph
                ? 8
                : t !== null &&
                    typeof t == "object" &&
                    typeof t.then == "function"
                  ? 6
                  : 1),
      (yt = t),
      ve === null && ((qe = 1), yi(e, Ct(t, e.current))));
  }
  function Ih() {
    var e = O.H;
    return ((O.H = xi), e === null ? xi : e);
  }
  function e0() {
    var e = O.A;
    return ((O.A = Pg), e);
  }
  function vo() {
    ((qe = 4),
      Hl || ((Ne & 4194048) !== Ne && _t.current !== null) || (en = !0),
      ((Ll & 134217727) === 0 && (ga & 134217727) === 0) ||
        De === null ||
        Gl(De, Ne, kt, !1));
  }
  function yo(e, t, l) {
    var n = Ce;
    Ce |= 2;
    var r = Ih(),
      u = e0();
    ((De !== e || Ne !== t) && ((Ai = null), nn(e, t)), (t = !1));
    var m = qe;
    e: do
      try {
        if (Oe !== 0 && ve !== null) {
          var g = ve,
            N = yt;
          switch (Oe) {
            case 8:
              (go(), (m = 6));
              break e;
            case 3:
            case 2:
            case 9:
            case 6:
              _t.current === null && (t = !0);
              var M = Oe;
              if (((Oe = 0), (yt = null), sn(e, g, N, M), l && en)) {
                m = 0;
                break e;
              }
              break;
            default:
              ((M = Oe), (Oe = 0), (yt = null), sn(e, g, N, M));
          }
        }
        (Fg(), (m = qe));
        break;
      } catch (U) {
        Wh(e, U);
      }
    while (!0);
    return (
      t && e.shellSuspendCounter++,
      (sl = fa = null),
      (Ce = n),
      (O.H = r),
      (O.A = u),
      ve === null && ((De = null), (Ne = 0), Js()),
      m
    );
  }
  function Fg() {
    for (; ve !== null; ) t0(ve);
  }
  function Wg(e, t) {
    var l = Ce;
    Ce |= 2;
    var n = Ih(),
      r = e0();
    De !== e || Ne !== t
      ? ((Ai = null), (Ti = Qt() + 500), nn(e, t))
      : (en = wn(e, t));
    e: do
      try {
        if (Oe !== 0 && ve !== null) {
          t = ve;
          var u = yt;
          t: switch (Oe) {
            case 1:
              ((Oe = 0), (yt = null), sn(e, t, u, 1));
              break;
            case 2:
            case 9:
              if (hf(u)) {
                ((Oe = 0), (yt = null), l0(t));
                break;
              }
              ((t = function () {
                ((Oe !== 2 && Oe !== 9) || De !== e || (Oe = 7), Jt(e));
              }),
                u.then(t, t));
              break e;
            case 3:
              Oe = 7;
              break e;
            case 4:
              Oe = 5;
              break e;
            case 7:
              hf(u)
                ? ((Oe = 0), (yt = null), l0(t))
                : ((Oe = 0), (yt = null), sn(e, t, u, 7));
              break;
            case 5:
              var m = null;
              switch (ve.tag) {
                case 26:
                  m = ve.memoizedState;
                case 5:
                case 27:
                  var g = ve;
                  if (!m || H0(m)) {
                    ((Oe = 0), (yt = null));
                    var N = g.sibling;
                    if (N !== null) ve = N;
                    else {
                      var M = g.return;
                      M !== null ? ((ve = M), Oi(M)) : (ve = null);
                    }
                    break t;
                  }
              }
              ((Oe = 0), (yt = null), sn(e, t, u, 5));
              break;
            case 6:
              ((Oe = 0), (yt = null), sn(e, t, u, 6));
              break;
            case 8:
              (go(), (qe = 6));
              break e;
            default:
              throw Error(o(462));
          }
        }
        Ig();
        break;
      } catch (U) {
        Wh(e, U);
      }
    while (!0);
    return (
      (sl = fa = null),
      (O.H = n),
      (O.A = r),
      (Ce = l),
      ve !== null ? 0 : ((De = null), (Ne = 0), Js(), qe)
    );
  }
  function Ig() {
    for (; ve !== null && !jb(); ) t0(ve);
  }
  function t0(e) {
    var t = Ch(e.alternate, e, hl);
    ((e.memoizedProps = e.pendingProps), t === null ? Oi(e) : (ve = t));
  }
  function l0(e) {
    var t = e,
      l = t.alternate;
    switch (t.tag) {
      case 15:
      case 0:
        t = Nh(l, t, t.pendingProps, t.type, void 0, Ne);
        break;
      case 11:
        t = Nh(l, t, t.pendingProps, t.type.render, t.ref, Ne);
        break;
      case 5:
        Dc(t);
      default:
        (Rh(l, t), (t = ve = lf(t, hl)), (t = Ch(l, t, hl)));
    }
    ((e.memoizedProps = e.pendingProps), t === null ? Oi(e) : (ve = t));
  }
  function sn(e, t, l, n) {
    ((sl = fa = null), Dc(t), (Ja = null), (Fn = 0));
    var r = t.return;
    try {
      if (Yg(e, r, t, l, Ne)) {
        ((qe = 1), yi(e, Ct(l, e.current)), (ve = null));
        return;
      }
    } catch (u) {
      if (r !== null) throw ((ve = r), u);
      ((qe = 1), yi(e, Ct(l, e.current)), (ve = null));
      return;
    }
    t.flags & 32768
      ? (Ee || n === 1
          ? (e = !0)
          : en || (Ne & 536870912) !== 0
            ? (e = !1)
            : ((Hl = e = !0),
              (n === 2 || n === 9 || n === 3 || n === 6) &&
                ((n = _t.current),
                n !== null && n.tag === 13 && (n.flags |= 16384))),
        a0(t, e))
      : Oi(t);
  }
  function Oi(e) {
    var t = e;
    do {
      if ((t.flags & 32768) !== 0) {
        a0(t, Hl);
        return;
      }
      e = t.return;
      var l = Xg(t.alternate, t, hl);
      if (l !== null) {
        ve = l;
        return;
      }
      if (((t = t.sibling), t !== null)) {
        ve = t;
        return;
      }
      ve = t = e;
    } while (t !== null);
    qe === 0 && (qe = 5);
  }
  function a0(e, t) {
    do {
      var l = Qg(e.alternate, e);
      if (l !== null) {
        ((l.flags &= 32767), (ve = l));
        return;
      }
      if (
        ((l = e.return),
        l !== null &&
          ((l.flags |= 32768), (l.subtreeFlags = 0), (l.deletions = null)),
        !t && ((e = e.sibling), e !== null))
      ) {
        ve = e;
        return;
      }
      ve = e = l;
    } while (e !== null);
    ((qe = 6), (ve = null));
  }
  function n0(e, t, l, n, r, u, m, g, N) {
    e.cancelPendingCommit = null;
    do Ri();
    while (tt !== 0);
    if ((Ce & 6) !== 0) throw Error(o(327));
    if (t !== null) {
      if (t === e.current) throw Error(o(177));
      if (
        ((u = t.lanes | t.childLanes),
        (u |= oc),
        Mb(e, l, u, m, g, N),
        e === De && ((ve = De = null), (Ne = 0)),
        (ln = t),
        (Bl = e),
        (an = l),
        (xo = u),
        (po = r),
        (Ph = n),
        (t.subtreeFlags & 10256) !== 0 || (t.flags & 10256) !== 0
          ? ((e.callbackNode = null),
            (e.callbackPriority = 0),
            av(zs, function () {
              return (o0(), null);
            }))
          : ((e.callbackNode = null), (e.callbackPriority = 0)),
        (n = (t.flags & 13878) !== 0),
        (t.subtreeFlags & 13878) !== 0 || n)
      ) {
        ((n = O.T), (O.T = null), (r = G.p), (G.p = 2), (m = Ce), (Ce |= 4));
        try {
          Zg(e, t, l);
        } finally {
          ((Ce = m), (G.p = r), (O.T = n));
        }
      }
      ((tt = 1), s0(), i0(), r0());
    }
  }
  function s0() {
    if (tt === 1) {
      tt = 0;
      var e = Bl,
        t = ln,
        l = (t.flags & 13878) !== 0;
      if ((t.subtreeFlags & 13878) !== 0 || l) {
        ((l = O.T), (O.T = null));
        var n = G.p;
        G.p = 2;
        var r = Ce;
        Ce |= 4;
        try {
          Gh(t, e);
          var u = _o,
            m = Zd(e.containerInfo),
            g = u.focusedElem,
            N = u.selectionRange;
          if (
            m !== g &&
            g &&
            g.ownerDocument &&
            Qd(g.ownerDocument.documentElement, g)
          ) {
            if (N !== null && nc(g)) {
              var M = N.start,
                U = N.end;
              if ((U === void 0 && (U = M), "selectionStart" in g))
                ((g.selectionStart = M),
                  (g.selectionEnd = Math.min(U, g.value.length)));
              else {
                var L = g.ownerDocument || document,
                  D = (L && L.defaultView) || window;
                if (D.getSelection) {
                  var z = D.getSelection(),
                    de = g.textContent.length,
                    re = Math.min(N.start, de),
                    _e = N.end === void 0 ? re : Math.min(N.end, de);
                  !z.extend && re > _e && ((m = _e), (_e = re), (re = m));
                  var T = Xd(g, re),
                    S = Xd(g, _e);
                  if (
                    T &&
                    S &&
                    (z.rangeCount !== 1 ||
                      z.anchorNode !== T.node ||
                      z.anchorOffset !== T.offset ||
                      z.focusNode !== S.node ||
                      z.focusOffset !== S.offset)
                  ) {
                    var C = L.createRange();
                    (C.setStart(T.node, T.offset),
                      z.removeAllRanges(),
                      re > _e
                        ? (z.addRange(C), z.extend(S.node, S.offset))
                        : (C.setEnd(S.node, S.offset), z.addRange(C)));
                  }
                }
              }
            }
            for (L = [], z = g; (z = z.parentNode); )
              z.nodeType === 1 &&
                L.push({ element: z, left: z.scrollLeft, top: z.scrollTop });
            for (
              typeof g.focus == "function" && g.focus(), g = 0;
              g < L.length;
              g++
            ) {
              var H = L[g];
              ((H.element.scrollLeft = H.left), (H.element.scrollTop = H.top));
            }
          }
          ((Yi = !!Mo), (_o = Mo = null));
        } finally {
          ((Ce = r), (G.p = n), (O.T = l));
        }
      }
      ((e.current = t), (tt = 2));
    }
  }
  function i0() {
    if (tt === 2) {
      tt = 0;
      var e = Bl,
        t = ln,
        l = (t.flags & 8772) !== 0;
      if ((t.subtreeFlags & 8772) !== 0 || l) {
        ((l = O.T), (O.T = null));
        var n = G.p;
        G.p = 2;
        var r = Ce;
        Ce |= 4;
        try {
          Hh(e, t.alternate, t);
        } finally {
          ((Ce = r), (G.p = n), (O.T = l));
        }
      }
      tt = 3;
    }
  }
  function r0() {
    if (tt === 4 || tt === 3) {
      ((tt = 0), Nb());
      var e = Bl,
        t = ln,
        l = an,
        n = Ph;
      (t.subtreeFlags & 10256) !== 0 || (t.flags & 10256) !== 0
        ? (tt = 5)
        : ((tt = 0), (ln = Bl = null), c0(e, e.pendingLanes));
      var r = e.pendingLanes;
      if (
        (r === 0 && (ql = null),
        Hr(l),
        (t = t.stateNode),
        mt && typeof mt.onCommitFiberRoot == "function")
      )
        try {
          mt.onCommitFiberRoot(Nn, t, void 0, (t.current.flags & 128) === 128);
        } catch {}
      if (n !== null) {
        ((t = O.T), (r = G.p), (G.p = 2), (O.T = null));
        try {
          for (var u = e.onRecoverableError, m = 0; m < n.length; m++) {
            var g = n[m];
            u(g.value, { componentStack: g.stack });
          }
        } finally {
          ((O.T = t), (G.p = r));
        }
      }
      ((an & 3) !== 0 && Ri(),
        Jt(e),
        (r = e.pendingLanes),
        (l & 4194090) !== 0 && (r & 42) !== 0
          ? e === bo
            ? is++
            : ((is = 0), (bo = e))
          : (is = 0),
        rs(0));
    }
  }
  function c0(e, t) {
    (e.pooledCacheLanes &= t) === 0 &&
      ((t = e.pooledCache), t != null && ((e.pooledCache = null), Bn(t)));
  }
  function Ri(e) {
    return (s0(), i0(), r0(), o0());
  }
  function o0() {
    if (tt !== 5) return !1;
    var e = Bl,
      t = xo;
    xo = 0;
    var l = Hr(an),
      n = O.T,
      r = G.p;
    try {
      ((G.p = 32 > l ? 32 : l), (O.T = null), (l = po), (po = null));
      var u = Bl,
        m = an;
      if (((tt = 0), (ln = Bl = null), (an = 0), (Ce & 6) !== 0))
        throw Error(o(331));
      var g = Ce;
      if (
        ((Ce |= 4),
        Zh(u.current),
        Vh(u, u.current, m, l),
        (Ce = g),
        rs(0, !1),
        mt && typeof mt.onPostCommitFiberRoot == "function")
      )
        try {
          mt.onPostCommitFiberRoot(Nn, u);
        } catch {}
      return !0;
    } finally {
      ((G.p = r), (O.T = n), c0(e, t));
    }
  }
  function u0(e, t, l) {
    ((t = Ct(l, t)),
      (t = Pc(e.stateNode, t, 2)),
      (e = Rl(e, t, 2)),
      e !== null && (Sn(e, 2), Jt(e)));
  }
  function ke(e, t, l) {
    if (e.tag === 3) u0(e, e, l);
    else
      for (; t !== null; ) {
        if (t.tag === 3) {
          u0(t, e, l);
          break;
        } else if (t.tag === 1) {
          var n = t.stateNode;
          if (
            typeof t.type.getDerivedStateFromError == "function" ||
            (typeof n.componentDidCatch == "function" &&
              (ql === null || !ql.has(n)))
          ) {
            ((e = Ct(l, e)),
              (l = mh(2)),
              (n = Rl(t, l, 2)),
              n !== null && (xh(l, n, t, e), Sn(n, 2), Jt(n)));
            break;
          }
        }
        t = t.return;
      }
  }
  function jo(e, t, l) {
    var n = e.pingCache;
    if (n === null) {
      n = e.pingCache = new $g();
      var r = new Set();
      n.set(t, r);
    } else ((r = n.get(t)), r === void 0 && ((r = new Set()), n.set(t, r)));
    r.has(l) ||
      ((uo = !0), r.add(l), (e = ev.bind(null, e, t, l)), t.then(e, e));
  }
  function ev(e, t, l) {
    var n = e.pingCache;
    (n !== null && n.delete(t),
      (e.pingedLanes |= e.suspendedLanes & l),
      (e.warmLanes &= ~l),
      De === e &&
        (Ne & l) === l &&
        (qe === 4 || (qe === 3 && (Ne & 62914560) === Ne && 300 > Qt() - mo)
          ? (Ce & 2) === 0 && nn(e, 0)
          : (fo |= l),
        tn === Ne && (tn = 0)),
      Jt(e));
  }
  function d0(e, t) {
    (t === 0 && (t = id()), (e = Ba(e, t)), e !== null && (Sn(e, t), Jt(e)));
  }
  function tv(e) {
    var t = e.memoizedState,
      l = 0;
    (t !== null && (l = t.retryLane), d0(e, l));
  }
  function lv(e, t) {
    var l = 0;
    switch (e.tag) {
      case 13:
        var n = e.stateNode,
          r = e.memoizedState;
        r !== null && (l = r.retryLane);
        break;
      case 19:
        n = e.stateNode;
        break;
      case 22:
        n = e.stateNode._retryCache;
        break;
      default:
        throw Error(o(314));
    }
    (n !== null && n.delete(t), d0(e, l));
  }
  function av(e, t) {
    return Et(e, t);
  }
  var Mi = null,
    rn = null,
    No = !1,
    _i = !1,
    wo = !1,
    va = 0;
  function Jt(e) {
    (e !== rn &&
      e.next === null &&
      (rn === null ? (Mi = rn = e) : (rn = rn.next = e)),
      (_i = !0),
      No || ((No = !0), sv()));
  }
  function rs(e, t) {
    if (!wo && _i) {
      wo = !0;
      do
        for (var l = !1, n = Mi; n !== null; ) {
          if (e !== 0) {
            var r = n.pendingLanes;
            if (r === 0) var u = 0;
            else {
              var m = n.suspendedLanes,
                g = n.pingedLanes;
              ((u = (1 << (31 - xt(42 | e) + 1)) - 1),
                (u &= r & ~(m & ~g)),
                (u = u & 201326741 ? (u & 201326741) | 1 : u ? u | 2 : 0));
            }
            u !== 0 && ((l = !0), x0(n, u));
          } else
            ((u = Ne),
              (u = Ls(
                n,
                n === De ? u : 0,
                n.cancelPendingCommit !== null || n.timeoutHandle !== -1,
              )),
              (u & 3) === 0 || wn(n, u) || ((l = !0), x0(n, u)));
          n = n.next;
        }
      while (l);
      wo = !1;
    }
  }
  function nv() {
    f0();
  }
  function f0() {
    _i = No = !1;
    var e = 0;
    va !== 0 && (hv() && (e = va), (va = 0));
    for (var t = Qt(), l = null, n = Mi; n !== null; ) {
      var r = n.next,
        u = h0(n, t);
      (u === 0
        ? ((n.next = null),
          l === null ? (Mi = r) : (l.next = r),
          r === null && (rn = l))
        : ((l = n), (e !== 0 || (u & 3) !== 0) && (_i = !0)),
        (n = r));
    }
    rs(e);
  }
  function h0(e, t) {
    for (
      var l = e.suspendedLanes,
        n = e.pingedLanes,
        r = e.expirationTimes,
        u = e.pendingLanes & -62914561;
      0 < u;
    ) {
      var m = 31 - xt(u),
        g = 1 << m,
        N = r[m];
      (N === -1
        ? ((g & l) === 0 || (g & n) !== 0) && (r[m] = Rb(g, t))
        : N <= t && (e.expiredLanes |= g),
        (u &= ~g));
    }
    if (
      ((t = De),
      (l = Ne),
      (l = Ls(
        e,
        e === t ? l : 0,
        e.cancelPendingCommit !== null || e.timeoutHandle !== -1,
      )),
      (n = e.callbackNode),
      l === 0 ||
        (e === t && (Oe === 2 || Oe === 9)) ||
        e.cancelPendingCommit !== null)
    )
      return (
        n !== null && n !== null && wl(n),
        (e.callbackNode = null),
        (e.callbackPriority = 0)
      );
    if ((l & 3) === 0 || wn(e, l)) {
      if (((t = l & -l), t === e.callbackPriority)) return t;
      switch ((n !== null && wl(n), Hr(l))) {
        case 2:
        case 8:
          l = ad;
          break;
        case 32:
          l = zs;
          break;
        case 268435456:
          l = nd;
          break;
        default:
          l = zs;
      }
      return (
        (n = m0.bind(null, e)),
        (l = Et(l, n)),
        (e.callbackPriority = t),
        (e.callbackNode = l),
        t
      );
    }
    return (
      n !== null && n !== null && wl(n),
      (e.callbackPriority = 2),
      (e.callbackNode = null),
      2
    );
  }
  function m0(e, t) {
    if (tt !== 0 && tt !== 5)
      return ((e.callbackNode = null), (e.callbackPriority = 0), null);
    var l = e.callbackNode;
    if (Ri() && e.callbackNode !== l) return null;
    var n = Ne;
    return (
      (n = Ls(
        e,
        e === De ? n : 0,
        e.cancelPendingCommit !== null || e.timeoutHandle !== -1,
      )),
      n === 0
        ? null
        : (Jh(e, n, t),
          h0(e, Qt()),
          e.callbackNode != null && e.callbackNode === l
            ? m0.bind(null, e)
            : null)
    );
  }
  function x0(e, t) {
    if (Ri()) return null;
    Jh(e, t, !0);
  }
  function sv() {
    xv(function () {
      (Ce & 6) !== 0 ? Et(ld, nv) : f0();
    });
  }
  function So() {
    return (va === 0 && (va = sd()), va);
  }
  function p0(e) {
    return e == null || typeof e == "symbol" || typeof e == "boolean"
      ? null
      : typeof e == "function"
        ? e
        : Vs("" + e);
  }
  function b0(e, t) {
    var l = t.ownerDocument.createElement("input");
    return (
      (l.name = t.name),
      (l.value = t.value),
      e.id && l.setAttribute("form", e.id),
      t.parentNode.insertBefore(l, t),
      (e = new FormData(e)),
      l.parentNode.removeChild(l),
      e
    );
  }
  function iv(e, t, l, n, r) {
    if (t === "submit" && l && l.stateNode === r) {
      var u = p0((r[ct] || null).action),
        m = n.submitter;
      m &&
        ((t = (t = m[ct] || null)
          ? p0(t.formAction)
          : m.getAttribute("formAction")),
        t !== null && ((u = t), (m = null)));
      var g = new Ks("action", "action", null, n, r);
      e.push({
        event: g,
        listeners: [
          {
            instance: null,
            listener: function () {
              if (n.defaultPrevented) {
                if (va !== 0) {
                  var N = m ? b0(r, m) : new FormData(r);
                  Vc(
                    l,
                    { pending: !0, data: N, method: r.method, action: u },
                    null,
                    N,
                  );
                }
              } else
                typeof u == "function" &&
                  (g.preventDefault(),
                  (N = m ? b0(r, m) : new FormData(r)),
                  Vc(
                    l,
                    { pending: !0, data: N, method: r.method, action: u },
                    u,
                    N,
                  ));
            },
            currentTarget: r,
          },
        ],
      });
    }
  }
  for (var Eo = 0; Eo < cc.length; Eo++) {
    var To = cc[Eo],
      rv = To.toLowerCase(),
      cv = To[0].toUpperCase() + To.slice(1);
    Ut(rv, "on" + cv);
  }
  (Ut($d, "onAnimationEnd"),
    Ut(Jd, "onAnimationIteration"),
    Ut(Fd, "onAnimationStart"),
    Ut("dblclick", "onDoubleClick"),
    Ut("focusin", "onFocus"),
    Ut("focusout", "onBlur"),
    Ut(Eg, "onTransitionRun"),
    Ut(Tg, "onTransitionStart"),
    Ut(Ag, "onTransitionCancel"),
    Ut(Wd, "onTransitionEnd"),
    Ra("onMouseEnter", ["mouseout", "mouseover"]),
    Ra("onMouseLeave", ["mouseout", "mouseover"]),
    Ra("onPointerEnter", ["pointerout", "pointerover"]),
    Ra("onPointerLeave", ["pointerout", "pointerover"]),
    aa(
      "onChange",
      "change click focusin focusout input keydown keyup selectionchange".split(
        " ",
      ),
    ),
    aa(
      "onSelect",
      "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(
        " ",
      ),
    ),
    aa("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]),
    aa(
      "onCompositionEnd",
      "compositionend focusout keydown keypress keyup mousedown".split(" "),
    ),
    aa(
      "onCompositionStart",
      "compositionstart focusout keydown keypress keyup mousedown".split(" "),
    ),
    aa(
      "onCompositionUpdate",
      "compositionupdate focusout keydown keypress keyup mousedown".split(" "),
    ));
  var cs =
      "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(
        " ",
      ),
    ov = new Set(
      "beforetoggle cancel close invalid load scroll scrollend toggle"
        .split(" ")
        .concat(cs),
    );
  function g0(e, t) {
    t = (t & 4) !== 0;
    for (var l = 0; l < e.length; l++) {
      var n = e[l],
        r = n.event;
      n = n.listeners;
      e: {
        var u = void 0;
        if (t)
          for (var m = n.length - 1; 0 <= m; m--) {
            var g = n[m],
              N = g.instance,
              M = g.currentTarget;
            if (((g = g.listener), N !== u && r.isPropagationStopped()))
              break e;
            ((u = g), (r.currentTarget = M));
            try {
              u(r);
            } catch (U) {
              vi(U);
            }
            ((r.currentTarget = null), (u = N));
          }
        else
          for (m = 0; m < n.length; m++) {
            if (
              ((g = n[m]),
              (N = g.instance),
              (M = g.currentTarget),
              (g = g.listener),
              N !== u && r.isPropagationStopped())
            )
              break e;
            ((u = g), (r.currentTarget = M));
            try {
              u(r);
            } catch (U) {
              vi(U);
            }
            ((r.currentTarget = null), (u = N));
          }
      }
    }
  }
  function ye(e, t) {
    var l = t[Lr];
    l === void 0 && (l = t[Lr] = new Set());
    var n = e + "__bubble";
    l.has(n) || (v0(t, e, 2, !1), l.add(n));
  }
  function Ao(e, t, l) {
    var n = 0;
    (t && (n |= 4), v0(l, e, n, t));
  }
  var ki = "_reactListening" + Math.random().toString(36).slice(2);
  function Co(e) {
    if (!e[ki]) {
      ((e[ki] = !0),
        dd.forEach(function (l) {
          l !== "selectionchange" && (ov.has(l) || Ao(l, !1, e), Ao(l, !0, e));
        }));
      var t = e.nodeType === 9 ? e : e.ownerDocument;
      t === null || t[ki] || ((t[ki] = !0), Ao("selectionchange", !1, t));
    }
  }
  function v0(e, t, l, n) {
    switch (V0(t)) {
      case 2:
        var r = Uv;
        break;
      case 8:
        r = Hv;
        break;
      default:
        r = Yo;
    }
    ((l = r.bind(null, t, l, e)),
      (r = void 0),
      !$r ||
        (t !== "touchstart" && t !== "touchmove" && t !== "wheel") ||
        (r = !0),
      n
        ? r !== void 0
          ? e.addEventListener(t, l, { capture: !0, passive: r })
          : e.addEventListener(t, l, !0)
        : r !== void 0
          ? e.addEventListener(t, l, { passive: r })
          : e.addEventListener(t, l, !1));
  }
  function Oo(e, t, l, n, r) {
    var u = n;
    if ((t & 1) === 0 && (t & 2) === 0 && n !== null)
      e: for (;;) {
        if (n === null) return;
        var m = n.tag;
        if (m === 3 || m === 4) {
          var g = n.stateNode.containerInfo;
          if (g === r) break;
          if (m === 4)
            for (m = n.return; m !== null; ) {
              var N = m.tag;
              if ((N === 3 || N === 4) && m.stateNode.containerInfo === r)
                return;
              m = m.return;
            }
          for (; g !== null; ) {
            if (((m = Aa(g)), m === null)) return;
            if (((N = m.tag), N === 5 || N === 6 || N === 26 || N === 27)) {
              n = u = m;
              continue e;
            }
            g = g.parentNode;
          }
        }
        n = n.return;
      }
    Ed(function () {
      var M = u,
        U = Kr(l),
        L = [];
      e: {
        var D = Id.get(e);
        if (D !== void 0) {
          var z = Ks,
            de = e;
          switch (e) {
            case "keypress":
              if (Qs(l) === 0) break e;
            case "keydown":
            case "keyup":
              z = ag;
              break;
            case "focusin":
              ((de = "focus"), (z = Ir));
              break;
            case "focusout":
              ((de = "blur"), (z = Ir));
              break;
            case "beforeblur":
            case "afterblur":
              z = Ir;
              break;
            case "click":
              if (l.button === 2) break e;
            case "auxclick":
            case "dblclick":
            case "mousedown":
            case "mousemove":
            case "mouseup":
            case "mouseout":
            case "mouseover":
            case "contextmenu":
              z = Cd;
              break;
            case "drag":
            case "dragend":
            case "dragenter":
            case "dragexit":
            case "dragleave":
            case "dragover":
            case "dragstart":
            case "drop":
              z = Qb;
              break;
            case "touchcancel":
            case "touchend":
            case "touchmove":
            case "touchstart":
              z = ig;
              break;
            case $d:
            case Jd:
            case Fd:
              z = Pb;
              break;
            case Wd:
              z = cg;
              break;
            case "scroll":
            case "scrollend":
              z = Vb;
              break;
            case "wheel":
              z = ug;
              break;
            case "copy":
            case "cut":
            case "paste":
              z = Jb;
              break;
            case "gotpointercapture":
            case "lostpointercapture":
            case "pointercancel":
            case "pointerdown":
            case "pointermove":
            case "pointerout":
            case "pointerover":
            case "pointerup":
              z = Rd;
              break;
            case "toggle":
            case "beforetoggle":
              z = fg;
          }
          var re = (t & 4) !== 0,
            _e = !re && (e === "scroll" || e === "scrollend"),
            T = re ? (D !== null ? D + "Capture" : null) : D;
          re = [];
          for (var S = M, C; S !== null; ) {
            var H = S;
            if (
              ((C = H.stateNode),
              (H = H.tag),
              (H !== 5 && H !== 26 && H !== 27) ||
                C === null ||
                T === null ||
                ((H = An(S, T)), H != null && re.push(os(S, H, C))),
              _e)
            )
              break;
            S = S.return;
          }
          0 < re.length &&
            ((D = new z(D, de, null, l, U)),
            L.push({ event: D, listeners: re }));
        }
      }
      if ((t & 7) === 0) {
        e: {
          if (
            ((D = e === "mouseover" || e === "pointerover"),
            (z = e === "mouseout" || e === "pointerout"),
            D &&
              l !== Zr &&
              (de = l.relatedTarget || l.fromElement) &&
              (Aa(de) || de[Ta]))
          )
            break e;
          if (
            (z || D) &&
            ((D =
              U.window === U
                ? U
                : (D = U.ownerDocument)
                  ? D.defaultView || D.parentWindow
                  : window),
            z
              ? ((de = l.relatedTarget || l.toElement),
                (z = M),
                (de = de ? Aa(de) : null),
                de !== null &&
                  ((_e = f(de)),
                  (re = de.tag),
                  de !== _e || (re !== 5 && re !== 27 && re !== 6)) &&
                  (de = null))
              : ((z = null), (de = M)),
            z !== de)
          ) {
            if (
              ((re = Cd),
              (H = "onMouseLeave"),
              (T = "onMouseEnter"),
              (S = "mouse"),
              (e === "pointerout" || e === "pointerover") &&
                ((re = Rd),
                (H = "onPointerLeave"),
                (T = "onPointerEnter"),
                (S = "pointer")),
              (_e = z == null ? D : Tn(z)),
              (C = de == null ? D : Tn(de)),
              (D = new re(H, S + "leave", z, l, U)),
              (D.target = _e),
              (D.relatedTarget = C),
              (H = null),
              Aa(U) === M &&
                ((re = new re(T, S + "enter", de, l, U)),
                (re.target = C),
                (re.relatedTarget = _e),
                (H = re)),
              (_e = H),
              z && de)
            )
              t: {
                for (re = z, T = de, S = 0, C = re; C; C = cn(C)) S++;
                for (C = 0, H = T; H; H = cn(H)) C++;
                for (; 0 < S - C; ) ((re = cn(re)), S--);
                for (; 0 < C - S; ) ((T = cn(T)), C--);
                for (; S--; ) {
                  if (re === T || (T !== null && re === T.alternate)) break t;
                  ((re = cn(re)), (T = cn(T)));
                }
                re = null;
              }
            else re = null;
            (z !== null && y0(L, D, z, re, !1),
              de !== null && _e !== null && y0(L, _e, de, re, !0));
          }
        }
        e: {
          if (
            ((D = M ? Tn(M) : window),
            (z = D.nodeName && D.nodeName.toLowerCase()),
            z === "select" || (z === "input" && D.type === "file"))
          )
            var I = Ld;
          else if (Ud(D))
            if (qd) I = Ng;
            else {
              I = yg;
              var be = vg;
            }
          else
            ((z = D.nodeName),
              !z ||
              z.toLowerCase() !== "input" ||
              (D.type !== "checkbox" && D.type !== "radio")
                ? M && Qr(M.elementType) && (I = Ld)
                : (I = jg));
          if (I && (I = I(e, M))) {
            Hd(L, I, l, U);
            break e;
          }
          (be && be(e, D, M),
            e === "focusout" &&
              M &&
              D.type === "number" &&
              M.memoizedProps.value != null &&
              Xr(D, "number", D.value));
        }
        switch (((be = M ? Tn(M) : window), e)) {
          case "focusin":
            (Ud(be) || be.contentEditable === "true") &&
              ((Ha = be), (sc = M), (zn = null));
            break;
          case "focusout":
            zn = sc = Ha = null;
            break;
          case "mousedown":
            ic = !0;
            break;
          case "contextmenu":
          case "mouseup":
          case "dragend":
            ((ic = !1), Kd(L, l, U));
            break;
          case "selectionchange":
            if (Sg) break;
          case "keydown":
          case "keyup":
            Kd(L, l, U);
        }
        var ne;
        if (tc)
          e: {
            switch (e) {
              case "compositionstart":
                var oe = "onCompositionStart";
                break e;
              case "compositionend":
                oe = "onCompositionEnd";
                break e;
              case "compositionupdate":
                oe = "onCompositionUpdate";
                break e;
            }
            oe = void 0;
          }
        else
          Ua
            ? Dd(e, l) && (oe = "onCompositionEnd")
            : e === "keydown" &&
              l.keyCode === 229 &&
              (oe = "onCompositionStart");
        (oe &&
          (Md &&
            l.locale !== "ko" &&
            (Ua || oe !== "onCompositionStart"
              ? oe === "onCompositionEnd" && Ua && (ne = Td())
              : ((Tl = U),
                (Jr = "value" in Tl ? Tl.value : Tl.textContent),
                (Ua = !0))),
          (be = Di(M, oe)),
          0 < be.length &&
            ((oe = new Od(oe, e, null, l, U)),
            L.push({ event: oe, listeners: be }),
            ne
              ? (oe.data = ne)
              : ((ne = zd(l)), ne !== null && (oe.data = ne)))),
          (ne = mg ? xg(e, l) : pg(e, l)) &&
            ((oe = Di(M, "onBeforeInput")),
            0 < oe.length &&
              ((be = new Od("onBeforeInput", "beforeinput", null, l, U)),
              L.push({ event: be, listeners: oe }),
              (be.data = ne))),
          iv(L, e, M, l, U));
      }
      g0(L, t);
    });
  }
  function os(e, t, l) {
    return { instance: e, listener: t, currentTarget: l };
  }
  function Di(e, t) {
    for (var l = t + "Capture", n = []; e !== null; ) {
      var r = e,
        u = r.stateNode;
      if (
        ((r = r.tag),
        (r !== 5 && r !== 26 && r !== 27) ||
          u === null ||
          ((r = An(e, l)),
          r != null && n.unshift(os(e, r, u)),
          (r = An(e, t)),
          r != null && n.push(os(e, r, u))),
        e.tag === 3)
      )
        return n;
      e = e.return;
    }
    return [];
  }
  function cn(e) {
    if (e === null) return null;
    do e = e.return;
    while (e && e.tag !== 5 && e.tag !== 27);
    return e || null;
  }
  function y0(e, t, l, n, r) {
    for (var u = t._reactName, m = []; l !== null && l !== n; ) {
      var g = l,
        N = g.alternate,
        M = g.stateNode;
      if (((g = g.tag), N !== null && N === n)) break;
      ((g !== 5 && g !== 26 && g !== 27) ||
        M === null ||
        ((N = M),
        r
          ? ((M = An(l, u)), M != null && m.unshift(os(l, M, N)))
          : r || ((M = An(l, u)), M != null && m.push(os(l, M, N)))),
        (l = l.return));
    }
    m.length !== 0 && e.push({ event: t, listeners: m });
  }
  var uv = /\r\n?/g,
    dv = /\u0000|\uFFFD/g;
  function j0(e) {
    return (typeof e == "string" ? e : "" + e)
      .replace(
        uv,
        `
`,
      )
      .replace(dv, "");
  }
  function N0(e, t) {
    return ((t = j0(t)), j0(e) === t);
  }
  function zi() {}
  function Me(e, t, l, n, r, u) {
    switch (l) {
      case "children":
        typeof n == "string"
          ? t === "body" || (t === "textarea" && n === "") || ka(e, n)
          : (typeof n == "number" || typeof n == "bigint") &&
            t !== "body" &&
            ka(e, "" + n);
        break;
      case "className":
        Bs(e, "class", n);
        break;
      case "tabIndex":
        Bs(e, "tabindex", n);
        break;
      case "dir":
      case "role":
      case "viewBox":
      case "width":
      case "height":
        Bs(e, l, n);
        break;
      case "style":
        wd(e, n, u);
        break;
      case "data":
        if (t !== "object") {
          Bs(e, "data", n);
          break;
        }
      case "src":
      case "href":
        if (n === "" && (t !== "a" || l !== "href")) {
          e.removeAttribute(l);
          break;
        }
        if (
          n == null ||
          typeof n == "function" ||
          typeof n == "symbol" ||
          typeof n == "boolean"
        ) {
          e.removeAttribute(l);
          break;
        }
        ((n = Vs("" + n)), e.setAttribute(l, n));
        break;
      case "action":
      case "formAction":
        if (typeof n == "function") {
          e.setAttribute(
            l,
            "javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')",
          );
          break;
        } else
          typeof u == "function" &&
            (l === "formAction"
              ? (t !== "input" && Me(e, t, "name", r.name, r, null),
                Me(e, t, "formEncType", r.formEncType, r, null),
                Me(e, t, "formMethod", r.formMethod, r, null),
                Me(e, t, "formTarget", r.formTarget, r, null))
              : (Me(e, t, "encType", r.encType, r, null),
                Me(e, t, "method", r.method, r, null),
                Me(e, t, "target", r.target, r, null)));
        if (n == null || typeof n == "symbol" || typeof n == "boolean") {
          e.removeAttribute(l);
          break;
        }
        ((n = Vs("" + n)), e.setAttribute(l, n));
        break;
      case "onClick":
        n != null && (e.onclick = zi);
        break;
      case "onScroll":
        n != null && ye("scroll", e);
        break;
      case "onScrollEnd":
        n != null && ye("scrollend", e);
        break;
      case "dangerouslySetInnerHTML":
        if (n != null) {
          if (typeof n != "object" || !("__html" in n)) throw Error(o(61));
          if (((l = n.__html), l != null)) {
            if (r.children != null) throw Error(o(60));
            e.innerHTML = l;
          }
        }
        break;
      case "multiple":
        e.multiple = n && typeof n != "function" && typeof n != "symbol";
        break;
      case "muted":
        e.muted = n && typeof n != "function" && typeof n != "symbol";
        break;
      case "suppressContentEditableWarning":
      case "suppressHydrationWarning":
      case "defaultValue":
      case "defaultChecked":
      case "innerHTML":
      case "ref":
        break;
      case "autoFocus":
        break;
      case "xlinkHref":
        if (
          n == null ||
          typeof n == "function" ||
          typeof n == "boolean" ||
          typeof n == "symbol"
        ) {
          e.removeAttribute("xlink:href");
          break;
        }
        ((l = Vs("" + n)),
          e.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", l));
        break;
      case "contentEditable":
      case "spellCheck":
      case "draggable":
      case "value":
      case "autoReverse":
      case "externalResourcesRequired":
      case "focusable":
      case "preserveAlpha":
        n != null && typeof n != "function" && typeof n != "symbol"
          ? e.setAttribute(l, "" + n)
          : e.removeAttribute(l);
        break;
      case "inert":
      case "allowFullScreen":
      case "async":
      case "autoPlay":
      case "controls":
      case "default":
      case "defer":
      case "disabled":
      case "disablePictureInPicture":
      case "disableRemotePlayback":
      case "formNoValidate":
      case "hidden":
      case "loop":
      case "noModule":
      case "noValidate":
      case "open":
      case "playsInline":
      case "readOnly":
      case "required":
      case "reversed":
      case "scoped":
      case "seamless":
      case "itemScope":
        n && typeof n != "function" && typeof n != "symbol"
          ? e.setAttribute(l, "")
          : e.removeAttribute(l);
        break;
      case "capture":
      case "download":
        n === !0
          ? e.setAttribute(l, "")
          : n !== !1 &&
              n != null &&
              typeof n != "function" &&
              typeof n != "symbol"
            ? e.setAttribute(l, n)
            : e.removeAttribute(l);
        break;
      case "cols":
      case "rows":
      case "size":
      case "span":
        n != null &&
        typeof n != "function" &&
        typeof n != "symbol" &&
        !isNaN(n) &&
        1 <= n
          ? e.setAttribute(l, n)
          : e.removeAttribute(l);
        break;
      case "rowSpan":
      case "start":
        n == null || typeof n == "function" || typeof n == "symbol" || isNaN(n)
          ? e.removeAttribute(l)
          : e.setAttribute(l, n);
        break;
      case "popover":
        (ye("beforetoggle", e), ye("toggle", e), qs(e, "popover", n));
        break;
      case "xlinkActuate":
        el(e, "http://www.w3.org/1999/xlink", "xlink:actuate", n);
        break;
      case "xlinkArcrole":
        el(e, "http://www.w3.org/1999/xlink", "xlink:arcrole", n);
        break;
      case "xlinkRole":
        el(e, "http://www.w3.org/1999/xlink", "xlink:role", n);
        break;
      case "xlinkShow":
        el(e, "http://www.w3.org/1999/xlink", "xlink:show", n);
        break;
      case "xlinkTitle":
        el(e, "http://www.w3.org/1999/xlink", "xlink:title", n);
        break;
      case "xlinkType":
        el(e, "http://www.w3.org/1999/xlink", "xlink:type", n);
        break;
      case "xmlBase":
        el(e, "http://www.w3.org/XML/1998/namespace", "xml:base", n);
        break;
      case "xmlLang":
        el(e, "http://www.w3.org/XML/1998/namespace", "xml:lang", n);
        break;
      case "xmlSpace":
        el(e, "http://www.w3.org/XML/1998/namespace", "xml:space", n);
        break;
      case "is":
        qs(e, "is", n);
        break;
      case "innerText":
      case "textContent":
        break;
      default:
        (!(2 < l.length) ||
          (l[0] !== "o" && l[0] !== "O") ||
          (l[1] !== "n" && l[1] !== "N")) &&
          ((l = Gb.get(l) || l), qs(e, l, n));
    }
  }
  function Ro(e, t, l, n, r, u) {
    switch (l) {
      case "style":
        wd(e, n, u);
        break;
      case "dangerouslySetInnerHTML":
        if (n != null) {
          if (typeof n != "object" || !("__html" in n)) throw Error(o(61));
          if (((l = n.__html), l != null)) {
            if (r.children != null) throw Error(o(60));
            e.innerHTML = l;
          }
        }
        break;
      case "children":
        typeof n == "string"
          ? ka(e, n)
          : (typeof n == "number" || typeof n == "bigint") && ka(e, "" + n);
        break;
      case "onScroll":
        n != null && ye("scroll", e);
        break;
      case "onScrollEnd":
        n != null && ye("scrollend", e);
        break;
      case "onClick":
        n != null && (e.onclick = zi);
        break;
      case "suppressContentEditableWarning":
      case "suppressHydrationWarning":
      case "innerHTML":
      case "ref":
        break;
      case "innerText":
      case "textContent":
        break;
      default:
        if (!fd.hasOwnProperty(l))
          e: {
            if (
              l[0] === "o" &&
              l[1] === "n" &&
              ((r = l.endsWith("Capture")),
              (t = l.slice(2, r ? l.length - 7 : void 0)),
              (u = e[ct] || null),
              (u = u != null ? u[l] : null),
              typeof u == "function" && e.removeEventListener(t, u, r),
              typeof n == "function")
            ) {
              (typeof u != "function" &&
                u !== null &&
                (l in e
                  ? (e[l] = null)
                  : e.hasAttribute(l) && e.removeAttribute(l)),
                e.addEventListener(t, n, r));
              break e;
            }
            l in e
              ? (e[l] = n)
              : n === !0
                ? e.setAttribute(l, "")
                : qs(e, l, n);
          }
    }
  }
  function lt(e, t, l) {
    switch (t) {
      case "div":
      case "span":
      case "svg":
      case "path":
      case "a":
      case "g":
      case "p":
      case "li":
        break;
      case "img":
        (ye("error", e), ye("load", e));
        var n = !1,
          r = !1,
          u;
        for (u in l)
          if (l.hasOwnProperty(u)) {
            var m = l[u];
            if (m != null)
              switch (u) {
                case "src":
                  n = !0;
                  break;
                case "srcSet":
                  r = !0;
                  break;
                case "children":
                case "dangerouslySetInnerHTML":
                  throw Error(o(137, t));
                default:
                  Me(e, t, u, m, l, null);
              }
          }
        (r && Me(e, t, "srcSet", l.srcSet, l, null),
          n && Me(e, t, "src", l.src, l, null));
        return;
      case "input":
        ye("invalid", e);
        var g = (u = m = r = null),
          N = null,
          M = null;
        for (n in l)
          if (l.hasOwnProperty(n)) {
            var U = l[n];
            if (U != null)
              switch (n) {
                case "name":
                  r = U;
                  break;
                case "type":
                  m = U;
                  break;
                case "checked":
                  N = U;
                  break;
                case "defaultChecked":
                  M = U;
                  break;
                case "value":
                  u = U;
                  break;
                case "defaultValue":
                  g = U;
                  break;
                case "children":
                case "dangerouslySetInnerHTML":
                  if (U != null) throw Error(o(137, t));
                  break;
                default:
                  Me(e, t, n, U, l, null);
              }
          }
        (vd(e, u, g, N, M, m, r, !1), Gs(e));
        return;
      case "select":
        (ye("invalid", e), (n = m = u = null));
        for (r in l)
          if (l.hasOwnProperty(r) && ((g = l[r]), g != null))
            switch (r) {
              case "value":
                u = g;
                break;
              case "defaultValue":
                m = g;
                break;
              case "multiple":
                n = g;
              default:
                Me(e, t, r, g, l, null);
            }
        ((t = u),
          (l = m),
          (e.multiple = !!n),
          t != null ? _a(e, !!n, t, !1) : l != null && _a(e, !!n, l, !0));
        return;
      case "textarea":
        (ye("invalid", e), (u = r = n = null));
        for (m in l)
          if (l.hasOwnProperty(m) && ((g = l[m]), g != null))
            switch (m) {
              case "value":
                n = g;
                break;
              case "defaultValue":
                r = g;
                break;
              case "children":
                u = g;
                break;
              case "dangerouslySetInnerHTML":
                if (g != null) throw Error(o(91));
                break;
              default:
                Me(e, t, m, g, l, null);
            }
        (jd(e, n, r, u), Gs(e));
        return;
      case "option":
        for (N in l)
          l.hasOwnProperty(N) &&
            ((n = l[N]), n != null) &&
            (N === "selected"
              ? (e.selected =
                  n && typeof n != "function" && typeof n != "symbol")
              : Me(e, t, N, n, l, null));
        return;
      case "dialog":
        (ye("beforetoggle", e),
          ye("toggle", e),
          ye("cancel", e),
          ye("close", e));
        break;
      case "iframe":
      case "object":
        ye("load", e);
        break;
      case "video":
      case "audio":
        for (n = 0; n < cs.length; n++) ye(cs[n], e);
        break;
      case "image":
        (ye("error", e), ye("load", e));
        break;
      case "details":
        ye("toggle", e);
        break;
      case "embed":
      case "source":
      case "link":
        (ye("error", e), ye("load", e));
      case "area":
      case "base":
      case "br":
      case "col":
      case "hr":
      case "keygen":
      case "meta":
      case "param":
      case "track":
      case "wbr":
      case "menuitem":
        for (M in l)
          if (l.hasOwnProperty(M) && ((n = l[M]), n != null))
            switch (M) {
              case "children":
              case "dangerouslySetInnerHTML":
                throw Error(o(137, t));
              default:
                Me(e, t, M, n, l, null);
            }
        return;
      default:
        if (Qr(t)) {
          for (U in l)
            l.hasOwnProperty(U) &&
              ((n = l[U]), n !== void 0 && Ro(e, t, U, n, l, void 0));
          return;
        }
    }
    for (g in l)
      l.hasOwnProperty(g) && ((n = l[g]), n != null && Me(e, t, g, n, l, null));
  }
  function fv(e, t, l, n) {
    switch (t) {
      case "div":
      case "span":
      case "svg":
      case "path":
      case "a":
      case "g":
      case "p":
      case "li":
        break;
      case "input":
        var r = null,
          u = null,
          m = null,
          g = null,
          N = null,
          M = null,
          U = null;
        for (z in l) {
          var L = l[z];
          if (l.hasOwnProperty(z) && L != null)
            switch (z) {
              case "checked":
                break;
              case "value":
                break;
              case "defaultValue":
                N = L;
              default:
                n.hasOwnProperty(z) || Me(e, t, z, null, n, L);
            }
        }
        for (var D in n) {
          var z = n[D];
          if (((L = l[D]), n.hasOwnProperty(D) && (z != null || L != null)))
            switch (D) {
              case "type":
                u = z;
                break;
              case "name":
                r = z;
                break;
              case "checked":
                M = z;
                break;
              case "defaultChecked":
                U = z;
                break;
              case "value":
                m = z;
                break;
              case "defaultValue":
                g = z;
                break;
              case "children":
              case "dangerouslySetInnerHTML":
                if (z != null) throw Error(o(137, t));
                break;
              default:
                z !== L && Me(e, t, D, z, n, L);
            }
        }
        Vr(e, m, g, N, M, U, u, r);
        return;
      case "select":
        z = m = g = D = null;
        for (u in l)
          if (((N = l[u]), l.hasOwnProperty(u) && N != null))
            switch (u) {
              case "value":
                break;
              case "multiple":
                z = N;
              default:
                n.hasOwnProperty(u) || Me(e, t, u, null, n, N);
            }
        for (r in n)
          if (
            ((u = n[r]),
            (N = l[r]),
            n.hasOwnProperty(r) && (u != null || N != null))
          )
            switch (r) {
              case "value":
                D = u;
                break;
              case "defaultValue":
                g = u;
                break;
              case "multiple":
                m = u;
              default:
                u !== N && Me(e, t, r, u, n, N);
            }
        ((t = g),
          (l = m),
          (n = z),
          D != null
            ? _a(e, !!l, D, !1)
            : !!n != !!l &&
              (t != null ? _a(e, !!l, t, !0) : _a(e, !!l, l ? [] : "", !1)));
        return;
      case "textarea":
        z = D = null;
        for (g in l)
          if (
            ((r = l[g]),
            l.hasOwnProperty(g) && r != null && !n.hasOwnProperty(g))
          )
            switch (g) {
              case "value":
                break;
              case "children":
                break;
              default:
                Me(e, t, g, null, n, r);
            }
        for (m in n)
          if (
            ((r = n[m]),
            (u = l[m]),
            n.hasOwnProperty(m) && (r != null || u != null))
          )
            switch (m) {
              case "value":
                D = r;
                break;
              case "defaultValue":
                z = r;
                break;
              case "children":
                break;
              case "dangerouslySetInnerHTML":
                if (r != null) throw Error(o(91));
                break;
              default:
                r !== u && Me(e, t, m, r, n, u);
            }
        yd(e, D, z);
        return;
      case "option":
        for (var de in l)
          ((D = l[de]),
            l.hasOwnProperty(de) &&
              D != null &&
              !n.hasOwnProperty(de) &&
              (de === "selected"
                ? (e.selected = !1)
                : Me(e, t, de, null, n, D)));
        for (N in n)
          ((D = n[N]),
            (z = l[N]),
            n.hasOwnProperty(N) &&
              D !== z &&
              (D != null || z != null) &&
              (N === "selected"
                ? (e.selected =
                    D && typeof D != "function" && typeof D != "symbol")
                : Me(e, t, N, D, n, z)));
        return;
      case "img":
      case "link":
      case "area":
      case "base":
      case "br":
      case "col":
      case "embed":
      case "hr":
      case "keygen":
      case "meta":
      case "param":
      case "source":
      case "track":
      case "wbr":
      case "menuitem":
        for (var re in l)
          ((D = l[re]),
            l.hasOwnProperty(re) &&
              D != null &&
              !n.hasOwnProperty(re) &&
              Me(e, t, re, null, n, D));
        for (M in n)
          if (
            ((D = n[M]),
            (z = l[M]),
            n.hasOwnProperty(M) && D !== z && (D != null || z != null))
          )
            switch (M) {
              case "children":
              case "dangerouslySetInnerHTML":
                if (D != null) throw Error(o(137, t));
                break;
              default:
                Me(e, t, M, D, n, z);
            }
        return;
      default:
        if (Qr(t)) {
          for (var _e in l)
            ((D = l[_e]),
              l.hasOwnProperty(_e) &&
                D !== void 0 &&
                !n.hasOwnProperty(_e) &&
                Ro(e, t, _e, void 0, n, D));
          for (U in n)
            ((D = n[U]),
              (z = l[U]),
              !n.hasOwnProperty(U) ||
                D === z ||
                (D === void 0 && z === void 0) ||
                Ro(e, t, U, D, n, z));
          return;
        }
    }
    for (var T in l)
      ((D = l[T]),
        l.hasOwnProperty(T) &&
          D != null &&
          !n.hasOwnProperty(T) &&
          Me(e, t, T, null, n, D));
    for (L in n)
      ((D = n[L]),
        (z = l[L]),
        !n.hasOwnProperty(L) ||
          D === z ||
          (D == null && z == null) ||
          Me(e, t, L, D, n, z));
  }
  var Mo = null,
    _o = null;
  function Ui(e) {
    return e.nodeType === 9 ? e : e.ownerDocument;
  }
  function w0(e) {
    switch (e) {
      case "http://www.w3.org/2000/svg":
        return 1;
      case "http://www.w3.org/1998/Math/MathML":
        return 2;
      default:
        return 0;
    }
  }
  function S0(e, t) {
    if (e === 0)
      switch (t) {
        case "svg":
          return 1;
        case "math":
          return 2;
        default:
          return 0;
      }
    return e === 1 && t === "foreignObject" ? 0 : e;
  }
  function ko(e, t) {
    return (
      e === "textarea" ||
      e === "noscript" ||
      typeof t.children == "string" ||
      typeof t.children == "number" ||
      typeof t.children == "bigint" ||
      (typeof t.dangerouslySetInnerHTML == "object" &&
        t.dangerouslySetInnerHTML !== null &&
        t.dangerouslySetInnerHTML.__html != null)
    );
  }
  var Do = null;
  function hv() {
    var e = window.event;
    return e && e.type === "popstate"
      ? e === Do
        ? !1
        : ((Do = e), !0)
      : ((Do = null), !1);
  }
  var E0 = typeof setTimeout == "function" ? setTimeout : void 0,
    mv = typeof clearTimeout == "function" ? clearTimeout : void 0,
    T0 = typeof Promise == "function" ? Promise : void 0,
    xv =
      typeof queueMicrotask == "function"
        ? queueMicrotask
        : typeof T0 < "u"
          ? function (e) {
              return T0.resolve(null).then(e).catch(pv);
            }
          : E0;
  function pv(e) {
    setTimeout(function () {
      throw e;
    });
  }
  function Yl(e) {
    return e === "head";
  }
  function A0(e, t) {
    var l = t,
      n = 0,
      r = 0;
    do {
      var u = l.nextSibling;
      if ((e.removeChild(l), u && u.nodeType === 8))
        if (((l = u.data), l === "/$")) {
          if (0 < n && 8 > n) {
            l = n;
            var m = e.ownerDocument;
            if ((l & 1 && us(m.documentElement), l & 2 && us(m.body), l & 4))
              for (l = m.head, us(l), m = l.firstChild; m; ) {
                var g = m.nextSibling,
                  N = m.nodeName;
                (m[En] ||
                  N === "SCRIPT" ||
                  N === "STYLE" ||
                  (N === "LINK" && m.rel.toLowerCase() === "stylesheet") ||
                  l.removeChild(m),
                  (m = g));
              }
          }
          if (r === 0) {
            (e.removeChild(u), gs(t));
            return;
          }
          r--;
        } else
          l === "$" || l === "$?" || l === "$!"
            ? r++
            : (n = l.charCodeAt(0) - 48);
      else n = 0;
      l = u;
    } while (l);
    gs(t);
  }
  function zo(e) {
    var t = e.firstChild;
    for (t && t.nodeType === 10 && (t = t.nextSibling); t; ) {
      var l = t;
      switch (((t = t.nextSibling), l.nodeName)) {
        case "HTML":
        case "HEAD":
        case "BODY":
          (zo(l), qr(l));
          continue;
        case "SCRIPT":
        case "STYLE":
          continue;
        case "LINK":
          if (l.rel.toLowerCase() === "stylesheet") continue;
      }
      e.removeChild(l);
    }
  }
  function bv(e, t, l, n) {
    for (; e.nodeType === 1; ) {
      var r = l;
      if (e.nodeName.toLowerCase() !== t.toLowerCase()) {
        if (!n && (e.nodeName !== "INPUT" || e.type !== "hidden")) break;
      } else if (n) {
        if (!e[En])
          switch (t) {
            case "meta":
              if (!e.hasAttribute("itemprop")) break;
              return e;
            case "link":
              if (
                ((u = e.getAttribute("rel")),
                u === "stylesheet" && e.hasAttribute("data-precedence"))
              )
                break;
              if (
                u !== r.rel ||
                e.getAttribute("href") !==
                  (r.href == null || r.href === "" ? null : r.href) ||
                e.getAttribute("crossorigin") !==
                  (r.crossOrigin == null ? null : r.crossOrigin) ||
                e.getAttribute("title") !== (r.title == null ? null : r.title)
              )
                break;
              return e;
            case "style":
              if (e.hasAttribute("data-precedence")) break;
              return e;
            case "script":
              if (
                ((u = e.getAttribute("src")),
                (u !== (r.src == null ? null : r.src) ||
                  e.getAttribute("type") !== (r.type == null ? null : r.type) ||
                  e.getAttribute("crossorigin") !==
                    (r.crossOrigin == null ? null : r.crossOrigin)) &&
                  u &&
                  e.hasAttribute("async") &&
                  !e.hasAttribute("itemprop"))
              )
                break;
              return e;
            default:
              return e;
          }
      } else if (t === "input" && e.type === "hidden") {
        var u = r.name == null ? null : "" + r.name;
        if (r.type === "hidden" && e.getAttribute("name") === u) return e;
      } else return e;
      if (((e = Lt(e.nextSibling)), e === null)) break;
    }
    return null;
  }
  function gv(e, t, l) {
    if (t === "") return null;
    for (; e.nodeType !== 3; )
      if (
        ((e.nodeType !== 1 || e.nodeName !== "INPUT" || e.type !== "hidden") &&
          !l) ||
        ((e = Lt(e.nextSibling)), e === null)
      )
        return null;
    return e;
  }
  function Uo(e) {
    return (
      e.data === "$!" ||
      (e.data === "$?" && e.ownerDocument.readyState === "complete")
    );
  }
  function vv(e, t) {
    var l = e.ownerDocument;
    if (e.data !== "$?" || l.readyState === "complete") t();
    else {
      var n = function () {
        (t(), l.removeEventListener("DOMContentLoaded", n));
      };
      (l.addEventListener("DOMContentLoaded", n), (e._reactRetry = n));
    }
  }
  function Lt(e) {
    for (; e != null; e = e.nextSibling) {
      var t = e.nodeType;
      if (t === 1 || t === 3) break;
      if (t === 8) {
        if (
          ((t = e.data),
          t === "$" || t === "$!" || t === "$?" || t === "F!" || t === "F")
        )
          break;
        if (t === "/$") return null;
      }
    }
    return e;
  }
  var Ho = null;
  function C0(e) {
    e = e.previousSibling;
    for (var t = 0; e; ) {
      if (e.nodeType === 8) {
        var l = e.data;
        if (l === "$" || l === "$!" || l === "$?") {
          if (t === 0) return e;
          t--;
        } else l === "/$" && t++;
      }
      e = e.previousSibling;
    }
    return null;
  }
  function O0(e, t, l) {
    switch (((t = Ui(l)), e)) {
      case "html":
        if (((e = t.documentElement), !e)) throw Error(o(452));
        return e;
      case "head":
        if (((e = t.head), !e)) throw Error(o(453));
        return e;
      case "body":
        if (((e = t.body), !e)) throw Error(o(454));
        return e;
      default:
        throw Error(o(451));
    }
  }
  function us(e) {
    for (var t = e.attributes; t.length; ) e.removeAttributeNode(t[0]);
    qr(e);
  }
  var Dt = new Map(),
    R0 = new Set();
  function Hi(e) {
    return typeof e.getRootNode == "function"
      ? e.getRootNode()
      : e.nodeType === 9
        ? e
        : e.ownerDocument;
  }
  var ml = G.d;
  G.d = { f: yv, r: jv, D: Nv, C: wv, L: Sv, m: Ev, X: Av, S: Tv, M: Cv };
  function yv() {
    var e = ml.f(),
      t = Ci();
    return e || t;
  }
  function jv(e) {
    var t = Ca(e);
    t !== null && t.tag === 5 && t.type === "form" ? Jf(t) : ml.r(e);
  }
  var on = typeof document > "u" ? null : document;
  function M0(e, t, l) {
    var n = on;
    if (n && typeof t == "string" && t) {
      var r = At(t);
      ((r = 'link[rel="' + e + '"][href="' + r + '"]'),
        typeof l == "string" && (r += '[crossorigin="' + l + '"]'),
        R0.has(r) ||
          (R0.add(r),
          (e = { rel: e, crossOrigin: l, href: t }),
          n.querySelector(r) === null &&
            ((t = n.createElement("link")),
            lt(t, "link", e),
            Je(t),
            n.head.appendChild(t))));
    }
  }
  function Nv(e) {
    (ml.D(e), M0("dns-prefetch", e, null));
  }
  function wv(e, t) {
    (ml.C(e, t), M0("preconnect", e, t));
  }
  function Sv(e, t, l) {
    ml.L(e, t, l);
    var n = on;
    if (n && e && t) {
      var r = 'link[rel="preload"][as="' + At(t) + '"]';
      t === "image" && l && l.imageSrcSet
        ? ((r += '[imagesrcset="' + At(l.imageSrcSet) + '"]'),
          typeof l.imageSizes == "string" &&
            (r += '[imagesizes="' + At(l.imageSizes) + '"]'))
        : (r += '[href="' + At(e) + '"]');
      var u = r;
      switch (t) {
        case "style":
          u = un(e);
          break;
        case "script":
          u = dn(e);
      }
      Dt.has(u) ||
        ((e = v(
          {
            rel: "preload",
            href: t === "image" && l && l.imageSrcSet ? void 0 : e,
            as: t,
          },
          l,
        )),
        Dt.set(u, e),
        n.querySelector(r) !== null ||
          (t === "style" && n.querySelector(ds(u))) ||
          (t === "script" && n.querySelector(fs(u))) ||
          ((t = n.createElement("link")),
          lt(t, "link", e),
          Je(t),
          n.head.appendChild(t)));
    }
  }
  function Ev(e, t) {
    ml.m(e, t);
    var l = on;
    if (l && e) {
      var n = t && typeof t.as == "string" ? t.as : "script",
        r =
          'link[rel="modulepreload"][as="' + At(n) + '"][href="' + At(e) + '"]',
        u = r;
      switch (n) {
        case "audioworklet":
        case "paintworklet":
        case "serviceworker":
        case "sharedworker":
        case "worker":
        case "script":
          u = dn(e);
      }
      if (
        !Dt.has(u) &&
        ((e = v({ rel: "modulepreload", href: e }, t)),
        Dt.set(u, e),
        l.querySelector(r) === null)
      ) {
        switch (n) {
          case "audioworklet":
          case "paintworklet":
          case "serviceworker":
          case "sharedworker":
          case "worker":
          case "script":
            if (l.querySelector(fs(u))) return;
        }
        ((n = l.createElement("link")),
          lt(n, "link", e),
          Je(n),
          l.head.appendChild(n));
      }
    }
  }
  function Tv(e, t, l) {
    ml.S(e, t, l);
    var n = on;
    if (n && e) {
      var r = Oa(n).hoistableStyles,
        u = un(e);
      t = t || "default";
      var m = r.get(u);
      if (!m) {
        var g = { loading: 0, preload: null };
        if ((m = n.querySelector(ds(u)))) g.loading = 5;
        else {
          ((e = v({ rel: "stylesheet", href: e, "data-precedence": t }, l)),
            (l = Dt.get(u)) && Lo(e, l));
          var N = (m = n.createElement("link"));
          (Je(N),
            lt(N, "link", e),
            (N._p = new Promise(function (M, U) {
              ((N.onload = M), (N.onerror = U));
            })),
            N.addEventListener("load", function () {
              g.loading |= 1;
            }),
            N.addEventListener("error", function () {
              g.loading |= 2;
            }),
            (g.loading |= 4),
            Li(m, t, n));
        }
        ((m = { type: "stylesheet", instance: m, count: 1, state: g }),
          r.set(u, m));
      }
    }
  }
  function Av(e, t) {
    ml.X(e, t);
    var l = on;
    if (l && e) {
      var n = Oa(l).hoistableScripts,
        r = dn(e),
        u = n.get(r);
      u ||
        ((u = l.querySelector(fs(r))),
        u ||
          ((e = v({ src: e, async: !0 }, t)),
          (t = Dt.get(r)) && qo(e, t),
          (u = l.createElement("script")),
          Je(u),
          lt(u, "link", e),
          l.head.appendChild(u)),
        (u = { type: "script", instance: u, count: 1, state: null }),
        n.set(r, u));
    }
  }
  function Cv(e, t) {
    ml.M(e, t);
    var l = on;
    if (l && e) {
      var n = Oa(l).hoistableScripts,
        r = dn(e),
        u = n.get(r);
      u ||
        ((u = l.querySelector(fs(r))),
        u ||
          ((e = v({ src: e, async: !0, type: "module" }, t)),
          (t = Dt.get(r)) && qo(e, t),
          (u = l.createElement("script")),
          Je(u),
          lt(u, "link", e),
          l.head.appendChild(u)),
        (u = { type: "script", instance: u, count: 1, state: null }),
        n.set(r, u));
    }
  }
  function _0(e, t, l, n) {
    var r = (r = le.current) ? Hi(r) : null;
    if (!r) throw Error(o(446));
    switch (e) {
      case "meta":
      case "title":
        return null;
      case "style":
        return typeof l.precedence == "string" && typeof l.href == "string"
          ? ((t = un(l.href)),
            (l = Oa(r).hoistableStyles),
            (n = l.get(t)),
            n ||
              ((n = { type: "style", instance: null, count: 0, state: null }),
              l.set(t, n)),
            n)
          : { type: "void", instance: null, count: 0, state: null };
      case "link":
        if (
          l.rel === "stylesheet" &&
          typeof l.href == "string" &&
          typeof l.precedence == "string"
        ) {
          e = un(l.href);
          var u = Oa(r).hoistableStyles,
            m = u.get(e);
          if (
            (m ||
              ((r = r.ownerDocument || r),
              (m = {
                type: "stylesheet",
                instance: null,
                count: 0,
                state: { loading: 0, preload: null },
              }),
              u.set(e, m),
              (u = r.querySelector(ds(e))) &&
                !u._p &&
                ((m.instance = u), (m.state.loading = 5)),
              Dt.has(e) ||
                ((l = {
                  rel: "preload",
                  as: "style",
                  href: l.href,
                  crossOrigin: l.crossOrigin,
                  integrity: l.integrity,
                  media: l.media,
                  hrefLang: l.hrefLang,
                  referrerPolicy: l.referrerPolicy,
                }),
                Dt.set(e, l),
                u || Ov(r, e, l, m.state))),
            t && n === null)
          )
            throw Error(o(528, ""));
          return m;
        }
        if (t && n !== null) throw Error(o(529, ""));
        return null;
      case "script":
        return (
          (t = l.async),
          (l = l.src),
          typeof l == "string" &&
          t &&
          typeof t != "function" &&
          typeof t != "symbol"
            ? ((t = dn(l)),
              (l = Oa(r).hoistableScripts),
              (n = l.get(t)),
              n ||
                ((n = {
                  type: "script",
                  instance: null,
                  count: 0,
                  state: null,
                }),
                l.set(t, n)),
              n)
            : { type: "void", instance: null, count: 0, state: null }
        );
      default:
        throw Error(o(444, e));
    }
  }
  function un(e) {
    return 'href="' + At(e) + '"';
  }
  function ds(e) {
    return 'link[rel="stylesheet"][' + e + "]";
  }
  function k0(e) {
    return v({}, e, { "data-precedence": e.precedence, precedence: null });
  }
  function Ov(e, t, l, n) {
    e.querySelector('link[rel="preload"][as="style"][' + t + "]")
      ? (n.loading = 1)
      : ((t = e.createElement("link")),
        (n.preload = t),
        t.addEventListener("load", function () {
          return (n.loading |= 1);
        }),
        t.addEventListener("error", function () {
          return (n.loading |= 2);
        }),
        lt(t, "link", l),
        Je(t),
        e.head.appendChild(t));
  }
  function dn(e) {
    return '[src="' + At(e) + '"]';
  }
  function fs(e) {
    return "script[async]" + e;
  }
  function D0(e, t, l) {
    if ((t.count++, t.instance === null))
      switch (t.type) {
        case "style":
          var n = e.querySelector('style[data-href~="' + At(l.href) + '"]');
          if (n) return ((t.instance = n), Je(n), n);
          var r = v({}, l, {
            "data-href": l.href,
            "data-precedence": l.precedence,
            href: null,
            precedence: null,
          });
          return (
            (n = (e.ownerDocument || e).createElement("style")),
            Je(n),
            lt(n, "style", r),
            Li(n, l.precedence, e),
            (t.instance = n)
          );
        case "stylesheet":
          r = un(l.href);
          var u = e.querySelector(ds(r));
          if (u) return ((t.state.loading |= 4), (t.instance = u), Je(u), u);
          ((n = k0(l)),
            (r = Dt.get(r)) && Lo(n, r),
            (u = (e.ownerDocument || e).createElement("link")),
            Je(u));
          var m = u;
          return (
            (m._p = new Promise(function (g, N) {
              ((m.onload = g), (m.onerror = N));
            })),
            lt(u, "link", n),
            (t.state.loading |= 4),
            Li(u, l.precedence, e),
            (t.instance = u)
          );
        case "script":
          return (
            (u = dn(l.src)),
            (r = e.querySelector(fs(u)))
              ? ((t.instance = r), Je(r), r)
              : ((n = l),
                (r = Dt.get(u)) && ((n = v({}, l)), qo(n, r)),
                (e = e.ownerDocument || e),
                (r = e.createElement("script")),
                Je(r),
                lt(r, "link", n),
                e.head.appendChild(r),
                (t.instance = r))
          );
        case "void":
          return null;
        default:
          throw Error(o(443, t.type));
      }
    else
      t.type === "stylesheet" &&
        (t.state.loading & 4) === 0 &&
        ((n = t.instance), (t.state.loading |= 4), Li(n, l.precedence, e));
    return t.instance;
  }
  function Li(e, t, l) {
    for (
      var n = l.querySelectorAll(
          'link[rel="stylesheet"][data-precedence],style[data-precedence]',
        ),
        r = n.length ? n[n.length - 1] : null,
        u = r,
        m = 0;
      m < n.length;
      m++
    ) {
      var g = n[m];
      if (g.dataset.precedence === t) u = g;
      else if (u !== r) break;
    }
    u
      ? u.parentNode.insertBefore(e, u.nextSibling)
      : ((t = l.nodeType === 9 ? l.head : l), t.insertBefore(e, t.firstChild));
  }
  function Lo(e, t) {
    (e.crossOrigin == null && (e.crossOrigin = t.crossOrigin),
      e.referrerPolicy == null && (e.referrerPolicy = t.referrerPolicy),
      e.title == null && (e.title = t.title));
  }
  function qo(e, t) {
    (e.crossOrigin == null && (e.crossOrigin = t.crossOrigin),
      e.referrerPolicy == null && (e.referrerPolicy = t.referrerPolicy),
      e.integrity == null && (e.integrity = t.integrity));
  }
  var qi = null;
  function z0(e, t, l) {
    if (qi === null) {
      var n = new Map(),
        r = (qi = new Map());
      r.set(l, n);
    } else ((r = qi), (n = r.get(l)), n || ((n = new Map()), r.set(l, n)));
    if (n.has(e)) return n;
    for (
      n.set(e, null), l = l.getElementsByTagName(e), r = 0;
      r < l.length;
      r++
    ) {
      var u = l[r];
      if (
        !(
          u[En] ||
          u[at] ||
          (e === "link" && u.getAttribute("rel") === "stylesheet")
        ) &&
        u.namespaceURI !== "http://www.w3.org/2000/svg"
      ) {
        var m = u.getAttribute(t) || "";
        m = e + m;
        var g = n.get(m);
        g ? g.push(u) : n.set(m, [u]);
      }
    }
    return n;
  }
  function U0(e, t, l) {
    ((e = e.ownerDocument || e),
      e.head.insertBefore(
        l,
        t === "title" ? e.querySelector("head > title") : null,
      ));
  }
  function Rv(e, t, l) {
    if (l === 1 || t.itemProp != null) return !1;
    switch (e) {
      case "meta":
      case "title":
        return !0;
      case "style":
        if (
          typeof t.precedence != "string" ||
          typeof t.href != "string" ||
          t.href === ""
        )
          break;
        return !0;
      case "link":
        if (
          typeof t.rel != "string" ||
          typeof t.href != "string" ||
          t.href === "" ||
          t.onLoad ||
          t.onError
        )
          break;
        return t.rel === "stylesheet"
          ? ((e = t.disabled), typeof t.precedence == "string" && e == null)
          : !0;
      case "script":
        if (
          t.async &&
          typeof t.async != "function" &&
          typeof t.async != "symbol" &&
          !t.onLoad &&
          !t.onError &&
          t.src &&
          typeof t.src == "string"
        )
          return !0;
    }
    return !1;
  }
  function H0(e) {
    return !(e.type === "stylesheet" && (e.state.loading & 3) === 0);
  }
  var hs = null;
  function Mv() {}
  function _v(e, t, l) {
    if (hs === null) throw Error(o(475));
    var n = hs;
    if (
      t.type === "stylesheet" &&
      (typeof l.media != "string" || matchMedia(l.media).matches !== !1) &&
      (t.state.loading & 4) === 0
    ) {
      if (t.instance === null) {
        var r = un(l.href),
          u = e.querySelector(ds(r));
        if (u) {
          ((e = u._p),
            e !== null &&
              typeof e == "object" &&
              typeof e.then == "function" &&
              (n.count++, (n = Bi.bind(n)), e.then(n, n)),
            (t.state.loading |= 4),
            (t.instance = u),
            Je(u));
          return;
        }
        ((u = e.ownerDocument || e),
          (l = k0(l)),
          (r = Dt.get(r)) && Lo(l, r),
          (u = u.createElement("link")),
          Je(u));
        var m = u;
        ((m._p = new Promise(function (g, N) {
          ((m.onload = g), (m.onerror = N));
        })),
          lt(u, "link", l),
          (t.instance = u));
      }
      (n.stylesheets === null && (n.stylesheets = new Map()),
        n.stylesheets.set(t, e),
        (e = t.state.preload) &&
          (t.state.loading & 3) === 0 &&
          (n.count++,
          (t = Bi.bind(n)),
          e.addEventListener("load", t),
          e.addEventListener("error", t)));
    }
  }
  function kv() {
    if (hs === null) throw Error(o(475));
    var e = hs;
    return (
      e.stylesheets && e.count === 0 && Bo(e, e.stylesheets),
      0 < e.count
        ? function (t) {
            var l = setTimeout(function () {
              if ((e.stylesheets && Bo(e, e.stylesheets), e.unsuspend)) {
                var n = e.unsuspend;
                ((e.unsuspend = null), n());
              }
            }, 6e4);
            return (
              (e.unsuspend = t),
              function () {
                ((e.unsuspend = null), clearTimeout(l));
              }
            );
          }
        : null
    );
  }
  function Bi() {
    if ((this.count--, this.count === 0)) {
      if (this.stylesheets) Bo(this, this.stylesheets);
      else if (this.unsuspend) {
        var e = this.unsuspend;
        ((this.unsuspend = null), e());
      }
    }
  }
  var Gi = null;
  function Bo(e, t) {
    ((e.stylesheets = null),
      e.unsuspend !== null &&
        (e.count++,
        (Gi = new Map()),
        t.forEach(Dv, e),
        (Gi = null),
        Bi.call(e)));
  }
  function Dv(e, t) {
    if (!(t.state.loading & 4)) {
      var l = Gi.get(e);
      if (l) var n = l.get(null);
      else {
        ((l = new Map()), Gi.set(e, l));
        for (
          var r = e.querySelectorAll(
              "link[data-precedence],style[data-precedence]",
            ),
            u = 0;
          u < r.length;
          u++
        ) {
          var m = r[u];
          (m.nodeName === "LINK" || m.getAttribute("media") !== "not all") &&
            (l.set(m.dataset.precedence, m), (n = m));
        }
        n && l.set(null, n);
      }
      ((r = t.instance),
        (m = r.getAttribute("data-precedence")),
        (u = l.get(m) || n),
        u === n && l.set(null, r),
        l.set(m, r),
        this.count++,
        (n = Bi.bind(this)),
        r.addEventListener("load", n),
        r.addEventListener("error", n),
        u
          ? u.parentNode.insertBefore(r, u.nextSibling)
          : ((e = e.nodeType === 9 ? e.head : e),
            e.insertBefore(r, e.firstChild)),
        (t.state.loading |= 4));
    }
  }
  var ms = {
    $$typeof: Y,
    Provider: null,
    Consumer: null,
    _currentValue: Q,
    _currentValue2: Q,
    _threadCount: 0,
  };
  function zv(e, t, l, n, r, u, m, g) {
    ((this.tag = 1),
      (this.containerInfo = e),
      (this.pingCache = this.current = this.pendingChildren = null),
      (this.timeoutHandle = -1),
      (this.callbackNode =
        this.next =
        this.pendingContext =
        this.context =
        this.cancelPendingCommit =
          null),
      (this.callbackPriority = 0),
      (this.expirationTimes = zr(-1)),
      (this.entangledLanes =
        this.shellSuspendCounter =
        this.errorRecoveryDisabledLanes =
        this.expiredLanes =
        this.warmLanes =
        this.pingedLanes =
        this.suspendedLanes =
        this.pendingLanes =
          0),
      (this.entanglements = zr(0)),
      (this.hiddenUpdates = zr(null)),
      (this.identifierPrefix = n),
      (this.onUncaughtError = r),
      (this.onCaughtError = u),
      (this.onRecoverableError = m),
      (this.pooledCache = null),
      (this.pooledCacheLanes = 0),
      (this.formState = g),
      (this.incompleteTransitions = new Map()));
  }
  function L0(e, t, l, n, r, u, m, g, N, M, U, L) {
    return (
      (e = new zv(e, t, l, m, g, N, M, L)),
      (t = 1),
      u === !0 && (t |= 24),
      (u = bt(3, null, null, t)),
      (e.current = u),
      (u.stateNode = e),
      (t = yc()),
      t.refCount++,
      (e.pooledCache = t),
      t.refCount++,
      (u.memoizedState = { element: n, isDehydrated: l, cache: t }),
      Sc(u),
      e
    );
  }
  function q0(e) {
    return e ? ((e = Ga), e) : Ga;
  }
  function B0(e, t, l, n, r, u) {
    ((r = q0(r)),
      n.context === null ? (n.context = r) : (n.pendingContext = r),
      (n = Ol(t)),
      (n.payload = { element: l }),
      (u = u === void 0 ? null : u),
      u !== null && (n.callback = u),
      (l = Rl(e, n, t)),
      l !== null && (Nt(l, e, t), Xn(l, e, t)));
  }
  function G0(e, t) {
    if (((e = e.memoizedState), e !== null && e.dehydrated !== null)) {
      var l = e.retryLane;
      e.retryLane = l !== 0 && l < t ? l : t;
    }
  }
  function Go(e, t) {
    (G0(e, t), (e = e.alternate) && G0(e, t));
  }
  function Y0(e) {
    if (e.tag === 13) {
      var t = Ba(e, 67108864);
      (t !== null && Nt(t, e, 67108864), Go(e, 67108864));
    }
  }
  var Yi = !0;
  function Uv(e, t, l, n) {
    var r = O.T;
    O.T = null;
    var u = G.p;
    try {
      ((G.p = 2), Yo(e, t, l, n));
    } finally {
      ((G.p = u), (O.T = r));
    }
  }
  function Hv(e, t, l, n) {
    var r = O.T;
    O.T = null;
    var u = G.p;
    try {
      ((G.p = 8), Yo(e, t, l, n));
    } finally {
      ((G.p = u), (O.T = r));
    }
  }
  function Yo(e, t, l, n) {
    if (Yi) {
      var r = Vo(n);
      if (r === null) (Oo(e, t, n, Vi, l), X0(e, n));
      else if (qv(r, e, t, l, n)) n.stopPropagation();
      else if ((X0(e, n), t & 4 && -1 < Lv.indexOf(e))) {
        for (; r !== null; ) {
          var u = Ca(r);
          if (u !== null)
            switch (u.tag) {
              case 3:
                if (((u = u.stateNode), u.current.memoizedState.isDehydrated)) {
                  var m = la(u.pendingLanes);
                  if (m !== 0) {
                    var g = u;
                    for (g.pendingLanes |= 2, g.entangledLanes |= 2; m; ) {
                      var N = 1 << (31 - xt(m));
                      ((g.entanglements[1] |= N), (m &= ~N));
                    }
                    (Jt(u), (Ce & 6) === 0 && ((Ti = Qt() + 500), rs(0)));
                  }
                }
                break;
              case 13:
                ((g = Ba(u, 2)), g !== null && Nt(g, u, 2), Ci(), Go(u, 2));
            }
          if (((u = Vo(n)), u === null && Oo(e, t, n, Vi, l), u === r)) break;
          r = u;
        }
        r !== null && n.stopPropagation();
      } else Oo(e, t, n, null, l);
    }
  }
  function Vo(e) {
    return ((e = Kr(e)), Xo(e));
  }
  var Vi = null;
  function Xo(e) {
    if (((Vi = null), (e = Aa(e)), e !== null)) {
      var t = f(e);
      if (t === null) e = null;
      else {
        var l = t.tag;
        if (l === 13) {
          if (((e = x(t)), e !== null)) return e;
          e = null;
        } else if (l === 3) {
          if (t.stateNode.current.memoizedState.isDehydrated)
            return t.tag === 3 ? t.stateNode.containerInfo : null;
          e = null;
        } else t !== e && (e = null);
      }
    }
    return ((Vi = e), null);
  }
  function V0(e) {
    switch (e) {
      case "beforetoggle":
      case "cancel":
      case "click":
      case "close":
      case "contextmenu":
      case "copy":
      case "cut":
      case "auxclick":
      case "dblclick":
      case "dragend":
      case "dragstart":
      case "drop":
      case "focusin":
      case "focusout":
      case "input":
      case "invalid":
      case "keydown":
      case "keypress":
      case "keyup":
      case "mousedown":
      case "mouseup":
      case "paste":
      case "pause":
      case "play":
      case "pointercancel":
      case "pointerdown":
      case "pointerup":
      case "ratechange":
      case "reset":
      case "resize":
      case "seeked":
      case "submit":
      case "toggle":
      case "touchcancel":
      case "touchend":
      case "touchstart":
      case "volumechange":
      case "change":
      case "selectionchange":
      case "textInput":
      case "compositionstart":
      case "compositionend":
      case "compositionupdate":
      case "beforeblur":
      case "afterblur":
      case "beforeinput":
      case "blur":
      case "fullscreenchange":
      case "focus":
      case "hashchange":
      case "popstate":
      case "select":
      case "selectstart":
        return 2;
      case "drag":
      case "dragenter":
      case "dragexit":
      case "dragleave":
      case "dragover":
      case "mousemove":
      case "mouseout":
      case "mouseover":
      case "pointermove":
      case "pointerout":
      case "pointerover":
      case "scroll":
      case "touchmove":
      case "wheel":
      case "mouseenter":
      case "mouseleave":
      case "pointerenter":
      case "pointerleave":
        return 8;
      case "message":
        switch (wb()) {
          case ld:
            return 2;
          case ad:
            return 8;
          case zs:
          case Sb:
            return 32;
          case nd:
            return 268435456;
          default:
            return 32;
        }
      default:
        return 32;
    }
  }
  var Qo = !1,
    Vl = null,
    Xl = null,
    Ql = null,
    xs = new Map(),
    ps = new Map(),
    Zl = [],
    Lv =
      "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(
        " ",
      );
  function X0(e, t) {
    switch (e) {
      case "focusin":
      case "focusout":
        Vl = null;
        break;
      case "dragenter":
      case "dragleave":
        Xl = null;
        break;
      case "mouseover":
      case "mouseout":
        Ql = null;
        break;
      case "pointerover":
      case "pointerout":
        xs.delete(t.pointerId);
        break;
      case "gotpointercapture":
      case "lostpointercapture":
        ps.delete(t.pointerId);
    }
  }
  function bs(e, t, l, n, r, u) {
    return e === null || e.nativeEvent !== u
      ? ((e = {
          blockedOn: t,
          domEventName: l,
          eventSystemFlags: n,
          nativeEvent: u,
          targetContainers: [r],
        }),
        t !== null && ((t = Ca(t)), t !== null && Y0(t)),
        e)
      : ((e.eventSystemFlags |= n),
        (t = e.targetContainers),
        r !== null && t.indexOf(r) === -1 && t.push(r),
        e);
  }
  function qv(e, t, l, n, r) {
    switch (t) {
      case "focusin":
        return ((Vl = bs(Vl, e, t, l, n, r)), !0);
      case "dragenter":
        return ((Xl = bs(Xl, e, t, l, n, r)), !0);
      case "mouseover":
        return ((Ql = bs(Ql, e, t, l, n, r)), !0);
      case "pointerover":
        var u = r.pointerId;
        return (xs.set(u, bs(xs.get(u) || null, e, t, l, n, r)), !0);
      case "gotpointercapture":
        return (
          (u = r.pointerId),
          ps.set(u, bs(ps.get(u) || null, e, t, l, n, r)),
          !0
        );
    }
    return !1;
  }
  function Q0(e) {
    var t = Aa(e.target);
    if (t !== null) {
      var l = f(t);
      if (l !== null) {
        if (((t = l.tag), t === 13)) {
          if (((t = x(l)), t !== null)) {
            ((e.blockedOn = t),
              _b(e.priority, function () {
                if (l.tag === 13) {
                  var n = jt();
                  n = Ur(n);
                  var r = Ba(l, n);
                  (r !== null && Nt(r, l, n), Go(l, n));
                }
              }));
            return;
          }
        } else if (t === 3 && l.stateNode.current.memoizedState.isDehydrated) {
          e.blockedOn = l.tag === 3 ? l.stateNode.containerInfo : null;
          return;
        }
      }
    }
    e.blockedOn = null;
  }
  function Xi(e) {
    if (e.blockedOn !== null) return !1;
    for (var t = e.targetContainers; 0 < t.length; ) {
      var l = Vo(e.nativeEvent);
      if (l === null) {
        l = e.nativeEvent;
        var n = new l.constructor(l.type, l);
        ((Zr = n), l.target.dispatchEvent(n), (Zr = null));
      } else return ((t = Ca(l)), t !== null && Y0(t), (e.blockedOn = l), !1);
      t.shift();
    }
    return !0;
  }
  function Z0(e, t, l) {
    Xi(e) && l.delete(t);
  }
  function Bv() {
    ((Qo = !1),
      Vl !== null && Xi(Vl) && (Vl = null),
      Xl !== null && Xi(Xl) && (Xl = null),
      Ql !== null && Xi(Ql) && (Ql = null),
      xs.forEach(Z0),
      ps.forEach(Z0));
  }
  function Qi(e, t) {
    e.blockedOn === t &&
      ((e.blockedOn = null),
      Qo ||
        ((Qo = !0),
        a.unstable_scheduleCallback(a.unstable_NormalPriority, Bv)));
  }
  var Zi = null;
  function K0(e) {
    Zi !== e &&
      ((Zi = e),
      a.unstable_scheduleCallback(a.unstable_NormalPriority, function () {
        Zi === e && (Zi = null);
        for (var t = 0; t < e.length; t += 3) {
          var l = e[t],
            n = e[t + 1],
            r = e[t + 2];
          if (typeof n != "function") {
            if (Xo(n || l) === null) continue;
            break;
          }
          var u = Ca(l);
          u !== null &&
            (e.splice(t, 3),
            (t -= 3),
            Vc(u, { pending: !0, data: r, method: l.method, action: n }, n, r));
        }
      }));
  }
  function gs(e) {
    function t(N) {
      return Qi(N, e);
    }
    (Vl !== null && Qi(Vl, e),
      Xl !== null && Qi(Xl, e),
      Ql !== null && Qi(Ql, e),
      xs.forEach(t),
      ps.forEach(t));
    for (var l = 0; l < Zl.length; l++) {
      var n = Zl[l];
      n.blockedOn === e && (n.blockedOn = null);
    }
    for (; 0 < Zl.length && ((l = Zl[0]), l.blockedOn === null); )
      (Q0(l), l.blockedOn === null && Zl.shift());
    if (((l = (e.ownerDocument || e).$$reactFormReplay), l != null))
      for (n = 0; n < l.length; n += 3) {
        var r = l[n],
          u = l[n + 1],
          m = r[ct] || null;
        if (typeof u == "function") m || K0(l);
        else if (m) {
          var g = null;
          if (u && u.hasAttribute("formAction")) {
            if (((r = u), (m = u[ct] || null))) g = m.formAction;
            else if (Xo(r) !== null) continue;
          } else g = m.action;
          (typeof g == "function" ? (l[n + 1] = g) : (l.splice(n, 3), (n -= 3)),
            K0(l));
        }
      }
  }
  function Zo(e) {
    this._internalRoot = e;
  }
  ((Ki.prototype.render = Zo.prototype.render =
    function (e) {
      var t = this._internalRoot;
      if (t === null) throw Error(o(409));
      var l = t.current,
        n = jt();
      B0(l, n, e, t, null, null);
    }),
    (Ki.prototype.unmount = Zo.prototype.unmount =
      function () {
        var e = this._internalRoot;
        if (e !== null) {
          this._internalRoot = null;
          var t = e.containerInfo;
          (B0(e.current, 2, null, e, null, null), Ci(), (t[Ta] = null));
        }
      }));
  function Ki(e) {
    this._internalRoot = e;
  }
  Ki.prototype.unstable_scheduleHydration = function (e) {
    if (e) {
      var t = od();
      e = { blockedOn: null, target: e, priority: t };
      for (var l = 0; l < Zl.length && t !== 0 && t < Zl[l].priority; l++);
      (Zl.splice(l, 0, e), l === 0 && Q0(e));
    }
  };
  var P0 = i.version;
  if (P0 !== "19.1.0") throw Error(o(527, P0, "19.1.0"));
  G.findDOMNode = function (e) {
    var t = e._reactInternals;
    if (t === void 0)
      throw typeof e.render == "function"
        ? Error(o(188))
        : ((e = Object.keys(e).join(",")), Error(o(268, e)));
    return (
      (e = p(t)),
      (e = e !== null ? h(e) : null),
      (e = e === null ? null : e.stateNode),
      e
    );
  };
  var Gv = {
    bundleType: 0,
    version: "19.1.0",
    rendererPackageName: "react-dom",
    currentDispatcherRef: O,
    reconcilerVersion: "19.1.0",
  };
  if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
    var Pi = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!Pi.isDisabled && Pi.supportsFiber)
      try {
        ((Nn = Pi.inject(Gv)), (mt = Pi));
      } catch {}
  }
  return (
    (ys.createRoot = function (e, t) {
      if (!d(e)) throw Error(o(299));
      var l = !1,
        n = "",
        r = uh,
        u = dh,
        m = fh,
        g = null;
      return (
        t != null &&
          (t.unstable_strictMode === !0 && (l = !0),
          t.identifierPrefix !== void 0 && (n = t.identifierPrefix),
          t.onUncaughtError !== void 0 && (r = t.onUncaughtError),
          t.onCaughtError !== void 0 && (u = t.onCaughtError),
          t.onRecoverableError !== void 0 && (m = t.onRecoverableError),
          t.unstable_transitionCallbacks !== void 0 &&
            (g = t.unstable_transitionCallbacks)),
        (t = L0(e, 1, !1, null, null, l, n, r, u, m, g, null)),
        (e[Ta] = t.current),
        Co(e),
        new Zo(t)
      );
    }),
    (ys.hydrateRoot = function (e, t, l) {
      if (!d(e)) throw Error(o(299));
      var n = !1,
        r = "",
        u = uh,
        m = dh,
        g = fh,
        N = null,
        M = null;
      return (
        l != null &&
          (l.unstable_strictMode === !0 && (n = !0),
          l.identifierPrefix !== void 0 && (r = l.identifierPrefix),
          l.onUncaughtError !== void 0 && (u = l.onUncaughtError),
          l.onCaughtError !== void 0 && (m = l.onCaughtError),
          l.onRecoverableError !== void 0 && (g = l.onRecoverableError),
          l.unstable_transitionCallbacks !== void 0 &&
            (N = l.unstable_transitionCallbacks),
          l.formState !== void 0 && (M = l.formState)),
        (t = L0(e, 1, !0, t, l ?? null, n, r, u, m, g, N, M)),
        (t.context = q0(null)),
        (l = t.current),
        (n = jt()),
        (n = Ur(n)),
        (r = Ol(n)),
        (r.callback = null),
        Rl(l, r, n),
        (l = n),
        (t.current.lanes = l),
        Sn(t, l),
        Jt(t),
        (e[Ta] = t.current),
        Co(e),
        new Ki(t)
      );
    }),
    (ys.version = "19.1.0"),
    ys
  );
}
var nm;
function Fv() {
  if (nm) return Po.exports;
  nm = 1;
  function a() {
    if (
      !(
        typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" ||
        typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"
      )
    )
      try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(a);
      } catch (i) {
        console.error(i);
      }
  }
  return (a(), (Po.exports = Jv()), Po.exports);
}
var Wv = Fv();
function Iv(a, i) {
  if (a instanceof RegExp) return { keys: !1, pattern: a };
  var c,
    o,
    d,
    f,
    x = [],
    b = "",
    p = a.split("/");
  for (p[0] || p.shift(); (d = p.shift()); )
    ((c = d[0]),
      c === "*"
        ? (x.push(c), (b += d[1] === "?" ? "(?:/(.*))?" : "/(.*)"))
        : c === ":"
          ? ((o = d.indexOf("?", 1)),
            (f = d.indexOf(".", 1)),
            x.push(d.substring(1, ~o ? o : ~f ? f : d.length)),
            (b += ~o && !~f ? "(?:/([^/]+?))?" : "/([^/]+?)"),
            ~f && (b += (~o ? "?" : "") + "\\" + d.substring(f)))
          : (b += "/" + d));
  return {
    keys: x,
    pattern: new RegExp("^" + b + (i ? "(?=$|/)" : "/?$"), "i"),
  };
}
var j = br();
const bl = nx(j),
  Eu = Vv({ __proto__: null, default: bl }, [j]);
var Io = { exports: {} },
  eu = {};
var sm;
function ey() {
  if (sm) return eu;
  sm = 1;
  var a = br();
  function i(w, E) {
    return (w === E && (w !== 0 || 1 / w === 1 / E)) || (w !== w && E !== E);
  }
  var c = typeof Object.is == "function" ? Object.is : i,
    o = a.useState,
    d = a.useEffect,
    f = a.useLayoutEffect,
    x = a.useDebugValue;
  function b(w, E) {
    var R = E(),
      k = o({ inst: { value: R, getSnapshot: E } }),
      A = k[0].inst,
      _ = k[1];
    return (
      f(
        function () {
          ((A.value = R), (A.getSnapshot = E), p(A) && _({ inst: A }));
        },
        [w, R, E],
      ),
      d(
        function () {
          return (
            p(A) && _({ inst: A }),
            w(function () {
              p(A) && _({ inst: A });
            })
          );
        },
        [w],
      ),
      x(R),
      R
    );
  }
  function p(w) {
    var E = w.getSnapshot;
    w = w.value;
    try {
      var R = E();
      return !c(w, R);
    } catch {
      return !0;
    }
  }
  function h(w, E) {
    return E();
  }
  var v =
    typeof window > "u" ||
    typeof window.document > "u" ||
    typeof window.document.createElement > "u"
      ? h
      : b;
  return (
    (eu.useSyncExternalStore =
      a.useSyncExternalStore !== void 0 ? a.useSyncExternalStore : v),
    eu
  );
}
var im;
function ty() {
  return (im || ((im = 1), (Io.exports = ey())), Io.exports);
}
var ix = ty();
const ly = Eu.useInsertionEffect,
  ay =
    typeof window < "u" &&
    typeof window.document < "u" &&
    typeof window.document.createElement < "u",
  ny = ay ? j.useLayoutEffect : j.useEffect,
  sy = ly || ny,
  rx = (a) => {
    const i = j.useRef([a, (...c) => i[0](...c)]).current;
    return (
      sy(() => {
        i[0] = a;
      }),
      i[1]
    );
  },
  iy = "popstate",
  Tu = "pushState",
  Au = "replaceState",
  ry = "hashchange",
  rm = [iy, Tu, Au, ry],
  cy = (a) => {
    for (const i of rm) addEventListener(i, a);
    return () => {
      for (const i of rm) removeEventListener(i, a);
    };
  },
  cx = (a, i) => ix.useSyncExternalStore(cy, a, i),
  cm = () => location.search,
  oy = ({ ssrSearch: a } = {}) => cx(cm, a != null ? () => a : cm),
  om = () => location.pathname,
  uy = ({ ssrPath: a } = {}) => cx(om, a != null ? () => a : om),
  dy = (a, { replace: i = !1, state: c = null } = {}) =>
    history[i ? Au : Tu](c, "", a),
  fy = (a = {}) => [uy(a), dy],
  um = Symbol.for("wouter_v3");
if (typeof history < "u" && typeof window[um] > "u") {
  for (const a of [Tu, Au]) {
    const i = history[a];
    history[a] = function () {
      const c = i.apply(this, arguments),
        o = new Event(a);
      return ((o.arguments = arguments), dispatchEvent(o), c);
    };
  }
  Object.defineProperty(window, um, { value: !0 });
}
const hy = (a, i) =>
    i.toLowerCase().indexOf(a.toLowerCase())
      ? "~" + i
      : i.slice(a.length) || "/",
  ox = (a = "") => (a === "/" ? "" : a),
  my = (a, i) => (a[0] === "~" ? a.slice(1) : ox(i) + a),
  xy = (a = "", i) => hy(dm(ox(a)), dm(i)),
  dm = (a) => {
    try {
      return decodeURI(a);
    } catch {
      return a;
    }
  },
  ux = {
    hook: fy,
    searchHook: oy,
    parser: Iv,
    base: "",
    ssrPath: void 0,
    ssrSearch: void 0,
    ssrContext: void 0,
    hrefs: (a) => a,
    aroundNav: (a, i, c) => a(i, c),
  },
  dx = j.createContext(ux),
  Rs = () => j.useContext(dx),
  fx = {},
  hx = j.createContext(fx),
  py = () => j.useContext(hx),
  gr = (a) => {
    const [i, c] = a.hook(a);
    return [xy(a.base, i), rx((o, d) => a.aroundNav(c, my(o, a.base), d))];
  },
  vn = () => gr(Rs()),
  mx = (a, i, c, o) => {
    const { pattern: d, keys: f } =
        i instanceof RegExp ? { keys: !1, pattern: i } : a(i || "*", o),
      x = d.exec(c) || [],
      [b, ...p] = x;
    return b !== void 0
      ? [
          !0,
          (() => {
            const h =
              f !== !1
                ? Object.fromEntries(f.map((w, E) => [w, p[E]]))
                : x.groups;
            let v = { ...p };
            return (h && Object.assign(v, h), v);
          })(),
          ...(o ? [b] : []),
        ]
      : [!1, null];
  },
  xx = ({ children: a, ...i }) => {
    const c = Rs(),
      o = i.hook ? ux : c;
    let d = o;
    const [f, x = i.ssrSearch ?? ""] = i.ssrPath?.split("?") ?? [];
    (f && ((i.ssrSearch = x), (i.ssrPath = f)),
      (i.hrefs = i.hrefs ?? i.hook?.hrefs),
      (i.searchHook = i.searchHook ?? i.hook?.searchHook));
    let b = j.useRef({}),
      p = b.current,
      h = p;
    for (let v in o) {
      const w = v === "base" ? o[v] + (i[v] ?? "") : (i[v] ?? o[v]);
      (p === h && w !== h[v] && (b.current = h = { ...h }),
        (h[v] = w),
        (w !== o[v] || w !== d[v]) && (d = h));
    }
    return j.createElement(dx.Provider, { value: d, children: a });
  },
  fm = ({ children: a, component: i }, c) =>
    i ? j.createElement(i, { params: c }) : typeof a == "function" ? a(c) : a,
  by = (a) => {
    let i = j.useRef(fx);
    const c = i.current;
    return (i.current =
      Object.keys(a).length !== Object.keys(c).length ||
      Object.entries(a).some(([o, d]) => d !== c[o])
        ? a
        : c);
  },
  xl = ({ path: a, nest: i, match: c, ...o }) => {
    const d = Rs(),
      [f] = gr(d),
      [x, b, p] = c ?? mx(d.parser, a, f, i),
      h = by({ ...py(), ...b });
    if (!x) return null;
    const v = p ? j.createElement(xx, { base: p }, fm(o, h)) : fm(o, h);
    return j.createElement(hx.Provider, { value: h, children: v });
  },
  Ye = j.forwardRef((a, i) => {
    const c = Rs(),
      [o, d] = gr(c),
      {
        to: f = "",
        href: x = f,
        onClick: b,
        asChild: p,
        children: h,
        className: v,
        replace: w,
        state: E,
        transition: R,
        ...k
      } = a,
      A = rx((B) => {
        B.ctrlKey ||
          B.metaKey ||
          B.altKey ||
          B.shiftKey ||
          B.button !== 0 ||
          (b?.(B), B.defaultPrevented || (B.preventDefault(), d(x, a)));
      }),
      _ = c.hrefs(x[0] === "~" ? x.slice(1) : c.base + x, c);
    return p && j.isValidElement(h)
      ? j.cloneElement(h, { onClick: A, href: _ })
      : j.createElement("a", {
          ...k,
          onClick: A,
          href: _,
          className: v?.call ? v(o === x) : v,
          children: h,
          ref: i,
        });
  }),
  px = (a) =>
    Array.isArray(a)
      ? a.flatMap((i) => px(i && i.type === j.Fragment ? i.props.children : i))
      : [a],
  gy = ({ children: a, location: i }) => {
    const c = Rs(),
      [o] = gr(c);
    for (const d of px(a)) {
      let f = 0;
      if (
        j.isValidElement(d) &&
        (f = mx(c.parser, d.props.path, i || o, d.props.nest))[0]
      )
        return j.cloneElement(d, { match: f });
    }
    return null;
  };
var vr = class {
    constructor() {
      ((this.listeners = new Set()),
        (this.subscribe = this.subscribe.bind(this)));
    }
    subscribe(a) {
      return (
        this.listeners.add(a),
        this.onSubscribe(),
        () => {
          (this.listeners.delete(a), this.onUnsubscribe());
        }
      );
    }
    hasListeners() {
      return this.listeners.size > 0;
    }
    onSubscribe() {}
    onUnsubscribe() {}
  },
  vy = {
    setTimeout: (a, i) => setTimeout(a, i),
    clearTimeout: (a) => clearTimeout(a),
    setInterval: (a, i) => setInterval(a, i),
    clearInterval: (a) => clearInterval(a),
  },
  yy = class {
    #e = vy;
    #l = !1;
    setTimeoutProvider(a) {
      this.#e = a;
    }
    setTimeout(a, i) {
      return this.#e.setTimeout(a, i);
    }
    clearTimeout(a) {
      this.#e.clearTimeout(a);
    }
    setInterval(a, i) {
      return this.#e.setInterval(a, i);
    }
    clearInterval(a) {
      this.#e.clearInterval(a);
    }
  },
  cu = new yy();
function jy(a) {
  setTimeout(a, 0);
}
var yr = typeof window > "u" || "Deno" in globalThis;
function qt() {}
function Ny(a, i) {
  return typeof a == "function" ? a(i) : a;
}
function wy(a) {
  return typeof a == "number" && a >= 0 && a !== 1 / 0;
}
function Sy(a, i) {
  return Math.max(a + (i || 0) - Date.now(), 0);
}
function ou(a, i) {
  return typeof a == "function" ? a(i) : a;
}
function Ey(a, i) {
  return typeof a == "function" ? a(i) : a;
}
function hm(a, i) {
  const {
    type: c = "all",
    exact: o,
    fetchStatus: d,
    predicate: f,
    queryKey: x,
    stale: b,
  } = a;
  if (x) {
    if (o) {
      if (i.queryHash !== Cu(x, i.options)) return !1;
    } else if (!Ts(i.queryKey, x)) return !1;
  }
  if (c !== "all") {
    const p = i.isActive();
    if ((c === "active" && !p) || (c === "inactive" && p)) return !1;
  }
  return !(
    (typeof b == "boolean" && i.isStale() !== b) ||
    (d && d !== i.state.fetchStatus) ||
    (f && !f(i))
  );
}
function mm(a, i) {
  const { exact: c, status: o, predicate: d, mutationKey: f } = a;
  if (f) {
    if (!i.options.mutationKey) return !1;
    if (c) {
      if (Es(i.options.mutationKey) !== Es(f)) return !1;
    } else if (!Ts(i.options.mutationKey, f)) return !1;
  }
  return !((o && i.state.status !== o) || (d && !d(i)));
}
function Cu(a, i) {
  return (i?.queryKeyHashFn || Es)(a);
}
function Es(a) {
  return JSON.stringify(a, (i, c) =>
    uu(c)
      ? Object.keys(c)
          .sort()
          .reduce((o, d) => ((o[d] = c[d]), o), {})
      : c,
  );
}
function Ts(a, i) {
  return a === i
    ? !0
    : typeof a != typeof i
      ? !1
      : a && i && typeof a == "object" && typeof i == "object"
        ? Object.keys(i).every((c) => Ts(a[c], i[c]))
        : !1;
}
var Ty = Object.prototype.hasOwnProperty;
function bx(a, i, c = 0) {
  if (a === i) return a;
  if (c > 500) return i;
  const o = xm(a) && xm(i);
  if (!o && !(uu(a) && uu(i))) return i;
  const f = (o ? a : Object.keys(a)).length,
    x = o ? i : Object.keys(i),
    b = x.length,
    p = o ? new Array(b) : {};
  let h = 0;
  for (let v = 0; v < b; v++) {
    const w = o ? v : x[v],
      E = a[w],
      R = i[w];
    if (E === R) {
      ((p[w] = E), (o ? v < f : Ty.call(a, w)) && h++);
      continue;
    }
    if (
      E === null ||
      R === null ||
      typeof E != "object" ||
      typeof R != "object"
    ) {
      p[w] = R;
      continue;
    }
    const k = bx(E, R, c + 1);
    ((p[w] = k), k === E && h++);
  }
  return f === b && h === f ? a : p;
}
function xm(a) {
  return Array.isArray(a) && a.length === Object.keys(a).length;
}
function uu(a) {
  if (!pm(a)) return !1;
  const i = a.constructor;
  if (i === void 0) return !0;
  const c = i.prototype;
  return !(
    !pm(c) ||
    !c.hasOwnProperty("isPrototypeOf") ||
    Object.getPrototypeOf(a) !== Object.prototype
  );
}
function pm(a) {
  return Object.prototype.toString.call(a) === "[object Object]";
}
function Ay(a) {
  return new Promise((i) => {
    cu.setTimeout(i, a);
  });
}
function Cy(a, i, c) {
  return typeof c.structuralSharing == "function"
    ? c.structuralSharing(a, i)
    : c.structuralSharing !== !1
      ? bx(a, i)
      : i;
}
function Oy(a, i, c = 0) {
  const o = [...a, i];
  return c && o.length > c ? o.slice(1) : o;
}
function Ry(a, i, c = 0) {
  const o = [i, ...a];
  return c && o.length > c ? o.slice(0, -1) : o;
}
var Ou = Symbol();
function gx(a, i) {
  return !a.queryFn && i?.initialPromise
    ? () => i.initialPromise
    : !a.queryFn || a.queryFn === Ou
      ? () => Promise.reject(new Error(`Missing queryFn: '${a.queryHash}'`))
      : a.queryFn;
}
function My(a, i, c) {
  let o = !1,
    d;
  return (
    Object.defineProperty(a, "signal", {
      enumerable: !0,
      get: () => (
        (d ??= i()),
        o ||
          ((o = !0),
          d.aborted ? c() : d.addEventListener("abort", c, { once: !0 })),
        d
      ),
    }),
    a
  );
}
var _y = class extends vr {
    #e;
    #l;
    #t;
    constructor() {
      (super(),
        (this.#t = (a) => {
          if (!yr && window.addEventListener) {
            const i = () => a();
            return (
              window.addEventListener("visibilitychange", i, !1),
              () => {
                window.removeEventListener("visibilitychange", i);
              }
            );
          }
        }));
    }
    onSubscribe() {
      this.#l || this.setEventListener(this.#t);
    }
    onUnsubscribe() {
      this.hasListeners() || (this.#l?.(), (this.#l = void 0));
    }
    setEventListener(a) {
      ((this.#t = a),
        this.#l?.(),
        (this.#l = a((i) => {
          typeof i == "boolean" ? this.setFocused(i) : this.onFocus();
        })));
    }
    setFocused(a) {
      this.#e !== a && ((this.#e = a), this.onFocus());
    }
    onFocus() {
      const a = this.isFocused();
      this.listeners.forEach((i) => {
        i(a);
      });
    }
    isFocused() {
      return typeof this.#e == "boolean"
        ? this.#e
        : globalThis.document?.visibilityState !== "hidden";
    }
  },
  vx = new _y();
function ky() {
  let a, i;
  const c = new Promise((d, f) => {
    ((a = d), (i = f));
  });
  ((c.status = "pending"), c.catch(() => {}));
  function o(d) {
    (Object.assign(c, d), delete c.resolve, delete c.reject);
  }
  return (
    (c.resolve = (d) => {
      (o({ status: "fulfilled", value: d }), a(d));
    }),
    (c.reject = (d) => {
      (o({ status: "rejected", reason: d }), i(d));
    }),
    c
  );
}
var Dy = jy;
function zy() {
  let a = [],
    i = 0,
    c = (b) => {
      b();
    },
    o = (b) => {
      b();
    },
    d = Dy;
  const f = (b) => {
      i
        ? a.push(b)
        : d(() => {
            c(b);
          });
    },
    x = () => {
      const b = a;
      ((a = []),
        b.length &&
          d(() => {
            o(() => {
              b.forEach((p) => {
                c(p);
              });
            });
          }));
    };
  return {
    batch: (b) => {
      let p;
      i++;
      try {
        p = b();
      } finally {
        (i--, i || x());
      }
      return p;
    },
    batchCalls:
      (b) =>
      (...p) => {
        f(() => {
          b(...p);
        });
      },
    schedule: f,
    setNotifyFunction: (b) => {
      c = b;
    },
    setBatchNotifyFunction: (b) => {
      o = b;
    },
    setScheduler: (b) => {
      d = b;
    },
  };
}
var rt = zy(),
  Uy = class extends vr {
    #e = !0;
    #l;
    #t;
    constructor() {
      (super(),
        (this.#t = (a) => {
          if (!yr && window.addEventListener) {
            const i = () => a(!0),
              c = () => a(!1);
            return (
              window.addEventListener("online", i, !1),
              window.addEventListener("offline", c, !1),
              () => {
                (window.removeEventListener("online", i),
                  window.removeEventListener("offline", c));
              }
            );
          }
        }));
    }
    onSubscribe() {
      this.#l || this.setEventListener(this.#t);
    }
    onUnsubscribe() {
      this.hasListeners() || (this.#l?.(), (this.#l = void 0));
    }
    setEventListener(a) {
      ((this.#t = a), this.#l?.(), (this.#l = a(this.setOnline.bind(this))));
    }
    setOnline(a) {
      this.#e !== a &&
        ((this.#e = a),
        this.listeners.forEach((c) => {
          c(a);
        }));
    }
    isOnline() {
      return this.#e;
    }
  },
  ir = new Uy();
function Hy(a) {
  return Math.min(1e3 * 2 ** a, 3e4);
}
function yx(a) {
  return (a ?? "online") === "online" ? ir.isOnline() : !0;
}
var du = class extends Error {
  constructor(a) {
    (super("CancelledError"),
      (this.revert = a?.revert),
      (this.silent = a?.silent));
  }
};
function jx(a) {
  let i = !1,
    c = 0,
    o;
  const d = ky(),
    f = () => d.status !== "pending",
    x = (A) => {
      if (!f()) {
        const _ = new du(A);
        (E(_), a.onCancel?.(_));
      }
    },
    b = () => {
      i = !0;
    },
    p = () => {
      i = !1;
    },
    h = () =>
      vx.isFocused() &&
      (a.networkMode === "always" || ir.isOnline()) &&
      a.canRun(),
    v = () => yx(a.networkMode) && a.canRun(),
    w = (A) => {
      f() || (o?.(), d.resolve(A));
    },
    E = (A) => {
      f() || (o?.(), d.reject(A));
    },
    R = () =>
      new Promise((A) => {
        ((o = (_) => {
          (f() || h()) && A(_);
        }),
          a.onPause?.());
      }).then(() => {
        ((o = void 0), f() || a.onContinue?.());
      }),
    k = () => {
      if (f()) return;
      let A;
      const _ = c === 0 ? a.initialPromise : void 0;
      try {
        A = _ ?? a.fn();
      } catch (B) {
        A = Promise.reject(B);
      }
      Promise.resolve(A)
        .then(w)
        .catch((B) => {
          if (f()) return;
          const V = a.retry ?? (yr ? 0 : 3),
            Y = a.retryDelay ?? Hy,
            Z = typeof Y == "function" ? Y(c, B) : Y,
            X =
              V === !0 ||
              (typeof V == "number" && c < V) ||
              (typeof V == "function" && V(c, B));
          if (i || !X) {
            E(B);
            return;
          }
          (c++,
            a.onFail?.(c, B),
            Ay(Z)
              .then(() => (h() ? void 0 : R()))
              .then(() => {
                i ? E(B) : k();
              }));
        });
    };
  return {
    promise: d,
    status: () => d.status,
    cancel: x,
    continue: () => (o?.(), d),
    cancelRetry: b,
    continueRetry: p,
    canStart: v,
    start: () => (v() ? k() : R().then(k), d),
  };
}
var Nx = class {
    #e;
    destroy() {
      this.clearGcTimeout();
    }
    scheduleGc() {
      (this.clearGcTimeout(),
        wy(this.gcTime) &&
          (this.#e = cu.setTimeout(() => {
            this.optionalRemove();
          }, this.gcTime)));
    }
    updateGcTime(a) {
      this.gcTime = Math.max(this.gcTime || 0, a ?? (yr ? 1 / 0 : 300 * 1e3));
    }
    clearGcTimeout() {
      this.#e && (cu.clearTimeout(this.#e), (this.#e = void 0));
    }
  },
  Ly = class extends Nx {
    #e;
    #l;
    #t;
    #n;
    #a;
    #i;
    #r;
    constructor(a) {
      (super(),
        (this.#r = !1),
        (this.#i = a.defaultOptions),
        this.setOptions(a.options),
        (this.observers = []),
        (this.#n = a.client),
        (this.#t = this.#n.getQueryCache()),
        (this.queryKey = a.queryKey),
        (this.queryHash = a.queryHash),
        (this.#e = gm(this.options)),
        (this.state = a.state ?? this.#e),
        this.scheduleGc());
    }
    get meta() {
      return this.options.meta;
    }
    get promise() {
      return this.#a?.promise;
    }
    setOptions(a) {
      if (
        ((this.options = { ...this.#i, ...a }),
        this.updateGcTime(this.options.gcTime),
        this.state && this.state.data === void 0)
      ) {
        const i = gm(this.options);
        i.data !== void 0 &&
          (this.setState(bm(i.data, i.dataUpdatedAt)), (this.#e = i));
      }
    }
    optionalRemove() {
      !this.observers.length &&
        this.state.fetchStatus === "idle" &&
        this.#t.remove(this);
    }
    setData(a, i) {
      const c = Cy(this.state.data, a, this.options);
      return (
        this.#s({
          data: c,
          type: "success",
          dataUpdatedAt: i?.updatedAt,
          manual: i?.manual,
        }),
        c
      );
    }
    setState(a, i) {
      this.#s({ type: "setState", state: a, setStateOptions: i });
    }
    cancel(a) {
      const i = this.#a?.promise;
      return (this.#a?.cancel(a), i ? i.then(qt).catch(qt) : Promise.resolve());
    }
    destroy() {
      (super.destroy(), this.cancel({ silent: !0 }));
    }
    reset() {
      (this.destroy(), this.setState(this.#e));
    }
    isActive() {
      return this.observers.some((a) => Ey(a.options.enabled, this) !== !1);
    }
    isDisabled() {
      return this.getObserversCount() > 0
        ? !this.isActive()
        : this.options.queryFn === Ou ||
            this.state.dataUpdateCount + this.state.errorUpdateCount === 0;
    }
    isStatic() {
      return this.getObserversCount() > 0
        ? this.observers.some((a) => ou(a.options.staleTime, this) === "static")
        : !1;
    }
    isStale() {
      return this.getObserversCount() > 0
        ? this.observers.some((a) => a.getCurrentResult().isStale)
        : this.state.data === void 0 || this.state.isInvalidated;
    }
    isStaleByTime(a = 0) {
      return this.state.data === void 0
        ? !0
        : a === "static"
          ? !1
          : this.state.isInvalidated
            ? !0
            : !Sy(this.state.dataUpdatedAt, a);
    }
    onFocus() {
      (this.observers
        .find((i) => i.shouldFetchOnWindowFocus())
        ?.refetch({ cancelRefetch: !1 }),
        this.#a?.continue());
    }
    onOnline() {
      (this.observers
        .find((i) => i.shouldFetchOnReconnect())
        ?.refetch({ cancelRefetch: !1 }),
        this.#a?.continue());
    }
    addObserver(a) {
      this.observers.includes(a) ||
        (this.observers.push(a),
        this.clearGcTimeout(),
        this.#t.notify({ type: "observerAdded", query: this, observer: a }));
    }
    removeObserver(a) {
      this.observers.includes(a) &&
        ((this.observers = this.observers.filter((i) => i !== a)),
        this.observers.length ||
          (this.#a &&
            (this.#r ? this.#a.cancel({ revert: !0 }) : this.#a.cancelRetry()),
          this.scheduleGc()),
        this.#t.notify({ type: "observerRemoved", query: this, observer: a }));
    }
    getObserversCount() {
      return this.observers.length;
    }
    invalidate() {
      this.state.isInvalidated || this.#s({ type: "invalidate" });
    }
    async fetch(a, i) {
      if (
        this.state.fetchStatus !== "idle" &&
        this.#a?.status() !== "rejected"
      ) {
        if (this.state.data !== void 0 && i?.cancelRefetch)
          this.cancel({ silent: !0 });
        else if (this.#a) return (this.#a.continueRetry(), this.#a.promise);
      }
      if ((a && this.setOptions(a), !this.options.queryFn)) {
        const b = this.observers.find((p) => p.options.queryFn);
        b && this.setOptions(b.options);
      }
      const c = new AbortController(),
        o = (b) => {
          Object.defineProperty(b, "signal", {
            enumerable: !0,
            get: () => ((this.#r = !0), c.signal),
          });
        },
        d = () => {
          const b = gx(this.options, i),
            h = (() => {
              const v = {
                client: this.#n,
                queryKey: this.queryKey,
                meta: this.meta,
              };
              return (o(v), v);
            })();
          return (
            (this.#r = !1),
            this.options.persister ? this.options.persister(b, h, this) : b(h)
          );
        },
        x = (() => {
          const b = {
            fetchOptions: i,
            options: this.options,
            queryKey: this.queryKey,
            client: this.#n,
            state: this.state,
            fetchFn: d,
          };
          return (o(b), b);
        })();
      (this.options.behavior?.onFetch(x, this),
        (this.#l = this.state),
        (this.state.fetchStatus === "idle" ||
          this.state.fetchMeta !== x.fetchOptions?.meta) &&
          this.#s({ type: "fetch", meta: x.fetchOptions?.meta }),
        (this.#a = jx({
          initialPromise: i?.initialPromise,
          fn: x.fetchFn,
          onCancel: (b) => {
            (b instanceof du &&
              b.revert &&
              this.setState({ ...this.#l, fetchStatus: "idle" }),
              c.abort());
          },
          onFail: (b, p) => {
            this.#s({ type: "failed", failureCount: b, error: p });
          },
          onPause: () => {
            this.#s({ type: "pause" });
          },
          onContinue: () => {
            this.#s({ type: "continue" });
          },
          retry: x.options.retry,
          retryDelay: x.options.retryDelay,
          networkMode: x.options.networkMode,
          canRun: () => !0,
        })));
      try {
        const b = await this.#a.start();
        if (b === void 0)
          throw new Error(`${this.queryHash} data is undefined`);
        return (
          this.setData(b),
          this.#t.config.onSuccess?.(b, this),
          this.#t.config.onSettled?.(b, this.state.error, this),
          b
        );
      } catch (b) {
        if (b instanceof du) {
          if (b.silent) return this.#a.promise;
          if (b.revert) {
            if (this.state.data === void 0) throw b;
            return this.state.data;
          }
        }
        throw (
          this.#s({ type: "error", error: b }),
          this.#t.config.onError?.(b, this),
          this.#t.config.onSettled?.(this.state.data, b, this),
          b
        );
      } finally {
        this.scheduleGc();
      }
    }
    #s(a) {
      const i = (c) => {
        switch (a.type) {
          case "failed":
            return {
              ...c,
              fetchFailureCount: a.failureCount,
              fetchFailureReason: a.error,
            };
          case "pause":
            return { ...c, fetchStatus: "paused" };
          case "continue":
            return { ...c, fetchStatus: "fetching" };
          case "fetch":
            return {
              ...c,
              ...qy(c.data, this.options),
              fetchMeta: a.meta ?? null,
            };
          case "success":
            const o = {
              ...c,
              ...bm(a.data, a.dataUpdatedAt),
              dataUpdateCount: c.dataUpdateCount + 1,
              ...(!a.manual && {
                fetchStatus: "idle",
                fetchFailureCount: 0,
                fetchFailureReason: null,
              }),
            };
            return ((this.#l = a.manual ? o : void 0), o);
          case "error":
            const d = a.error;
            return {
              ...c,
              error: d,
              errorUpdateCount: c.errorUpdateCount + 1,
              errorUpdatedAt: Date.now(),
              fetchFailureCount: c.fetchFailureCount + 1,
              fetchFailureReason: d,
              fetchStatus: "idle",
              status: "error",
              isInvalidated: !0,
            };
          case "invalidate":
            return { ...c, isInvalidated: !0 };
          case "setState":
            return { ...c, ...a.state };
        }
      };
      ((this.state = i(this.state)),
        rt.batch(() => {
          (this.observers.forEach((c) => {
            c.onQueryUpdate();
          }),
            this.#t.notify({ query: this, type: "updated", action: a }));
        }));
    }
  };
function qy(a, i) {
  return {
    fetchFailureCount: 0,
    fetchFailureReason: null,
    fetchStatus: yx(i.networkMode) ? "fetching" : "paused",
    ...(a === void 0 && { error: null, status: "pending" }),
  };
}
function bm(a, i) {
  return {
    data: a,
    dataUpdatedAt: i ?? Date.now(),
    error: null,
    isInvalidated: !1,
    status: "success",
  };
}
function gm(a) {
  const i =
      typeof a.initialData == "function" ? a.initialData() : a.initialData,
    c = i !== void 0,
    o = c
      ? typeof a.initialDataUpdatedAt == "function"
        ? a.initialDataUpdatedAt()
        : a.initialDataUpdatedAt
      : 0;
  return {
    data: i,
    dataUpdateCount: 0,
    dataUpdatedAt: c ? (o ?? Date.now()) : 0,
    error: null,
    errorUpdateCount: 0,
    errorUpdatedAt: 0,
    fetchFailureCount: 0,
    fetchFailureReason: null,
    fetchMeta: null,
    isInvalidated: !1,
    status: c ? "success" : "pending",
    fetchStatus: "idle",
  };
}
function vm(a) {
  return {
    onFetch: (i, c) => {
      const o = i.options,
        d = i.fetchOptions?.meta?.fetchMore?.direction,
        f = i.state.data?.pages || [],
        x = i.state.data?.pageParams || [];
      let b = { pages: [], pageParams: [] },
        p = 0;
      const h = async () => {
        let v = !1;
        const w = (k) => {
            My(
              k,
              () => i.signal,
              () => (v = !0),
            );
          },
          E = gx(i.options, i.fetchOptions),
          R = async (k, A, _) => {
            if (v) return Promise.reject();
            if (A == null && k.pages.length) return Promise.resolve(k);
            const V = (() => {
                const $ = {
                  client: i.client,
                  queryKey: i.queryKey,
                  pageParam: A,
                  direction: _ ? "backward" : "forward",
                  meta: i.options.meta,
                };
                return (w($), $);
              })(),
              Y = await E(V),
              { maxPages: Z } = i.options,
              X = _ ? Ry : Oy;
            return {
              pages: X(k.pages, Y, Z),
              pageParams: X(k.pageParams, A, Z),
            };
          };
        if (d && f.length) {
          const k = d === "backward",
            A = k ? By : ym,
            _ = { pages: f, pageParams: x },
            B = A(o, _);
          b = await R(_, B, k);
        } else {
          const k = a ?? f.length;
          do {
            const A = p === 0 ? (x[0] ?? o.initialPageParam) : ym(o, b);
            if (p > 0 && A == null) break;
            ((b = await R(b, A)), p++);
          } while (p < k);
        }
        return b;
      };
      i.options.persister
        ? (i.fetchFn = () =>
            i.options.persister?.(
              h,
              {
                client: i.client,
                queryKey: i.queryKey,
                meta: i.options.meta,
                signal: i.signal,
              },
              c,
            ))
        : (i.fetchFn = h);
    },
  };
}
function ym(a, { pages: i, pageParams: c }) {
  const o = i.length - 1;
  return i.length > 0 ? a.getNextPageParam(i[o], i, c[o], c) : void 0;
}
function By(a, { pages: i, pageParams: c }) {
  return i.length > 0 ? a.getPreviousPageParam?.(i[0], i, c[0], c) : void 0;
}
var Gy = class extends Nx {
  #e;
  #l;
  #t;
  #n;
  constructor(a) {
    (super(),
      (this.#e = a.client),
      (this.mutationId = a.mutationId),
      (this.#t = a.mutationCache),
      (this.#l = []),
      (this.state = a.state || Yy()),
      this.setOptions(a.options),
      this.scheduleGc());
  }
  setOptions(a) {
    ((this.options = a), this.updateGcTime(this.options.gcTime));
  }
  get meta() {
    return this.options.meta;
  }
  addObserver(a) {
    this.#l.includes(a) ||
      (this.#l.push(a),
      this.clearGcTimeout(),
      this.#t.notify({ type: "observerAdded", mutation: this, observer: a }));
  }
  removeObserver(a) {
    ((this.#l = this.#l.filter((i) => i !== a)),
      this.scheduleGc(),
      this.#t.notify({ type: "observerRemoved", mutation: this, observer: a }));
  }
  optionalRemove() {
    this.#l.length ||
      (this.state.status === "pending"
        ? this.scheduleGc()
        : this.#t.remove(this));
  }
  continue() {
    return this.#n?.continue() ?? this.execute(this.state.variables);
  }
  async execute(a) {
    const i = () => {
        this.#a({ type: "continue" });
      },
      c = {
        client: this.#e,
        meta: this.options.meta,
        mutationKey: this.options.mutationKey,
      };
    this.#n = jx({
      fn: () =>
        this.options.mutationFn
          ? this.options.mutationFn(a, c)
          : Promise.reject(new Error("No mutationFn found")),
      onFail: (f, x) => {
        this.#a({ type: "failed", failureCount: f, error: x });
      },
      onPause: () => {
        this.#a({ type: "pause" });
      },
      onContinue: i,
      retry: this.options.retry ?? 0,
      retryDelay: this.options.retryDelay,
      networkMode: this.options.networkMode,
      canRun: () => this.#t.canRun(this),
    });
    const o = this.state.status === "pending",
      d = !this.#n.canStart();
    try {
      if (o) i();
      else {
        (this.#a({ type: "pending", variables: a, isPaused: d }),
          this.#t.config.onMutate &&
            (await this.#t.config.onMutate(a, this, c)));
        const x = await this.options.onMutate?.(a, c);
        x !== this.state.context &&
          this.#a({ type: "pending", context: x, variables: a, isPaused: d });
      }
      const f = await this.#n.start();
      return (
        await this.#t.config.onSuccess?.(f, a, this.state.context, this, c),
        await this.options.onSuccess?.(f, a, this.state.context, c),
        await this.#t.config.onSettled?.(
          f,
          null,
          this.state.variables,
          this.state.context,
          this,
          c,
        ),
        await this.options.onSettled?.(f, null, a, this.state.context, c),
        this.#a({ type: "success", data: f }),
        f
      );
    } catch (f) {
      try {
        await this.#t.config.onError?.(f, a, this.state.context, this, c);
      } catch (x) {
        Promise.reject(x);
      }
      try {
        await this.options.onError?.(f, a, this.state.context, c);
      } catch (x) {
        Promise.reject(x);
      }
      try {
        await this.#t.config.onSettled?.(
          void 0,
          f,
          this.state.variables,
          this.state.context,
          this,
          c,
        );
      } catch (x) {
        Promise.reject(x);
      }
      try {
        await this.options.onSettled?.(void 0, f, a, this.state.context, c);
      } catch (x) {
        Promise.reject(x);
      }
      throw (this.#a({ type: "error", error: f }), f);
    } finally {
      this.#t.runNext(this);
    }
  }
  #a(a) {
    const i = (c) => {
      switch (a.type) {
        case "failed":
          return { ...c, failureCount: a.failureCount, failureReason: a.error };
        case "pause":
          return { ...c, isPaused: !0 };
        case "continue":
          return { ...c, isPaused: !1 };
        case "pending":
          return {
            ...c,
            context: a.context,
            data: void 0,
            failureCount: 0,
            failureReason: null,
            error: null,
            isPaused: a.isPaused,
            status: "pending",
            variables: a.variables,
            submittedAt: Date.now(),
          };
        case "success":
          return {
            ...c,
            data: a.data,
            failureCount: 0,
            failureReason: null,
            error: null,
            status: "success",
            isPaused: !1,
          };
        case "error":
          return {
            ...c,
            data: void 0,
            error: a.error,
            failureCount: c.failureCount + 1,
            failureReason: a.error,
            isPaused: !1,
            status: "error",
          };
      }
    };
    ((this.state = i(this.state)),
      rt.batch(() => {
        (this.#l.forEach((c) => {
          c.onMutationUpdate(a);
        }),
          this.#t.notify({ mutation: this, type: "updated", action: a }));
      }));
  }
};
function Yy() {
  return {
    context: void 0,
    data: void 0,
    error: null,
    failureCount: 0,
    failureReason: null,
    isPaused: !1,
    status: "idle",
    variables: void 0,
    submittedAt: 0,
  };
}
var Vy = class extends vr {
  constructor(a = {}) {
    (super(),
      (this.config = a),
      (this.#e = new Set()),
      (this.#l = new Map()),
      (this.#t = 0));
  }
  #e;
  #l;
  #t;
  build(a, i, c) {
    const o = new Gy({
      client: a,
      mutationCache: this,
      mutationId: ++this.#t,
      options: a.defaultMutationOptions(i),
      state: c,
    });
    return (this.add(o), o);
  }
  add(a) {
    this.#e.add(a);
    const i = $i(a);
    if (typeof i == "string") {
      const c = this.#l.get(i);
      c ? c.push(a) : this.#l.set(i, [a]);
    }
    this.notify({ type: "added", mutation: a });
  }
  remove(a) {
    if (this.#e.delete(a)) {
      const i = $i(a);
      if (typeof i == "string") {
        const c = this.#l.get(i);
        if (c)
          if (c.length > 1) {
            const o = c.indexOf(a);
            o !== -1 && c.splice(o, 1);
          } else c[0] === a && this.#l.delete(i);
      }
    }
    this.notify({ type: "removed", mutation: a });
  }
  canRun(a) {
    const i = $i(a);
    if (typeof i == "string") {
      const o = this.#l.get(i)?.find((d) => d.state.status === "pending");
      return !o || o === a;
    } else return !0;
  }
  runNext(a) {
    const i = $i(a);
    return typeof i == "string"
      ? (this.#l
          .get(i)
          ?.find((o) => o !== a && o.state.isPaused)
          ?.continue() ?? Promise.resolve())
      : Promise.resolve();
  }
  clear() {
    rt.batch(() => {
      (this.#e.forEach((a) => {
        this.notify({ type: "removed", mutation: a });
      }),
        this.#e.clear(),
        this.#l.clear());
    });
  }
  getAll() {
    return Array.from(this.#e);
  }
  find(a) {
    const i = { exact: !0, ...a };
    return this.getAll().find((c) => mm(i, c));
  }
  findAll(a = {}) {
    return this.getAll().filter((i) => mm(a, i));
  }
  notify(a) {
    rt.batch(() => {
      this.listeners.forEach((i) => {
        i(a);
      });
    });
  }
  resumePausedMutations() {
    const a = this.getAll().filter((i) => i.state.isPaused);
    return rt.batch(() => Promise.all(a.map((i) => i.continue().catch(qt))));
  }
};
function $i(a) {
  return a.options.scope?.id;
}
var Xy = class extends vr {
    constructor(a = {}) {
      (super(), (this.config = a), (this.#e = new Map()));
    }
    #e;
    build(a, i, c) {
      const o = i.queryKey,
        d = i.queryHash ?? Cu(o, i);
      let f = this.get(d);
      return (
        f ||
          ((f = new Ly({
            client: a,
            queryKey: o,
            queryHash: d,
            options: a.defaultQueryOptions(i),
            state: c,
            defaultOptions: a.getQueryDefaults(o),
          })),
          this.add(f)),
        f
      );
    }
    add(a) {
      this.#e.has(a.queryHash) ||
        (this.#e.set(a.queryHash, a), this.notify({ type: "added", query: a }));
    }
    remove(a) {
      const i = this.#e.get(a.queryHash);
      i &&
        (a.destroy(),
        i === a && this.#e.delete(a.queryHash),
        this.notify({ type: "removed", query: a }));
    }
    clear() {
      rt.batch(() => {
        this.getAll().forEach((a) => {
          this.remove(a);
        });
      });
    }
    get(a) {
      return this.#e.get(a);
    }
    getAll() {
      return [...this.#e.values()];
    }
    find(a) {
      const i = { exact: !0, ...a };
      return this.getAll().find((c) => hm(i, c));
    }
    findAll(a = {}) {
      const i = this.getAll();
      return Object.keys(a).length > 0 ? i.filter((c) => hm(a, c)) : i;
    }
    notify(a) {
      rt.batch(() => {
        this.listeners.forEach((i) => {
          i(a);
        });
      });
    }
    onFocus() {
      rt.batch(() => {
        this.getAll().forEach((a) => {
          a.onFocus();
        });
      });
    }
    onOnline() {
      rt.batch(() => {
        this.getAll().forEach((a) => {
          a.onOnline();
        });
      });
    }
  },
  Qy = class {
    #e;
    #l;
    #t;
    #n;
    #a;
    #i;
    #r;
    #s;
    constructor(a = {}) {
      ((this.#e = a.queryCache || new Xy()),
        (this.#l = a.mutationCache || new Vy()),
        (this.#t = a.defaultOptions || {}),
        (this.#n = new Map()),
        (this.#a = new Map()),
        (this.#i = 0));
    }
    mount() {
      (this.#i++,
        this.#i === 1 &&
          ((this.#r = vx.subscribe(async (a) => {
            a && (await this.resumePausedMutations(), this.#e.onFocus());
          })),
          (this.#s = ir.subscribe(async (a) => {
            a && (await this.resumePausedMutations(), this.#e.onOnline());
          }))));
    }
    unmount() {
      (this.#i--,
        this.#i === 0 &&
          (this.#r?.(), (this.#r = void 0), this.#s?.(), (this.#s = void 0)));
    }
    isFetching(a) {
      return this.#e.findAll({ ...a, fetchStatus: "fetching" }).length;
    }
    isMutating(a) {
      return this.#l.findAll({ ...a, status: "pending" }).length;
    }
    getQueryData(a) {
      const i = this.defaultQueryOptions({ queryKey: a });
      return this.#e.get(i.queryHash)?.state.data;
    }
    ensureQueryData(a) {
      const i = this.defaultQueryOptions(a),
        c = this.#e.build(this, i),
        o = c.state.data;
      return o === void 0
        ? this.fetchQuery(a)
        : (a.revalidateIfStale &&
            c.isStaleByTime(ou(i.staleTime, c)) &&
            this.prefetchQuery(i),
          Promise.resolve(o));
    }
    getQueriesData(a) {
      return this.#e.findAll(a).map(({ queryKey: i, state: c }) => {
        const o = c.data;
        return [i, o];
      });
    }
    setQueryData(a, i, c) {
      const o = this.defaultQueryOptions({ queryKey: a }),
        f = this.#e.get(o.queryHash)?.state.data,
        x = Ny(i, f);
      if (x !== void 0)
        return this.#e.build(this, o).setData(x, { ...c, manual: !0 });
    }
    setQueriesData(a, i, c) {
      return rt.batch(() =>
        this.#e
          .findAll(a)
          .map(({ queryKey: o }) => [o, this.setQueryData(o, i, c)]),
      );
    }
    getQueryState(a) {
      const i = this.defaultQueryOptions({ queryKey: a });
      return this.#e.get(i.queryHash)?.state;
    }
    removeQueries(a) {
      const i = this.#e;
      rt.batch(() => {
        i.findAll(a).forEach((c) => {
          i.remove(c);
        });
      });
    }
    resetQueries(a, i) {
      const c = this.#e;
      return rt.batch(
        () => (
          c.findAll(a).forEach((o) => {
            o.reset();
          }),
          this.refetchQueries({ type: "active", ...a }, i)
        ),
      );
    }
    cancelQueries(a, i = {}) {
      const c = { revert: !0, ...i },
        o = rt.batch(() => this.#e.findAll(a).map((d) => d.cancel(c)));
      return Promise.all(o).then(qt).catch(qt);
    }
    invalidateQueries(a, i = {}) {
      return rt.batch(
        () => (
          this.#e.findAll(a).forEach((c) => {
            c.invalidate();
          }),
          a?.refetchType === "none"
            ? Promise.resolve()
            : this.refetchQueries(
                { ...a, type: a?.refetchType ?? a?.type ?? "active" },
                i,
              )
        ),
      );
    }
    refetchQueries(a, i = {}) {
      const c = { ...i, cancelRefetch: i.cancelRefetch ?? !0 },
        o = rt.batch(() =>
          this.#e
            .findAll(a)
            .filter((d) => !d.isDisabled() && !d.isStatic())
            .map((d) => {
              let f = d.fetch(void 0, c);
              return (
                c.throwOnError || (f = f.catch(qt)),
                d.state.fetchStatus === "paused" ? Promise.resolve() : f
              );
            }),
        );
      return Promise.all(o).then(qt);
    }
    fetchQuery(a) {
      const i = this.defaultQueryOptions(a);
      i.retry === void 0 && (i.retry = !1);
      const c = this.#e.build(this, i);
      return c.isStaleByTime(ou(i.staleTime, c))
        ? c.fetch(i)
        : Promise.resolve(c.state.data);
    }
    prefetchQuery(a) {
      return this.fetchQuery(a).then(qt).catch(qt);
    }
    fetchInfiniteQuery(a) {
      return ((a.behavior = vm(a.pages)), this.fetchQuery(a));
    }
    prefetchInfiniteQuery(a) {
      return this.fetchInfiniteQuery(a).then(qt).catch(qt);
    }
    ensureInfiniteQueryData(a) {
      return ((a.behavior = vm(a.pages)), this.ensureQueryData(a));
    }
    resumePausedMutations() {
      return ir.isOnline()
        ? this.#l.resumePausedMutations()
        : Promise.resolve();
    }
    getQueryCache() {
      return this.#e;
    }
    getMutationCache() {
      return this.#l;
    }
    getDefaultOptions() {
      return this.#t;
    }
    setDefaultOptions(a) {
      this.#t = a;
    }
    setQueryDefaults(a, i) {
      this.#n.set(Es(a), { queryKey: a, defaultOptions: i });
    }
    getQueryDefaults(a) {
      const i = [...this.#n.values()],
        c = {};
      return (
        i.forEach((o) => {
          Ts(a, o.queryKey) && Object.assign(c, o.defaultOptions);
        }),
        c
      );
    }
    setMutationDefaults(a, i) {
      this.#a.set(Es(a), { mutationKey: a, defaultOptions: i });
    }
    getMutationDefaults(a) {
      const i = [...this.#a.values()],
        c = {};
      return (
        i.forEach((o) => {
          Ts(a, o.mutationKey) && Object.assign(c, o.defaultOptions);
        }),
        c
      );
    }
    defaultQueryOptions(a) {
      if (a._defaulted) return a;
      const i = {
        ...this.#t.queries,
        ...this.getQueryDefaults(a.queryKey),
        ...a,
        _defaulted: !0,
      };
      return (
        i.queryHash || (i.queryHash = Cu(i.queryKey, i)),
        i.refetchOnReconnect === void 0 &&
          (i.refetchOnReconnect = i.networkMode !== "always"),
        i.throwOnError === void 0 && (i.throwOnError = !!i.suspense),
        !i.networkMode && i.persister && (i.networkMode = "offlineFirst"),
        i.queryFn === Ou && (i.enabled = !1),
        i
      );
    }
    defaultMutationOptions(a) {
      return a?._defaulted
        ? a
        : {
            ...this.#t.mutations,
            ...(a?.mutationKey && this.getMutationDefaults(a.mutationKey)),
            ...a,
            _defaulted: !0,
          };
    }
    clear() {
      (this.#e.clear(), this.#l.clear());
    }
  },
  Zy = j.createContext(void 0),
  Ky = ({ client: a, children: i }) => (
    j.useEffect(
      () => (
        a.mount(),
        () => {
          a.unmount();
        }
      ),
      [a],
    ),
    s.jsx(Zy.Provider, { value: a, children: i })
  );
const Py = 1,
  $y = 1e6;
let tu = 0;
function Jy() {
  return ((tu = (tu + 1) % Number.MAX_SAFE_INTEGER), tu.toString());
}
const lu = new Map(),
  jm = (a) => {
    if (lu.has(a)) return;
    const i = setTimeout(() => {
      (lu.delete(a), ws({ type: "REMOVE_TOAST", toastId: a }));
    }, $y);
    lu.set(a, i);
  },
  Fy = (a, i) => {
    switch (i.type) {
      case "ADD_TOAST":
        return { ...a, toasts: [i.toast, ...a.toasts].slice(0, Py) };
      case "UPDATE_TOAST":
        return {
          ...a,
          toasts: a.toasts.map((c) =>
            c.id === i.toast.id ? { ...c, ...i.toast } : c,
          ),
        };
      case "DISMISS_TOAST": {
        const { toastId: c } = i;
        return (
          c
            ? jm(c)
            : a.toasts.forEach((o) => {
                jm(o.id);
              }),
          {
            ...a,
            toasts: a.toasts.map((o) =>
              o.id === c || c === void 0 ? { ...o, open: !1 } : o,
            ),
          }
        );
      }
      case "REMOVE_TOAST":
        return i.toastId === void 0
          ? { ...a, toasts: [] }
          : { ...a, toasts: a.toasts.filter((c) => c.id !== i.toastId) };
    }
  },
  ar = [];
let nr = { toasts: [] };
function ws(a) {
  ((nr = Fy(nr, a)),
    ar.forEach((i) => {
      i(nr);
    }));
}
function Wy({ ...a }) {
  const i = Jy(),
    c = (d) => ws({ type: "UPDATE_TOAST", toast: { ...d, id: i } }),
    o = () => ws({ type: "DISMISS_TOAST", toastId: i });
  return (
    ws({
      type: "ADD_TOAST",
      toast: {
        ...a,
        id: i,
        open: !0,
        onOpenChange: (d) => {
          d || o();
        },
      },
    }),
    { id: i, dismiss: o, update: c }
  );
}
function Iy() {
  const [a, i] = j.useState(nr);
  return (
    j.useEffect(
      () => (
        ar.push(i),
        () => {
          const c = ar.indexOf(i);
          c > -1 && ar.splice(c, 1);
        }
      ),
      [a],
    ),
    {
      ...a,
      toast: Wy,
      dismiss: (c) => ws({ type: "DISMISS_TOAST", toastId: c }),
    }
  );
}
var jr = sx();
const e1 = nx(jr);
function Pe(a, i, { checkForDefaultPrevented: c = !0 } = {}) {
  return function (d) {
    if ((a?.(d), c === !1 || !d.defaultPrevented)) return i?.(d);
  };
}
function Nm(a, i) {
  if (typeof a == "function") return a(i);
  a != null && (a.current = i);
}
function Ru(...a) {
  return (i) => {
    let c = !1;
    const o = a.map((d) => {
      const f = Nm(d, i);
      return (!c && typeof f == "function" && (c = !0), f);
    });
    if (c)
      return () => {
        for (let d = 0; d < o.length; d++) {
          const f = o[d];
          typeof f == "function" ? f() : Nm(a[d], null);
        }
      };
  };
}
function Bt(...a) {
  return j.useCallback(Ru(...a), a);
}
function Nr(a, i = []) {
  let c = [];
  function o(f, x) {
    const b = j.createContext(x),
      p = c.length;
    c = [...c, x];
    const h = (w) => {
      const { scope: E, children: R, ...k } = w,
        A = E?.[a]?.[p] || b,
        _ = j.useMemo(() => k, Object.values(k));
      return s.jsx(A.Provider, { value: _, children: R });
    };
    h.displayName = f + "Provider";
    function v(w, E) {
      const R = E?.[a]?.[p] || b,
        k = j.useContext(R);
      if (k) return k;
      if (x !== void 0) return x;
      throw new Error(`\`${w}\` must be used within \`${f}\``);
    }
    return [h, v];
  }
  const d = () => {
    const f = c.map((x) => j.createContext(x));
    return function (b) {
      const p = b?.[a] || f;
      return j.useMemo(() => ({ [`__scope${a}`]: { ...b, [a]: p } }), [b, p]);
    };
  };
  return ((d.scopeName = a), [o, t1(d, ...i)]);
}
function t1(...a) {
  const i = a[0];
  if (a.length === 1) return i;
  const c = () => {
    const o = a.map((d) => ({ useScope: d(), scopeName: d.scopeName }));
    return function (f) {
      const x = o.reduce((b, { useScope: p, scopeName: h }) => {
        const w = p(f)[`__scope${h}`];
        return { ...b, ...w };
      }, {});
      return j.useMemo(() => ({ [`__scope${i.scopeName}`]: x }), [x]);
    };
  };
  return ((c.scopeName = i.scopeName), c);
}
function fu(a) {
  const i = l1(a),
    c = j.forwardRef((o, d) => {
      const { children: f, ...x } = o,
        b = j.Children.toArray(f),
        p = b.find(n1);
      if (p) {
        const h = p.props.children,
          v = b.map((w) =>
            w === p
              ? j.Children.count(h) > 1
                ? j.Children.only(null)
                : j.isValidElement(h)
                  ? h.props.children
                  : null
              : w,
          );
        return s.jsx(i, {
          ...x,
          ref: d,
          children: j.isValidElement(h) ? j.cloneElement(h, void 0, v) : null,
        });
      }
      return s.jsx(i, { ...x, ref: d, children: f });
    });
  return ((c.displayName = `${a}.Slot`), c);
}
function l1(a) {
  const i = j.forwardRef((c, o) => {
    const { children: d, ...f } = c;
    if (j.isValidElement(d)) {
      const x = i1(d),
        b = s1(f, d.props);
      return (
        d.type !== j.Fragment && (b.ref = o ? Ru(o, x) : x),
        j.cloneElement(d, b)
      );
    }
    return j.Children.count(d) > 1 ? j.Children.only(null) : null;
  });
  return ((i.displayName = `${a}.SlotClone`), i);
}
var wx = Symbol("radix.slottable");
function a1(a) {
  const i = ({ children: c }) => s.jsx(s.Fragment, { children: c });
  return ((i.displayName = `${a}.Slottable`), (i.__radixId = wx), i);
}
function n1(a) {
  return (
    j.isValidElement(a) &&
    typeof a.type == "function" &&
    "__radixId" in a.type &&
    a.type.__radixId === wx
  );
}
function s1(a, i) {
  const c = { ...i };
  for (const o in i) {
    const d = a[o],
      f = i[o];
    /^on[A-Z]/.test(o)
      ? d && f
        ? (c[o] = (...b) => {
            const p = f(...b);
            return (d(...b), p);
          })
        : d && (c[o] = d)
      : o === "style"
        ? (c[o] = { ...d, ...f })
        : o === "className" && (c[o] = [d, f].filter(Boolean).join(" "));
  }
  return { ...a, ...c };
}
function i1(a) {
  let i = Object.getOwnPropertyDescriptor(a.props, "ref")?.get,
    c = i && "isReactWarning" in i && i.isReactWarning;
  return c
    ? a.ref
    : ((i = Object.getOwnPropertyDescriptor(a, "ref")?.get),
      (c = i && "isReactWarning" in i && i.isReactWarning),
      c ? a.props.ref : a.props.ref || a.ref);
}
function r1(a) {
  const i = a + "CollectionProvider",
    [c, o] = Nr(i),
    [d, f] = c(i, { collectionRef: { current: null }, itemMap: new Map() }),
    x = (A) => {
      const { scope: _, children: B } = A,
        V = bl.useRef(null),
        Y = bl.useRef(new Map()).current;
      return s.jsx(d, { scope: _, itemMap: Y, collectionRef: V, children: B });
    };
  x.displayName = i;
  const b = a + "CollectionSlot",
    p = fu(b),
    h = bl.forwardRef((A, _) => {
      const { scope: B, children: V } = A,
        Y = f(b, B),
        Z = Bt(_, Y.collectionRef);
      return s.jsx(p, { ref: Z, children: V });
    });
  h.displayName = b;
  const v = a + "CollectionItemSlot",
    w = "data-radix-collection-item",
    E = fu(v),
    R = bl.forwardRef((A, _) => {
      const { scope: B, children: V, ...Y } = A,
        Z = bl.useRef(null),
        X = Bt(_, Z),
        $ = f(v, B);
      return (
        bl.useEffect(
          () => (
            $.itemMap.set(Z, { ref: Z, ...Y }),
            () => {
              $.itemMap.delete(Z);
            }
          ),
        ),
        s.jsx(E, { [w]: "", ref: X, children: V })
      );
    });
  R.displayName = v;
  function k(A) {
    const _ = f(a + "CollectionConsumer", A);
    return bl.useCallback(() => {
      const V = _.collectionRef.current;
      if (!V) return [];
      const Y = Array.from(V.querySelectorAll(`[${w}]`));
      return Array.from(_.itemMap.values()).sort(
        ($, F) => Y.indexOf($.ref.current) - Y.indexOf(F.ref.current),
      );
    }, [_.collectionRef, _.itemMap]);
  }
  return [{ Provider: x, Slot: h, ItemSlot: R }, k, o];
}
var c1 = [
    "a",
    "button",
    "div",
    "form",
    "h2",
    "h3",
    "img",
    "input",
    "label",
    "li",
    "nav",
    "ol",
    "p",
    "select",
    "span",
    "svg",
    "ul",
  ],
  ht = c1.reduce((a, i) => {
    const c = fu(`Primitive.${i}`),
      o = j.forwardRef((d, f) => {
        const { asChild: x, ...b } = d,
          p = x ? c : i;
        return (
          typeof window < "u" && (window[Symbol.for("radix-ui")] = !0),
          s.jsx(p, { ...b, ref: f })
        );
      });
    return ((o.displayName = `Primitive.${i}`), { ...a, [i]: o });
  }, {});
function Sx(a, i) {
  a && jr.flushSync(() => a.dispatchEvent(i));
}
function gl(a) {
  const i = j.useRef(a);
  return (
    j.useEffect(() => {
      i.current = a;
    }),
    j.useMemo(
      () =>
        (...c) =>
          i.current?.(...c),
      [],
    )
  );
}
function o1(a, i = globalThis?.document) {
  const c = gl(a);
  j.useEffect(() => {
    const o = (d) => {
      d.key === "Escape" && c(d);
    };
    return (
      i.addEventListener("keydown", o, { capture: !0 }),
      () => i.removeEventListener("keydown", o, { capture: !0 })
    );
  }, [c, i]);
}
var u1 = "DismissableLayer",
  hu = "dismissableLayer.update",
  d1 = "dismissableLayer.pointerDownOutside",
  f1 = "dismissableLayer.focusOutside",
  wm,
  Ex = j.createContext({
    layers: new Set(),
    layersWithOutsidePointerEventsDisabled: new Set(),
    branches: new Set(),
  }),
  Mu = j.forwardRef((a, i) => {
    const {
        disableOutsidePointerEvents: c = !1,
        onEscapeKeyDown: o,
        onPointerDownOutside: d,
        onFocusOutside: f,
        onInteractOutside: x,
        onDismiss: b,
        ...p
      } = a,
      h = j.useContext(Ex),
      [v, w] = j.useState(null),
      E = v?.ownerDocument ?? globalThis?.document,
      [, R] = j.useState({}),
      k = Bt(i, (F) => w(F)),
      A = Array.from(h.layers),
      [_] = [...h.layersWithOutsidePointerEventsDisabled].slice(-1),
      B = A.indexOf(_),
      V = v ? A.indexOf(v) : -1,
      Y = h.layersWithOutsidePointerEventsDisabled.size > 0,
      Z = V >= B,
      X = m1((F) => {
        const K = F.target,
          ue = [...h.branches].some((ge) => ge.contains(K));
        !Z || ue || (d?.(F), x?.(F), F.defaultPrevented || b?.());
      }, E),
      $ = x1((F) => {
        const K = F.target;
        [...h.branches].some((ge) => ge.contains(K)) ||
          (f?.(F), x?.(F), F.defaultPrevented || b?.());
      }, E);
    return (
      o1((F) => {
        V === h.layers.size - 1 &&
          (o?.(F), !F.defaultPrevented && b && (F.preventDefault(), b()));
      }, E),
      j.useEffect(() => {
        if (v)
          return (
            c &&
              (h.layersWithOutsidePointerEventsDisabled.size === 0 &&
                ((wm = E.body.style.pointerEvents),
                (E.body.style.pointerEvents = "none")),
              h.layersWithOutsidePointerEventsDisabled.add(v)),
            h.layers.add(v),
            Sm(),
            () => {
              c &&
                h.layersWithOutsidePointerEventsDisabled.size === 1 &&
                (E.body.style.pointerEvents = wm);
            }
          );
      }, [v, E, c, h]),
      j.useEffect(
        () => () => {
          v &&
            (h.layers.delete(v),
            h.layersWithOutsidePointerEventsDisabled.delete(v),
            Sm());
        },
        [v, h],
      ),
      j.useEffect(() => {
        const F = () => R({});
        return (
          document.addEventListener(hu, F),
          () => document.removeEventListener(hu, F)
        );
      }, []),
      s.jsx(ht.div, {
        ...p,
        ref: k,
        style: {
          pointerEvents: Y ? (Z ? "auto" : "none") : void 0,
          ...a.style,
        },
        onFocusCapture: Pe(a.onFocusCapture, $.onFocusCapture),
        onBlurCapture: Pe(a.onBlurCapture, $.onBlurCapture),
        onPointerDownCapture: Pe(
          a.onPointerDownCapture,
          X.onPointerDownCapture,
        ),
      })
    );
  });
Mu.displayName = u1;
var h1 = "DismissableLayerBranch",
  Tx = j.forwardRef((a, i) => {
    const c = j.useContext(Ex),
      o = j.useRef(null),
      d = Bt(i, o);
    return (
      j.useEffect(() => {
        const f = o.current;
        if (f)
          return (
            c.branches.add(f),
            () => {
              c.branches.delete(f);
            }
          );
      }, [c.branches]),
      s.jsx(ht.div, { ...a, ref: d })
    );
  });
Tx.displayName = h1;
function m1(a, i = globalThis?.document) {
  const c = gl(a),
    o = j.useRef(!1),
    d = j.useRef(() => {});
  return (
    j.useEffect(() => {
      const f = (b) => {
          if (b.target && !o.current) {
            let p = function () {
              Ax(d1, c, h, { discrete: !0 });
            };
            const h = { originalEvent: b };
            b.pointerType === "touch"
              ? (i.removeEventListener("click", d.current),
                (d.current = p),
                i.addEventListener("click", d.current, { once: !0 }))
              : p();
          } else i.removeEventListener("click", d.current);
          o.current = !1;
        },
        x = window.setTimeout(() => {
          i.addEventListener("pointerdown", f);
        }, 0);
      return () => {
        (window.clearTimeout(x),
          i.removeEventListener("pointerdown", f),
          i.removeEventListener("click", d.current));
      };
    }, [i, c]),
    { onPointerDownCapture: () => (o.current = !0) }
  );
}
function x1(a, i = globalThis?.document) {
  const c = gl(a),
    o = j.useRef(!1);
  return (
    j.useEffect(() => {
      const d = (f) => {
        f.target &&
          !o.current &&
          Ax(f1, c, { originalEvent: f }, { discrete: !1 });
      };
      return (
        i.addEventListener("focusin", d),
        () => i.removeEventListener("focusin", d)
      );
    }, [i, c]),
    {
      onFocusCapture: () => (o.current = !0),
      onBlurCapture: () => (o.current = !1),
    }
  );
}
function Sm() {
  const a = new CustomEvent(hu);
  document.dispatchEvent(a);
}
function Ax(a, i, c, { discrete: o }) {
  const d = c.originalEvent.target,
    f = new CustomEvent(a, { bubbles: !1, cancelable: !0, detail: c });
  (i && d.addEventListener(a, i, { once: !0 }),
    o ? Sx(d, f) : d.dispatchEvent(f));
}
var p1 = Mu,
  b1 = Tx,
  Gt = globalThis?.document ? j.useLayoutEffect : () => {},
  g1 = "Portal",
  _u = j.forwardRef((a, i) => {
    const { container: c, ...o } = a,
      [d, f] = j.useState(!1);
    Gt(() => f(!0), []);
    const x = c || (d && globalThis?.document?.body);
    return x ? e1.createPortal(s.jsx(ht.div, { ...o, ref: i }), x) : null;
  });
_u.displayName = g1;
function v1(a, i) {
  return j.useReducer((c, o) => i[c][o] ?? c, a);
}
var wr = (a) => {
  const { present: i, children: c } = a,
    o = y1(i),
    d =
      typeof c == "function" ? c({ present: o.isPresent }) : j.Children.only(c),
    f = Bt(o.ref, j1(d));
  return typeof c == "function" || o.isPresent
    ? j.cloneElement(d, { ref: f })
    : null;
};
wr.displayName = "Presence";
function y1(a) {
  const [i, c] = j.useState(),
    o = j.useRef(null),
    d = j.useRef(a),
    f = j.useRef("none"),
    x = a ? "mounted" : "unmounted",
    [b, p] = v1(x, {
      mounted: { UNMOUNT: "unmounted", ANIMATION_OUT: "unmountSuspended" },
      unmountSuspended: { MOUNT: "mounted", ANIMATION_END: "unmounted" },
      unmounted: { MOUNT: "mounted" },
    });
  return (
    j.useEffect(() => {
      const h = Ji(o.current);
      f.current = b === "mounted" ? h : "none";
    }, [b]),
    Gt(() => {
      const h = o.current,
        v = d.current;
      if (v !== a) {
        const E = f.current,
          R = Ji(h);
        (a
          ? p("MOUNT")
          : R === "none" || h?.display === "none"
            ? p("UNMOUNT")
            : p(v && E !== R ? "ANIMATION_OUT" : "UNMOUNT"),
          (d.current = a));
      }
    }, [a, p]),
    Gt(() => {
      if (i) {
        let h;
        const v = i.ownerDocument.defaultView ?? window,
          w = (R) => {
            const A = Ji(o.current).includes(CSS.escape(R.animationName));
            if (R.target === i && A && (p("ANIMATION_END"), !d.current)) {
              const _ = i.style.animationFillMode;
              ((i.style.animationFillMode = "forwards"),
                (h = v.setTimeout(() => {
                  i.style.animationFillMode === "forwards" &&
                    (i.style.animationFillMode = _);
                })));
            }
          },
          E = (R) => {
            R.target === i && (f.current = Ji(o.current));
          };
        return (
          i.addEventListener("animationstart", E),
          i.addEventListener("animationcancel", w),
          i.addEventListener("animationend", w),
          () => {
            (v.clearTimeout(h),
              i.removeEventListener("animationstart", E),
              i.removeEventListener("animationcancel", w),
              i.removeEventListener("animationend", w));
          }
        );
      } else p("ANIMATION_END");
    }, [i, p]),
    {
      isPresent: ["mounted", "unmountSuspended"].includes(b),
      ref: j.useCallback((h) => {
        ((o.current = h ? getComputedStyle(h) : null), c(h));
      }, []),
    }
  );
}
function Ji(a) {
  return a?.animationName || "none";
}
function j1(a) {
  let i = Object.getOwnPropertyDescriptor(a.props, "ref")?.get,
    c = i && "isReactWarning" in i && i.isReactWarning;
  return c
    ? a.ref
    : ((i = Object.getOwnPropertyDescriptor(a, "ref")?.get),
      (c = i && "isReactWarning" in i && i.isReactWarning),
      c ? a.props.ref : a.props.ref || a.ref);
}
var N1 = Eu[" useInsertionEffect ".trim().toString()] || Gt;
function w1({ prop: a, defaultProp: i, onChange: c = () => {}, caller: o }) {
  const [d, f, x] = S1({ defaultProp: i, onChange: c }),
    b = a !== void 0,
    p = b ? a : d;
  {
    const v = j.useRef(a !== void 0);
    j.useEffect(() => {
      const w = v.current;
      (w !== b &&
        console.warn(
          `${o} is changing from ${w ? "controlled" : "uncontrolled"} to ${b ? "controlled" : "uncontrolled"}. Components should not switch from controlled to uncontrolled (or vice versa). Decide between using a controlled or uncontrolled value for the lifetime of the component.`,
        ),
        (v.current = b));
    }, [b, o]);
  }
  const h = j.useCallback(
    (v) => {
      if (b) {
        const w = E1(v) ? v(a) : v;
        w !== a && x.current?.(w);
      } else f(v);
    },
    [b, a, f, x],
  );
  return [p, h];
}
function S1({ defaultProp: a, onChange: i }) {
  const [c, o] = j.useState(a),
    d = j.useRef(c),
    f = j.useRef(i);
  return (
    N1(() => {
      f.current = i;
    }, [i]),
    j.useEffect(() => {
      d.current !== c && (f.current?.(c), (d.current = c));
    }, [c, d]),
    [c, o, f]
  );
}
function E1(a) {
  return typeof a == "function";
}
var T1 = Object.freeze({
    position: "absolute",
    border: 0,
    width: 1,
    height: 1,
    padding: 0,
    margin: -1,
    overflow: "hidden",
    clip: "rect(0, 0, 0, 0)",
    whiteSpace: "nowrap",
    wordWrap: "normal",
  }),
  A1 = "VisuallyHidden",
  Sr = j.forwardRef((a, i) =>
    s.jsx(ht.span, { ...a, ref: i, style: { ...T1, ...a.style } }),
  );
Sr.displayName = A1;
var C1 = Sr,
  ku = "ToastProvider",
  [Du, O1, R1] = r1("Toast"),
  [Cx] = Nr("Toast", [R1]),
  [M1, Er] = Cx(ku),
  Ox = (a) => {
    const {
        __scopeToast: i,
        label: c = "Notification",
        duration: o = 5e3,
        swipeDirection: d = "right",
        swipeThreshold: f = 50,
        children: x,
      } = a,
      [b, p] = j.useState(null),
      [h, v] = j.useState(0),
      w = j.useRef(!1),
      E = j.useRef(!1);
    return (
      c.trim() ||
        console.error(
          `Invalid prop \`label\` supplied to \`${ku}\`. Expected non-empty \`string\`.`,
        ),
      s.jsx(Du.Provider, {
        scope: i,
        children: s.jsx(M1, {
          scope: i,
          label: c,
          duration: o,
          swipeDirection: d,
          swipeThreshold: f,
          toastCount: h,
          viewport: b,
          onViewportChange: p,
          onToastAdd: j.useCallback(() => v((R) => R + 1), []),
          onToastRemove: j.useCallback(() => v((R) => R - 1), []),
          isFocusedToastEscapeKeyDownRef: w,
          isClosePausedRef: E,
          children: x,
        }),
      })
    );
  };
Ox.displayName = ku;
var Rx = "ToastViewport",
  _1 = ["F8"],
  mu = "toast.viewportPause",
  xu = "toast.viewportResume",
  Mx = j.forwardRef((a, i) => {
    const {
        __scopeToast: c,
        hotkey: o = _1,
        label: d = "Notifications ({hotkey})",
        ...f
      } = a,
      x = Er(Rx, c),
      b = O1(c),
      p = j.useRef(null),
      h = j.useRef(null),
      v = j.useRef(null),
      w = j.useRef(null),
      E = Bt(i, w, x.onViewportChange),
      R = o.join("+").replace(/Key/g, "").replace(/Digit/g, ""),
      k = x.toastCount > 0;
    (j.useEffect(() => {
      const _ = (B) => {
        o.length !== 0 &&
          o.every((Y) => B[Y] || B.code === Y) &&
          w.current?.focus();
      };
      return (
        document.addEventListener("keydown", _),
        () => document.removeEventListener("keydown", _)
      );
    }, [o]),
      j.useEffect(() => {
        const _ = p.current,
          B = w.current;
        if (k && _ && B) {
          const V = () => {
              if (!x.isClosePausedRef.current) {
                const $ = new CustomEvent(mu);
                (B.dispatchEvent($), (x.isClosePausedRef.current = !0));
              }
            },
            Y = () => {
              if (x.isClosePausedRef.current) {
                const $ = new CustomEvent(xu);
                (B.dispatchEvent($), (x.isClosePausedRef.current = !1));
              }
            },
            Z = ($) => {
              !_.contains($.relatedTarget) && Y();
            },
            X = () => {
              _.contains(document.activeElement) || Y();
            };
          return (
            _.addEventListener("focusin", V),
            _.addEventListener("focusout", Z),
            _.addEventListener("pointermove", V),
            _.addEventListener("pointerleave", X),
            window.addEventListener("blur", V),
            window.addEventListener("focus", Y),
            () => {
              (_.removeEventListener("focusin", V),
                _.removeEventListener("focusout", Z),
                _.removeEventListener("pointermove", V),
                _.removeEventListener("pointerleave", X),
                window.removeEventListener("blur", V),
                window.removeEventListener("focus", Y));
            }
          );
        }
      }, [k, x.isClosePausedRef]));
    const A = j.useCallback(
      ({ tabbingDirection: _ }) => {
        const V = b().map((Y) => {
          const Z = Y.ref.current,
            X = [Z, ...Q1(Z)];
          return _ === "forwards" ? X : X.reverse();
        });
        return (_ === "forwards" ? V.reverse() : V).flat();
      },
      [b],
    );
    return (
      j.useEffect(() => {
        const _ = w.current;
        if (_) {
          const B = (V) => {
            const Y = V.altKey || V.ctrlKey || V.metaKey;
            if (V.key === "Tab" && !Y) {
              const X = document.activeElement,
                $ = V.shiftKey;
              if (V.target === _ && $) {
                h.current?.focus();
                return;
              }
              const ue = A({ tabbingDirection: $ ? "backwards" : "forwards" }),
                ge = ue.findIndex((je) => je === X);
              au(ue.slice(ge + 1))
                ? V.preventDefault()
                : $
                  ? h.current?.focus()
                  : v.current?.focus();
            }
          };
          return (
            _.addEventListener("keydown", B),
            () => _.removeEventListener("keydown", B)
          );
        }
      }, [b, A]),
      s.jsxs(b1, {
        ref: p,
        role: "region",
        "aria-label": d.replace("{hotkey}", R),
        tabIndex: -1,
        style: { pointerEvents: k ? void 0 : "none" },
        children: [
          k &&
            s.jsx(pu, {
              ref: h,
              onFocusFromOutsideViewport: () => {
                const _ = A({ tabbingDirection: "forwards" });
                au(_);
              },
            }),
          s.jsx(Du.Slot, {
            scope: c,
            children: s.jsx(ht.ol, { tabIndex: -1, ...f, ref: E }),
          }),
          k &&
            s.jsx(pu, {
              ref: v,
              onFocusFromOutsideViewport: () => {
                const _ = A({ tabbingDirection: "backwards" });
                au(_);
              },
            }),
        ],
      })
    );
  });
Mx.displayName = Rx;
var _x = "ToastFocusProxy",
  pu = j.forwardRef((a, i) => {
    const { __scopeToast: c, onFocusFromOutsideViewport: o, ...d } = a,
      f = Er(_x, c);
    return s.jsx(Sr, {
      tabIndex: 0,
      ...d,
      ref: i,
      style: { position: "fixed" },
      onFocus: (x) => {
        const b = x.relatedTarget;
        !f.viewport?.contains(b) && o();
      },
    });
  });
pu.displayName = _x;
var Ms = "Toast",
  k1 = "toast.swipeStart",
  D1 = "toast.swipeMove",
  z1 = "toast.swipeCancel",
  U1 = "toast.swipeEnd",
  kx = j.forwardRef((a, i) => {
    const { forceMount: c, open: o, defaultOpen: d, onOpenChange: f, ...x } = a,
      [b, p] = w1({ prop: o, defaultProp: d ?? !0, onChange: f, caller: Ms });
    return s.jsx(wr, {
      present: c || b,
      children: s.jsx(q1, {
        open: b,
        ...x,
        ref: i,
        onClose: () => p(!1),
        onPause: gl(a.onPause),
        onResume: gl(a.onResume),
        onSwipeStart: Pe(a.onSwipeStart, (h) => {
          h.currentTarget.setAttribute("data-swipe", "start");
        }),
        onSwipeMove: Pe(a.onSwipeMove, (h) => {
          const { x: v, y: w } = h.detail.delta;
          (h.currentTarget.setAttribute("data-swipe", "move"),
            h.currentTarget.style.setProperty(
              "--radix-toast-swipe-move-x",
              `${v}px`,
            ),
            h.currentTarget.style.setProperty(
              "--radix-toast-swipe-move-y",
              `${w}px`,
            ));
        }),
        onSwipeCancel: Pe(a.onSwipeCancel, (h) => {
          (h.currentTarget.setAttribute("data-swipe", "cancel"),
            h.currentTarget.style.removeProperty("--radix-toast-swipe-move-x"),
            h.currentTarget.style.removeProperty("--radix-toast-swipe-move-y"),
            h.currentTarget.style.removeProperty("--radix-toast-swipe-end-x"),
            h.currentTarget.style.removeProperty("--radix-toast-swipe-end-y"));
        }),
        onSwipeEnd: Pe(a.onSwipeEnd, (h) => {
          const { x: v, y: w } = h.detail.delta;
          (h.currentTarget.setAttribute("data-swipe", "end"),
            h.currentTarget.style.removeProperty("--radix-toast-swipe-move-x"),
            h.currentTarget.style.removeProperty("--radix-toast-swipe-move-y"),
            h.currentTarget.style.setProperty(
              "--radix-toast-swipe-end-x",
              `${v}px`,
            ),
            h.currentTarget.style.setProperty(
              "--radix-toast-swipe-end-y",
              `${w}px`,
            ),
            p(!1));
        }),
      }),
    });
  });
kx.displayName = Ms;
var [H1, L1] = Cx(Ms, { onClose() {} }),
  q1 = j.forwardRef((a, i) => {
    const {
        __scopeToast: c,
        type: o = "foreground",
        duration: d,
        open: f,
        onClose: x,
        onEscapeKeyDown: b,
        onPause: p,
        onResume: h,
        onSwipeStart: v,
        onSwipeMove: w,
        onSwipeCancel: E,
        onSwipeEnd: R,
        ...k
      } = a,
      A = Er(Ms, c),
      [_, B] = j.useState(null),
      V = Bt(i, (W) => B(W)),
      Y = j.useRef(null),
      Z = j.useRef(null),
      X = d || A.duration,
      $ = j.useRef(0),
      F = j.useRef(X),
      K = j.useRef(0),
      { onToastAdd: ue, onToastRemove: ge } = A,
      je = gl(() => {
        (_?.contains(document.activeElement) && A.viewport?.focus(), x());
      }),
      he = j.useCallback(
        (W) => {
          !W ||
            W === 1 / 0 ||
            (window.clearTimeout(K.current),
            ($.current = new Date().getTime()),
            (K.current = window.setTimeout(je, W)));
        },
        [je],
      );
    (j.useEffect(() => {
      const W = A.viewport;
      if (W) {
        const fe = () => {
            (he(F.current), h?.());
          },
          O = () => {
            const G = new Date().getTime() - $.current;
            ((F.current = F.current - G),
              window.clearTimeout(K.current),
              p?.());
          };
        return (
          W.addEventListener(mu, O),
          W.addEventListener(xu, fe),
          () => {
            (W.removeEventListener(mu, O), W.removeEventListener(xu, fe));
          }
        );
      }
    }, [A.viewport, X, p, h, he]),
      j.useEffect(() => {
        f && !A.isClosePausedRef.current && he(X);
      }, [f, X, A.isClosePausedRef, he]),
      j.useEffect(() => (ue(), () => ge()), [ue, ge]));
    const we = j.useMemo(() => (_ ? Bx(_) : null), [_]);
    return A.viewport
      ? s.jsxs(s.Fragment, {
          children: [
            we &&
              s.jsx(B1, {
                __scopeToast: c,
                role: "status",
                "aria-live": o === "foreground" ? "assertive" : "polite",
                children: we,
              }),
            s.jsx(H1, {
              scope: c,
              onClose: je,
              children: jr.createPortal(
                s.jsx(Du.ItemSlot, {
                  scope: c,
                  children: s.jsx(p1, {
                    asChild: !0,
                    onEscapeKeyDown: Pe(b, () => {
                      (A.isFocusedToastEscapeKeyDownRef.current || je(),
                        (A.isFocusedToastEscapeKeyDownRef.current = !1));
                    }),
                    children: s.jsx(ht.li, {
                      tabIndex: 0,
                      "data-state": f ? "open" : "closed",
                      "data-swipe-direction": A.swipeDirection,
                      ...k,
                      ref: V,
                      style: {
                        userSelect: "none",
                        touchAction: "none",
                        ...a.style,
                      },
                      onKeyDown: Pe(a.onKeyDown, (W) => {
                        W.key === "Escape" &&
                          (b?.(W.nativeEvent),
                          W.nativeEvent.defaultPrevented ||
                            ((A.isFocusedToastEscapeKeyDownRef.current = !0),
                            je()));
                      }),
                      onPointerDown: Pe(a.onPointerDown, (W) => {
                        W.button === 0 &&
                          (Y.current = { x: W.clientX, y: W.clientY });
                      }),
                      onPointerMove: Pe(a.onPointerMove, (W) => {
                        if (!Y.current) return;
                        const fe = W.clientX - Y.current.x,
                          O = W.clientY - Y.current.y,
                          G = !!Z.current,
                          Q = ["left", "right"].includes(A.swipeDirection),
                          se = ["left", "up"].includes(A.swipeDirection)
                            ? Math.min
                            : Math.max,
                          y = Q ? se(0, fe) : 0,
                          q = Q ? 0 : se(0, O),
                          J = W.pointerType === "touch" ? 10 : 2,
                          P = { x: y, y: q },
                          ae = { originalEvent: W, delta: P };
                        G
                          ? ((Z.current = P), Fi(D1, w, ae, { discrete: !1 }))
                          : Em(P, A.swipeDirection, J)
                            ? ((Z.current = P),
                              Fi(k1, v, ae, { discrete: !1 }),
                              W.target.setPointerCapture(W.pointerId))
                            : (Math.abs(fe) > J || Math.abs(O) > J) &&
                              (Y.current = null);
                      }),
                      onPointerUp: Pe(a.onPointerUp, (W) => {
                        const fe = Z.current,
                          O = W.target;
                        if (
                          (O.hasPointerCapture(W.pointerId) &&
                            O.releasePointerCapture(W.pointerId),
                          (Z.current = null),
                          (Y.current = null),
                          fe)
                        ) {
                          const G = W.currentTarget,
                            Q = { originalEvent: W, delta: fe };
                          (Em(fe, A.swipeDirection, A.swipeThreshold)
                            ? Fi(U1, R, Q, { discrete: !0 })
                            : Fi(z1, E, Q, { discrete: !0 }),
                            G.addEventListener(
                              "click",
                              (se) => se.preventDefault(),
                              { once: !0 },
                            ));
                        }
                      }),
                    }),
                  }),
                }),
                A.viewport,
              ),
            }),
          ],
        })
      : null;
  }),
  B1 = (a) => {
    const { __scopeToast: i, children: c, ...o } = a,
      d = Er(Ms, i),
      [f, x] = j.useState(!1),
      [b, p] = j.useState(!1);
    return (
      V1(() => x(!0)),
      j.useEffect(() => {
        const h = window.setTimeout(() => p(!0), 1e3);
        return () => window.clearTimeout(h);
      }, []),
      b
        ? null
        : s.jsx(_u, {
            asChild: !0,
            children: s.jsx(Sr, {
              ...o,
              children:
                f && s.jsxs(s.Fragment, { children: [d.label, " ", c] }),
            }),
          })
    );
  },
  G1 = "ToastTitle",
  Dx = j.forwardRef((a, i) => {
    const { __scopeToast: c, ...o } = a;
    return s.jsx(ht.div, { ...o, ref: i });
  });
Dx.displayName = G1;
var Y1 = "ToastDescription",
  zx = j.forwardRef((a, i) => {
    const { __scopeToast: c, ...o } = a;
    return s.jsx(ht.div, { ...o, ref: i });
  });
zx.displayName = Y1;
var Ux = "ToastAction",
  Hx = j.forwardRef((a, i) => {
    const { altText: c, ...o } = a;
    return c.trim()
      ? s.jsx(qx, {
          altText: c,
          asChild: !0,
          children: s.jsx(zu, { ...o, ref: i }),
        })
      : (console.error(
          `Invalid prop \`altText\` supplied to \`${Ux}\`. Expected non-empty \`string\`.`,
        ),
        null);
  });
Hx.displayName = Ux;
var Lx = "ToastClose",
  zu = j.forwardRef((a, i) => {
    const { __scopeToast: c, ...o } = a,
      d = L1(Lx, c);
    return s.jsx(qx, {
      asChild: !0,
      children: s.jsx(ht.button, {
        type: "button",
        ...o,
        ref: i,
        onClick: Pe(a.onClick, d.onClose),
      }),
    });
  });
zu.displayName = Lx;
var qx = j.forwardRef((a, i) => {
  const { __scopeToast: c, altText: o, ...d } = a;
  return s.jsx(ht.div, {
    "data-radix-toast-announce-exclude": "",
    "data-radix-toast-announce-alt": o || void 0,
    ...d,
    ref: i,
  });
});
function Bx(a) {
  const i = [];
  return (
    Array.from(a.childNodes).forEach((o) => {
      if (
        (o.nodeType === o.TEXT_NODE && o.textContent && i.push(o.textContent),
        X1(o))
      ) {
        const d = o.ariaHidden || o.hidden || o.style.display === "none",
          f = o.dataset.radixToastAnnounceExclude === "";
        if (!d)
          if (f) {
            const x = o.dataset.radixToastAnnounceAlt;
            x && i.push(x);
          } else i.push(...Bx(o));
      }
    }),
    i
  );
}
function Fi(a, i, c, { discrete: o }) {
  const d = c.originalEvent.currentTarget,
    f = new CustomEvent(a, { bubbles: !0, cancelable: !0, detail: c });
  (i && d.addEventListener(a, i, { once: !0 }),
    o ? Sx(d, f) : d.dispatchEvent(f));
}
var Em = (a, i, c = 0) => {
  const o = Math.abs(a.x),
    d = Math.abs(a.y),
    f = o > d;
  return i === "left" || i === "right" ? f && o > c : !f && d > c;
};
function V1(a = () => {}) {
  const i = gl(a);
  Gt(() => {
    let c = 0,
      o = 0;
    return (
      (c = window.requestAnimationFrame(
        () => (o = window.requestAnimationFrame(i)),
      )),
      () => {
        (window.cancelAnimationFrame(c), window.cancelAnimationFrame(o));
      }
    );
  }, [i]);
}
function X1(a) {
  return a.nodeType === a.ELEMENT_NODE;
}
function Q1(a) {
  const i = [],
    c = document.createTreeWalker(a, NodeFilter.SHOW_ELEMENT, {
      acceptNode: (o) => {
        const d = o.tagName === "INPUT" && o.type === "hidden";
        return o.disabled || o.hidden || d
          ? NodeFilter.FILTER_SKIP
          : o.tabIndex >= 0
            ? NodeFilter.FILTER_ACCEPT
            : NodeFilter.FILTER_SKIP;
      },
    });
  for (; c.nextNode(); ) i.push(c.currentNode);
  return i;
}
function au(a) {
  const i = document.activeElement;
  return a.some((c) =>
    c === i ? !0 : (c.focus(), document.activeElement !== i),
  );
}
var Z1 = Ox,
  Gx = Mx,
  Yx = kx,
  Vx = Dx,
  Xx = zx,
  Qx = Hx,
  Zx = zu;
function Kx(a) {
  var i,
    c,
    o = "";
  if (typeof a == "string" || typeof a == "number") o += a;
  else if (typeof a == "object")
    if (Array.isArray(a)) {
      var d = a.length;
      for (i = 0; i < d; i++)
        a[i] && (c = Kx(a[i])) && (o && (o += " "), (o += c));
    } else for (c in a) a[c] && (o && (o += " "), (o += c));
  return o;
}
function Px() {
  for (var a, i, c = 0, o = "", d = arguments.length; c < d; c++)
    (a = arguments[c]) && (i = Kx(a)) && (o && (o += " "), (o += i));
  return o;
}
const Tm = (a) => (typeof a == "boolean" ? `${a}` : a === 0 ? "0" : a),
  Am = Px,
  Uu = (a, i) => (c) => {
    var o;
    if (i?.variants == null) return Am(a, c?.class, c?.className);
    const { variants: d, defaultVariants: f } = i,
      x = Object.keys(d).map((h) => {
        const v = c?.[h],
          w = f?.[h];
        if (v === null) return null;
        const E = Tm(v) || Tm(w);
        return d[h][E];
      }),
      b =
        c &&
        Object.entries(c).reduce((h, v) => {
          let [w, E] = v;
          return (E === void 0 || (h[w] = E), h);
        }, {}),
      p =
        i == null || (o = i.compoundVariants) === null || o === void 0
          ? void 0
          : o.reduce((h, v) => {
              let { class: w, className: E, ...R } = v;
              return Object.entries(R).every((k) => {
                let [A, _] = k;
                return Array.isArray(_)
                  ? _.includes({ ...f, ...b }[A])
                  : { ...f, ...b }[A] === _;
              })
                ? [...h, w, E]
                : h;
            }, []);
    return Am(a, x, p, c?.class, c?.className);
  };
const K1 = (a) => a.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(),
  P1 = (a) =>
    a.replace(/^([A-Z])|[\s-_]+(\w)/g, (i, c, o) =>
      o ? o.toUpperCase() : c.toLowerCase(),
    ),
  Cm = (a) => {
    const i = P1(a);
    return i.charAt(0).toUpperCase() + i.slice(1);
  },
  $x = (...a) =>
    a
      .filter((i, c, o) => !!i && i.trim() !== "" && o.indexOf(i) === c)
      .join(" ")
      .trim(),
  $1 = (a) => {
    for (const i in a)
      if (i.startsWith("aria-") || i === "role" || i === "title") return !0;
  };
var J1 = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round",
};
const F1 = j.forwardRef(
  (
    {
      color: a = "currentColor",
      size: i = 24,
      strokeWidth: c = 2,
      absoluteStrokeWidth: o,
      className: d = "",
      children: f,
      iconNode: x,
      ...b
    },
    p,
  ) =>
    j.createElement(
      "svg",
      {
        ref: p,
        ...J1,
        width: i,
        height: i,
        stroke: a,
        strokeWidth: o ? (Number(c) * 24) / Number(i) : c,
        className: $x("lucide", d),
        ...(!f && !$1(b) && { "aria-hidden": "true" }),
        ...b,
      },
      [
        ...x.map(([h, v]) => j.createElement(h, v)),
        ...(Array.isArray(f) ? f : [f]),
      ],
    ),
);
const ie = (a, i) => {
  const c = j.forwardRef(({ className: o, ...d }, f) =>
    j.createElement(F1, {
      ref: f,
      iconNode: i,
      className: $x(`lucide-${K1(Cm(a))}`, `lucide-${a}`, o),
      ...d,
    }),
  );
  return ((c.displayName = Cm(a)), c);
};
const W1 = [
    ["path", { d: "m12 19-7-7 7-7", key: "1l729n" }],
    ["path", { d: "M19 12H5", key: "x3x0zl" }],
  ],
  I1 = ie("arrow-left", W1);
const e2 = [
    [
      "path",
      {
        d: "m15.477 12.89 1.515 8.526a.5.5 0 0 1-.81.47l-3.58-2.687a1 1 0 0 0-1.197 0l-3.586 2.686a.5.5 0 0 1-.81-.469l1.514-8.526",
        key: "1yiouv",
      },
    ],
    ["circle", { cx: "12", cy: "8", r: "6", key: "1vp47v" }],
  ],
  t2 = ie("award", e2);
const l2 = [
    ["path", { d: "M10.268 21a2 2 0 0 0 3.464 0", key: "vwvbt9" }],
    [
      "path",
      {
        d: "M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326",
        key: "11g9vi",
      },
    ],
  ],
  Tr = ie("bell", l2);
const a2 = [
    ["path", { d: "M10 12h4", key: "a56b0p" }],
    ["path", { d: "M10 8h4", key: "1sr2af" }],
    ["path", { d: "M14 21v-3a2 2 0 0 0-4 0v3", key: "1rgiei" }],
    [
      "path",
      {
        d: "M6 10H4a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-2",
        key: "secmi2",
      },
    ],
    ["path", { d: "M6 21V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v16", key: "16ra0t" }],
  ],
  Jx = ie("building-2", a2);
const n2 = [
    ["path", { d: "M8 2v4", key: "1cmpym" }],
    ["path", { d: "M16 2v4", key: "4m81vk" }],
    [
      "rect",
      { width: "18", height: "18", x: "3", y: "4", rx: "2", key: "1hopcy" },
    ],
    ["path", { d: "M3 10h18", key: "8toen8" }],
  ],
  s2 = ie("calendar", n2);
const i2 = [
    [
      "path",
      {
        d: "M13.997 4a2 2 0 0 1 1.76 1.05l.486.9A2 2 0 0 0 18.003 7H20a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h1.997a2 2 0 0 0 1.759-1.048l.489-.904A2 2 0 0 1 10.004 4z",
        key: "18u6gg",
      },
    ],
    ["circle", { cx: "12", cy: "13", r: "3", key: "1vg3eu" }],
  ],
  Ar = ie("camera", i2);
const r2 = [
    [
      "path",
      {
        d: "M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2",
        key: "5owen",
      },
    ],
    ["circle", { cx: "7", cy: "17", r: "2", key: "u2ysq9" }],
    ["path", { d: "M9 17h6", key: "r8uit2" }],
    ["circle", { cx: "17", cy: "17", r: "2", key: "axvx0g" }],
  ],
  rr = ie("car", r2);
const c2 = [
    ["path", { d: "M3 3v16a2 2 0 0 0 2 2h16", key: "c24i48" }],
    ["path", { d: "M18 17V9", key: "2bz60n" }],
    ["path", { d: "M13 17V5", key: "1frdt8" }],
    ["path", { d: "M8 17v-3", key: "17ska0" }],
  ],
  Cr = ie("chart-column", c2);
const o2 = [["path", { d: "m6 9 6 6 6-6", key: "qrunsl" }]],
  Om = ie("chevron-down", o2);
const u2 = [["path", { d: "m15 18-6-6 6-6", key: "1wnfg3" }]],
  As = ie("chevron-left", u2);
const d2 = [
    ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
    ["line", { x1: "12", x2: "12", y1: "8", y2: "12", key: "1pkeuh" }],
    ["line", { x1: "12", x2: "12.01", y1: "16", y2: "16", key: "4dfq90" }],
  ],
  Fx = ie("circle-alert", d2);
const f2 = [
    ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
    ["path", { d: "m9 12 2 2 4-4", key: "dzmm74" }],
  ],
  xn = ie("circle-check", f2);
const h2 = [
    ["path", { d: "M21.801 10A10 10 0 1 1 17 3.335", key: "yps3ct" }],
    ["path", { d: "m9 11 3 3L22 4", key: "1pflzl" }],
  ],
  Wi = ie("circle-check-big", h2);
const m2 = [
    ["path", { d: "M12 6v6l4 2", key: "mmk7yg" }],
    ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ],
  pn = ie("clock", m2);
const x2 = [
    [
      "rect",
      { width: "20", height: "14", x: "2", y: "5", rx: "2", key: "ynyp8z" },
    ],
    ["line", { x1: "2", x2: "22", y1: "10", y2: "10", key: "1b3vmo" }],
  ],
  p2 = ie("credit-card", x2);
const b2 = [
    ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
    ["line", { x1: "22", x2: "18", y1: "12", y2: "12", key: "l9bcsi" }],
    ["line", { x1: "6", x2: "2", y1: "12", y2: "12", key: "13hhkx" }],
    ["line", { x1: "12", x2: "12", y1: "6", y2: "2", key: "10w3f3" }],
    ["line", { x1: "12", x2: "12", y1: "22", y2: "18", key: "15g9kq" }],
  ],
  g2 = ie("crosshair", b2);
const v2 = [
    [
      "path",
      {
        d: "M7 16.3c2.2 0 4-1.83 4-4.05 0-1.16-.57-2.26-1.71-3.19S7.29 6.75 7 5.3c-.29 1.45-1.14 2.84-2.29 3.76S3 11.1 3 12.25c0 2.22 1.8 4.05 4 4.05z",
        key: "1ptgy4",
      },
    ],
    [
      "path",
      {
        d: "M12.56 6.6A10.97 10.97 0 0 0 14 3.02c.5 2.5 2 4.9 4 6.5s3 3.5 3 5.5a6.98 6.98 0 0 1-11.91 4.97",
        key: "1sl1rz",
      },
    ],
  ],
  Wx = ie("droplets", v2);
const y2 = [
    ["circle", { cx: "12", cy: "12", r: "1", key: "41hilf" }],
    ["circle", { cx: "12", cy: "5", r: "1", key: "gxeob9" }],
    ["circle", { cx: "12", cy: "19", r: "1", key: "lyex9k" }],
  ],
  hn = ie("ellipsis-vertical", y2);
const j2 = [
    [
      "path",
      {
        d: "M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49",
        key: "ct8e1f",
      },
    ],
    ["path", { d: "M14.084 14.158a3 3 0 0 1-4.242-4.242", key: "151rxh" }],
    [
      "path",
      {
        d: "M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143",
        key: "13bj9a",
      },
    ],
    ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  ],
  Rm = ie("eye-off", j2);
const N2 = [
    [
      "path",
      {
        d: "M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",
        key: "1nclc0",
      },
    ],
    ["circle", { cx: "12", cy: "12", r: "3", key: "1v7zrd" }],
  ],
  Mm = ie("eye", N2);
const w2 = [
    [
      "path",
      {
        d: "M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",
        key: "1rqfz7",
      },
    ],
    ["path", { d: "M14 2v4a2 2 0 0 0 2 2h4", key: "tnqrlb" }],
    ["path", { d: "M10 9H8", key: "b1mrlr" }],
    ["path", { d: "M16 13H8", key: "t4e002" }],
    ["path", { d: "M16 17H8", key: "z1uh3a" }],
  ],
  wa = ie("file-text", w2);
const S2 = [
    [
      "path",
      {
        d: "M4 22V4a1 1 0 0 1 .4-.8A6 6 0 0 1 8 2c3 0 5 2 7.333 2q2 0 3.067-.8A1 1 0 0 1 20 4v10a1 1 0 0 1-.4.8A6 6 0 0 1 16 16c-3 0-5-2-8-2a6 6 0 0 0-4 1.528",
        key: "1jaruq",
      },
    ],
  ],
  E2 = ie("flag", S2);
const T2 = [
    [
      "path",
      {
        d: "M10 20a1 1 0 0 0 .553.895l2 1A1 1 0 0 0 14 21v-7a2 2 0 0 1 .517-1.341L21.74 4.67A1 1 0 0 0 21 3H3a1 1 0 0 0-.742 1.67l7.225 7.989A2 2 0 0 1 10 14z",
        key: "sc7q7i",
      },
    ],
  ],
  Ix = ie("funnel", T2);
const A2 = [
    [
      "path",
      { d: "M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8", key: "5wwlr5" },
    ],
    [
      "path",
      {
        d: "M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
        key: "r6nss1",
      },
    ],
  ],
  C2 = ie("house", A2);
const O2 = [
    [
      "rect",
      {
        width: "18",
        height: "18",
        x: "3",
        y: "3",
        rx: "2",
        ry: "2",
        key: "1m3agn",
      },
    ],
    ["circle", { cx: "9", cy: "9", r: "2", key: "af1f0g" }],
    ["path", { d: "m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21", key: "1xmnt7" }],
  ],
  ep = ie("image", O2);
const R2 = [
    ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
    ["path", { d: "M12 16v-4", key: "1dtifu" }],
    ["path", { d: "M12 8h.01", key: "e9boi3" }],
  ],
  M2 = ie("info", R2);
const _2 = [
    [
      "path",
      {
        d: "M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z",
        key: "zw3jo",
      },
    ],
    [
      "path",
      {
        d: "M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12",
        key: "1wduqc",
      },
    ],
    [
      "path",
      {
        d: "M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17",
        key: "kqbvx6",
      },
    ],
  ],
  k2 = ie("layers", _2);
const D2 = [
    ["path", { d: "m16 17 5-5-5-5", key: "1bji2h" }],
    ["path", { d: "M21 12H9", key: "dn1m92" }],
    ["path", { d: "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4", key: "1uf3rs" }],
  ],
  z2 = ie("log-out", D2);
const U2 = [
    [
      "rect",
      {
        width: "18",
        height: "11",
        x: "3",
        y: "11",
        rx: "2",
        ry: "2",
        key: "1w4ew1",
      },
    ],
    ["path", { d: "M7 11V7a5 5 0 0 1 10 0v4", key: "fwvmzm" }],
  ],
  _m = ie("lock", U2);
const H2 = [
    [
      "path",
      {
        d: "M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",
        key: "1r0f0z",
      },
    ],
    ["circle", { cx: "12", cy: "10", r: "3", key: "ilqhr7" }],
  ],
  Na = ie("map-pin", H2);
const L2 = [
    [
      "path",
      {
        d: "M14.106 5.553a2 2 0 0 0 1.788 0l3.659-1.83A1 1 0 0 1 21 4.619v12.764a1 1 0 0 1-.553.894l-4.553 2.277a2 2 0 0 1-1.788 0l-4.212-2.106a2 2 0 0 0-1.788 0l-3.659 1.83A1 1 0 0 1 3 19.381V6.618a1 1 0 0 1 .553-.894l4.553-2.277a2 2 0 0 1 1.788 0z",
        key: "169xi5",
      },
    ],
    ["path", { d: "M15 5.764v15", key: "1pn4in" }],
    ["path", { d: "M9 3.236v15", key: "1uimfh" }],
  ],
  Hu = ie("map", L2);
const q2 = [
    ["path", { d: "M4 5h16", key: "1tepv9" }],
    ["path", { d: "M4 12h16", key: "1lakjw" }],
    ["path", { d: "M4 19h16", key: "1djgab" }],
  ],
  B2 = ie("menu", q2);
const G2 = [
    [
      "path",
      {
        d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
        key: "18887p",
      },
    ],
  ],
  Y2 = ie("message-square", G2);
const V2 = [
    ["polygon", { points: "3 11 22 2 13 21 11 13 3 11", key: "1ltx0t" }],
  ],
  tp = ie("navigation", V2);
const X2 = [
    [
      "path",
      {
        d: "M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384",
        key: "9njp5v",
      },
    ],
  ],
  km = ie("phone", X2);
const Q2 = [
    ["path", { d: "M5 12h14", key: "1ays0h" }],
    ["path", { d: "M12 5v14", key: "s699le" }],
  ],
  cr = ie("plus", Q2);
const Z2 = [
    ["path", { d: "m21 21-4.34-4.34", key: "14j7rj" }],
    ["circle", { cx: "11", cy: "11", r: "8", key: "4ej97u" }],
  ],
  Lu = ie("search", Z2);
const K2 = [
    [
      "path",
      {
        d: "M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z",
        key: "1ffxy3",
      },
    ],
    ["path", { d: "m21.854 2.147-10.94 10.939", key: "12cjpa" }],
  ],
  P2 = ie("send", K2);
const $2 = [
    [
      "path",
      {
        d: "M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915",
        key: "1i5ecw",
      },
    ],
    ["circle", { cx: "12", cy: "12", r: "3", key: "1v7zrd" }],
  ],
  qu = ie("settings", $2);
const J2 = [
    ["circle", { cx: "18", cy: "5", r: "3", key: "gq8acd" }],
    ["circle", { cx: "6", cy: "12", r: "3", key: "w7nqdw" }],
    ["circle", { cx: "18", cy: "19", r: "3", key: "1xt0gg" }],
    [
      "line",
      { x1: "8.59", x2: "15.42", y1: "13.51", y2: "17.49", key: "47mynk" },
    ],
    [
      "line",
      { x1: "15.41", x2: "8.59", y1: "6.51", y2: "10.49", key: "1n3mei" },
    ],
  ],
  F2 = ie("share-2", J2);
const W2 = [
    [
      "path",
      {
        d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
        key: "oel41y",
      },
    ],
  ],
  lp = ie("shield", W2);
const I2 = [
    [
      "path",
      {
        d: "M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z",
        key: "r04s7s",
      },
    ],
  ],
  or = ie("star", I2);
const ej = [
    ["path", { d: "M10 11v6", key: "nco0om" }],
    ["path", { d: "M14 11v6", key: "outv1u" }],
    ["path", { d: "M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6", key: "miytrc" }],
    ["path", { d: "M3 6h18", key: "d0wm0j" }],
    ["path", { d: "M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2", key: "e791ji" }],
  ],
  ap = ie("trash-2", ej);
const tj = [
    ["path", { d: "M16 17h6v-6", key: "t6n2it" }],
    ["path", { d: "m22 17-8.5-8.5-5 5L2 7", key: "x473p" }],
  ],
  np = ie("trending-down", tj);
const lj = [
    ["path", { d: "M16 7h6v6", key: "box55l" }],
    ["path", { d: "m22 7-8.5 8.5-5-5L2 17", key: "1t1m79" }],
  ],
  Ss = ie("trending-up", lj);
const aj = [
    [
      "path",
      {
        d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",
        key: "wmoenq",
      },
    ],
    ["path", { d: "M12 9v4", key: "juzpu7" }],
    ["path", { d: "M12 17h.01", key: "p32p05" }],
  ],
  Bu = ie("triangle-alert", aj);
const nj = [
    ["path", { d: "m16 11 2 2 4-4", key: "9rsbq5" }],
    ["path", { d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2", key: "1yyitq" }],
    ["circle", { cx: "9", cy: "7", r: "4", key: "nufk8" }],
  ],
  sj = ie("user-check", nj);
const ij = [
    ["path", { d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2", key: "1yyitq" }],
    ["path", { d: "M16 3.128a4 4 0 0 1 0 7.744", key: "16gr8j" }],
    ["path", { d: "M22 21v-2a4 4 0 0 0-3-3.87", key: "kshegd" }],
    ["circle", { cx: "9", cy: "7", r: "4", key: "nufk8" }],
  ],
  Cs = ie("users", ij);
const rj = [
    ["path", { d: "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2", key: "975kel" }],
    ["circle", { cx: "12", cy: "7", r: "4", key: "17ys0d" }],
  ],
  sp = ie("user", rj);
const cj = [
    ["path", { d: "M18 6 6 18", key: "1bl5f8" }],
    ["path", { d: "m6 6 12 12", key: "d8bk6v" }],
  ],
  Or = ie("x", cj);
const oj = [
    [
      "path",
      {
        d: "M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",
        key: "1xq2db",
      },
    ],
  ],
  Gu = ie("zap", oj);
const uj = [
    ["circle", { cx: "11", cy: "11", r: "8", key: "4ej97u" }],
    ["line", { x1: "21", x2: "16.65", y1: "21", y2: "16.65", key: "13gj7c" }],
    ["line", { x1: "11", x2: "11", y1: "8", y2: "14", key: "1vmskp" }],
    ["line", { x1: "8", x2: "14", y1: "11", y2: "11", key: "durymu" }],
  ],
  dj = ie("zoom-in", uj);
const fj = [
    ["circle", { cx: "11", cy: "11", r: "8", key: "4ej97u" }],
    ["line", { x1: "21", x2: "16.65", y1: "21", y2: "16.65", key: "13gj7c" }],
    ["line", { x1: "8", x2: "14", y1: "11", y2: "11", key: "durymu" }],
  ],
  hj = ie("zoom-out", fj),
  mj = (a, i) => {
    const c = new Array(a.length + i.length);
    for (let o = 0; o < a.length; o++) c[o] = a[o];
    for (let o = 0; o < i.length; o++) c[a.length + o] = i[o];
    return c;
  },
  xj = (a, i) => ({ classGroupId: a, validator: i }),
  ip = (a = new Map(), i = null, c) => ({
    nextPart: a,
    validators: i,
    classGroupId: c,
  }),
  ur = "-",
  Dm = [],
  pj = "arbitrary..",
  bj = (a) => {
    const i = vj(a),
      { conflictingClassGroups: c, conflictingClassGroupModifiers: o } = a;
    return {
      getClassGroupId: (x) => {
        if (x.startsWith("[") && x.endsWith("]")) return gj(x);
        const b = x.split(ur),
          p = b[0] === "" && b.length > 1 ? 1 : 0;
        return rp(b, p, i);
      },
      getConflictingClassGroupIds: (x, b) => {
        if (b) {
          const p = o[x],
            h = c[x];
          return p ? (h ? mj(h, p) : p) : h || Dm;
        }
        return c[x] || Dm;
      },
    };
  },
  rp = (a, i, c) => {
    if (a.length - i === 0) return c.classGroupId;
    const d = a[i],
      f = c.nextPart.get(d);
    if (f) {
      const h = rp(a, i + 1, f);
      if (h) return h;
    }
    const x = c.validators;
    if (x === null) return;
    const b = i === 0 ? a.join(ur) : a.slice(i).join(ur),
      p = x.length;
    for (let h = 0; h < p; h++) {
      const v = x[h];
      if (v.validator(b)) return v.classGroupId;
    }
  },
  gj = (a) =>
    a.slice(1, -1).indexOf(":") === -1
      ? void 0
      : (() => {
          const i = a.slice(1, -1),
            c = i.indexOf(":"),
            o = i.slice(0, c);
          return o ? pj + o : void 0;
        })(),
  vj = (a) => {
    const { theme: i, classGroups: c } = a;
    return yj(c, i);
  },
  yj = (a, i) => {
    const c = ip();
    for (const o in a) {
      const d = a[o];
      Yu(d, c, o, i);
    }
    return c;
  },
  Yu = (a, i, c, o) => {
    const d = a.length;
    for (let f = 0; f < d; f++) {
      const x = a[f];
      jj(x, i, c, o);
    }
  },
  jj = (a, i, c, o) => {
    if (typeof a == "string") {
      Nj(a, i, c);
      return;
    }
    if (typeof a == "function") {
      wj(a, i, c, o);
      return;
    }
    Sj(a, i, c, o);
  },
  Nj = (a, i, c) => {
    const o = a === "" ? i : cp(i, a);
    o.classGroupId = c;
  },
  wj = (a, i, c, o) => {
    if (Ej(a)) {
      Yu(a(o), i, c, o);
      return;
    }
    (i.validators === null && (i.validators = []), i.validators.push(xj(c, a)));
  },
  Sj = (a, i, c, o) => {
    const d = Object.entries(a),
      f = d.length;
    for (let x = 0; x < f; x++) {
      const [b, p] = d[x];
      Yu(p, cp(i, b), c, o);
    }
  },
  cp = (a, i) => {
    let c = a;
    const o = i.split(ur),
      d = o.length;
    for (let f = 0; f < d; f++) {
      const x = o[f];
      let b = c.nextPart.get(x);
      (b || ((b = ip()), c.nextPart.set(x, b)), (c = b));
    }
    return c;
  },
  Ej = (a) => "isThemeGetter" in a && a.isThemeGetter === !0,
  Tj = (a) => {
    if (a < 1) return { get: () => {}, set: () => {} };
    let i = 0,
      c = Object.create(null),
      o = Object.create(null);
    const d = (f, x) => {
      ((c[f] = x), i++, i > a && ((i = 0), (o = c), (c = Object.create(null))));
    };
    return {
      get(f) {
        let x = c[f];
        if (x !== void 0) return x;
        if ((x = o[f]) !== void 0) return (d(f, x), x);
      },
      set(f, x) {
        f in c ? (c[f] = x) : d(f, x);
      },
    };
  },
  bu = "!",
  zm = ":",
  Aj = [],
  Um = (a, i, c, o, d) => ({
    modifiers: a,
    hasImportantModifier: i,
    baseClassName: c,
    maybePostfixModifierPosition: o,
    isExternal: d,
  }),
  Cj = (a) => {
    const { prefix: i, experimentalParseClassName: c } = a;
    let o = (d) => {
      const f = [];
      let x = 0,
        b = 0,
        p = 0,
        h;
      const v = d.length;
      for (let A = 0; A < v; A++) {
        const _ = d[A];
        if (x === 0 && b === 0) {
          if (_ === zm) {
            (f.push(d.slice(p, A)), (p = A + 1));
            continue;
          }
          if (_ === "/") {
            h = A;
            continue;
          }
        }
        _ === "[" ? x++ : _ === "]" ? x-- : _ === "(" ? b++ : _ === ")" && b--;
      }
      const w = f.length === 0 ? d : d.slice(p);
      let E = w,
        R = !1;
      w.endsWith(bu)
        ? ((E = w.slice(0, -1)), (R = !0))
        : w.startsWith(bu) && ((E = w.slice(1)), (R = !0));
      const k = h && h > p ? h - p : void 0;
      return Um(f, R, E, k);
    };
    if (i) {
      const d = i + zm,
        f = o;
      o = (x) =>
        x.startsWith(d) ? f(x.slice(d.length)) : Um(Aj, !1, x, void 0, !0);
    }
    if (c) {
      const d = o;
      o = (f) => c({ className: f, parseClassName: d });
    }
    return o;
  },
  Oj = (a) => {
    const i = new Map();
    return (
      a.orderSensitiveModifiers.forEach((c, o) => {
        i.set(c, 1e6 + o);
      }),
      (c) => {
        const o = [];
        let d = [];
        for (let f = 0; f < c.length; f++) {
          const x = c[f],
            b = x[0] === "[",
            p = i.has(x);
          b || p
            ? (d.length > 0 && (d.sort(), o.push(...d), (d = [])), o.push(x))
            : d.push(x);
        }
        return (d.length > 0 && (d.sort(), o.push(...d)), o);
      }
    );
  },
  Rj = (a) => ({
    cache: Tj(a.cacheSize),
    parseClassName: Cj(a),
    sortModifiers: Oj(a),
    ...bj(a),
  }),
  Mj = /\s+/,
  _j = (a, i) => {
    const {
        parseClassName: c,
        getClassGroupId: o,
        getConflictingClassGroupIds: d,
        sortModifiers: f,
      } = i,
      x = [],
      b = a.trim().split(Mj);
    let p = "";
    for (let h = b.length - 1; h >= 0; h -= 1) {
      const v = b[h],
        {
          isExternal: w,
          modifiers: E,
          hasImportantModifier: R,
          baseClassName: k,
          maybePostfixModifierPosition: A,
        } = c(v);
      if (w) {
        p = v + (p.length > 0 ? " " + p : p);
        continue;
      }
      let _ = !!A,
        B = o(_ ? k.substring(0, A) : k);
      if (!B) {
        if (!_) {
          p = v + (p.length > 0 ? " " + p : p);
          continue;
        }
        if (((B = o(k)), !B)) {
          p = v + (p.length > 0 ? " " + p : p);
          continue;
        }
        _ = !1;
      }
      const V = E.length === 0 ? "" : E.length === 1 ? E[0] : f(E).join(":"),
        Y = R ? V + bu : V,
        Z = Y + B;
      if (x.indexOf(Z) > -1) continue;
      x.push(Z);
      const X = d(B, _);
      for (let $ = 0; $ < X.length; ++$) {
        const F = X[$];
        x.push(Y + F);
      }
      p = v + (p.length > 0 ? " " + p : p);
    }
    return p;
  },
  kj = (...a) => {
    let i = 0,
      c,
      o,
      d = "";
    for (; i < a.length; )
      (c = a[i++]) && (o = op(c)) && (d && (d += " "), (d += o));
    return d;
  },
  op = (a) => {
    if (typeof a == "string") return a;
    let i,
      c = "";
    for (let o = 0; o < a.length; o++)
      a[o] && (i = op(a[o])) && (c && (c += " "), (c += i));
    return c;
  },
  Dj = (a, ...i) => {
    let c, o, d, f;
    const x = (p) => {
        const h = i.reduce((v, w) => w(v), a());
        return (
          (c = Rj(h)),
          (o = c.cache.get),
          (d = c.cache.set),
          (f = b),
          b(p)
        );
      },
      b = (p) => {
        const h = o(p);
        if (h) return h;
        const v = _j(p, c);
        return (d(p, v), v);
      };
    return ((f = x), (...p) => f(kj(...p)));
  },
  zj = [],
  Ke = (a) => {
    const i = (c) => c[a] || zj;
    return ((i.isThemeGetter = !0), i);
  },
  up = /^\[(?:(\w[\w-]*):)?(.+)\]$/i,
  dp = /^\((?:(\w[\w-]*):)?(.+)\)$/i,
  Uj = /^\d+(?:\.\d+)?\/\d+(?:\.\d+)?$/,
  Hj = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,
  Lj =
    /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,
  qj = /^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/,
  Bj = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/,
  Gj =
    /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/,
  Pl = (a) => Uj.test(a),
  pe = (a) => !!a && !Number.isNaN(Number(a)),
  $l = (a) => !!a && Number.isInteger(Number(a)),
  nu = (a) => a.endsWith("%") && pe(a.slice(0, -1)),
  pl = (a) => Hj.test(a),
  fp = () => !0,
  Yj = (a) => Lj.test(a) && !qj.test(a),
  Vu = () => !1,
  Vj = (a) => Bj.test(a),
  Xj = (a) => Gj.test(a),
  Qj = (a) => !ee(a) && !te(a),
  Zj = (a) => ta(a, xp, Vu),
  ee = (a) => up.test(a),
  ya = (a) => ta(a, pp, Yj),
  Hm = (a) => ta(a, eN, pe),
  Kj = (a) => ta(a, gp, fp),
  Pj = (a) => ta(a, bp, Vu),
  Lm = (a) => ta(a, hp, Vu),
  $j = (a) => ta(a, mp, Xj),
  Ii = (a) => ta(a, vp, Vj),
  te = (a) => dp.test(a),
  js = (a) => Ea(a, pp),
  Jj = (a) => Ea(a, bp),
  qm = (a) => Ea(a, hp),
  Fj = (a) => Ea(a, xp),
  Wj = (a) => Ea(a, mp),
  er = (a) => Ea(a, vp, !0),
  Ij = (a) => Ea(a, gp, !0),
  ta = (a, i, c) => {
    const o = up.exec(a);
    return o ? (o[1] ? i(o[1]) : c(o[2])) : !1;
  },
  Ea = (a, i, c = !1) => {
    const o = dp.exec(a);
    return o ? (o[1] ? i(o[1]) : c) : !1;
  },
  hp = (a) => a === "position" || a === "percentage",
  mp = (a) => a === "image" || a === "url",
  xp = (a) => a === "length" || a === "size" || a === "bg-size",
  pp = (a) => a === "length",
  eN = (a) => a === "number",
  bp = (a) => a === "family-name",
  gp = (a) => a === "number" || a === "weight",
  vp = (a) => a === "shadow",
  tN = () => {
    const a = Ke("color"),
      i = Ke("font"),
      c = Ke("text"),
      o = Ke("font-weight"),
      d = Ke("tracking"),
      f = Ke("leading"),
      x = Ke("breakpoint"),
      b = Ke("container"),
      p = Ke("spacing"),
      h = Ke("radius"),
      v = Ke("shadow"),
      w = Ke("inset-shadow"),
      E = Ke("text-shadow"),
      R = Ke("drop-shadow"),
      k = Ke("blur"),
      A = Ke("perspective"),
      _ = Ke("aspect"),
      B = Ke("ease"),
      V = Ke("animate"),
      Y = () => [
        "auto",
        "avoid",
        "all",
        "avoid-page",
        "page",
        "left",
        "right",
        "column",
      ],
      Z = () => [
        "center",
        "top",
        "bottom",
        "left",
        "right",
        "top-left",
        "left-top",
        "top-right",
        "right-top",
        "bottom-right",
        "right-bottom",
        "bottom-left",
        "left-bottom",
      ],
      X = () => [...Z(), te, ee],
      $ = () => ["auto", "hidden", "clip", "visible", "scroll"],
      F = () => ["auto", "contain", "none"],
      K = () => [te, ee, p],
      ue = () => [Pl, "full", "auto", ...K()],
      ge = () => [$l, "none", "subgrid", te, ee],
      je = () => ["auto", { span: ["full", $l, te, ee] }, $l, te, ee],
      he = () => [$l, "auto", te, ee],
      we = () => ["auto", "min", "max", "fr", te, ee],
      W = () => [
        "start",
        "end",
        "center",
        "between",
        "around",
        "evenly",
        "stretch",
        "baseline",
        "center-safe",
        "end-safe",
      ],
      fe = () => [
        "start",
        "end",
        "center",
        "stretch",
        "center-safe",
        "end-safe",
      ],
      O = () => ["auto", ...K()],
      G = () => [
        Pl,
        "auto",
        "full",
        "dvw",
        "dvh",
        "lvw",
        "lvh",
        "svw",
        "svh",
        "min",
        "max",
        "fit",
        ...K(),
      ],
      Q = () => [
        Pl,
        "screen",
        "full",
        "dvw",
        "lvw",
        "svw",
        "min",
        "max",
        "fit",
        ...K(),
      ],
      se = () => [
        Pl,
        "screen",
        "full",
        "lh",
        "dvh",
        "lvh",
        "svh",
        "min",
        "max",
        "fit",
        ...K(),
      ],
      y = () => [a, te, ee],
      q = () => [...Z(), qm, Lm, { position: [te, ee] }],
      J = () => ["no-repeat", { repeat: ["", "x", "y", "space", "round"] }],
      P = () => ["auto", "cover", "contain", Fj, Zj, { size: [te, ee] }],
      ae = () => [nu, js, ya],
      ce = () => ["", "none", "full", h, te, ee],
      le = () => ["", pe, js, ya],
      ze = () => ["solid", "dashed", "dotted", "double"],
      Te = () => [
        "normal",
        "multiply",
        "screen",
        "overlay",
        "darken",
        "lighten",
        "color-dodge",
        "color-burn",
        "hard-light",
        "soft-light",
        "difference",
        "exclusion",
        "hue",
        "saturation",
        "color",
        "luminosity",
      ],
      Ae = () => [pe, nu, qm, Lm],
      Nl = () => ["", "none", k, te, ee],
      zt = () => ["none", pe, te, ee],
      Xt = () => ["none", pe, te, ee],
      Et = () => [pe, te, ee],
      wl = () => [Pl, "full", ...K()];
    return {
      cacheSize: 500,
      theme: {
        animate: ["spin", "ping", "pulse", "bounce"],
        aspect: ["video"],
        blur: [pl],
        breakpoint: [pl],
        color: [fp],
        container: [pl],
        "drop-shadow": [pl],
        ease: ["in", "out", "in-out"],
        font: [Qj],
        "font-weight": [
          "thin",
          "extralight",
          "light",
          "normal",
          "medium",
          "semibold",
          "bold",
          "extrabold",
          "black",
        ],
        "inset-shadow": [pl],
        leading: ["none", "tight", "snug", "normal", "relaxed", "loose"],
        perspective: [
          "dramatic",
          "near",
          "normal",
          "midrange",
          "distant",
          "none",
        ],
        radius: [pl],
        shadow: [pl],
        spacing: ["px", pe],
        text: [pl],
        "text-shadow": [pl],
        tracking: ["tighter", "tight", "normal", "wide", "wider", "widest"],
      },
      classGroups: {
        aspect: [{ aspect: ["auto", "square", Pl, ee, te, _] }],
        container: ["container"],
        columns: [{ columns: [pe, ee, te, b] }],
        "break-after": [{ "break-after": Y() }],
        "break-before": [{ "break-before": Y() }],
        "break-inside": [
          { "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"] },
        ],
        "box-decoration": [{ "box-decoration": ["slice", "clone"] }],
        box: [{ box: ["border", "content"] }],
        display: [
          "block",
          "inline-block",
          "inline",
          "flex",
          "inline-flex",
          "table",
          "inline-table",
          "table-caption",
          "table-cell",
          "table-column",
          "table-column-group",
          "table-footer-group",
          "table-header-group",
          "table-row-group",
          "table-row",
          "flow-root",
          "grid",
          "inline-grid",
          "contents",
          "list-item",
          "hidden",
        ],
        sr: ["sr-only", "not-sr-only"],
        float: [{ float: ["right", "left", "none", "start", "end"] }],
        clear: [{ clear: ["left", "right", "both", "none", "start", "end"] }],
        isolation: ["isolate", "isolation-auto"],
        "object-fit": [
          { object: ["contain", "cover", "fill", "none", "scale-down"] },
        ],
        "object-position": [{ object: X() }],
        overflow: [{ overflow: $() }],
        "overflow-x": [{ "overflow-x": $() }],
        "overflow-y": [{ "overflow-y": $() }],
        overscroll: [{ overscroll: F() }],
        "overscroll-x": [{ "overscroll-x": F() }],
        "overscroll-y": [{ "overscroll-y": F() }],
        position: ["static", "fixed", "absolute", "relative", "sticky"],
        inset: [{ inset: ue() }],
        "inset-x": [{ "inset-x": ue() }],
        "inset-y": [{ "inset-y": ue() }],
        start: [{ "inset-s": ue(), start: ue() }],
        end: [{ "inset-e": ue(), end: ue() }],
        "inset-bs": [{ "inset-bs": ue() }],
        "inset-be": [{ "inset-be": ue() }],
        top: [{ top: ue() }],
        right: [{ right: ue() }],
        bottom: [{ bottom: ue() }],
        left: [{ left: ue() }],
        visibility: ["visible", "invisible", "collapse"],
        z: [{ z: [$l, "auto", te, ee] }],
        basis: [{ basis: [Pl, "full", "auto", b, ...K()] }],
        "flex-direction": [
          { flex: ["row", "row-reverse", "col", "col-reverse"] },
        ],
        "flex-wrap": [{ flex: ["nowrap", "wrap", "wrap-reverse"] }],
        flex: [{ flex: [pe, Pl, "auto", "initial", "none", ee] }],
        grow: [{ grow: ["", pe, te, ee] }],
        shrink: [{ shrink: ["", pe, te, ee] }],
        order: [{ order: [$l, "first", "last", "none", te, ee] }],
        "grid-cols": [{ "grid-cols": ge() }],
        "col-start-end": [{ col: je() }],
        "col-start": [{ "col-start": he() }],
        "col-end": [{ "col-end": he() }],
        "grid-rows": [{ "grid-rows": ge() }],
        "row-start-end": [{ row: je() }],
        "row-start": [{ "row-start": he() }],
        "row-end": [{ "row-end": he() }],
        "grid-flow": [
          { "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"] },
        ],
        "auto-cols": [{ "auto-cols": we() }],
        "auto-rows": [{ "auto-rows": we() }],
        gap: [{ gap: K() }],
        "gap-x": [{ "gap-x": K() }],
        "gap-y": [{ "gap-y": K() }],
        "justify-content": [{ justify: [...W(), "normal"] }],
        "justify-items": [{ "justify-items": [...fe(), "normal"] }],
        "justify-self": [{ "justify-self": ["auto", ...fe()] }],
        "align-content": [{ content: ["normal", ...W()] }],
        "align-items": [{ items: [...fe(), { baseline: ["", "last"] }] }],
        "align-self": [{ self: ["auto", ...fe(), { baseline: ["", "last"] }] }],
        "place-content": [{ "place-content": W() }],
        "place-items": [{ "place-items": [...fe(), "baseline"] }],
        "place-self": [{ "place-self": ["auto", ...fe()] }],
        p: [{ p: K() }],
        px: [{ px: K() }],
        py: [{ py: K() }],
        ps: [{ ps: K() }],
        pe: [{ pe: K() }],
        pbs: [{ pbs: K() }],
        pbe: [{ pbe: K() }],
        pt: [{ pt: K() }],
        pr: [{ pr: K() }],
        pb: [{ pb: K() }],
        pl: [{ pl: K() }],
        m: [{ m: O() }],
        mx: [{ mx: O() }],
        my: [{ my: O() }],
        ms: [{ ms: O() }],
        me: [{ me: O() }],
        mbs: [{ mbs: O() }],
        mbe: [{ mbe: O() }],
        mt: [{ mt: O() }],
        mr: [{ mr: O() }],
        mb: [{ mb: O() }],
        ml: [{ ml: O() }],
        "space-x": [{ "space-x": K() }],
        "space-x-reverse": ["space-x-reverse"],
        "space-y": [{ "space-y": K() }],
        "space-y-reverse": ["space-y-reverse"],
        size: [{ size: G() }],
        "inline-size": [{ inline: ["auto", ...Q()] }],
        "min-inline-size": [{ "min-inline": ["auto", ...Q()] }],
        "max-inline-size": [{ "max-inline": ["none", ...Q()] }],
        "block-size": [{ block: ["auto", ...se()] }],
        "min-block-size": [{ "min-block": ["auto", ...se()] }],
        "max-block-size": [{ "max-block": ["none", ...se()] }],
        w: [{ w: [b, "screen", ...G()] }],
        "min-w": [{ "min-w": [b, "screen", "none", ...G()] }],
        "max-w": [
          { "max-w": [b, "screen", "none", "prose", { screen: [x] }, ...G()] },
        ],
        h: [{ h: ["screen", "lh", ...G()] }],
        "min-h": [{ "min-h": ["screen", "lh", "none", ...G()] }],
        "max-h": [{ "max-h": ["screen", "lh", ...G()] }],
        "font-size": [{ text: ["base", c, js, ya] }],
        "font-smoothing": ["antialiased", "subpixel-antialiased"],
        "font-style": ["italic", "not-italic"],
        "font-weight": [{ font: [o, Ij, Kj] }],
        "font-stretch": [
          {
            "font-stretch": [
              "ultra-condensed",
              "extra-condensed",
              "condensed",
              "semi-condensed",
              "normal",
              "semi-expanded",
              "expanded",
              "extra-expanded",
              "ultra-expanded",
              nu,
              ee,
            ],
          },
        ],
        "font-family": [{ font: [Jj, Pj, i] }],
        "font-features": [{ "font-features": [ee] }],
        "fvn-normal": ["normal-nums"],
        "fvn-ordinal": ["ordinal"],
        "fvn-slashed-zero": ["slashed-zero"],
        "fvn-figure": ["lining-nums", "oldstyle-nums"],
        "fvn-spacing": ["proportional-nums", "tabular-nums"],
        "fvn-fraction": ["diagonal-fractions", "stacked-fractions"],
        tracking: [{ tracking: [d, te, ee] }],
        "line-clamp": [{ "line-clamp": [pe, "none", te, Hm] }],
        leading: [{ leading: [f, ...K()] }],
        "list-image": [{ "list-image": ["none", te, ee] }],
        "list-style-position": [{ list: ["inside", "outside"] }],
        "list-style-type": [{ list: ["disc", "decimal", "none", te, ee] }],
        "text-alignment": [
          { text: ["left", "center", "right", "justify", "start", "end"] },
        ],
        "placeholder-color": [{ placeholder: y() }],
        "text-color": [{ text: y() }],
        "text-decoration": [
          "underline",
          "overline",
          "line-through",
          "no-underline",
        ],
        "text-decoration-style": [{ decoration: [...ze(), "wavy"] }],
        "text-decoration-thickness": [
          { decoration: [pe, "from-font", "auto", te, ya] },
        ],
        "text-decoration-color": [{ decoration: y() }],
        "underline-offset": [{ "underline-offset": [pe, "auto", te, ee] }],
        "text-transform": [
          "uppercase",
          "lowercase",
          "capitalize",
          "normal-case",
        ],
        "text-overflow": ["truncate", "text-ellipsis", "text-clip"],
        "text-wrap": [{ text: ["wrap", "nowrap", "balance", "pretty"] }],
        indent: [{ indent: K() }],
        "vertical-align": [
          {
            align: [
              "baseline",
              "top",
              "middle",
              "bottom",
              "text-top",
              "text-bottom",
              "sub",
              "super",
              te,
              ee,
            ],
          },
        ],
        whitespace: [
          {
            whitespace: [
              "normal",
              "nowrap",
              "pre",
              "pre-line",
              "pre-wrap",
              "break-spaces",
            ],
          },
        ],
        break: [{ break: ["normal", "words", "all", "keep"] }],
        wrap: [{ wrap: ["break-word", "anywhere", "normal"] }],
        hyphens: [{ hyphens: ["none", "manual", "auto"] }],
        content: [{ content: ["none", te, ee] }],
        "bg-attachment": [{ bg: ["fixed", "local", "scroll"] }],
        "bg-clip": [{ "bg-clip": ["border", "padding", "content", "text"] }],
        "bg-origin": [{ "bg-origin": ["border", "padding", "content"] }],
        "bg-position": [{ bg: q() }],
        "bg-repeat": [{ bg: J() }],
        "bg-size": [{ bg: P() }],
        "bg-image": [
          {
            bg: [
              "none",
              {
                linear: [
                  { to: ["t", "tr", "r", "br", "b", "bl", "l", "tl"] },
                  $l,
                  te,
                  ee,
                ],
                radial: ["", te, ee],
                conic: [$l, te, ee],
              },
              Wj,
              $j,
            ],
          },
        ],
        "bg-color": [{ bg: y() }],
        "gradient-from-pos": [{ from: ae() }],
        "gradient-via-pos": [{ via: ae() }],
        "gradient-to-pos": [{ to: ae() }],
        "gradient-from": [{ from: y() }],
        "gradient-via": [{ via: y() }],
        "gradient-to": [{ to: y() }],
        rounded: [{ rounded: ce() }],
        "rounded-s": [{ "rounded-s": ce() }],
        "rounded-e": [{ "rounded-e": ce() }],
        "rounded-t": [{ "rounded-t": ce() }],
        "rounded-r": [{ "rounded-r": ce() }],
        "rounded-b": [{ "rounded-b": ce() }],
        "rounded-l": [{ "rounded-l": ce() }],
        "rounded-ss": [{ "rounded-ss": ce() }],
        "rounded-se": [{ "rounded-se": ce() }],
        "rounded-ee": [{ "rounded-ee": ce() }],
        "rounded-es": [{ "rounded-es": ce() }],
        "rounded-tl": [{ "rounded-tl": ce() }],
        "rounded-tr": [{ "rounded-tr": ce() }],
        "rounded-br": [{ "rounded-br": ce() }],
        "rounded-bl": [{ "rounded-bl": ce() }],
        "border-w": [{ border: le() }],
        "border-w-x": [{ "border-x": le() }],
        "border-w-y": [{ "border-y": le() }],
        "border-w-s": [{ "border-s": le() }],
        "border-w-e": [{ "border-e": le() }],
        "border-w-bs": [{ "border-bs": le() }],
        "border-w-be": [{ "border-be": le() }],
        "border-w-t": [{ "border-t": le() }],
        "border-w-r": [{ "border-r": le() }],
        "border-w-b": [{ "border-b": le() }],
        "border-w-l": [{ "border-l": le() }],
        "divide-x": [{ "divide-x": le() }],
        "divide-x-reverse": ["divide-x-reverse"],
        "divide-y": [{ "divide-y": le() }],
        "divide-y-reverse": ["divide-y-reverse"],
        "border-style": [{ border: [...ze(), "hidden", "none"] }],
        "divide-style": [{ divide: [...ze(), "hidden", "none"] }],
        "border-color": [{ border: y() }],
        "border-color-x": [{ "border-x": y() }],
        "border-color-y": [{ "border-y": y() }],
        "border-color-s": [{ "border-s": y() }],
        "border-color-e": [{ "border-e": y() }],
        "border-color-bs": [{ "border-bs": y() }],
        "border-color-be": [{ "border-be": y() }],
        "border-color-t": [{ "border-t": y() }],
        "border-color-r": [{ "border-r": y() }],
        "border-color-b": [{ "border-b": y() }],
        "border-color-l": [{ "border-l": y() }],
        "divide-color": [{ divide: y() }],
        "outline-style": [{ outline: [...ze(), "none", "hidden"] }],
        "outline-offset": [{ "outline-offset": [pe, te, ee] }],
        "outline-w": [{ outline: ["", pe, js, ya] }],
        "outline-color": [{ outline: y() }],
        shadow: [{ shadow: ["", "none", v, er, Ii] }],
        "shadow-color": [{ shadow: y() }],
        "inset-shadow": [{ "inset-shadow": ["none", w, er, Ii] }],
        "inset-shadow-color": [{ "inset-shadow": y() }],
        "ring-w": [{ ring: le() }],
        "ring-w-inset": ["ring-inset"],
        "ring-color": [{ ring: y() }],
        "ring-offset-w": [{ "ring-offset": [pe, ya] }],
        "ring-offset-color": [{ "ring-offset": y() }],
        "inset-ring-w": [{ "inset-ring": le() }],
        "inset-ring-color": [{ "inset-ring": y() }],
        "text-shadow": [{ "text-shadow": ["none", E, er, Ii] }],
        "text-shadow-color": [{ "text-shadow": y() }],
        opacity: [{ opacity: [pe, te, ee] }],
        "mix-blend": [
          { "mix-blend": [...Te(), "plus-darker", "plus-lighter"] },
        ],
        "bg-blend": [{ "bg-blend": Te() }],
        "mask-clip": [
          {
            "mask-clip": [
              "border",
              "padding",
              "content",
              "fill",
              "stroke",
              "view",
            ],
          },
          "mask-no-clip",
        ],
        "mask-composite": [
          { mask: ["add", "subtract", "intersect", "exclude"] },
        ],
        "mask-image-linear-pos": [{ "mask-linear": [pe] }],
        "mask-image-linear-from-pos": [{ "mask-linear-from": Ae() }],
        "mask-image-linear-to-pos": [{ "mask-linear-to": Ae() }],
        "mask-image-linear-from-color": [{ "mask-linear-from": y() }],
        "mask-image-linear-to-color": [{ "mask-linear-to": y() }],
        "mask-image-t-from-pos": [{ "mask-t-from": Ae() }],
        "mask-image-t-to-pos": [{ "mask-t-to": Ae() }],
        "mask-image-t-from-color": [{ "mask-t-from": y() }],
        "mask-image-t-to-color": [{ "mask-t-to": y() }],
        "mask-image-r-from-pos": [{ "mask-r-from": Ae() }],
        "mask-image-r-to-pos": [{ "mask-r-to": Ae() }],
        "mask-image-r-from-color": [{ "mask-r-from": y() }],
        "mask-image-r-to-color": [{ "mask-r-to": y() }],
        "mask-image-b-from-pos": [{ "mask-b-from": Ae() }],
        "mask-image-b-to-pos": [{ "mask-b-to": Ae() }],
        "mask-image-b-from-color": [{ "mask-b-from": y() }],
        "mask-image-b-to-color": [{ "mask-b-to": y() }],
        "mask-image-l-from-pos": [{ "mask-l-from": Ae() }],
        "mask-image-l-to-pos": [{ "mask-l-to": Ae() }],
        "mask-image-l-from-color": [{ "mask-l-from": y() }],
        "mask-image-l-to-color": [{ "mask-l-to": y() }],
        "mask-image-x-from-pos": [{ "mask-x-from": Ae() }],
        "mask-image-x-to-pos": [{ "mask-x-to": Ae() }],
        "mask-image-x-from-color": [{ "mask-x-from": y() }],
        "mask-image-x-to-color": [{ "mask-x-to": y() }],
        "mask-image-y-from-pos": [{ "mask-y-from": Ae() }],
        "mask-image-y-to-pos": [{ "mask-y-to": Ae() }],
        "mask-image-y-from-color": [{ "mask-y-from": y() }],
        "mask-image-y-to-color": [{ "mask-y-to": y() }],
        "mask-image-radial": [{ "mask-radial": [te, ee] }],
        "mask-image-radial-from-pos": [{ "mask-radial-from": Ae() }],
        "mask-image-radial-to-pos": [{ "mask-radial-to": Ae() }],
        "mask-image-radial-from-color": [{ "mask-radial-from": y() }],
        "mask-image-radial-to-color": [{ "mask-radial-to": y() }],
        "mask-image-radial-shape": [{ "mask-radial": ["circle", "ellipse"] }],
        "mask-image-radial-size": [
          {
            "mask-radial": [
              { closest: ["side", "corner"], farthest: ["side", "corner"] },
            ],
          },
        ],
        "mask-image-radial-pos": [{ "mask-radial-at": Z() }],
        "mask-image-conic-pos": [{ "mask-conic": [pe] }],
        "mask-image-conic-from-pos": [{ "mask-conic-from": Ae() }],
        "mask-image-conic-to-pos": [{ "mask-conic-to": Ae() }],
        "mask-image-conic-from-color": [{ "mask-conic-from": y() }],
        "mask-image-conic-to-color": [{ "mask-conic-to": y() }],
        "mask-mode": [{ mask: ["alpha", "luminance", "match"] }],
        "mask-origin": [
          {
            "mask-origin": [
              "border",
              "padding",
              "content",
              "fill",
              "stroke",
              "view",
            ],
          },
        ],
        "mask-position": [{ mask: q() }],
        "mask-repeat": [{ mask: J() }],
        "mask-size": [{ mask: P() }],
        "mask-type": [{ "mask-type": ["alpha", "luminance"] }],
        "mask-image": [{ mask: ["none", te, ee] }],
        filter: [{ filter: ["", "none", te, ee] }],
        blur: [{ blur: Nl() }],
        brightness: [{ brightness: [pe, te, ee] }],
        contrast: [{ contrast: [pe, te, ee] }],
        "drop-shadow": [{ "drop-shadow": ["", "none", R, er, Ii] }],
        "drop-shadow-color": [{ "drop-shadow": y() }],
        grayscale: [{ grayscale: ["", pe, te, ee] }],
        "hue-rotate": [{ "hue-rotate": [pe, te, ee] }],
        invert: [{ invert: ["", pe, te, ee] }],
        saturate: [{ saturate: [pe, te, ee] }],
        sepia: [{ sepia: ["", pe, te, ee] }],
        "backdrop-filter": [{ "backdrop-filter": ["", "none", te, ee] }],
        "backdrop-blur": [{ "backdrop-blur": Nl() }],
        "backdrop-brightness": [{ "backdrop-brightness": [pe, te, ee] }],
        "backdrop-contrast": [{ "backdrop-contrast": [pe, te, ee] }],
        "backdrop-grayscale": [{ "backdrop-grayscale": ["", pe, te, ee] }],
        "backdrop-hue-rotate": [{ "backdrop-hue-rotate": [pe, te, ee] }],
        "backdrop-invert": [{ "backdrop-invert": ["", pe, te, ee] }],
        "backdrop-opacity": [{ "backdrop-opacity": [pe, te, ee] }],
        "backdrop-saturate": [{ "backdrop-saturate": [pe, te, ee] }],
        "backdrop-sepia": [{ "backdrop-sepia": ["", pe, te, ee] }],
        "border-collapse": [{ border: ["collapse", "separate"] }],
        "border-spacing": [{ "border-spacing": K() }],
        "border-spacing-x": [{ "border-spacing-x": K() }],
        "border-spacing-y": [{ "border-spacing-y": K() }],
        "table-layout": [{ table: ["auto", "fixed"] }],
        caption: [{ caption: ["top", "bottom"] }],
        transition: [
          {
            transition: [
              "",
              "all",
              "colors",
              "opacity",
              "shadow",
              "transform",
              "none",
              te,
              ee,
            ],
          },
        ],
        "transition-behavior": [{ transition: ["normal", "discrete"] }],
        duration: [{ duration: [pe, "initial", te, ee] }],
        ease: [{ ease: ["linear", "initial", B, te, ee] }],
        delay: [{ delay: [pe, te, ee] }],
        animate: [{ animate: ["none", V, te, ee] }],
        backface: [{ backface: ["hidden", "visible"] }],
        perspective: [{ perspective: [A, te, ee] }],
        "perspective-origin": [{ "perspective-origin": X() }],
        rotate: [{ rotate: zt() }],
        "rotate-x": [{ "rotate-x": zt() }],
        "rotate-y": [{ "rotate-y": zt() }],
        "rotate-z": [{ "rotate-z": zt() }],
        scale: [{ scale: Xt() }],
        "scale-x": [{ "scale-x": Xt() }],
        "scale-y": [{ "scale-y": Xt() }],
        "scale-z": [{ "scale-z": Xt() }],
        "scale-3d": ["scale-3d"],
        skew: [{ skew: Et() }],
        "skew-x": [{ "skew-x": Et() }],
        "skew-y": [{ "skew-y": Et() }],
        transform: [{ transform: [te, ee, "", "none", "gpu", "cpu"] }],
        "transform-origin": [{ origin: X() }],
        "transform-style": [{ transform: ["3d", "flat"] }],
        translate: [{ translate: wl() }],
        "translate-x": [{ "translate-x": wl() }],
        "translate-y": [{ "translate-y": wl() }],
        "translate-z": [{ "translate-z": wl() }],
        "translate-none": ["translate-none"],
        accent: [{ accent: y() }],
        appearance: [{ appearance: ["none", "auto"] }],
        "caret-color": [{ caret: y() }],
        "color-scheme": [
          {
            scheme: [
              "normal",
              "dark",
              "light",
              "light-dark",
              "only-dark",
              "only-light",
            ],
          },
        ],
        cursor: [
          {
            cursor: [
              "auto",
              "default",
              "pointer",
              "wait",
              "text",
              "move",
              "help",
              "not-allowed",
              "none",
              "context-menu",
              "progress",
              "cell",
              "crosshair",
              "vertical-text",
              "alias",
              "copy",
              "no-drop",
              "grab",
              "grabbing",
              "all-scroll",
              "col-resize",
              "row-resize",
              "n-resize",
              "e-resize",
              "s-resize",
              "w-resize",
              "ne-resize",
              "nw-resize",
              "se-resize",
              "sw-resize",
              "ew-resize",
              "ns-resize",
              "nesw-resize",
              "nwse-resize",
              "zoom-in",
              "zoom-out",
              te,
              ee,
            ],
          },
        ],
        "field-sizing": [{ "field-sizing": ["fixed", "content"] }],
        "pointer-events": [{ "pointer-events": ["auto", "none"] }],
        resize: [{ resize: ["none", "", "y", "x"] }],
        "scroll-behavior": [{ scroll: ["auto", "smooth"] }],
        "scroll-m": [{ "scroll-m": K() }],
        "scroll-mx": [{ "scroll-mx": K() }],
        "scroll-my": [{ "scroll-my": K() }],
        "scroll-ms": [{ "scroll-ms": K() }],
        "scroll-me": [{ "scroll-me": K() }],
        "scroll-mbs": [{ "scroll-mbs": K() }],
        "scroll-mbe": [{ "scroll-mbe": K() }],
        "scroll-mt": [{ "scroll-mt": K() }],
        "scroll-mr": [{ "scroll-mr": K() }],
        "scroll-mb": [{ "scroll-mb": K() }],
        "scroll-ml": [{ "scroll-ml": K() }],
        "scroll-p": [{ "scroll-p": K() }],
        "scroll-px": [{ "scroll-px": K() }],
        "scroll-py": [{ "scroll-py": K() }],
        "scroll-ps": [{ "scroll-ps": K() }],
        "scroll-pe": [{ "scroll-pe": K() }],
        "scroll-pbs": [{ "scroll-pbs": K() }],
        "scroll-pbe": [{ "scroll-pbe": K() }],
        "scroll-pt": [{ "scroll-pt": K() }],
        "scroll-pr": [{ "scroll-pr": K() }],
        "scroll-pb": [{ "scroll-pb": K() }],
        "scroll-pl": [{ "scroll-pl": K() }],
        "snap-align": [{ snap: ["start", "end", "center", "align-none"] }],
        "snap-stop": [{ snap: ["normal", "always"] }],
        "snap-type": [{ snap: ["none", "x", "y", "both"] }],
        "snap-strictness": [{ snap: ["mandatory", "proximity"] }],
        touch: [{ touch: ["auto", "none", "manipulation"] }],
        "touch-x": [{ "touch-pan": ["x", "left", "right"] }],
        "touch-y": [{ "touch-pan": ["y", "up", "down"] }],
        "touch-pz": ["touch-pinch-zoom"],
        select: [{ select: ["none", "text", "all", "auto"] }],
        "will-change": [
          {
            "will-change": ["auto", "scroll", "contents", "transform", te, ee],
          },
        ],
        fill: [{ fill: ["none", ...y()] }],
        "stroke-w": [{ stroke: [pe, js, ya, Hm] }],
        stroke: [{ stroke: ["none", ...y()] }],
        "forced-color-adjust": [{ "forced-color-adjust": ["auto", "none"] }],
      },
      conflictingClassGroups: {
        overflow: ["overflow-x", "overflow-y"],
        overscroll: ["overscroll-x", "overscroll-y"],
        inset: [
          "inset-x",
          "inset-y",
          "inset-bs",
          "inset-be",
          "start",
          "end",
          "top",
          "right",
          "bottom",
          "left",
        ],
        "inset-x": ["right", "left"],
        "inset-y": ["top", "bottom"],
        flex: ["basis", "grow", "shrink"],
        gap: ["gap-x", "gap-y"],
        p: ["px", "py", "ps", "pe", "pbs", "pbe", "pt", "pr", "pb", "pl"],
        px: ["pr", "pl"],
        py: ["pt", "pb"],
        m: ["mx", "my", "ms", "me", "mbs", "mbe", "mt", "mr", "mb", "ml"],
        mx: ["mr", "ml"],
        my: ["mt", "mb"],
        size: ["w", "h"],
        "font-size": ["leading"],
        "fvn-normal": [
          "fvn-ordinal",
          "fvn-slashed-zero",
          "fvn-figure",
          "fvn-spacing",
          "fvn-fraction",
        ],
        "fvn-ordinal": ["fvn-normal"],
        "fvn-slashed-zero": ["fvn-normal"],
        "fvn-figure": ["fvn-normal"],
        "fvn-spacing": ["fvn-normal"],
        "fvn-fraction": ["fvn-normal"],
        "line-clamp": ["display", "overflow"],
        rounded: [
          "rounded-s",
          "rounded-e",
          "rounded-t",
          "rounded-r",
          "rounded-b",
          "rounded-l",
          "rounded-ss",
          "rounded-se",
          "rounded-ee",
          "rounded-es",
          "rounded-tl",
          "rounded-tr",
          "rounded-br",
          "rounded-bl",
        ],
        "rounded-s": ["rounded-ss", "rounded-es"],
        "rounded-e": ["rounded-se", "rounded-ee"],
        "rounded-t": ["rounded-tl", "rounded-tr"],
        "rounded-r": ["rounded-tr", "rounded-br"],
        "rounded-b": ["rounded-br", "rounded-bl"],
        "rounded-l": ["rounded-tl", "rounded-bl"],
        "border-spacing": ["border-spacing-x", "border-spacing-y"],
        "border-w": [
          "border-w-x",
          "border-w-y",
          "border-w-s",
          "border-w-e",
          "border-w-bs",
          "border-w-be",
          "border-w-t",
          "border-w-r",
          "border-w-b",
          "border-w-l",
        ],
        "border-w-x": ["border-w-r", "border-w-l"],
        "border-w-y": ["border-w-t", "border-w-b"],
        "border-color": [
          "border-color-x",
          "border-color-y",
          "border-color-s",
          "border-color-e",
          "border-color-bs",
          "border-color-be",
          "border-color-t",
          "border-color-r",
          "border-color-b",
          "border-color-l",
        ],
        "border-color-x": ["border-color-r", "border-color-l"],
        "border-color-y": ["border-color-t", "border-color-b"],
        translate: ["translate-x", "translate-y", "translate-none"],
        "translate-none": [
          "translate",
          "translate-x",
          "translate-y",
          "translate-z",
        ],
        "scroll-m": [
          "scroll-mx",
          "scroll-my",
          "scroll-ms",
          "scroll-me",
          "scroll-mbs",
          "scroll-mbe",
          "scroll-mt",
          "scroll-mr",
          "scroll-mb",
          "scroll-ml",
        ],
        "scroll-mx": ["scroll-mr", "scroll-ml"],
        "scroll-my": ["scroll-mt", "scroll-mb"],
        "scroll-p": [
          "scroll-px",
          "scroll-py",
          "scroll-ps",
          "scroll-pe",
          "scroll-pbs",
          "scroll-pbe",
          "scroll-pt",
          "scroll-pr",
          "scroll-pb",
          "scroll-pl",
        ],
        "scroll-px": ["scroll-pr", "scroll-pl"],
        "scroll-py": ["scroll-pt", "scroll-pb"],
        touch: ["touch-x", "touch-y", "touch-pz"],
        "touch-x": ["touch"],
        "touch-y": ["touch"],
        "touch-pz": ["touch"],
      },
      conflictingClassGroupModifiers: { "font-size": ["leading"] },
      orderSensitiveModifiers: [
        "*",
        "**",
        "after",
        "backdrop",
        "before",
        "details-content",
        "file",
        "first-letter",
        "first-line",
        "marker",
        "placeholder",
        "selection",
      ],
    };
  },
  lN = Dj(tN);
function $e(...a) {
  return lN(Px(a));
}
const aN = Z1,
  yp = j.forwardRef(({ className: a, ...i }, c) =>
    s.jsx(Gx, {
      ref: c,
      className: $e(
        "fixed top-0 z-[100] flex max-h-screen w-full flex-col-reverse p-4 sm:bottom-0 sm:right-0 sm:top-auto sm:flex-col md:max-w-[420px]",
        a,
      ),
      ...i,
    }),
  );
yp.displayName = Gx.displayName;
const nN = Uu(
    "group pointer-events-auto relative flex w-full items-center justify-between space-x-4 overflow-hidden rounded-md border p-6 pr-8 shadow-lg transition-all data-[swipe=cancel]:translate-x-0 data-[swipe=end]:translate-x-[var(--radix-toast-swipe-end-x)] data-[swipe=move]:translate-x-[var(--radix-toast-swipe-move-x)] data-[swipe=move]:transition-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[swipe=end]:animate-out data-[state=closed]:fade-out-80 data-[state=closed]:slide-out-to-right-full data-[state=open]:slide-in-from-top-full data-[state=open]:sm:slide-in-from-bottom-full",
    {
      variants: {
        variant: {
          default: "border bg-background text-foreground",
          destructive:
            "destructive group border-destructive bg-destructive text-destructive-foreground",
        },
      },
      defaultVariants: { variant: "default" },
    },
  ),
  jp = j.forwardRef(({ className: a, variant: i, ...c }, o) =>
    s.jsx(Yx, { ref: o, className: $e(nN({ variant: i }), a), ...c }),
  );
jp.displayName = Yx.displayName;
const sN = j.forwardRef(({ className: a, ...i }, c) =>
  s.jsx(Qx, {
    ref: c,
    className: $e(
      "inline-flex h-8 shrink-0 items-center justify-center rounded-md border bg-transparent px-3 text-sm font-medium ring-offset-background transition-colors hover:bg-secondary focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 group-[.destructive]:border-muted/40 group-[.destructive]:hover:border-destructive/30 group-[.destructive]:hover:bg-destructive group-[.destructive]:hover:text-destructive-foreground group-[.destructive]:focus:ring-destructive",
      a,
    ),
    ...i,
  }),
);
sN.displayName = Qx.displayName;
const Np = j.forwardRef(({ className: a, ...i }, c) =>
  s.jsx(Zx, {
    ref: c,
    className: $e(
      "absolute right-2 top-2 rounded-md p-1 text-foreground/50 opacity-0 transition-opacity hover:text-foreground focus:opacity-100 focus:outline-none focus:ring-2 group-hover:opacity-100 group-[.destructive]:text-red-300 group-[.destructive]:hover:text-red-50 group-[.destructive]:focus:ring-red-400 group-[.destructive]:focus:ring-offset-red-600",
      a,
    ),
    "toast-close": "",
    ...i,
    children: s.jsx(Or, { className: "h-4 w-4" }),
  }),
);
Np.displayName = Zx.displayName;
const wp = j.forwardRef(({ className: a, ...i }, c) =>
  s.jsx(Vx, { ref: c, className: $e("text-sm font-semibold", a), ...i }),
);
wp.displayName = Vx.displayName;
const Sp = j.forwardRef(({ className: a, ...i }, c) =>
  s.jsx(Xx, { ref: c, className: $e("text-sm opacity-90", a), ...i }),
);
Sp.displayName = Xx.displayName;
function iN() {
  const { toasts: a } = Iy();
  return s.jsxs(aN, {
    children: [
      a.map(function ({ id: i, title: c, description: o, action: d, ...f }) {
        return s.jsxs(
          jp,
          {
            ...f,
            children: [
              s.jsxs("div", {
                className: "grid gap-1",
                children: [
                  c && s.jsx(wp, { children: c }),
                  o && s.jsx(Sp, { children: o }),
                ],
              }),
              d,
              s.jsx(Np, {}),
            ],
          },
          i,
        );
      }),
      s.jsx(yp, {}),
    ],
  });
}
const rN = ["top", "right", "bottom", "left"],
  Il = Math.min,
  wt = Math.max,
  dr = Math.round,
  tr = Math.floor,
  Wt = (a) => ({ x: a, y: a }),
  cN = { left: "right", right: "left", bottom: "top", top: "bottom" };
function gu(a, i, c) {
  return wt(a, Il(i, c));
}
function vl(a, i) {
  return typeof a == "function" ? a(i) : a;
}
function yl(a) {
  return a.split("-")[0];
}
function yn(a) {
  return a.split("-")[1];
}
function Xu(a) {
  return a === "x" ? "y" : "x";
}
function Qu(a) {
  return a === "y" ? "height" : "width";
}
function Ft(a) {
  const i = a[0];
  return i === "t" || i === "b" ? "y" : "x";
}
function Zu(a) {
  return Xu(Ft(a));
}
function oN(a, i, c) {
  c === void 0 && (c = !1);
  const o = yn(a),
    d = Zu(a),
    f = Qu(d);
  let x =
    d === "x"
      ? o === (c ? "end" : "start")
        ? "right"
        : "left"
      : o === "start"
        ? "bottom"
        : "top";
  return (i.reference[f] > i.floating[f] && (x = fr(x)), [x, fr(x)]);
}
function uN(a) {
  const i = fr(a);
  return [vu(a), i, vu(i)];
}
function vu(a) {
  return a.includes("start")
    ? a.replace("start", "end")
    : a.replace("end", "start");
}
const Bm = ["left", "right"],
  Gm = ["right", "left"],
  dN = ["top", "bottom"],
  fN = ["bottom", "top"];
function hN(a, i, c) {
  switch (a) {
    case "top":
    case "bottom":
      return c ? (i ? Gm : Bm) : i ? Bm : Gm;
    case "left":
    case "right":
      return i ? dN : fN;
    default:
      return [];
  }
}
function mN(a, i, c, o) {
  const d = yn(a);
  let f = hN(yl(a), c === "start", o);
  return (
    d && ((f = f.map((x) => x + "-" + d)), i && (f = f.concat(f.map(vu)))),
    f
  );
}
function fr(a) {
  const i = yl(a);
  return cN[i] + a.slice(i.length);
}
function xN(a) {
  return { top: 0, right: 0, bottom: 0, left: 0, ...a };
}
function Ep(a) {
  return typeof a != "number"
    ? xN(a)
    : { top: a, right: a, bottom: a, left: a };
}
function hr(a) {
  const { x: i, y: c, width: o, height: d } = a;
  return {
    width: o,
    height: d,
    top: c,
    left: i,
    right: i + o,
    bottom: c + d,
    x: i,
    y: c,
  };
}
function Ym(a, i, c) {
  let { reference: o, floating: d } = a;
  const f = Ft(i),
    x = Zu(i),
    b = Qu(x),
    p = yl(i),
    h = f === "y",
    v = o.x + o.width / 2 - d.width / 2,
    w = o.y + o.height / 2 - d.height / 2,
    E = o[b] / 2 - d[b] / 2;
  let R;
  switch (p) {
    case "top":
      R = { x: v, y: o.y - d.height };
      break;
    case "bottom":
      R = { x: v, y: o.y + o.height };
      break;
    case "right":
      R = { x: o.x + o.width, y: w };
      break;
    case "left":
      R = { x: o.x - d.width, y: w };
      break;
    default:
      R = { x: o.x, y: o.y };
  }
  switch (yn(i)) {
    case "start":
      R[x] -= E * (c && h ? -1 : 1);
      break;
    case "end":
      R[x] += E * (c && h ? -1 : 1);
      break;
  }
  return R;
}
async function pN(a, i) {
  var c;
  i === void 0 && (i = {});
  const { x: o, y: d, platform: f, rects: x, elements: b, strategy: p } = a,
    {
      boundary: h = "clippingAncestors",
      rootBoundary: v = "viewport",
      elementContext: w = "floating",
      altBoundary: E = !1,
      padding: R = 0,
    } = vl(i, a),
    k = Ep(R),
    _ = b[E ? (w === "floating" ? "reference" : "floating") : w],
    B = hr(
      await f.getClippingRect({
        element:
          (c = await (f.isElement == null ? void 0 : f.isElement(_))) == null ||
          c
            ? _
            : _.contextElement ||
              (await (f.getDocumentElement == null
                ? void 0
                : f.getDocumentElement(b.floating))),
        boundary: h,
        rootBoundary: v,
        strategy: p,
      }),
    ),
    V =
      w === "floating"
        ? { x: o, y: d, width: x.floating.width, height: x.floating.height }
        : x.reference,
    Y = await (f.getOffsetParent == null
      ? void 0
      : f.getOffsetParent(b.floating)),
    Z = (await (f.isElement == null ? void 0 : f.isElement(Y)))
      ? (await (f.getScale == null ? void 0 : f.getScale(Y))) || { x: 1, y: 1 }
      : { x: 1, y: 1 },
    X = hr(
      f.convertOffsetParentRelativeRectToViewportRelativeRect
        ? await f.convertOffsetParentRelativeRectToViewportRelativeRect({
            elements: b,
            rect: V,
            offsetParent: Y,
            strategy: p,
          })
        : V,
    );
  return {
    top: (B.top - X.top + k.top) / Z.y,
    bottom: (X.bottom - B.bottom + k.bottom) / Z.y,
    left: (B.left - X.left + k.left) / Z.x,
    right: (X.right - B.right + k.right) / Z.x,
  };
}
const bN = 50,
  gN = async (a, i, c) => {
    const {
        placement: o = "bottom",
        strategy: d = "absolute",
        middleware: f = [],
        platform: x,
      } = c,
      b = x.detectOverflow ? x : { ...x, detectOverflow: pN },
      p = await (x.isRTL == null ? void 0 : x.isRTL(i));
    let h = await x.getElementRects({ reference: a, floating: i, strategy: d }),
      { x: v, y: w } = Ym(h, o, p),
      E = o,
      R = 0;
    const k = {};
    for (let A = 0; A < f.length; A++) {
      const _ = f[A];
      if (!_) continue;
      const { name: B, fn: V } = _,
        {
          x: Y,
          y: Z,
          data: X,
          reset: $,
        } = await V({
          x: v,
          y: w,
          initialPlacement: o,
          placement: E,
          strategy: d,
          middlewareData: k,
          rects: h,
          platform: b,
          elements: { reference: a, floating: i },
        });
      ((v = Y ?? v),
        (w = Z ?? w),
        (k[B] = { ...k[B], ...X }),
        $ &&
          R < bN &&
          (R++,
          typeof $ == "object" &&
            ($.placement && (E = $.placement),
            $.rects &&
              (h =
                $.rects === !0
                  ? await x.getElementRects({
                      reference: a,
                      floating: i,
                      strategy: d,
                    })
                  : $.rects),
            ({ x: v, y: w } = Ym(h, E, p))),
          (A = -1)));
    }
    return { x: v, y: w, placement: E, strategy: d, middlewareData: k };
  },
  vN = (a) => ({
    name: "arrow",
    options: a,
    async fn(i) {
      const {
          x: c,
          y: o,
          placement: d,
          rects: f,
          platform: x,
          elements: b,
          middlewareData: p,
        } = i,
        { element: h, padding: v = 0 } = vl(a, i) || {};
      if (h == null) return {};
      const w = Ep(v),
        E = { x: c, y: o },
        R = Zu(d),
        k = Qu(R),
        A = await x.getDimensions(h),
        _ = R === "y",
        B = _ ? "top" : "left",
        V = _ ? "bottom" : "right",
        Y = _ ? "clientHeight" : "clientWidth",
        Z = f.reference[k] + f.reference[R] - E[R] - f.floating[k],
        X = E[R] - f.reference[R],
        $ = await (x.getOffsetParent == null ? void 0 : x.getOffsetParent(h));
      let F = $ ? $[Y] : 0;
      (!F || !(await (x.isElement == null ? void 0 : x.isElement($)))) &&
        (F = b.floating[Y] || f.floating[k]);
      const K = Z / 2 - X / 2,
        ue = F / 2 - A[k] / 2 - 1,
        ge = Il(w[B], ue),
        je = Il(w[V], ue),
        he = ge,
        we = F - A[k] - je,
        W = F / 2 - A[k] / 2 + K,
        fe = gu(he, W, we),
        O =
          !p.arrow &&
          yn(d) != null &&
          W !== fe &&
          f.reference[k] / 2 - (W < he ? ge : je) - A[k] / 2 < 0,
        G = O ? (W < he ? W - he : W - we) : 0;
      return {
        [R]: E[R] + G,
        data: {
          [R]: fe,
          centerOffset: W - fe - G,
          ...(O && { alignmentOffset: G }),
        },
        reset: O,
      };
    },
  }),
  yN = function (a) {
    return (
      a === void 0 && (a = {}),
      {
        name: "flip",
        options: a,
        async fn(i) {
          var c, o;
          const {
              placement: d,
              middlewareData: f,
              rects: x,
              initialPlacement: b,
              platform: p,
              elements: h,
            } = i,
            {
              mainAxis: v = !0,
              crossAxis: w = !0,
              fallbackPlacements: E,
              fallbackStrategy: R = "bestFit",
              fallbackAxisSideDirection: k = "none",
              flipAlignment: A = !0,
              ..._
            } = vl(a, i);
          if ((c = f.arrow) != null && c.alignmentOffset) return {};
          const B = yl(d),
            V = Ft(b),
            Y = yl(b) === b,
            Z = await (p.isRTL == null ? void 0 : p.isRTL(h.floating)),
            X = E || (Y || !A ? [fr(b)] : uN(b)),
            $ = k !== "none";
          !E && $ && X.push(...mN(b, A, k, Z));
          const F = [b, ...X],
            K = await p.detectOverflow(i, _),
            ue = [];
          let ge = ((o = f.flip) == null ? void 0 : o.overflows) || [];
          if ((v && ue.push(K[B]), w)) {
            const W = oN(d, x, Z);
            ue.push(K[W[0]], K[W[1]]);
          }
          if (
            ((ge = [...ge, { placement: d, overflows: ue }]),
            !ue.every((W) => W <= 0))
          ) {
            var je, he;
            const W = (((je = f.flip) == null ? void 0 : je.index) || 0) + 1,
              fe = F[W];
            if (
              fe &&
              (!(w === "alignment" ? V !== Ft(fe) : !1) ||
                ge.every((Q) =>
                  Ft(Q.placement) === V ? Q.overflows[0] > 0 : !0,
                ))
            )
              return {
                data: { index: W, overflows: ge },
                reset: { placement: fe },
              };
            let O =
              (he = ge
                .filter((G) => G.overflows[0] <= 0)
                .sort((G, Q) => G.overflows[1] - Q.overflows[1])[0]) == null
                ? void 0
                : he.placement;
            if (!O)
              switch (R) {
                case "bestFit": {
                  var we;
                  const G =
                    (we = ge
                      .filter((Q) => {
                        if ($) {
                          const se = Ft(Q.placement);
                          return se === V || se === "y";
                        }
                        return !0;
                      })
                      .map((Q) => [
                        Q.placement,
                        Q.overflows
                          .filter((se) => se > 0)
                          .reduce((se, y) => se + y, 0),
                      ])
                      .sort((Q, se) => Q[1] - se[1])[0]) == null
                      ? void 0
                      : we[0];
                  G && (O = G);
                  break;
                }
                case "initialPlacement":
                  O = b;
                  break;
              }
            if (d !== O) return { reset: { placement: O } };
          }
          return {};
        },
      }
    );
  };
function Vm(a, i) {
  return {
    top: a.top - i.height,
    right: a.right - i.width,
    bottom: a.bottom - i.height,
    left: a.left - i.width,
  };
}
function Xm(a) {
  return rN.some((i) => a[i] >= 0);
}
const jN = function (a) {
    return (
      a === void 0 && (a = {}),
      {
        name: "hide",
        options: a,
        async fn(i) {
          const { rects: c, platform: o } = i,
            { strategy: d = "referenceHidden", ...f } = vl(a, i);
          switch (d) {
            case "referenceHidden": {
              const x = await o.detectOverflow(i, {
                  ...f,
                  elementContext: "reference",
                }),
                b = Vm(x, c.reference);
              return {
                data: { referenceHiddenOffsets: b, referenceHidden: Xm(b) },
              };
            }
            case "escaped": {
              const x = await o.detectOverflow(i, { ...f, altBoundary: !0 }),
                b = Vm(x, c.floating);
              return { data: { escapedOffsets: b, escaped: Xm(b) } };
            }
            default:
              return {};
          }
        },
      }
    );
  },
  Tp = new Set(["left", "top"]);
async function NN(a, i) {
  const { placement: c, platform: o, elements: d } = a,
    f = await (o.isRTL == null ? void 0 : o.isRTL(d.floating)),
    x = yl(c),
    b = yn(c),
    p = Ft(c) === "y",
    h = Tp.has(x) ? -1 : 1,
    v = f && p ? -1 : 1,
    w = vl(i, a);
  let {
    mainAxis: E,
    crossAxis: R,
    alignmentAxis: k,
  } = typeof w == "number"
    ? { mainAxis: w, crossAxis: 0, alignmentAxis: null }
    : {
        mainAxis: w.mainAxis || 0,
        crossAxis: w.crossAxis || 0,
        alignmentAxis: w.alignmentAxis,
      };
  return (
    b && typeof k == "number" && (R = b === "end" ? k * -1 : k),
    p ? { x: R * v, y: E * h } : { x: E * h, y: R * v }
  );
}
const wN = function (a) {
    return (
      a === void 0 && (a = 0),
      {
        name: "offset",
        options: a,
        async fn(i) {
          var c, o;
          const { x: d, y: f, placement: x, middlewareData: b } = i,
            p = await NN(i, a);
          return x === ((c = b.offset) == null ? void 0 : c.placement) &&
            (o = b.arrow) != null &&
            o.alignmentOffset
            ? {}
            : { x: d + p.x, y: f + p.y, data: { ...p, placement: x } };
        },
      }
    );
  },
  SN = function (a) {
    return (
      a === void 0 && (a = {}),
      {
        name: "shift",
        options: a,
        async fn(i) {
          const { x: c, y: o, placement: d, platform: f } = i,
            {
              mainAxis: x = !0,
              crossAxis: b = !1,
              limiter: p = {
                fn: (B) => {
                  let { x: V, y: Y } = B;
                  return { x: V, y: Y };
                },
              },
              ...h
            } = vl(a, i),
            v = { x: c, y: o },
            w = await f.detectOverflow(i, h),
            E = Ft(yl(d)),
            R = Xu(E);
          let k = v[R],
            A = v[E];
          if (x) {
            const B = R === "y" ? "top" : "left",
              V = R === "y" ? "bottom" : "right",
              Y = k + w[B],
              Z = k - w[V];
            k = gu(Y, k, Z);
          }
          if (b) {
            const B = E === "y" ? "top" : "left",
              V = E === "y" ? "bottom" : "right",
              Y = A + w[B],
              Z = A - w[V];
            A = gu(Y, A, Z);
          }
          const _ = p.fn({ ...i, [R]: k, [E]: A });
          return {
            ..._,
            data: { x: _.x - c, y: _.y - o, enabled: { [R]: x, [E]: b } },
          };
        },
      }
    );
  },
  EN = function (a) {
    return (
      a === void 0 && (a = {}),
      {
        options: a,
        fn(i) {
          const { x: c, y: o, placement: d, rects: f, middlewareData: x } = i,
            { offset: b = 0, mainAxis: p = !0, crossAxis: h = !0 } = vl(a, i),
            v = { x: c, y: o },
            w = Ft(d),
            E = Xu(w);
          let R = v[E],
            k = v[w];
          const A = vl(b, i),
            _ =
              typeof A == "number"
                ? { mainAxis: A, crossAxis: 0 }
                : { mainAxis: 0, crossAxis: 0, ...A };
          if (p) {
            const Y = E === "y" ? "height" : "width",
              Z = f.reference[E] - f.floating[Y] + _.mainAxis,
              X = f.reference[E] + f.reference[Y] - _.mainAxis;
            R < Z ? (R = Z) : R > X && (R = X);
          }
          if (h) {
            var B, V;
            const Y = E === "y" ? "width" : "height",
              Z = Tp.has(yl(d)),
              X =
                f.reference[w] -
                f.floating[Y] +
                ((Z && ((B = x.offset) == null ? void 0 : B[w])) || 0) +
                (Z ? 0 : _.crossAxis),
              $ =
                f.reference[w] +
                f.reference[Y] +
                (Z ? 0 : ((V = x.offset) == null ? void 0 : V[w]) || 0) -
                (Z ? _.crossAxis : 0);
            k < X ? (k = X) : k > $ && (k = $);
          }
          return { [E]: R, [w]: k };
        },
      }
    );
  },
  TN = function (a) {
    return (
      a === void 0 && (a = {}),
      {
        name: "size",
        options: a,
        async fn(i) {
          var c, o;
          const { placement: d, rects: f, platform: x, elements: b } = i,
            { apply: p = () => {}, ...h } = vl(a, i),
            v = await x.detectOverflow(i, h),
            w = yl(d),
            E = yn(d),
            R = Ft(d) === "y",
            { width: k, height: A } = f.floating;
          let _, B;
          w === "top" || w === "bottom"
            ? ((_ = w),
              (B =
                E ===
                ((await (x.isRTL == null ? void 0 : x.isRTL(b.floating)))
                  ? "start"
                  : "end")
                  ? "left"
                  : "right"))
            : ((B = w), (_ = E === "end" ? "top" : "bottom"));
          const V = A - v.top - v.bottom,
            Y = k - v.left - v.right,
            Z = Il(A - v[_], V),
            X = Il(k - v[B], Y),
            $ = !i.middlewareData.shift;
          let F = Z,
            K = X;
          if (
            ((c = i.middlewareData.shift) != null && c.enabled.x && (K = Y),
            (o = i.middlewareData.shift) != null && o.enabled.y && (F = V),
            $ && !E)
          ) {
            const ge = wt(v.left, 0),
              je = wt(v.right, 0),
              he = wt(v.top, 0),
              we = wt(v.bottom, 0);
            R
              ? (K =
                  k -
                  2 * (ge !== 0 || je !== 0 ? ge + je : wt(v.left, v.right)))
              : (F =
                  A -
                  2 * (he !== 0 || we !== 0 ? he + we : wt(v.top, v.bottom)));
          }
          await p({ ...i, availableWidth: K, availableHeight: F });
          const ue = await x.getDimensions(b.floating);
          return k !== ue.width || A !== ue.height
            ? { reset: { rects: !0 } }
            : {};
        },
      }
    );
  };
function Rr() {
  return typeof window < "u";
}
function jn(a) {
  return Ap(a) ? (a.nodeName || "").toLowerCase() : "#document";
}
function St(a) {
  var i;
  return (
    (a == null || (i = a.ownerDocument) == null ? void 0 : i.defaultView) ||
    window
  );
}
function It(a) {
  var i;
  return (i = (Ap(a) ? a.ownerDocument : a.document) || window.document) == null
    ? void 0
    : i.documentElement;
}
function Ap(a) {
  return Rr() ? a instanceof Node || a instanceof St(a).Node : !1;
}
function Yt(a) {
  return Rr() ? a instanceof Element || a instanceof St(a).Element : !1;
}
function jl(a) {
  return Rr() ? a instanceof HTMLElement || a instanceof St(a).HTMLElement : !1;
}
function Qm(a) {
  return !Rr() || typeof ShadowRoot > "u"
    ? !1
    : a instanceof ShadowRoot || a instanceof St(a).ShadowRoot;
}
function _s(a) {
  const { overflow: i, overflowX: c, overflowY: o, display: d } = Vt(a);
  return (
    /auto|scroll|overlay|hidden|clip/.test(i + o + c) &&
    d !== "inline" &&
    d !== "contents"
  );
}
function AN(a) {
  return /^(table|td|th)$/.test(jn(a));
}
function Mr(a) {
  try {
    if (a.matches(":popover-open")) return !0;
  } catch {}
  try {
    return a.matches(":modal");
  } catch {
    return !1;
  }
}
const CN = /transform|translate|scale|rotate|perspective|filter/,
  ON = /paint|layout|strict|content/,
  ja = (a) => !!a && a !== "none";
let su;
function Ku(a) {
  const i = Yt(a) ? Vt(a) : a;
  return (
    ja(i.transform) ||
    ja(i.translate) ||
    ja(i.scale) ||
    ja(i.rotate) ||
    ja(i.perspective) ||
    (!Pu() && (ja(i.backdropFilter) || ja(i.filter))) ||
    CN.test(i.willChange || "") ||
    ON.test(i.contain || "")
  );
}
function RN(a) {
  let i = ea(a);
  for (; jl(i) && !bn(i); ) {
    if (Ku(i)) return i;
    if (Mr(i)) return null;
    i = ea(i);
  }
  return null;
}
function Pu() {
  return (
    su == null &&
      (su =
        typeof CSS < "u" &&
        CSS.supports &&
        CSS.supports("-webkit-backdrop-filter", "none")),
    su
  );
}
function bn(a) {
  return /^(html|body|#document)$/.test(jn(a));
}
function Vt(a) {
  return St(a).getComputedStyle(a);
}
function _r(a) {
  return Yt(a)
    ? { scrollLeft: a.scrollLeft, scrollTop: a.scrollTop }
    : { scrollLeft: a.scrollX, scrollTop: a.scrollY };
}
function ea(a) {
  if (jn(a) === "html") return a;
  const i = a.assignedSlot || a.parentNode || (Qm(a) && a.host) || It(a);
  return Qm(i) ? i.host : i;
}
function Cp(a) {
  const i = ea(a);
  return bn(i)
    ? a.ownerDocument
      ? a.ownerDocument.body
      : a.body
    : jl(i) && _s(i)
      ? i
      : Cp(i);
}
function Os(a, i, c) {
  var o;
  (i === void 0 && (i = []), c === void 0 && (c = !0));
  const d = Cp(a),
    f = d === ((o = a.ownerDocument) == null ? void 0 : o.body),
    x = St(d);
  if (f) {
    const b = yu(x);
    return i.concat(
      x,
      x.visualViewport || [],
      _s(d) ? d : [],
      b && c ? Os(b) : [],
    );
  } else return i.concat(d, Os(d, [], c));
}
function yu(a) {
  return a.parent && Object.getPrototypeOf(a.parent) ? a.frameElement : null;
}
function Op(a) {
  const i = Vt(a);
  let c = parseFloat(i.width) || 0,
    o = parseFloat(i.height) || 0;
  const d = jl(a),
    f = d ? a.offsetWidth : c,
    x = d ? a.offsetHeight : o,
    b = dr(c) !== f || dr(o) !== x;
  return (b && ((c = f), (o = x)), { width: c, height: o, $: b });
}
function $u(a) {
  return Yt(a) ? a : a.contextElement;
}
function mn(a) {
  const i = $u(a);
  if (!jl(i)) return Wt(1);
  const c = i.getBoundingClientRect(),
    { width: o, height: d, $: f } = Op(i);
  let x = (f ? dr(c.width) : c.width) / o,
    b = (f ? dr(c.height) : c.height) / d;
  return (
    (!x || !Number.isFinite(x)) && (x = 1),
    (!b || !Number.isFinite(b)) && (b = 1),
    { x, y: b }
  );
}
const MN = Wt(0);
function Rp(a) {
  const i = St(a);
  return !Pu() || !i.visualViewport
    ? MN
    : { x: i.visualViewport.offsetLeft, y: i.visualViewport.offsetTop };
}
function _N(a, i, c) {
  return (i === void 0 && (i = !1), !c || (i && c !== St(a)) ? !1 : i);
}
function Sa(a, i, c, o) {
  (i === void 0 && (i = !1), c === void 0 && (c = !1));
  const d = a.getBoundingClientRect(),
    f = $u(a);
  let x = Wt(1);
  i && (o ? Yt(o) && (x = mn(o)) : (x = mn(a)));
  const b = _N(f, c, o) ? Rp(f) : Wt(0);
  let p = (d.left + b.x) / x.x,
    h = (d.top + b.y) / x.y,
    v = d.width / x.x,
    w = d.height / x.y;
  if (f) {
    const E = St(f),
      R = o && Yt(o) ? St(o) : o;
    let k = E,
      A = yu(k);
    for (; A && o && R !== k; ) {
      const _ = mn(A),
        B = A.getBoundingClientRect(),
        V = Vt(A),
        Y = B.left + (A.clientLeft + parseFloat(V.paddingLeft)) * _.x,
        Z = B.top + (A.clientTop + parseFloat(V.paddingTop)) * _.y;
      ((p *= _.x),
        (h *= _.y),
        (v *= _.x),
        (w *= _.y),
        (p += Y),
        (h += Z),
        (k = St(A)),
        (A = yu(k)));
    }
  }
  return hr({ width: v, height: w, x: p, y: h });
}
function kr(a, i) {
  const c = _r(a).scrollLeft;
  return i ? i.left + c : Sa(It(a)).left + c;
}
function Mp(a, i) {
  const c = a.getBoundingClientRect(),
    o = c.left + i.scrollLeft - kr(a, c),
    d = c.top + i.scrollTop;
  return { x: o, y: d };
}
function kN(a) {
  let { elements: i, rect: c, offsetParent: o, strategy: d } = a;
  const f = d === "fixed",
    x = It(o),
    b = i ? Mr(i.floating) : !1;
  if (o === x || (b && f)) return c;
  let p = { scrollLeft: 0, scrollTop: 0 },
    h = Wt(1);
  const v = Wt(0),
    w = jl(o);
  if ((w || (!w && !f)) && ((jn(o) !== "body" || _s(x)) && (p = _r(o)), w)) {
    const R = Sa(o);
    ((h = mn(o)), (v.x = R.x + o.clientLeft), (v.y = R.y + o.clientTop));
  }
  const E = x && !w && !f ? Mp(x, p) : Wt(0);
  return {
    width: c.width * h.x,
    height: c.height * h.y,
    x: c.x * h.x - p.scrollLeft * h.x + v.x + E.x,
    y: c.y * h.y - p.scrollTop * h.y + v.y + E.y,
  };
}
function DN(a) {
  return Array.from(a.getClientRects());
}
function zN(a) {
  const i = It(a),
    c = _r(a),
    o = a.ownerDocument.body,
    d = wt(i.scrollWidth, i.clientWidth, o.scrollWidth, o.clientWidth),
    f = wt(i.scrollHeight, i.clientHeight, o.scrollHeight, o.clientHeight);
  let x = -c.scrollLeft + kr(a);
  const b = -c.scrollTop;
  return (
    Vt(o).direction === "rtl" && (x += wt(i.clientWidth, o.clientWidth) - d),
    { width: d, height: f, x, y: b }
  );
}
const Zm = 25;
function UN(a, i) {
  const c = St(a),
    o = It(a),
    d = c.visualViewport;
  let f = o.clientWidth,
    x = o.clientHeight,
    b = 0,
    p = 0;
  if (d) {
    ((f = d.width), (x = d.height));
    const v = Pu();
    (!v || (v && i === "fixed")) && ((b = d.offsetLeft), (p = d.offsetTop));
  }
  const h = kr(o);
  if (h <= 0) {
    const v = o.ownerDocument,
      w = v.body,
      E = getComputedStyle(w),
      R =
        (v.compatMode === "CSS1Compat" &&
          parseFloat(E.marginLeft) + parseFloat(E.marginRight)) ||
        0,
      k = Math.abs(o.clientWidth - w.clientWidth - R);
    k <= Zm && (f -= k);
  } else h <= Zm && (f += h);
  return { width: f, height: x, x: b, y: p };
}
function HN(a, i) {
  const c = Sa(a, !0, i === "fixed"),
    o = c.top + a.clientTop,
    d = c.left + a.clientLeft,
    f = jl(a) ? mn(a) : Wt(1),
    x = a.clientWidth * f.x,
    b = a.clientHeight * f.y,
    p = d * f.x,
    h = o * f.y;
  return { width: x, height: b, x: p, y: h };
}
function Km(a, i, c) {
  let o;
  if (i === "viewport") o = UN(a, c);
  else if (i === "document") o = zN(It(a));
  else if (Yt(i)) o = HN(i, c);
  else {
    const d = Rp(a);
    o = { x: i.x - d.x, y: i.y - d.y, width: i.width, height: i.height };
  }
  return hr(o);
}
function _p(a, i) {
  const c = ea(a);
  return c === i || !Yt(c) || bn(c)
    ? !1
    : Vt(c).position === "fixed" || _p(c, i);
}
function LN(a, i) {
  const c = i.get(a);
  if (c) return c;
  let o = Os(a, [], !1).filter((b) => Yt(b) && jn(b) !== "body"),
    d = null;
  const f = Vt(a).position === "fixed";
  let x = f ? ea(a) : a;
  for (; Yt(x) && !bn(x); ) {
    const b = Vt(x),
      p = Ku(x);
    (!p && b.position === "fixed" && (d = null),
      (
        f
          ? !p && !d
          : (!p &&
              b.position === "static" &&
              !!d &&
              (d.position === "absolute" || d.position === "fixed")) ||
            (_s(x) && !p && _p(a, x))
      )
        ? (o = o.filter((v) => v !== x))
        : (d = b),
      (x = ea(x)));
  }
  return (i.set(a, o), o);
}
function qN(a) {
  let { element: i, boundary: c, rootBoundary: o, strategy: d } = a;
  const x = [
      ...(c === "clippingAncestors"
        ? Mr(i)
          ? []
          : LN(i, this._c)
        : [].concat(c)),
      o,
    ],
    b = Km(i, x[0], d);
  let p = b.top,
    h = b.right,
    v = b.bottom,
    w = b.left;
  for (let E = 1; E < x.length; E++) {
    const R = Km(i, x[E], d);
    ((p = wt(R.top, p)),
      (h = Il(R.right, h)),
      (v = Il(R.bottom, v)),
      (w = wt(R.left, w)));
  }
  return { width: h - w, height: v - p, x: w, y: p };
}
function BN(a) {
  const { width: i, height: c } = Op(a);
  return { width: i, height: c };
}
function GN(a, i, c) {
  const o = jl(i),
    d = It(i),
    f = c === "fixed",
    x = Sa(a, !0, f, i);
  let b = { scrollLeft: 0, scrollTop: 0 };
  const p = Wt(0);
  function h() {
    p.x = kr(d);
  }
  if (o || (!o && !f))
    if (((jn(i) !== "body" || _s(d)) && (b = _r(i)), o)) {
      const R = Sa(i, !0, f, i);
      ((p.x = R.x + i.clientLeft), (p.y = R.y + i.clientTop));
    } else d && h();
  f && !o && d && h();
  const v = d && !o && !f ? Mp(d, b) : Wt(0),
    w = x.left + b.scrollLeft - p.x - v.x,
    E = x.top + b.scrollTop - p.y - v.y;
  return { x: w, y: E, width: x.width, height: x.height };
}
function iu(a) {
  return Vt(a).position === "static";
}
function Pm(a, i) {
  if (!jl(a) || Vt(a).position === "fixed") return null;
  if (i) return i(a);
  let c = a.offsetParent;
  return (It(a) === c && (c = c.ownerDocument.body), c);
}
function kp(a, i) {
  const c = St(a);
  if (Mr(a)) return c;
  if (!jl(a)) {
    let d = ea(a);
    for (; d && !bn(d); ) {
      if (Yt(d) && !iu(d)) return d;
      d = ea(d);
    }
    return c;
  }
  let o = Pm(a, i);
  for (; o && AN(o) && iu(o); ) o = Pm(o, i);
  return o && bn(o) && iu(o) && !Ku(o) ? c : o || RN(a) || c;
}
const YN = async function (a) {
  const i = this.getOffsetParent || kp,
    c = this.getDimensions,
    o = await c(a.floating);
  return {
    reference: GN(a.reference, await i(a.floating), a.strategy),
    floating: { x: 0, y: 0, width: o.width, height: o.height },
  };
};
function VN(a) {
  return Vt(a).direction === "rtl";
}
const XN = {
  convertOffsetParentRelativeRectToViewportRelativeRect: kN,
  getDocumentElement: It,
  getClippingRect: qN,
  getOffsetParent: kp,
  getElementRects: YN,
  getClientRects: DN,
  getDimensions: BN,
  getScale: mn,
  isElement: Yt,
  isRTL: VN,
};
function Dp(a, i) {
  return (
    a.x === i.x && a.y === i.y && a.width === i.width && a.height === i.height
  );
}
function QN(a, i) {
  let c = null,
    o;
  const d = It(a);
  function f() {
    var b;
    (clearTimeout(o), (b = c) == null || b.disconnect(), (c = null));
  }
  function x(b, p) {
    (b === void 0 && (b = !1), p === void 0 && (p = 1), f());
    const h = a.getBoundingClientRect(),
      { left: v, top: w, width: E, height: R } = h;
    if ((b || i(), !E || !R)) return;
    const k = tr(w),
      A = tr(d.clientWidth - (v + E)),
      _ = tr(d.clientHeight - (w + R)),
      B = tr(v),
      Y = {
        rootMargin: -k + "px " + -A + "px " + -_ + "px " + -B + "px",
        threshold: wt(0, Il(1, p)) || 1,
      };
    let Z = !0;
    function X($) {
      const F = $[0].intersectionRatio;
      if (F !== p) {
        if (!Z) return x();
        F
          ? x(!1, F)
          : (o = setTimeout(() => {
              x(!1, 1e-7);
            }, 1e3));
      }
      (F === 1 && !Dp(h, a.getBoundingClientRect()) && x(), (Z = !1));
    }
    try {
      c = new IntersectionObserver(X, { ...Y, root: d.ownerDocument });
    } catch {
      c = new IntersectionObserver(X, Y);
    }
    c.observe(a);
  }
  return (x(!0), f);
}
function ZN(a, i, c, o) {
  o === void 0 && (o = {});
  const {
      ancestorScroll: d = !0,
      ancestorResize: f = !0,
      elementResize: x = typeof ResizeObserver == "function",
      layoutShift: b = typeof IntersectionObserver == "function",
      animationFrame: p = !1,
    } = o,
    h = $u(a),
    v = d || f ? [...(h ? Os(h) : []), ...(i ? Os(i) : [])] : [];
  v.forEach((B) => {
    (d && B.addEventListener("scroll", c, { passive: !0 }),
      f && B.addEventListener("resize", c));
  });
  const w = h && b ? QN(h, c) : null;
  let E = -1,
    R = null;
  x &&
    ((R = new ResizeObserver((B) => {
      let [V] = B;
      (V &&
        V.target === h &&
        R &&
        i &&
        (R.unobserve(i),
        cancelAnimationFrame(E),
        (E = requestAnimationFrame(() => {
          var Y;
          (Y = R) == null || Y.observe(i);
        }))),
        c());
    })),
    h && !p && R.observe(h),
    i && R.observe(i));
  let k,
    A = p ? Sa(a) : null;
  p && _();
  function _() {
    const B = Sa(a);
    (A && !Dp(A, B) && c(), (A = B), (k = requestAnimationFrame(_)));
  }
  return (
    c(),
    () => {
      var B;
      (v.forEach((V) => {
        (d && V.removeEventListener("scroll", c),
          f && V.removeEventListener("resize", c));
      }),
        w?.(),
        (B = R) == null || B.disconnect(),
        (R = null),
        p && cancelAnimationFrame(k));
    }
  );
}
const KN = wN,
  PN = SN,
  $N = yN,
  JN = TN,
  FN = jN,
  $m = vN,
  WN = EN,
  IN = (a, i, c) => {
    const o = new Map(),
      d = { platform: XN, ...c },
      f = { ...d.platform, _c: o };
    return gN(a, i, { ...d, platform: f });
  };
var ew = typeof document < "u",
  tw = function () {},
  sr = ew ? j.useLayoutEffect : tw;
function mr(a, i) {
  if (a === i) return !0;
  if (typeof a != typeof i) return !1;
  if (typeof a == "function" && a.toString() === i.toString()) return !0;
  let c, o, d;
  if (a && i && typeof a == "object") {
    if (Array.isArray(a)) {
      if (((c = a.length), c !== i.length)) return !1;
      for (o = c; o-- !== 0; ) if (!mr(a[o], i[o])) return !1;
      return !0;
    }
    if (((d = Object.keys(a)), (c = d.length), c !== Object.keys(i).length))
      return !1;
    for (o = c; o-- !== 0; ) if (!{}.hasOwnProperty.call(i, d[o])) return !1;
    for (o = c; o-- !== 0; ) {
      const f = d[o];
      if (!(f === "_owner" && a.$$typeof) && !mr(a[f], i[f])) return !1;
    }
    return !0;
  }
  return a !== a && i !== i;
}
function zp(a) {
  return typeof window > "u"
    ? 1
    : (a.ownerDocument.defaultView || window).devicePixelRatio || 1;
}
function Jm(a, i) {
  const c = zp(a);
  return Math.round(i * c) / c;
}
function ru(a) {
  const i = j.useRef(a);
  return (
    sr(() => {
      i.current = a;
    }),
    i
  );
}
function lw(a) {
  a === void 0 && (a = {});
  const {
      placement: i = "bottom",
      strategy: c = "absolute",
      middleware: o = [],
      platform: d,
      elements: { reference: f, floating: x } = {},
      transform: b = !0,
      whileElementsMounted: p,
      open: h,
    } = a,
    [v, w] = j.useState({
      x: 0,
      y: 0,
      strategy: c,
      placement: i,
      middlewareData: {},
      isPositioned: !1,
    }),
    [E, R] = j.useState(o);
  mr(E, o) || R(o);
  const [k, A] = j.useState(null),
    [_, B] = j.useState(null),
    V = j.useCallback((Q) => {
      Q !== $.current && (($.current = Q), A(Q));
    }, []),
    Y = j.useCallback((Q) => {
      Q !== F.current && ((F.current = Q), B(Q));
    }, []),
    Z = f || k,
    X = x || _,
    $ = j.useRef(null),
    F = j.useRef(null),
    K = j.useRef(v),
    ue = p != null,
    ge = ru(p),
    je = ru(d),
    he = ru(h),
    we = j.useCallback(() => {
      if (!$.current || !F.current) return;
      const Q = { placement: i, strategy: c, middleware: E };
      (je.current && (Q.platform = je.current),
        IN($.current, F.current, Q).then((se) => {
          const y = { ...se, isPositioned: he.current !== !1 };
          W.current &&
            !mr(K.current, y) &&
            ((K.current = y),
            jr.flushSync(() => {
              w(y);
            }));
        }));
    }, [E, i, c, je, he]);
  sr(() => {
    h === !1 &&
      K.current.isPositioned &&
      ((K.current.isPositioned = !1), w((Q) => ({ ...Q, isPositioned: !1 })));
  }, [h]);
  const W = j.useRef(!1);
  (sr(
    () => (
      (W.current = !0),
      () => {
        W.current = !1;
      }
    ),
    [],
  ),
    sr(() => {
      if ((Z && ($.current = Z), X && (F.current = X), Z && X)) {
        if (ge.current) return ge.current(Z, X, we);
        we();
      }
    }, [Z, X, we, ge, ue]));
  const fe = j.useMemo(
      () => ({ reference: $, floating: F, setReference: V, setFloating: Y }),
      [V, Y],
    ),
    O = j.useMemo(() => ({ reference: Z, floating: X }), [Z, X]),
    G = j.useMemo(() => {
      const Q = { position: c, left: 0, top: 0 };
      if (!O.floating) return Q;
      const se = Jm(O.floating, v.x),
        y = Jm(O.floating, v.y);
      return b
        ? {
            ...Q,
            transform: "translate(" + se + "px, " + y + "px)",
            ...(zp(O.floating) >= 1.5 && { willChange: "transform" }),
          }
        : { position: c, left: se, top: y };
    }, [c, b, O.floating, v.x, v.y]);
  return j.useMemo(
    () => ({ ...v, update: we, refs: fe, elements: O, floatingStyles: G }),
    [v, we, fe, O, G],
  );
}
const aw = (a) => {
    function i(c) {
      return {}.hasOwnProperty.call(c, "current");
    }
    return {
      name: "arrow",
      options: a,
      fn(c) {
        const { element: o, padding: d } = typeof a == "function" ? a(c) : a;
        return o && i(o)
          ? o.current != null
            ? $m({ element: o.current, padding: d }).fn(c)
            : {}
          : o
            ? $m({ element: o, padding: d }).fn(c)
            : {};
      },
    };
  },
  nw = (a, i) => {
    const c = KN(a);
    return { name: c.name, fn: c.fn, options: [a, i] };
  },
  sw = (a, i) => {
    const c = PN(a);
    return { name: c.name, fn: c.fn, options: [a, i] };
  },
  iw = (a, i) => ({ fn: WN(a).fn, options: [a, i] }),
  rw = (a, i) => {
    const c = $N(a);
    return { name: c.name, fn: c.fn, options: [a, i] };
  },
  cw = (a, i) => {
    const c = JN(a);
    return { name: c.name, fn: c.fn, options: [a, i] };
  },
  ow = (a, i) => {
    const c = FN(a);
    return { name: c.name, fn: c.fn, options: [a, i] };
  },
  uw = (a, i) => {
    const c = aw(a);
    return { name: c.name, fn: c.fn, options: [a, i] };
  };
var dw = "Arrow",
  Up = j.forwardRef((a, i) => {
    const { children: c, width: o = 10, height: d = 5, ...f } = a;
    return s.jsx(ht.svg, {
      ...f,
      ref: i,
      width: o,
      height: d,
      viewBox: "0 0 30 10",
      preserveAspectRatio: "none",
      children: a.asChild ? c : s.jsx("polygon", { points: "0,0 30,0 15,10" }),
    });
  });
Up.displayName = dw;
var fw = Up;
function hw(a) {
  const [i, c] = j.useState(void 0);
  return (
    Gt(() => {
      if (a) {
        c({ width: a.offsetWidth, height: a.offsetHeight });
        const o = new ResizeObserver((d) => {
          if (!Array.isArray(d) || !d.length) return;
          const f = d[0];
          let x, b;
          if ("borderBoxSize" in f) {
            const p = f.borderBoxSize,
              h = Array.isArray(p) ? p[0] : p;
            ((x = h.inlineSize), (b = h.blockSize));
          } else ((x = a.offsetWidth), (b = a.offsetHeight));
          c({ width: x, height: b });
        });
        return (o.observe(a, { box: "border-box" }), () => o.unobserve(a));
      } else c(void 0);
    }, [a]),
    i
  );
}
var Hp = "Popper",
  [Lp, qp] = Nr(Hp),
  [H4, Bp] = Lp(Hp),
  Gp = "PopperAnchor",
  Yp = j.forwardRef((a, i) => {
    const { __scopePopper: c, virtualRef: o, ...d } = a,
      f = Bp(Gp, c),
      x = j.useRef(null),
      b = Bt(i, x),
      p = j.useRef(null);
    return (
      j.useEffect(() => {
        const h = p.current;
        ((p.current = o?.current || x.current),
          h !== p.current && f.onAnchorChange(p.current));
      }),
      o ? null : s.jsx(ht.div, { ...d, ref: b })
    );
  });
Yp.displayName = Gp;
var Ju = "PopperContent",
  [mw, xw] = Lp(Ju),
  Vp = j.forwardRef((a, i) => {
    const {
        __scopePopper: c,
        side: o = "bottom",
        sideOffset: d = 0,
        align: f = "center",
        alignOffset: x = 0,
        arrowPadding: b = 0,
        avoidCollisions: p = !0,
        collisionBoundary: h = [],
        collisionPadding: v = 0,
        sticky: w = "partial",
        hideWhenDetached: E = !1,
        updatePositionStrategy: R = "optimized",
        onPlaced: k,
        ...A
      } = a,
      _ = Bp(Ju, c),
      [B, V] = j.useState(null),
      Y = Bt(i, (ze) => V(ze)),
      [Z, X] = j.useState(null),
      $ = hw(Z),
      F = $?.width ?? 0,
      K = $?.height ?? 0,
      ue = o + (f !== "center" ? "-" + f : ""),
      ge =
        typeof v == "number"
          ? v
          : { top: 0, right: 0, bottom: 0, left: 0, ...v },
      je = Array.isArray(h) ? h : [h],
      he = je.length > 0,
      we = { padding: ge, boundary: je.filter(bw), altBoundary: he },
      {
        refs: W,
        floatingStyles: fe,
        placement: O,
        isPositioned: G,
        middlewareData: Q,
      } = lw({
        strategy: "fixed",
        placement: ue,
        whileElementsMounted: (...ze) =>
          ZN(...ze, { animationFrame: R === "always" }),
        elements: { reference: _.anchor },
        middleware: [
          nw({ mainAxis: d + K, alignmentAxis: x }),
          p &&
            sw({
              mainAxis: !0,
              crossAxis: !1,
              limiter: w === "partial" ? iw() : void 0,
              ...we,
            }),
          p && rw({ ...we }),
          cw({
            ...we,
            apply: ({
              elements: ze,
              rects: Te,
              availableWidth: Ae,
              availableHeight: Nl,
            }) => {
              const { width: zt, height: Xt } = Te.reference,
                Et = ze.floating.style;
              (Et.setProperty("--radix-popper-available-width", `${Ae}px`),
                Et.setProperty("--radix-popper-available-height", `${Nl}px`),
                Et.setProperty("--radix-popper-anchor-width", `${zt}px`),
                Et.setProperty("--radix-popper-anchor-height", `${Xt}px`));
            },
          }),
          Z && uw({ element: Z, padding: b }),
          gw({ arrowWidth: F, arrowHeight: K }),
          E && ow({ strategy: "referenceHidden", ...we }),
        ],
      }),
      [se, y] = Zp(O),
      q = gl(k);
    Gt(() => {
      G && q?.();
    }, [G, q]);
    const J = Q.arrow?.x,
      P = Q.arrow?.y,
      ae = Q.arrow?.centerOffset !== 0,
      [ce, le] = j.useState();
    return (
      Gt(() => {
        B && le(window.getComputedStyle(B).zIndex);
      }, [B]),
      s.jsx("div", {
        ref: W.setFloating,
        "data-radix-popper-content-wrapper": "",
        style: {
          ...fe,
          transform: G ? fe.transform : "translate(0, -200%)",
          minWidth: "max-content",
          zIndex: ce,
          "--radix-popper-transform-origin": [
            Q.transformOrigin?.x,
            Q.transformOrigin?.y,
          ].join(" "),
          ...(Q.hide?.referenceHidden && {
            visibility: "hidden",
            pointerEvents: "none",
          }),
        },
        dir: a.dir,
        children: s.jsx(mw, {
          scope: c,
          placedSide: se,
          onArrowChange: X,
          arrowX: J,
          arrowY: P,
          shouldHideArrow: ae,
          children: s.jsx(ht.div, {
            "data-side": se,
            "data-align": y,
            ...A,
            ref: Y,
            style: { ...A.style, animation: G ? void 0 : "none" },
          }),
        }),
      })
    );
  });
Vp.displayName = Ju;
var Xp = "PopperArrow",
  pw = { top: "bottom", right: "left", bottom: "top", left: "right" },
  Qp = j.forwardRef(function (i, c) {
    const { __scopePopper: o, ...d } = i,
      f = xw(Xp, o),
      x = pw[f.placedSide];
    return s.jsx("span", {
      ref: f.onArrowChange,
      style: {
        position: "absolute",
        left: f.arrowX,
        top: f.arrowY,
        [x]: 0,
        transformOrigin: {
          top: "",
          right: "0 0",
          bottom: "center 0",
          left: "100% 0",
        }[f.placedSide],
        transform: {
          top: "translateY(100%)",
          right: "translateY(50%) rotate(90deg) translateX(-50%)",
          bottom: "rotate(180deg)",
          left: "translateY(50%) rotate(-90deg) translateX(50%)",
        }[f.placedSide],
        visibility: f.shouldHideArrow ? "hidden" : void 0,
      },
      children: s.jsx(fw, {
        ...d,
        ref: c,
        style: { ...d.style, display: "block" },
      }),
    });
  });
Qp.displayName = Xp;
function bw(a) {
  return a !== null;
}
var gw = (a) => ({
  name: "transformOrigin",
  options: a,
  fn(i) {
    const { placement: c, rects: o, middlewareData: d } = i,
      x = d.arrow?.centerOffset !== 0,
      b = x ? 0 : a.arrowWidth,
      p = x ? 0 : a.arrowHeight,
      [h, v] = Zp(c),
      w = { start: "0%", center: "50%", end: "100%" }[v],
      E = (d.arrow?.x ?? 0) + b / 2,
      R = (d.arrow?.y ?? 0) + p / 2;
    let k = "",
      A = "";
    return (
      h === "bottom"
        ? ((k = x ? w : `${E}px`), (A = `${-p}px`))
        : h === "top"
          ? ((k = x ? w : `${E}px`), (A = `${o.floating.height + p}px`))
          : h === "right"
            ? ((k = `${-p}px`), (A = x ? w : `${R}px`))
            : h === "left" &&
              ((k = `${o.floating.width + p}px`), (A = x ? w : `${R}px`)),
      { data: { x: k, y: A } }
    );
  },
});
function Zp(a) {
  const [i, c = "center"] = a.split("-");
  return [i, c];
}
var vw = Yp,
  yw = Vp,
  jw = Qp,
  [Dr] = Nr("Tooltip", [qp]),
  Fu = qp(),
  Kp = "TooltipProvider",
  Nw = 700,
  Fm = "tooltip.open",
  [ww, Pp] = Dr(Kp),
  $p = (a) => {
    const {
        __scopeTooltip: i,
        delayDuration: c = Nw,
        skipDelayDuration: o = 300,
        disableHoverableContent: d = !1,
        children: f,
      } = a,
      x = j.useRef(!0),
      b = j.useRef(!1),
      p = j.useRef(0);
    return (
      j.useEffect(() => {
        const h = p.current;
        return () => window.clearTimeout(h);
      }, []),
      s.jsx(ww, {
        scope: i,
        isOpenDelayedRef: x,
        delayDuration: c,
        onOpen: j.useCallback(() => {
          (window.clearTimeout(p.current), (x.current = !1));
        }, []),
        onClose: j.useCallback(() => {
          (window.clearTimeout(p.current),
            (p.current = window.setTimeout(() => (x.current = !0), o)));
        }, [o]),
        isPointerInTransitRef: b,
        onPointerInTransitChange: j.useCallback((h) => {
          b.current = h;
        }, []),
        disableHoverableContent: d,
        children: f,
      })
    );
  };
$p.displayName = Kp;
var Jp = "Tooltip",
  [L4, ks] = Dr(Jp),
  ju = "TooltipTrigger",
  Sw = j.forwardRef((a, i) => {
    const { __scopeTooltip: c, ...o } = a,
      d = ks(ju, c),
      f = Pp(ju, c),
      x = Fu(c),
      b = j.useRef(null),
      p = Bt(i, b, d.onTriggerChange),
      h = j.useRef(!1),
      v = j.useRef(!1),
      w = j.useCallback(() => (h.current = !1), []);
    return (
      j.useEffect(
        () => () => document.removeEventListener("pointerup", w),
        [w],
      ),
      s.jsx(vw, {
        asChild: !0,
        ...x,
        children: s.jsx(ht.button, {
          "aria-describedby": d.open ? d.contentId : void 0,
          "data-state": d.stateAttribute,
          ...o,
          ref: p,
          onPointerMove: Pe(a.onPointerMove, (E) => {
            E.pointerType !== "touch" &&
              !v.current &&
              !f.isPointerInTransitRef.current &&
              (d.onTriggerEnter(), (v.current = !0));
          }),
          onPointerLeave: Pe(a.onPointerLeave, () => {
            (d.onTriggerLeave(), (v.current = !1));
          }),
          onPointerDown: Pe(a.onPointerDown, () => {
            (d.open && d.onClose(),
              (h.current = !0),
              document.addEventListener("pointerup", w, { once: !0 }));
          }),
          onFocus: Pe(a.onFocus, () => {
            h.current || d.onOpen();
          }),
          onBlur: Pe(a.onBlur, d.onClose),
          onClick: Pe(a.onClick, d.onClose),
        }),
      })
    );
  });
Sw.displayName = ju;
var Wu = "TooltipPortal",
  [Ew, Tw] = Dr(Wu, { forceMount: void 0 }),
  Fp = (a) => {
    const { __scopeTooltip: i, forceMount: c, children: o, container: d } = a,
      f = ks(Wu, i);
    return s.jsx(Ew, {
      scope: i,
      forceMount: c,
      children: s.jsx(wr, {
        present: c || f.open,
        children: s.jsx(_u, { asChild: !0, container: d, children: o }),
      }),
    });
  };
Fp.displayName = Wu;
var gn = "TooltipContent",
  Wp = j.forwardRef((a, i) => {
    const c = Tw(gn, a.__scopeTooltip),
      { forceMount: o = c.forceMount, side: d = "top", ...f } = a,
      x = ks(gn, a.__scopeTooltip);
    return s.jsx(wr, {
      present: o || x.open,
      children: x.disableHoverableContent
        ? s.jsx(Ip, { side: d, ...f, ref: i })
        : s.jsx(Aw, { side: d, ...f, ref: i }),
    });
  }),
  Aw = j.forwardRef((a, i) => {
    const c = ks(gn, a.__scopeTooltip),
      o = Pp(gn, a.__scopeTooltip),
      d = j.useRef(null),
      f = Bt(i, d),
      [x, b] = j.useState(null),
      { trigger: p, onClose: h } = c,
      v = d.current,
      { onPointerInTransitChange: w } = o,
      E = j.useCallback(() => {
        (b(null), w(!1));
      }, [w]),
      R = j.useCallback(
        (k, A) => {
          const _ = k.currentTarget,
            B = { x: k.clientX, y: k.clientY },
            V = _w(B, _.getBoundingClientRect()),
            Y = kw(B, V),
            Z = Dw(A.getBoundingClientRect()),
            X = Uw([...Y, ...Z]);
          (b(X), w(!0));
        },
        [w],
      );
    return (
      j.useEffect(() => () => E(), [E]),
      j.useEffect(() => {
        if (p && v) {
          const k = (_) => R(_, v),
            A = (_) => R(_, p);
          return (
            p.addEventListener("pointerleave", k),
            v.addEventListener("pointerleave", A),
            () => {
              (p.removeEventListener("pointerleave", k),
                v.removeEventListener("pointerleave", A));
            }
          );
        }
      }, [p, v, R, E]),
      j.useEffect(() => {
        if (x) {
          const k = (A) => {
            const _ = A.target,
              B = { x: A.clientX, y: A.clientY },
              V = p?.contains(_) || v?.contains(_),
              Y = !zw(B, x);
            V ? E() : Y && (E(), h());
          };
          return (
            document.addEventListener("pointermove", k),
            () => document.removeEventListener("pointermove", k)
          );
        }
      }, [p, v, x, h, E]),
      s.jsx(Ip, { ...a, ref: f })
    );
  }),
  [Cw, Ow] = Dr(Jp, { isInside: !1 }),
  Rw = a1("TooltipContent"),
  Ip = j.forwardRef((a, i) => {
    const {
        __scopeTooltip: c,
        children: o,
        "aria-label": d,
        onEscapeKeyDown: f,
        onPointerDownOutside: x,
        ...b
      } = a,
      p = ks(gn, c),
      h = Fu(c),
      { onClose: v } = p;
    return (
      j.useEffect(
        () => (
          document.addEventListener(Fm, v),
          () => document.removeEventListener(Fm, v)
        ),
        [v],
      ),
      j.useEffect(() => {
        if (p.trigger) {
          const w = (E) => {
            E.target?.contains(p.trigger) && v();
          };
          return (
            window.addEventListener("scroll", w, { capture: !0 }),
            () => window.removeEventListener("scroll", w, { capture: !0 })
          );
        }
      }, [p.trigger, v]),
      s.jsx(Mu, {
        asChild: !0,
        disableOutsidePointerEvents: !1,
        onEscapeKeyDown: f,
        onPointerDownOutside: x,
        onFocusOutside: (w) => w.preventDefault(),
        onDismiss: v,
        children: s.jsxs(yw, {
          "data-state": p.stateAttribute,
          ...h,
          ...b,
          ref: i,
          style: {
            ...b.style,
            "--radix-tooltip-content-transform-origin":
              "var(--radix-popper-transform-origin)",
            "--radix-tooltip-content-available-width":
              "var(--radix-popper-available-width)",
            "--radix-tooltip-content-available-height":
              "var(--radix-popper-available-height)",
            "--radix-tooltip-trigger-width": "var(--radix-popper-anchor-width)",
            "--radix-tooltip-trigger-height":
              "var(--radix-popper-anchor-height)",
          },
          children: [
            s.jsx(Rw, { children: o }),
            s.jsx(Cw, {
              scope: c,
              isInside: !0,
              children: s.jsx(C1, {
                id: p.contentId,
                role: "tooltip",
                children: d || o,
              }),
            }),
          ],
        }),
      })
    );
  });
Wp.displayName = gn;
var eb = "TooltipArrow",
  Mw = j.forwardRef((a, i) => {
    const { __scopeTooltip: c, ...o } = a,
      d = Fu(c);
    return Ow(eb, c).isInside ? null : s.jsx(jw, { ...d, ...o, ref: i });
  });
Mw.displayName = eb;
function _w(a, i) {
  const c = Math.abs(i.top - a.y),
    o = Math.abs(i.bottom - a.y),
    d = Math.abs(i.right - a.x),
    f = Math.abs(i.left - a.x);
  switch (Math.min(c, o, d, f)) {
    case f:
      return "left";
    case d:
      return "right";
    case c:
      return "top";
    case o:
      return "bottom";
    default:
      throw new Error("unreachable");
  }
}
function kw(a, i, c = 5) {
  const o = [];
  switch (i) {
    case "top":
      o.push({ x: a.x - c, y: a.y + c }, { x: a.x + c, y: a.y + c });
      break;
    case "bottom":
      o.push({ x: a.x - c, y: a.y - c }, { x: a.x + c, y: a.y - c });
      break;
    case "left":
      o.push({ x: a.x + c, y: a.y - c }, { x: a.x + c, y: a.y + c });
      break;
    case "right":
      o.push({ x: a.x - c, y: a.y - c }, { x: a.x - c, y: a.y + c });
      break;
  }
  return o;
}
function Dw(a) {
  const { top: i, right: c, bottom: o, left: d } = a;
  return [
    { x: d, y: i },
    { x: c, y: i },
    { x: c, y: o },
    { x: d, y: o },
  ];
}
function zw(a, i) {
  const { x: c, y: o } = a;
  let d = !1;
  for (let f = 0, x = i.length - 1; f < i.length; x = f++) {
    const b = i[f],
      p = i[x],
      h = b.x,
      v = b.y,
      w = p.x,
      E = p.y;
    v > o != E > o && c < ((w - h) * (o - v)) / (E - v) + h && (d = !d);
  }
  return d;
}
function Uw(a) {
  const i = a.slice();
  return (
    i.sort((c, o) =>
      c.x < o.x ? -1 : c.x > o.x ? 1 : c.y < o.y ? -1 : c.y > o.y ? 1 : 0,
    ),
    Hw(i)
  );
}
function Hw(a) {
  if (a.length <= 1) return a.slice();
  const i = [];
  for (let o = 0; o < a.length; o++) {
    const d = a[o];
    for (; i.length >= 2; ) {
      const f = i[i.length - 1],
        x = i[i.length - 2];
      if ((f.x - x.x) * (d.y - x.y) >= (f.y - x.y) * (d.x - x.x)) i.pop();
      else break;
    }
    i.push(d);
  }
  i.pop();
  const c = [];
  for (let o = a.length - 1; o >= 0; o--) {
    const d = a[o];
    for (; c.length >= 2; ) {
      const f = c[c.length - 1],
        x = c[c.length - 2];
      if ((f.x - x.x) * (d.y - x.y) >= (f.y - x.y) * (d.x - x.x)) c.pop();
      else break;
    }
    c.push(d);
  }
  return (
    c.pop(),
    i.length === 1 && c.length === 1 && i[0].x === c[0].x && i[0].y === c[0].y
      ? i
      : i.concat(c)
  );
}
var Lw = $p,
  qw = Fp,
  tb = Wp;
const Bw = Lw,
  Gw = j.forwardRef(({ className: a, sideOffset: i = 4, ...c }, o) =>
    s.jsx(qw, {
      children: s.jsx(tb, {
        ref: o,
        sideOffset: i,
        className: $e(
          "z-50 overflow-hidden rounded-md bg-primary px-3 py-1.5 text-xs text-primary-foreground animate-in fade-in-0 zoom-in-95 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-[--radix-tooltip-content-transform-origin]",
          a,
        ),
        ...c,
      }),
    }),
  );
Gw.displayName = tb.displayName;
const Fl = j.forwardRef(({ className: a, ...i }, c) =>
  s.jsx("div", {
    ref: c,
    className: $e("rounded-xl border bg-card text-card-foreground shadow", a),
    ...i,
  }),
);
Fl.displayName = "Card";
const Nu = j.forwardRef(({ className: a, ...i }, c) =>
  s.jsx("div", {
    ref: c,
    className: $e("flex flex-col space-y-1.5 p-6", a),
    ...i,
  }),
);
Nu.displayName = "CardHeader";
const wu = j.forwardRef(({ className: a, ...i }, c) =>
  s.jsx("div", {
    ref: c,
    className: $e("font-semibold leading-none tracking-tight", a),
    ...i,
  }),
);
wu.displayName = "CardTitle";
const Su = j.forwardRef(({ className: a, ...i }, c) =>
  s.jsx("div", {
    ref: c,
    className: $e("text-sm text-muted-foreground", a),
    ...i,
  }),
);
Su.displayName = "CardDescription";
const Wl = j.forwardRef(({ className: a, ...i }, c) =>
  s.jsx("div", { ref: c, className: $e("p-6 pt-0", a), ...i }),
);
Wl.displayName = "CardContent";
const Yw = j.forwardRef(({ className: a, ...i }, c) =>
  s.jsx("div", {
    ref: c,
    className: $e("flex items-center p-6 pt-0", a),
    ...i,
  }),
);
Yw.displayName = "CardFooter";
function Vw() {
  return s.jsx("div", {
    className:
      "min-h-screen w-full flex items-center justify-center bg-gray-50",
    children: s.jsx(Fl, {
      className: "w-full max-w-md mx-4",
      children: s.jsxs(Wl, {
        className: "pt-6",
        children: [
          s.jsxs("div", {
            className: "flex mb-4 gap-2",
            children: [
              s.jsx(Fx, { className: "h-8 w-8 text-red-500" }),
              s.jsx("h1", {
                className: "text-2xl font-bold text-gray-900",
                children: "404 Page Not Found",
              }),
            ],
          }),
          s.jsx("p", {
            className: "mt-4 text-sm text-gray-600",
            children: "Did you forget to add the page to the router?",
          }),
        ],
      }),
    }),
  });
}
const Xw = [
    {
      icon: s.jsx(Ar, { className: "w-7 h-7" }),
      color: "bg-teal-50 text-teal-600",
      title: "إبلاغ لحظي بالصور",
      desc: "صوّر المشكلة وأرسل بلاغك في ثوانٍ مع تحديد تلقائي للموقع عبر GPS",
    },
    {
      icon: s.jsx(Gu, { className: "w-7 h-7" }),
      color: "bg-amber-50 text-amber-600",
      title: "أولوية ذكية",
      desc: "نظام ذكي يحسب درجة الخطورة بناءً على نوع المشكلة وقربها من المدارس والمستشفيات",
    },
    {
      icon: s.jsx(Na, { className: "w-7 h-7" }),
      color: "bg-blue-50 text-blue-600",
      title: "خريطة حرارية حية",
      desc: "شاهد توزيع البلاغات على خريطة تفاعلية وتحديد المناطق الأكثر احتياجاً",
    },
    {
      icon: s.jsx(Tr, { className: "w-7 h-7" }),
      color: "bg-purple-50 text-purple-600",
      title: "تتبع فوري",
      desc: "استقبل إشعارات لحظية عند تحديث حالة بلاغك في كل مرحلة",
    },
    {
      icon: s.jsx(Cr, { className: "w-7 h-7" }),
      color: "bg-rose-50 text-rose-600",
      title: "تحليلات متقدمة",
      desc: "لوحة تحكم إدارية شاملة بمؤشرات الأداء وتقارير الاستجابة لكل دائرة",
    },
    {
      icon: s.jsx(lp, { className: "w-7 h-7" }),
      color: "bg-emerald-50 text-emerald-600",
      title: "مؤشر الخطر العمراني",
      desc: "تقييم ديناميكي لمستوى خطورة كل منطقة بناءً على تراكم البلاغات وسرعة الاستجابة",
    },
  ],
  Qw = [
    { value: "١٢,٨٤٠", label: "بلاغ منذ الإطلاق", color: "text-teal-600" },
    { value: "٨٩٪", label: "معدل الحل الناجح", color: "text-emerald-600" },
    { value: "٢.٤", label: "ساعة متوسط الاستجابة", color: "text-blue-600" },
    { value: "٧", label: "مراكز مُغطّاة", color: "text-amber-600" },
  ],
  Zw = [
    {
      num: "١",
      title: "سجّل أو سجّل الدخول",
      desc: "أنشئ حسابك بدقيقة واحدة فقط بالاسم والرقم القومي",
    },
    {
      num: "٢",
      title: "صوّر وحدد الموقع",
      desc: "التقط صورة للمشكلة ويحدد التطبيق موقعك تلقائياً",
    },
    {
      num: "٣",
      title: "اختر الفئة وأرسل",
      desc: "حدد نوع المشكلة واكتب وصفاً موجزاً ثم أرسل البلاغ",
    },
    {
      num: "٤",
      title: "تابع وقيّم",
      desc: "استقبل تحديثات لحظية وقيّم الخدمة بعد الحل",
    },
  ],
  Kw = [
    {
      name: "سارة عبد الرحمن",
      city: "قليوب",
      rating: 5,
      text: "بلّغت عن حفرة في شارعنا وتم إصلاحها خلال ٣ أيام فقط! خدمة رائعة.",
      avatar: "/images/avatar-sara.png",
    },
    {
      name: "أحمد محمد",
      city: "بنها",
      rating: 5,
      text: "أخيراً منصة تجعل صوتنا مسموعاً. بلاغ كسر الماسورة تم متابعته بشفافية كاملة.",
      avatar: "/images/avatar-ahmed.png",
    },
    {
      name: "نهال فرج",
      city: "شبرا الخيمة",
      rating: 4,
      text: "سهلة الاستخدام جداً وسريعة الاستجابة. أنصح كل مواطن بتحميلها.",
      avatar: null,
    },
  ];
function Pw() {
  const [a, i] = j.useState(!1);
  return s.jsxs("div", {
    dir: "rtl",
    className: "min-h-screen bg-white text-slate-900",
    children: [
      s.jsxs("nav", {
        className:
          "fixed top-0 right-0 left-0 z-50 bg-white/95 backdrop-blur border-b border-slate-100 shadow-sm",
        children: [
          s.jsxs("div", {
            className:
              "max-w-6xl mx-auto px-6 h-16 flex items-center justify-between",
            children: [
              s.jsxs(Ye, {
                href: "/",
                className: "flex items-center gap-3",
                children: [
                  s.jsx("div", {
                    className:
                      "w-9 h-9 bg-teal-700 rounded-lg flex items-center justify-center text-white font-black text-lg",
                    children: "CP",
                  }),
                  s.jsxs("div", {
                    className: "leading-tight",
                    children: [
                      s.jsx("span", {
                        className:
                          "font-black text-teal-900 text-lg block leading-none",
                        children: "CityPulse",
                      }),
                      s.jsx("span", {
                        className: "text-[10px] text-slate-400 tracking-wider",
                        children: "محافظة القليوبية",
                      }),
                    ],
                  }),
                ],
              }),
              s.jsx("div", {
                className: "hidden md:flex items-center gap-8",
                children: [
                  "المميزات",
                  "كيف يعمل",
                  "آراء المواطنين",
                  "تواصل معنا",
                ].map((c) =>
                  s.jsx(
                    "a",
                    {
                      href: "#",
                      className:
                        "text-sm font-bold text-slate-600 hover:text-teal-700 transition-colors",
                      children: c,
                    },
                    c,
                  ),
                ),
              }),
              s.jsxs("div", {
                className: "hidden md:flex items-center gap-3",
                children: [
                  s.jsx(Ye, {
                    href: "/auth",
                    className:
                      "px-5 py-2 text-sm font-bold text-teal-700 border border-teal-200 rounded-lg hover:bg-teal-50 transition-colors",
                    children: "تسجيل الدخول",
                  }),
                  s.jsx(Ye, {
                    href: "/auth",
                    className:
                      "px-5 py-2 text-sm font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 transition-colors shadow-sm",
                    children: "ابدأ الآن",
                  }),
                ],
              }),
              s.jsx("button", {
                className: "md:hidden text-slate-600",
                onClick: () => i(!a),
                children: a
                  ? s.jsx(Or, { className: "w-6 h-6" })
                  : s.jsx(B2, { className: "w-6 h-6" }),
              }),
            ],
          }),
          a &&
            s.jsxs("div", {
              className:
                "md:hidden bg-white border-t border-slate-100 px-6 py-4 space-y-3",
              children: [
                ["المميزات", "كيف يعمل", "آراء المواطنين"].map((c) =>
                  s.jsx(
                    "a",
                    {
                      href: "#",
                      className: "block text-sm font-bold text-slate-700 py-1",
                      children: c,
                    },
                    c,
                  ),
                ),
                s.jsxs("div", {
                  className: "flex gap-3 pt-2",
                  children: [
                    s.jsx(Ye, {
                      href: "/auth",
                      className:
                        "flex-1 text-center py-2 text-sm font-bold text-teal-700 border border-teal-200 rounded-lg",
                      children: "تسجيل الدخول",
                    }),
                    s.jsx(Ye, {
                      href: "/auth",
                      className:
                        "flex-1 text-center py-2 text-sm font-bold text-white bg-teal-600 rounded-lg",
                      children: "ابدأ الآن",
                    }),
                  ],
                }),
              ],
            }),
        ],
      }),
      s.jsxs("section", {
        className:
          "pt-24 pb-20 px-6 bg-gradient-to-br from-slate-900 via-teal-950 to-slate-900 relative overflow-hidden",
        children: [
          s.jsxs("div", {
            className: "absolute inset-0",
            children: [
              s.jsx("img", {
                src: "/images/hero-city.png",
                alt: "",
                className: "w-full h-full object-cover opacity-20",
              }),
              s.jsx("div", {
                className:
                  "absolute inset-0 bg-gradient-to-b from-slate-900/60 via-teal-950/70 to-slate-900/90",
              }),
            ],
          }),
          s.jsxs("div", {
            className: "absolute inset-0 opacity-5 pointer-events-none",
            children: [
              s.jsx("div", {
                className:
                  "absolute top-20 right-10 w-96 h-96 bg-teal-400 rounded-full blur-3xl",
              }),
              s.jsx("div", {
                className:
                  "absolute bottom-10 left-20 w-72 h-72 bg-blue-400 rounded-full blur-3xl",
              }),
            ],
          }),
          s.jsxs("div", {
            className: "max-w-5xl mx-auto text-center relative",
            children: [
              s.jsxs("div", {
                className:
                  "inline-flex items-center gap-2 bg-teal-500/20 text-teal-300 px-4 py-2 rounded-full text-sm font-bold mb-8 border border-teal-500/30",
                children: [
                  s.jsx("div", {
                    className: "w-2 h-2 bg-teal-400 rounded-full animate-pulse",
                  }),
                  "منصة القليوبية الرقمية لإدارة البلاغات",
                ],
              }),
              s.jsxs("h1", {
                className:
                  "text-4xl md:text-6xl font-black text-white mb-6 leading-tight",
                children: [
                  "صوتك يبني",
                  s.jsx("span", {
                    className: "block text-teal-400 mt-1",
                    children: "محافظتك",
                  }),
                ],
              }),
              s.jsx("p", {
                className:
                  "text-lg text-slate-300 max-w-2xl mx-auto mb-10 leading-relaxed",
                children:
                  "منصة ذكية تمكّن مواطني القليوبية من الإبلاغ عن مشكلات البنية التحتية، وتمنح الإدارة أدوات متطورة لمتابعة الحلول وقياس الأداء بشفافية كاملة.",
              }),
              s.jsxs("div", {
                className:
                  "flex flex-col sm:flex-row items-center justify-center gap-4 mb-16",
                children: [
                  s.jsxs(Ye, {
                    href: "/report",
                    className:
                      "w-full sm:w-auto px-8 py-4 text-lg font-black text-white bg-teal-500 hover:bg-teal-400 rounded-xl transition-colors shadow-lg shadow-teal-500/25 flex items-center justify-center gap-2",
                    children: [
                      "ابدأ الإبلاغ الآن",
                      s.jsx(I1, { className: "w-5 h-5" }),
                    ],
                  }),
                  s.jsx("button", {
                    className:
                      "w-full sm:w-auto px-8 py-4 text-lg font-bold text-slate-200 bg-white/10 border border-white/20 rounded-xl hover:bg-white/20 transition-colors backdrop-blur",
                    children: "شاهد كيف يعمل",
                  }),
                ],
              }),
              s.jsx("div", {
                className:
                  "grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto",
                children: Qw.map((c) =>
                  s.jsxs(
                    "div",
                    {
                      className:
                        "bg-white/5 border border-white/10 rounded-xl p-4 backdrop-blur",
                      children: [
                        s.jsx("div", {
                          className: `text-3xl font-black mb-1 ${c.color}`,
                          children: c.value,
                        }),
                        s.jsx("div", {
                          className: "text-xs text-slate-400 font-bold",
                          children: c.label,
                        }),
                      ],
                    },
                    c.label,
                  ),
                ),
              }),
            ],
          }),
        ],
      }),
      s.jsx("section", {
        className: "py-20 px-6 bg-white",
        children: s.jsxs("div", {
          className: "max-w-6xl mx-auto",
          children: [
            s.jsxs("div", {
              className: "text-center mb-12",
              children: [
                s.jsx("span", {
                  className:
                    "text-sm font-black text-teal-600 uppercase tracking-wider mb-3 block",
                  children: "التأثير الحقيقي",
                }),
                s.jsx("h2", {
                  className:
                    "text-3xl md:text-4xl font-black text-slate-900 mb-4",
                  children: "من البلاغ إلى الحل",
                }),
                s.jsx("p", {
                  className: "text-slate-500 max-w-xl mx-auto",
                  children:
                    "آلاف المشاكل تم حلها بفضل مواطنين فاعلين ومنصة ذكية",
                }),
              ],
            }),
            s.jsx("div", {
              className: "grid grid-cols-1 md:grid-cols-3 gap-5 mb-10",
              children: [
                {
                  src: "/images/street-clean.png",
                  label: "طرق نظيفة وآمنة",
                  desc: "بعد كل بلاغ وكل إصلاح",
                },
                {
                  src: "/images/workers-team.png",
                  label: "فرق متخصصة سريعة الاستجابة",
                  desc: "٤٣ موظف في ٥ أقسام",
                },
                {
                  src: "/images/before-after.png",
                  label: "قبل وبعد",
                  desc: "التحول الذي يصنعه كل بلاغ",
                },
              ].map((c, o) =>
                s.jsxs(
                  "div",
                  {
                    className:
                      "rounded-2xl overflow-hidden shadow-md group relative",
                    children: [
                      s.jsx("img", {
                        src: c.src,
                        alt: c.label,
                        className:
                          "w-full h-52 object-cover group-hover:scale-105 transition-transform duration-500",
                        onError: (d) => {
                          const f = d.target;
                          f.style.display = "none";
                          const x = f.parentElement;
                          x &&
                            x.classList.add(
                              "bg-slate-200",
                              "h-52",
                              "flex",
                              "items-center",
                              "justify-center",
                            );
                        },
                      }),
                      s.jsx("div", {
                        className:
                          "absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent",
                      }),
                      s.jsxs("div", {
                        className:
                          "absolute bottom-0 right-0 left-0 p-5 text-white",
                        children: [
                          s.jsx("p", {
                            className: "font-black text-sm",
                            children: c.label,
                          }),
                          s.jsx("p", {
                            className: "text-xs text-white/70 mt-0.5",
                            children: c.desc,
                          }),
                        ],
                      }),
                    ],
                  },
                  o,
                ),
              ),
            }),
            s.jsx("div", {
              className: "grid grid-cols-2 md:grid-cols-4 gap-4",
              children: [
                {
                  value: "٨٩٪",
                  label: "معدل الحل الناجح",
                  sub: "من إجمالي البلاغات",
                },
                {
                  value: "٢.٤ ساعة",
                  label: "متوسط وقت الاستجابة",
                  sub: "منذ لحظة البلاغ",
                },
                {
                  value: "٤٣ موظف",
                  label: "في فرق متخصصة",
                  sub: "٥ أقسام فنية",
                },
                {
                  value: "١٢,٨٤٠",
                  label: "بلاغ مُعالج",
                  sub: "منذ إطلاق المنصة",
                },
              ].map((c, o) =>
                s.jsxs(
                  "div",
                  {
                    className:
                      "bg-slate-50 rounded-2xl p-5 border border-slate-100 text-center",
                    children: [
                      s.jsx("div", {
                        className: "text-2xl font-black text-teal-700 mb-1",
                        children: c.value,
                      }),
                      s.jsx("div", {
                        className: "text-xs font-black text-slate-700",
                        children: c.label,
                      }),
                      s.jsx("div", {
                        className: "text-[10px] text-slate-400 mt-0.5",
                        children: c.sub,
                      }),
                    ],
                  },
                  o,
                ),
              ),
            }),
          ],
        }),
      }),
      s.jsx("section", {
        className: "py-20 px-6 bg-slate-50",
        children: s.jsxs("div", {
          className: "max-w-6xl mx-auto",
          children: [
            s.jsxs("div", {
              className: "text-center mb-14",
              children: [
                s.jsx("span", {
                  className:
                    "text-sm font-black text-teal-600 uppercase tracking-wider mb-3 block",
                  children: "المميزات",
                }),
                s.jsx("h2", {
                  className:
                    "text-3xl md:text-4xl font-black text-slate-900 mb-4",
                  children: "كل ما تحتاجه في منصة واحدة",
                }),
                s.jsx("p", {
                  className: "text-slate-500 max-w-xl mx-auto",
                  children:
                    "نظام متكامل يربط المواطن بالجهة المختصة بسلاسة وشفافية",
                }),
              ],
            }),
            s.jsx("div", {
              className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",
              children: Xw.map((c) =>
                s.jsxs(
                  "div",
                  {
                    className:
                      "bg-white rounded-2xl p-7 border border-slate-100 shadow-sm hover:shadow-md transition-shadow group",
                    children: [
                      s.jsx("div", {
                        className: `w-14 h-14 rounded-xl flex items-center justify-center mb-5 ${c.color}`,
                        children: c.icon,
                      }),
                      s.jsx("h3", {
                        className: "text-lg font-black text-slate-800 mb-2",
                        children: c.title,
                      }),
                      s.jsx("p", {
                        className: "text-slate-500 text-sm leading-relaxed",
                        children: c.desc,
                      }),
                    ],
                  },
                  c.title,
                ),
              ),
            }),
          ],
        }),
      }),
      s.jsx("section", {
        className: "py-20 px-6 bg-white",
        children: s.jsxs("div", {
          className: "max-w-5xl mx-auto",
          children: [
            s.jsxs("div", {
              className: "text-center mb-14",
              children: [
                s.jsx("span", {
                  className:
                    "text-sm font-black text-teal-600 uppercase tracking-wider mb-3 block",
                  children: "كيف يعمل",
                }),
                s.jsx("h2", {
                  className:
                    "text-3xl md:text-4xl font-black text-slate-900 mb-4",
                  children: "أربع خطوات وبلاغك وصل",
                }),
              ],
            }),
            s.jsxs("div", {
              className: "grid grid-cols-1 md:grid-cols-4 gap-8 relative",
              children: [
                s.jsx("div", {
                  className:
                    "hidden md:block absolute top-10 right-[12.5%] left-[12.5%] h-0.5 bg-teal-100 z-0",
                }),
                Zw.map((c, o) =>
                  s.jsxs(
                    "div",
                    {
                      className: "text-center relative z-10",
                      children: [
                        s.jsx("div", {
                          className:
                            "w-20 h-20 bg-teal-600 text-white rounded-2xl flex items-center justify-center text-3xl font-black mx-auto mb-5 shadow-md shadow-teal-200",
                          children: c.num,
                        }),
                        s.jsx("h3", {
                          className: "font-black text-slate-800 mb-2",
                          children: c.title,
                        }),
                        s.jsx("p", {
                          className: "text-slate-500 text-sm leading-relaxed",
                          children: c.desc,
                        }),
                      ],
                    },
                    o,
                  ),
                ),
              ],
            }),
          ],
        }),
      }),
      s.jsx("section", {
        className: "py-20 px-6 bg-slate-50",
        children: s.jsxs("div", {
          className: "max-w-6xl mx-auto",
          children: [
            s.jsxs("div", {
              className: "text-center mb-12",
              children: [
                s.jsx("span", {
                  className:
                    "text-sm font-black text-teal-600 uppercase tracking-wider mb-3 block",
                  children: "التغطية الجغرافية",
                }),
                s.jsx("h2", {
                  className: "text-3xl font-black text-slate-900 mb-4",
                  children: "٧ مراكز تُغطيها المنصة",
                }),
                s.jsx("p", {
                  className: "text-slate-500 max-w-xl mx-auto",
                  children: "مراكز محافظة القليوبية كلها داخل شبكة CityPulse",
                }),
              ],
            }),
            s.jsx("div", {
              className: "grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3",
              children: [
                {
                  name: "شبرا الخيمة",
                  reports: "٣٤٢",
                  risk: 92,
                  color: "bg-red-50 border-red-200 text-red-700",
                },
                {
                  name: "الخانكة",
                  reports: "١٩٨",
                  risk: 71,
                  color: "bg-orange-50 border-orange-200 text-orange-700",
                },
                {
                  name: "بنها",
                  reports: "١٥٦",
                  risk: 58,
                  color: "bg-amber-50 border-amber-200 text-amber-700",
                },
                {
                  name: "قليوب",
                  reports: "١٣٤",
                  risk: 45,
                  color: "bg-yellow-50 border-yellow-200 text-yellow-700",
                },
                {
                  name: "القناطر",
                  reports: "٨٩",
                  risk: 28,
                  color: "bg-emerald-50 border-emerald-200 text-emerald-700",
                },
                {
                  name: "كفر شكر",
                  reports: "٦٧",
                  risk: 22,
                  color: "bg-green-50 border-green-200 text-green-700",
                },
                {
                  name: "طوخ",
                  reports: "٤٥",
                  risk: 15,
                  color: "bg-teal-50 border-teal-200 text-teal-700",
                },
              ].map((c, o) =>
                s.jsxs(
                  "div",
                  {
                    className: `rounded-2xl border-2 p-4 text-center hover:shadow-md transition-shadow cursor-pointer ${c.color}`,
                    children: [
                      s.jsx("div", {
                        className: "text-2xl font-black mb-1",
                        children: c.reports,
                      }),
                      s.jsx("div", {
                        className: "text-[11px] font-black leading-tight mb-2",
                        children: c.name,
                      }),
                      s.jsxs("div", {
                        className: "text-[10px] opacity-70",
                        children: [c.risk, "٪ مؤشر الخطر"],
                      }),
                      s.jsx("div", {
                        className:
                          "mt-2 h-1 bg-current rounded-full opacity-30",
                      }),
                      s.jsx("div", {
                        className: "mt-0.5 h-1 rounded-full opacity-70",
                        style: {
                          width: `${c.risk}%`,
                          background: "currentColor",
                        },
                      }),
                    ],
                  },
                  o,
                ),
              ),
            }),
          ],
        }),
      }),
      s.jsx("section", {
        className: "py-20 px-6 bg-slate-50",
        children: s.jsxs("div", {
          className: "max-w-6xl mx-auto",
          children: [
            s.jsxs("div", {
              className: "text-center mb-14",
              children: [
                s.jsx("span", {
                  className:
                    "text-sm font-black text-teal-600 uppercase tracking-wider mb-3 block",
                  children: "آراء المواطنين",
                }),
                s.jsx("h2", {
                  className: "text-3xl font-black text-slate-900 mb-4",
                  children: "ماذا يقولون عنا؟",
                }),
              ],
            }),
            s.jsx("div", {
              className: "grid grid-cols-1 md:grid-cols-3 gap-6",
              children: Kw.map((c, o) =>
                s.jsxs(
                  "div",
                  {
                    className:
                      "bg-white rounded-2xl p-7 border border-slate-100 shadow-sm",
                    children: [
                      s.jsx("div", {
                        className: "flex gap-1 mb-4",
                        children: Array.from({ length: c.rating }).map((d, f) =>
                          s.jsx(
                            or,
                            {
                              className:
                                "w-4 h-4 text-amber-400 fill-amber-400",
                            },
                            f,
                          ),
                        ),
                      }),
                      s.jsxs("p", {
                        className:
                          "text-slate-600 leading-relaxed mb-5 text-sm",
                        children: ['"', c.text, '"'],
                      }),
                      s.jsxs("div", {
                        className: "flex items-center gap-3",
                        children: [
                          c.avatar
                            ? s.jsx("img", {
                                src: c.avatar,
                                alt: c.name,
                                className:
                                  "w-10 h-10 rounded-full object-cover border-2 border-teal-100",
                                onError: (d) => {
                                  const f = d.target;
                                  ((f.style.display = "none"),
                                    f.nextElementSibling?.classList.remove(
                                      "hidden",
                                    ));
                                },
                              })
                            : null,
                          s.jsx("div", {
                            className: `w-10 h-10 bg-teal-100 rounded-full flex items-center justify-center text-teal-700 font-black text-sm ${c.avatar ? "hidden" : ""}`,
                            children: c.name[0],
                          }),
                          s.jsxs("div", {
                            children: [
                              s.jsx("p", {
                                className: "font-black text-slate-800 text-sm",
                                children: c.name,
                              }),
                              s.jsx("p", {
                                className: "text-xs text-slate-400",
                                children: c.city,
                              }),
                            ],
                          }),
                        ],
                      }),
                    ],
                  },
                  o,
                ),
              ),
            }),
          ],
        }),
      }),
      s.jsxs("section", {
        className: "py-24 px-6 relative overflow-hidden",
        children: [
          s.jsxs("div", {
            className: "absolute inset-0",
            children: [
              s.jsx("img", {
                src: "/images/gov-building.png",
                alt: "",
                className: "w-full h-full object-cover",
                onError: (c) => {
                  c.target.style.display = "none";
                },
              }),
              s.jsx("div", {
                className:
                  "absolute inset-0 bg-gradient-to-l from-teal-900/95 to-slate-900/90",
              }),
            ],
          }),
          s.jsxs("div", {
            className: "max-w-4xl mx-auto text-center relative z-10",
            children: [
              s.jsxs("div", {
                className:
                  "inline-flex items-center gap-2 bg-white/10 border border-white/20 rounded-full px-4 py-2 text-teal-300 text-sm font-bold mb-8",
                children: [
                  s.jsx(Jx, { className: "w-4 h-4" }),
                  "محافظة القليوبية — مشروع التحول الرقمي",
                ],
              }),
              s.jsxs("h2", {
                className:
                  "text-3xl md:text-5xl font-black text-white mb-5 leading-tight",
                children: [
                  "ابدأ في تحسين",
                  s.jsx("br", {}),
                  s.jsx("span", {
                    className: "text-teal-400",
                    children: "محيطك اليوم",
                  }),
                ],
              }),
              s.jsx("p", {
                className:
                  "text-slate-300 mb-10 text-lg max-w-2xl mx-auto leading-relaxed",
                children:
                  "انضم لآلاف مواطني القليوبية الذين يساهمون في بناء محافظة أفضل. صوتك يُحدث فرقاً حقيقياً.",
              }),
              s.jsxs("div", {
                className: "flex flex-col sm:flex-row gap-4 justify-center",
                children: [
                  s.jsx(Ye, {
                    href: "/auth",
                    className:
                      "px-10 py-4 text-lg font-black text-teal-900 bg-white rounded-xl hover:bg-teal-50 transition-colors shadow-lg",
                    children: "سجّل مجاناً الآن",
                  }),
                  s.jsx("button", {
                    className:
                      "px-10 py-4 text-lg font-bold text-white border-2 border-white/30 rounded-xl hover:bg-white/10 transition-colors backdrop-blur",
                    children: "تعرّف على المشروع",
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
      s.jsx("footer", {
        className: "bg-slate-900 text-slate-400 py-12 px-6",
        children: s.jsxs("div", {
          className: "max-w-6xl mx-auto",
          children: [
            s.jsxs("div", {
              className: "grid grid-cols-1 md:grid-cols-4 gap-8 mb-10",
              children: [
                s.jsxs("div", {
                  children: [
                    s.jsxs("div", {
                      className: "flex items-center gap-2 mb-4",
                      children: [
                        s.jsx("div", {
                          className:
                            "w-8 h-8 bg-teal-600 rounded-lg flex items-center justify-center text-white font-black text-sm",
                          children: "CP",
                        }),
                        s.jsx("span", {
                          className: "font-black text-white",
                          children: "CityPulse",
                        }),
                      ],
                    }),
                    s.jsx("p", {
                      className: "text-sm leading-relaxed",
                      children:
                        "منصة بلاغات محافظة القليوبية — نربط المواطن بالمسؤول بشفافية وكفاءة.",
                    }),
                  ],
                }),
                [
                  {
                    title: "الخدمات",
                    links: [
                      "تقديم بلاغ",
                      "متابعة بلاغاتي",
                      "الخريطة الحية",
                      "التقارير",
                    ],
                  },
                  {
                    title: "المحافظة",
                    links: [
                      "عن المشروع",
                      "الفرق المختصة",
                      "إحصاءات الأداء",
                      "سياسة الخصوصية",
                    ],
                  },
                  {
                    title: "تواصل",
                    links: [
                      "info@qalyubia.gov.eg",
                      "١٦٣٢٨",
                      "قليوب، محافظة القليوبية",
                      "الاثنين – الجمعة ٨ص – ٤م",
                    ],
                  },
                ].map((c) =>
                  s.jsxs(
                    "div",
                    {
                      children: [
                        s.jsx("h4", {
                          className: "font-black text-white mb-4",
                          children: c.title,
                        }),
                        s.jsx("ul", {
                          className: "space-y-2",
                          children: c.links.map((o) =>
                            s.jsx(
                              "li",
                              {
                                children: s.jsx("a", {
                                  href: "#",
                                  className:
                                    "text-sm hover:text-teal-400 transition-colors",
                                  children: o,
                                }),
                              },
                              o,
                            ),
                          ),
                        }),
                      ],
                    },
                    c.title,
                  ),
                ),
              ],
            }),
            s.jsx("div", {
              className: "border-t border-slate-800 pt-6 text-center text-xs",
              children: s.jsx("p", {
                children:
                  "© ٢٠٢٥ CityPulse — محافظة القليوبية. جميع الحقوق محفوظة.",
              }),
            }),
          ],
        }),
      }),
    ],
  });
}
function $w() {
  const [a, i] = j.useState("login"),
    [c, o] = j.useState(!1),
    [d, f] = j.useState(1),
    [x, b] = j.useState("01"),
    [, p] = vn(),
    h = () => {
      p("/dashboard");
    };
  return s.jsxs("div", {
    dir: "rtl",
    className:
      "min-h-screen bg-gradient-to-bl from-slate-900 via-teal-950 to-slate-900 flex",
    children: [
      s.jsxs("div", {
        className:
          "hidden lg:flex lg:w-5/12 flex-col justify-between p-12 relative overflow-hidden",
        children: [
          s.jsxs("div", {
            className: "absolute inset-0 opacity-10",
            children: [
              s.jsx("div", {
                className:
                  "absolute -top-20 -right-20 w-96 h-96 bg-teal-400 rounded-full blur-3xl",
              }),
              s.jsx("div", {
                className:
                  "absolute bottom-0 left-0 w-72 h-72 bg-blue-500 rounded-full blur-3xl",
              }),
            ],
          }),
          s.jsxs(Ye, {
            href: "/",
            className: "flex items-center gap-3 relative cursor-pointer z-10",
            children: [
              s.jsx("div", {
                className:
                  "w-11 h-11 bg-teal-500 rounded-xl flex items-center justify-center text-white font-black text-lg shadow-lg",
                children: "CP",
              }),
              s.jsxs("div", {
                children: [
                  s.jsx("span", {
                    className:
                      "font-black text-white text-xl block leading-none",
                    children: "CityPulse",
                  }),
                  s.jsx("span", {
                    className: "text-teal-400 text-xs tracking-wider",
                    children: "محافظة القليوبية",
                  }),
                ],
              }),
            ],
          }),
          s.jsxs("div", {
            className: "relative",
            children: [
              s.jsxs("h2", {
                className: "text-3xl font-black text-white mb-4 leading-tight",
                children: [
                  "بلاغك يصنع",
                  s.jsx("br", {}),
                  s.jsx("span", {
                    className: "text-teal-400",
                    children: "الفارق",
                  }),
                ],
              }),
              s.jsx("p", {
                className: "text-slate-300 leading-relaxed mb-10",
                children:
                  "انضم لمجتمع المواطنين الفاعلين وشارك في بناء محافظة القليوبية بالإبلاغ عن المشكلات واقتراح الحلول.",
              }),
              s.jsx("div", {
                className: "space-y-4",
                children: [
                  {
                    icon: s.jsx(Wi, { className: "w-5 h-5 text-teal-400" }),
                    text: "إبلاغ فوري بصورة وموقع GPS",
                  },
                  {
                    icon: s.jsx(Wi, { className: "w-5 h-5 text-teal-400" }),
                    text: "متابعة حالة بلاغك أولاً بأول",
                  },
                  {
                    icon: s.jsx(Wi, { className: "w-5 h-5 text-teal-400" }),
                    text: "إشعارات لحظية عند الحل",
                  },
                  {
                    icon: s.jsx(Wi, { className: "w-5 h-5 text-teal-400" }),
                    text: "تقييم الخدمة وبناء سجل الأداء",
                  },
                ].map((v, w) =>
                  s.jsxs(
                    "div",
                    {
                      className: "flex items-center gap-3",
                      children: [
                        v.icon,
                        s.jsx("span", {
                          className: "text-slate-200 text-sm font-bold",
                          children: v.text,
                        }),
                      ],
                    },
                    w,
                  ),
                ),
              }),
            ],
          }),
          s.jsx("div", {
            className: "grid grid-cols-3 gap-4 relative",
            children: [
              { val: "+١٢ألف", label: "مواطن مسجل" },
              { val: "٨٩٪", label: "نسبة الحل" },
              { val: "٢.٤س", label: "متوسط الاستجابة" },
            ].map((v) =>
              s.jsxs(
                "div",
                {
                  className:
                    "bg-white/5 border border-white/10 rounded-xl p-3 text-center backdrop-blur",
                  children: [
                    s.jsx("div", {
                      className: "text-teal-400 font-black text-lg",
                      children: v.val,
                    }),
                    s.jsx("div", {
                      className: "text-slate-400 text-xs",
                      children: v.label,
                    }),
                  ],
                },
                v.label,
              ),
            ),
          }),
        ],
      }),
      s.jsxs("div", {
        className:
          "flex-1 flex items-center justify-center p-6 lg:p-10 relative",
        children: [
          s.jsxs(Ye, {
            href: "/",
            className:
              "absolute top-6 right-6 text-slate-400 hover:text-white flex items-center gap-2 z-10 lg:hidden",
            children: [
              s.jsx(As, { className: "w-5 h-5" }),
              s.jsx("span", {
                className: "text-sm font-bold",
                children: "العودة",
              }),
            ],
          }),
          s.jsxs("div", {
            className: "w-full max-w-md mt-8 lg:mt-0",
            children: [
              s.jsxs("div", {
                className:
                  "bg-white/5 border border-white/10 rounded-2xl p-1 flex mb-8 backdrop-blur",
                children: [
                  s.jsx("button", {
                    onClick: () => {
                      (i("login"), f(1));
                    },
                    className: `flex-1 py-3 text-sm font-black rounded-xl transition-all ${a === "login" ? "bg-teal-600 text-white shadow-md" : "text-slate-400 hover:text-white"}`,
                    children: "تسجيل الدخول",
                  }),
                  s.jsx("button", {
                    onClick: () => {
                      (i("register"), f(1));
                    },
                    className: `flex-1 py-3 text-sm font-black rounded-xl transition-all ${a === "register" ? "bg-teal-600 text-white shadow-md" : "text-slate-400 hover:text-white"}`,
                    children: "حساب جديد",
                  }),
                ],
              }),
              s.jsxs("div", {
                className:
                  "bg-white/5 border border-white/10 backdrop-blur-xl rounded-2xl p-8",
                children: [
                  a === "login" &&
                    s.jsxs("div", {
                      className: "space-y-6",
                      children: [
                        s.jsxs("div", {
                          children: [
                            s.jsx("h3", {
                              className: "text-2xl font-black text-white mb-1",
                              children: "أهلاً بعودتك",
                            }),
                            s.jsx("p", {
                              className: "text-slate-400 text-sm",
                              children: "ادخل بياناتك للمتابعة",
                            }),
                          ],
                        }),
                        s.jsxs("div", {
                          className: "space-y-4",
                          children: [
                            s.jsxs("div", {
                              children: [
                                s.jsx("label", {
                                  className:
                                    "block text-sm font-black text-slate-300 mb-2",
                                  children: "رقم الهاتف",
                                }),
                                s.jsxs("div", {
                                  className: "relative",
                                  children: [
                                    s.jsx(km, {
                                      className:
                                        "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500",
                                    }),
                                    s.jsx("input", {
                                      type: "tel",
                                      defaultValue: "01xxxxxxxxx",
                                      className:
                                        "w-full bg-white/5 border border-white/10 text-white placeholder-slate-500 rounded-xl px-4 py-3 pr-10 text-sm font-bold focus:outline-none focus:border-teal-500 transition-colors",
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            s.jsxs("div", {
                              children: [
                                s.jsxs("div", {
                                  className: "flex justify-between mb-2",
                                  children: [
                                    s.jsx("label", {
                                      className:
                                        "text-sm font-black text-slate-300",
                                      children: "كلمة المرور",
                                    }),
                                    s.jsx("a", {
                                      href: "#",
                                      className:
                                        "text-xs text-teal-400 hover:text-teal-300",
                                      children: "نسيت كلمة المرور؟",
                                    }),
                                  ],
                                }),
                                s.jsxs("div", {
                                  className: "relative",
                                  children: [
                                    s.jsx(_m, {
                                      className:
                                        "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500",
                                    }),
                                    s.jsx("input", {
                                      type: c ? "text" : "password",
                                      defaultValue: "••••••••",
                                      className:
                                        "w-full bg-white/5 border border-white/10 text-white rounded-xl px-4 py-3 pr-10 text-sm font-bold focus:outline-none focus:border-teal-500 transition-colors",
                                    }),
                                    s.jsx("button", {
                                      onClick: () => o(!c),
                                      className:
                                        "absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300",
                                      children: c
                                        ? s.jsx(Rm, { className: "w-4 h-4" })
                                        : s.jsx(Mm, { className: "w-4 h-4" }),
                                    }),
                                  ],
                                }),
                              ],
                            }),
                          ],
                        }),
                        s.jsx("button", {
                          onClick: h,
                          className:
                            "w-full py-3.5 text-base font-black text-white bg-teal-600 hover:bg-teal-500 rounded-xl transition-colors shadow-lg shadow-teal-900/50",
                          children: "دخول",
                        }),
                        s.jsxs("div", {
                          className: "relative flex items-center gap-4",
                          children: [
                            s.jsx("div", {
                              className: "flex-1 h-px bg-white/10",
                            }),
                            s.jsx("span", {
                              className: "text-xs text-slate-500",
                              children: "أو",
                            }),
                            s.jsx("div", {
                              className: "flex-1 h-px bg-white/10",
                            }),
                          ],
                        }),
                        s.jsx("button", {
                          onClick: () => i("register"),
                          className:
                            "w-full py-3 text-sm font-black text-slate-300 border border-white/10 rounded-xl hover:bg-white/5 transition-colors",
                          children: "أنشئ حساباً جديداً",
                        }),
                      ],
                    }),
                  a === "register" &&
                    s.jsxs("div", {
                      children: [
                        s.jsx("div", {
                          className: "flex items-center gap-2 mb-6",
                          children: [1, 2, 3].map((v) =>
                            s.jsx(
                              "div",
                              {
                                className: `flex-1 h-1 rounded-full transition-all ${d >= v ? "bg-teal-500" : "bg-white/10"}`,
                              },
                              v,
                            ),
                          ),
                        }),
                        d === 1 &&
                          s.jsxs("div", {
                            className: "space-y-5",
                            children: [
                              s.jsxs("div", {
                                children: [
                                  s.jsx("h3", {
                                    className:
                                      "text-2xl font-black text-white mb-1",
                                    children: "معلوماتك الشخصية",
                                  }),
                                  s.jsx("p", {
                                    className: "text-slate-400 text-sm",
                                    children:
                                      "الخطوة ١ من ٣ — البيانات الأساسية",
                                  }),
                                ],
                              }),
                              s.jsxs("div", {
                                className: "space-y-4",
                                children: [
                                  s.jsxs("div", {
                                    children: [
                                      s.jsx("label", {
                                        className:
                                          "block text-sm font-black text-slate-300 mb-2",
                                        children: "الاسم الكامل",
                                      }),
                                      s.jsxs("div", {
                                        className: "relative",
                                        children: [
                                          s.jsx(sp, {
                                            className:
                                              "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500",
                                          }),
                                          s.jsx("input", {
                                            type: "text",
                                            placeholder: "محمد أحمد السيد",
                                            className:
                                              "w-full bg-white/5 border border-white/10 text-white placeholder-slate-500 rounded-xl px-4 py-3 pr-10 text-sm font-bold focus:outline-none focus:border-teal-500",
                                          }),
                                        ],
                                      }),
                                    ],
                                  }),
                                  s.jsxs("div", {
                                    children: [
                                      s.jsx("label", {
                                        className:
                                          "block text-sm font-black text-slate-300 mb-2",
                                        children: "الرقم القومي",
                                      }),
                                      s.jsxs("div", {
                                        className: "relative",
                                        children: [
                                          s.jsx(p2, {
                                            className:
                                              "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500",
                                          }),
                                          s.jsx("input", {
                                            type: "text",
                                            placeholder: "2XXXXXXXXXXXXXXXXX",
                                            maxLength: 14,
                                            className:
                                              "w-full bg-white/5 border border-white/10 text-white placeholder-slate-500 rounded-xl px-4 py-3 pr-10 text-sm font-bold focus:outline-none focus:border-teal-500 tracking-widest",
                                          }),
                                        ],
                                      }),
                                      s.jsx("p", {
                                        className:
                                          "text-xs text-slate-500 mt-1",
                                        children:
                                          "للتحقق من هويتك وتجنب البلاغات المكررة",
                                      }),
                                    ],
                                  }),
                                  s.jsxs("div", {
                                    children: [
                                      s.jsx("label", {
                                        className:
                                          "block text-sm font-black text-slate-300 mb-2",
                                        children: "المنطقة / المركز",
                                      }),
                                      s.jsxs("select", {
                                        className:
                                          "w-full bg-white/5 border border-white/10 text-white rounded-xl px-4 py-3 text-sm font-bold focus:outline-none focus:border-teal-500 appearance-none",
                                        children: [
                                          s.jsx("option", {
                                            value: "",
                                            className: "bg-slate-800",
                                            children: "اختر مركزك",
                                          }),
                                          [
                                            "قليوب",
                                            "بنها",
                                            "شبرا الخيمة",
                                            "القناطر الخيرية",
                                            "كفر شكر",
                                            "طوخ",
                                            "الخانكة",
                                          ].map((v) =>
                                            s.jsx(
                                              "option",
                                              {
                                                value: v,
                                                className: "bg-slate-800",
                                                children: v,
                                              },
                                              v,
                                            ),
                                          ),
                                        ],
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                              s.jsx("button", {
                                onClick: () => f(2),
                                className:
                                  "w-full py-3.5 text-base font-black text-white bg-teal-600 hover:bg-teal-500 rounded-xl transition-colors",
                                children: "التالي",
                              }),
                            ],
                          }),
                        d === 2 &&
                          s.jsxs("div", {
                            className: "space-y-5",
                            children: [
                              s.jsxs("div", {
                                children: [
                                  s.jsx("h3", {
                                    className:
                                      "text-2xl font-black text-white mb-1",
                                    children: "بيانات الاتصال",
                                  }),
                                  s.jsx("p", {
                                    className: "text-slate-400 text-sm",
                                    children:
                                      "الخطوة ٢ من ٣ — سيتم التحقق برمز OTP",
                                  }),
                                ],
                              }),
                              s.jsxs("div", {
                                className: "space-y-4",
                                children: [
                                  s.jsxs("div", {
                                    children: [
                                      s.jsx("label", {
                                        className:
                                          "block text-sm font-black text-slate-300 mb-2",
                                        children: "رقم الهاتف",
                                      }),
                                      s.jsxs("div", {
                                        className: "relative",
                                        children: [
                                          s.jsx(km, {
                                            className:
                                              "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500",
                                          }),
                                          s.jsx("input", {
                                            type: "tel",
                                            placeholder: "01XXXXXXXXX",
                                            className:
                                              "w-full bg-white/5 border border-white/10 text-white placeholder-slate-500 rounded-xl px-4 py-3 pr-10 text-sm font-bold focus:outline-none focus:border-teal-500",
                                          }),
                                        ],
                                      }),
                                    ],
                                  }),
                                  s.jsxs("div", {
                                    children: [
                                      s.jsx("label", {
                                        className:
                                          "block text-sm font-black text-slate-300 mb-2",
                                        children: "كلمة مرور جديدة",
                                      }),
                                      s.jsxs("div", {
                                        className: "relative",
                                        children: [
                                          s.jsx(_m, {
                                            className:
                                              "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500",
                                          }),
                                          s.jsx("input", {
                                            type: c ? "text" : "password",
                                            placeholder: "٨ أحرف على الأقل",
                                            className:
                                              "w-full bg-white/5 border border-white/10 text-white placeholder-slate-500 rounded-xl px-4 py-3 pr-10 text-sm font-bold focus:outline-none focus:border-teal-500",
                                          }),
                                          s.jsx("button", {
                                            onClick: () => o(!c),
                                            className:
                                              "absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300",
                                            children: c
                                              ? s.jsx(Rm, {
                                                  className: "w-4 h-4",
                                                })
                                              : s.jsx(Mm, {
                                                  className: "w-4 h-4",
                                                }),
                                          }),
                                        ],
                                      }),
                                      s.jsx("div", {
                                        className: "flex gap-1 mt-2",
                                        children: [
                                          "bg-red-500",
                                          "bg-amber-500",
                                          "bg-teal-500",
                                        ].map((v, w) =>
                                          s.jsx(
                                            "div",
                                            {
                                              className: `flex-1 h-1 rounded-full ${v} opacity-${w === 0 ? "100" : w === 1 ? "50" : "20"}`,
                                            },
                                            w,
                                          ),
                                        ),
                                      }),
                                      s.jsx("p", {
                                        className: "text-xs text-red-400 mt-1",
                                        children:
                                          "كلمة المرور ضعيفة — أضف أرقاماً ورموزاً",
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                              s.jsxs("div", {
                                className: "flex gap-3",
                                children: [
                                  s.jsx("button", {
                                    onClick: () => f(1),
                                    className:
                                      "px-5 py-3 text-sm font-black text-slate-400 border border-white/10 rounded-xl hover:bg-white/5",
                                    children: "رجوع",
                                  }),
                                  s.jsx("button", {
                                    onClick: () => f(3),
                                    className:
                                      "flex-1 py-3.5 text-base font-black text-white bg-teal-600 hover:bg-teal-500 rounded-xl transition-colors",
                                    children: "إرسال رمز التحقق",
                                  }),
                                ],
                              }),
                            ],
                          }),
                        d === 3 &&
                          s.jsxs("div", {
                            className: "space-y-5",
                            children: [
                              s.jsxs("div", {
                                children: [
                                  s.jsx("h3", {
                                    className:
                                      "text-2xl font-black text-white mb-1",
                                    children: "رمز التحقق",
                                  }),
                                  s.jsxs("p", {
                                    className: "text-slate-400 text-sm",
                                    children: [
                                      "تم إرسال رمز مكوّن من ٦ أرقام إلى ",
                                      s.jsx("span", {
                                        className: "text-teal-400",
                                        children: "0100XXXXXXX",
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                              s.jsx("div", {
                                className: "flex gap-3 justify-center my-6",
                                dir: "ltr",
                                children: [0, 1, 2, 3, 4, 5].map((v) =>
                                  s.jsx(
                                    "input",
                                    {
                                      type: "text",
                                      maxLength: 1,
                                      defaultValue: v < 4 ? "•" : "",
                                      className:
                                        "w-11 h-14 text-center text-xl font-black bg-white/5 border-2 border-white/10 rounded-xl text-white focus:border-teal-500 focus:outline-none transition-colors",
                                    },
                                    v,
                                  ),
                                ),
                              }),
                              s.jsxs("div", {
                                className:
                                  "bg-teal-900/30 border border-teal-500/30 rounded-xl p-3 flex items-start gap-2",
                                children: [
                                  s.jsx(Fx, {
                                    className:
                                      "w-4 h-4 text-teal-400 mt-0.5 shrink-0",
                                  }),
                                  s.jsxs("p", {
                                    className: "text-xs text-teal-300",
                                    children: [
                                      "ينتهي الرمز خلال ",
                                      s.jsx("span", {
                                        className: "font-black",
                                        children: "٤:٣٢",
                                      }),
                                      " دقيقة. لم تستلمه؟ ",
                                      s.jsx("a", {
                                        href: "#",
                                        className: "underline",
                                        children: "أعد الإرسال",
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                              s.jsx("button", {
                                onClick: h,
                                className:
                                  "w-full py-3.5 text-base font-black text-white bg-teal-600 hover:bg-teal-500 rounded-xl transition-colors shadow-lg",
                                children: "تأكيد وإنشاء الحساب",
                              }),
                            ],
                          }),
                      ],
                    }),
                ],
              }),
              s.jsxs("p", {
                className: "text-center text-xs text-slate-500 mt-6",
                children: [
                  "بالمتابعة، أنت توافق على",
                  " ",
                  s.jsx("a", {
                    href: "#",
                    className: "text-teal-400 hover:underline",
                    children: "سياسة الخصوصية",
                  }),
                  " ",
                  "و",
                  " ",
                  s.jsx("a", {
                    href: "#",
                    className: "text-teal-400 hover:underline",
                    children: "شروط الاستخدام",
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
    ],
  });
}
const Jw = [
    {
      id: "roads",
      icon: s.jsx(rr, { className: "w-6 h-6" }),
      label: "طرق وأرصفة",
      color: "text-orange-600 bg-orange-50 border-orange-200",
      selectedColor: "bg-orange-600 text-white border-orange-600",
    },
    {
      id: "water",
      icon: s.jsx(Wx, { className: "w-6 h-6" }),
      label: "مياه وصرف",
      color: "text-blue-600 bg-blue-50 border-blue-200",
      selectedColor: "bg-blue-600 text-white border-blue-600",
    },
    {
      id: "electric",
      icon: s.jsx(Gu, { className: "w-6 h-6" }),
      label: "كهرباء وإنارة",
      color: "text-amber-600 bg-amber-50 border-amber-200",
      selectedColor: "bg-amber-500 text-white border-amber-500",
    },
    {
      id: "cleaning",
      icon: s.jsx(ap, { className: "w-6 h-6" }),
      label: "نظافة وتجميل",
      color: "text-green-600 bg-green-50 border-green-200",
      selectedColor: "bg-green-600 text-white border-green-600",
    },
    {
      id: "other",
      icon: s.jsx(Bu, { className: "w-6 h-6" }),
      label: "مخاطر أخرى",
      color: "text-red-600 bg-red-50 border-red-200",
      selectedColor: "bg-red-600 text-white border-red-600",
    },
    {
      id: "infrastructure",
      icon: s.jsx(M2, { className: "w-6 h-6" }),
      label: "بنية تحتية",
      color: "text-purple-600 bg-purple-50 border-purple-200",
      selectedColor: "bg-purple-600 text-white border-purple-600",
    },
  ],
  Wm = ["الموقع والفئة", "التفاصيل والصور", "المراجعة والإرسال"];
function Fw() {
  const [a, i] = j.useState(0),
    [c, o] = j.useState("roads"),
    [d, f] = j.useState("medium"),
    [x, b] = j.useState(!1);
  return (
    vn(),
    x
      ? s.jsx("div", {
          dir: "rtl",
          className:
            "min-h-screen bg-gradient-to-br from-teal-50 to-emerald-50 flex items-center justify-center p-6",
          children: s.jsxs("div", {
            className:
              "bg-white rounded-3xl shadow-xl p-10 text-center max-w-md w-full",
            children: [
              s.jsx("div", {
                className:
                  "w-24 h-24 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6",
                children: s.jsx(xn, {
                  className: "w-12 h-12 text-emerald-600",
                }),
              }),
              s.jsx("h2", {
                className: "text-2xl font-black text-slate-900 mb-3",
                children: "تم إرسال بلاغك بنجاح!",
              }),
              s.jsxs("p", {
                className: "text-slate-500 mb-6",
                children: [
                  "رقم البلاغ: ",
                  s.jsx("span", {
                    className: "font-black text-teal-700 text-lg",
                    children: "#C-٩٠١",
                  }),
                ],
              }),
              s.jsxs("div", {
                className:
                  "bg-slate-50 rounded-2xl p-5 text-right mb-6 space-y-3",
                children: [
                  s.jsxs("div", {
                    className: "flex justify-between text-sm",
                    children: [
                      s.jsx("span", {
                        className: "text-slate-500",
                        children: "الفئة",
                      }),
                      s.jsx("span", {
                        className: "font-bold text-slate-800",
                        children: "طرق وأرصفة",
                      }),
                    ],
                  }),
                  s.jsxs("div", {
                    className: "flex justify-between text-sm",
                    children: [
                      s.jsx("span", {
                        className: "text-slate-500",
                        children: "الموقع",
                      }),
                      s.jsx("span", {
                        className: "font-bold text-slate-800",
                        children: "شارع السيوف، قليوب",
                      }),
                    ],
                  }),
                  s.jsxs("div", {
                    className: "flex justify-between text-sm",
                    children: [
                      s.jsx("span", {
                        className: "text-slate-500",
                        children: "الأولوية المتوقعة",
                      }),
                      s.jsx("span", {
                        className: "font-bold text-amber-600",
                        children: "هام",
                      }),
                    ],
                  }),
                  s.jsxs("div", {
                    className: "flex justify-between text-sm",
                    children: [
                      s.jsx("span", {
                        className: "text-slate-500",
                        children: "وقت الاستجابة المتوقع",
                      }),
                      s.jsx("span", {
                        className: "font-bold text-teal-700",
                        children: "١–٣ أيام عمل",
                      }),
                    ],
                  }),
                ],
              }),
              s.jsxs("div", {
                className:
                  "flex items-center gap-2 bg-teal-50 border border-teal-100 rounded-xl p-3 text-right mb-6",
                children: [
                  s.jsx(pn, { className: "w-4 h-4 text-teal-600 shrink-0" }),
                  s.jsx("p", {
                    className: "text-xs text-teal-700",
                    children: "ستصلك رسالة نصية عند تحديث حالة البلاغ",
                  }),
                ],
              }),
              s.jsxs("div", {
                className: "flex flex-col gap-3",
                children: [
                  s.jsx("button", {
                    onClick: () => {
                      (b(!1), i(0));
                    },
                    className:
                      "w-full py-3 text-sm font-black text-white bg-teal-600 rounded-xl hover:bg-teal-700 transition-colors",
                    children: "تقديم بلاغ آخر",
                  }),
                  s.jsx(Ye, {
                    href: "/dashboard",
                    className:
                      "w-full text-center py-3 text-sm font-black text-slate-600 bg-slate-100 rounded-xl hover:bg-slate-200 transition-colors",
                    children: "العودة للوحة التحكم",
                  }),
                ],
              }),
            ],
          }),
        })
      : s.jsxs("div", {
          dir: "rtl",
          className: "min-h-screen bg-slate-50",
          children: [
            s.jsxs("header", {
              className:
                "bg-white border-b border-slate-100 sticky top-0 z-20 shadow-sm",
              children: [
                s.jsxs("div", {
                  className:
                    "max-w-3xl mx-auto px-4 h-16 flex items-center gap-4",
                  children: [
                    s.jsx("button", {
                      onClick: () => window.history.back(),
                      className:
                        "text-slate-500 hover:text-slate-800 transition-colors",
                      children: s.jsx(As, { className: "w-5 h-5" }),
                    }),
                    s.jsxs("div", {
                      children: [
                        s.jsx("h1", {
                          className: "font-black text-slate-900",
                          children: "تقديم بلاغ جديد",
                        }),
                        s.jsx("p", {
                          className: "text-xs text-slate-400",
                          children: "محافظة القليوبية — CityPulse",
                        }),
                      ],
                    }),
                  ],
                }),
                s.jsx("div", {
                  className: "max-w-3xl mx-auto px-4 pb-4",
                  children: s.jsx("div", {
                    className: "flex items-center gap-2 mb-2",
                    children: Wm.map((p, h) =>
                      s.jsxs(
                        bl.Fragment,
                        {
                          children: [
                            s.jsxs("div", {
                              className: `flex items-center gap-1.5 text-xs font-black transition-colors ${h <= a ? "text-teal-700" : "text-slate-400"}`,
                              children: [
                                s.jsx("div", {
                                  className: `w-6 h-6 rounded-full flex items-center justify-center text-xs font-black border-2 transition-all ${h < a ? "bg-teal-600 border-teal-600 text-white" : h === a ? "border-teal-600 text-teal-600 bg-white" : "border-slate-300 text-slate-400"}`,
                                  children:
                                    h < a
                                      ? s.jsx(xn, { className: "w-3.5 h-3.5" })
                                      : h + 1,
                                }),
                                s.jsx("span", {
                                  className: "hidden sm:inline",
                                  children: p,
                                }),
                              ],
                            }),
                            h < Wm.length - 1 &&
                              s.jsx("div", {
                                className: `flex-1 h-0.5 rounded transition-all ${h < a ? "bg-teal-500" : "bg-slate-200"}`,
                              }),
                          ],
                        },
                        h,
                      ),
                    ),
                  }),
                }),
              ],
            }),
            s.jsxs("main", {
              className: "max-w-3xl mx-auto px-4 py-8 pb-24",
              children: [
                a === 0 &&
                  s.jsxs("div", {
                    className: "space-y-6",
                    children: [
                      s.jsxs("div", {
                        className:
                          "bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden",
                        children: [
                          s.jsxs("div", {
                            className:
                              "relative h-56 bg-gradient-to-br from-teal-900 via-teal-800 to-slate-800",
                            children: [
                              s.jsxs("svg", {
                                className:
                                  "absolute inset-0 w-full h-full opacity-20",
                                viewBox: "0 0 320 224",
                                children: [
                                  [
                                    20, 40, 60, 80, 100, 120, 140, 160, 180,
                                    200, 220, 240, 260, 280, 300,
                                  ].map((p) =>
                                    s.jsx(
                                      "line",
                                      {
                                        x1: p,
                                        y1: "0",
                                        x2: p,
                                        y2: "224",
                                        stroke: "white",
                                        strokeWidth: "0.5",
                                      },
                                      p,
                                    ),
                                  ),
                                  [
                                    20, 40, 60, 80, 100, 120, 140, 160, 180,
                                    200,
                                  ].map((p) =>
                                    s.jsx(
                                      "line",
                                      {
                                        x1: "0",
                                        y1: p,
                                        x2: "320",
                                        y2: p,
                                        stroke: "white",
                                        strokeWidth: "0.5",
                                      },
                                      p,
                                    ),
                                  ),
                                  s.jsx("circle", {
                                    cx: "160",
                                    cy: "112",
                                    r: "40",
                                    fill: "none",
                                    stroke: "#2dd4bf",
                                    strokeWidth: "1.5",
                                    opacity: "0.6",
                                  }),
                                  s.jsx("circle", {
                                    cx: "160",
                                    cy: "112",
                                    r: "70",
                                    fill: "none",
                                    stroke: "#2dd4bf",
                                    strokeWidth: "0.5",
                                    opacity: "0.3",
                                  }),
                                  s.jsx("rect", {
                                    x: "60",
                                    y: "40",
                                    width: "60",
                                    height: "30",
                                    fill: "#134e4a",
                                    rx: "2",
                                  }),
                                  s.jsx("rect", {
                                    x: "150",
                                    y: "20",
                                    width: "80",
                                    height: "20",
                                    fill: "#134e4a",
                                    rx: "2",
                                  }),
                                  s.jsx("rect", {
                                    x: "80",
                                    y: "100",
                                    width: "40",
                                    height: "50",
                                    fill: "#134e4a",
                                    rx: "2",
                                  }),
                                  s.jsx("rect", {
                                    x: "200",
                                    y: "80",
                                    width: "70",
                                    height: "40",
                                    fill: "#134e4a",
                                    rx: "2",
                                  }),
                                  s.jsx("rect", {
                                    x: "180",
                                    y: "140",
                                    width: "50",
                                    height: "60",
                                    fill: "#134e4a",
                                    rx: "2",
                                  }),
                                ],
                              }),
                              s.jsxs("div", {
                                className:
                                  "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-full",
                                children: [
                                  s.jsx("div", {
                                    className:
                                      "w-8 h-8 bg-red-500 rounded-full border-4 border-white shadow-lg flex items-center justify-center",
                                    children: s.jsx("div", {
                                      className:
                                        "w-2 h-2 bg-white rounded-full",
                                    }),
                                  }),
                                  s.jsx("div", {
                                    className:
                                      "w-0 h-0 border-x-4 border-x-transparent border-t-8 border-t-red-500 mx-auto",
                                  }),
                                ],
                              }),
                              s.jsxs("div", {
                                className:
                                  "absolute bottom-3 right-3 bg-white/95 rounded-lg px-3 py-1.5 text-xs font-black text-slate-700 shadow-sm flex items-center gap-1",
                                children: [
                                  s.jsx(tp, {
                                    className: "w-3 h-3 text-teal-600",
                                  }),
                                  "شارع السيوف، قليوب",
                                ],
                              }),
                              s.jsx("div", {
                                className: "absolute top-3 left-3 flex gap-2",
                                children: s.jsxs("button", {
                                  className:
                                    "bg-white shadow-sm rounded-lg px-3 py-1.5 text-xs font-black text-teal-700 flex items-center gap-1",
                                  children: [
                                    s.jsx(Na, { className: "w-3.5 h-3.5" }),
                                    "موقعي الحالي",
                                  ],
                                }),
                              }),
                            ],
                          }),
                          s.jsxs("div", {
                            className: "p-4",
                            children: [
                              s.jsx("label", {
                                className:
                                  "block text-sm font-black text-slate-700 mb-2",
                                children: "أو اكتب العنوان يدوياً",
                              }),
                              s.jsxs("div", {
                                className: "flex gap-2",
                                children: [
                                  s.jsx("input", {
                                    type: "text",
                                    placeholder:
                                      "مثال: ميدان محطة القناطر الخيرية",
                                    className:
                                      "flex-1 border border-slate-200 rounded-xl px-4 py-2.5 text-sm font-bold text-slate-700 placeholder-slate-400 focus:outline-none focus:border-teal-500",
                                  }),
                                  s.jsx("select", {
                                    className:
                                      "border border-slate-200 rounded-xl px-3 py-2.5 text-sm font-bold text-slate-700 focus:outline-none focus:border-teal-500 bg-white",
                                    children: [
                                      "قليوب",
                                      "بنها",
                                      "شبرا الخيمة",
                                      "القناطر",
                                      "كفر شكر",
                                      "طوخ",
                                    ].map((p) =>
                                      s.jsx("option", { children: p }, p),
                                    ),
                                  }),
                                ],
                              }),
                            ],
                          }),
                        ],
                      }),
                      s.jsxs("div", {
                        className:
                          "bg-white rounded-2xl border border-slate-100 shadow-sm p-6",
                        children: [
                          s.jsx("h2", {
                            className: "font-black text-slate-800 mb-4",
                            children: "نوع المشكلة",
                          }),
                          s.jsx("div", {
                            className: "grid grid-cols-2 sm:grid-cols-3 gap-3",
                            children: Jw.map((p) =>
                              s.jsxs(
                                "button",
                                {
                                  onClick: () => o(p.id),
                                  className: `flex flex-col items-center gap-2 p-4 border-2 rounded-2xl transition-all font-bold text-sm ${c === p.id ? p.selectedColor : p.color}`,
                                  children: [p.icon, p.label],
                                },
                                p.id,
                              ),
                            ),
                          }),
                        ],
                      }),
                      s.jsxs("div", {
                        className:
                          "bg-white rounded-2xl border border-slate-100 shadow-sm p-6",
                        children: [
                          s.jsx("h2", {
                            className: "font-black text-slate-800 mb-4",
                            children: "درجة الخطورة",
                          }),
                          s.jsx("div", {
                            className: "flex gap-3",
                            children: [
                              {
                                id: "low",
                                label: "منخفضة",
                                color:
                                  "bg-emerald-500 text-white border-emerald-500",
                                idle: "text-emerald-600 border-emerald-200 bg-emerald-50",
                              },
                              {
                                id: "medium",
                                label: "متوسطة",
                                color:
                                  "bg-amber-500 text-white border-amber-500",
                                idle: "text-amber-600 border-amber-200 bg-amber-50",
                              },
                              {
                                id: "high",
                                label: "عالية / طارئ",
                                color: "bg-red-500 text-white border-red-500",
                                idle: "text-red-600 border-red-200 bg-red-50",
                              },
                            ].map((p) =>
                              s.jsx(
                                "button",
                                {
                                  onClick: () => f(p.id),
                                  className: `flex-1 py-3 border-2 rounded-xl text-sm font-black transition-all ${d === p.id ? p.color : p.idle}`,
                                  children: p.label,
                                },
                                p.id,
                              ),
                            ),
                          }),
                          d === "high" &&
                            s.jsxs("div", {
                              className:
                                "mt-3 flex items-center gap-2 bg-red-50 border border-red-100 rounded-xl p-3",
                              children: [
                                s.jsx(Bu, {
                                  className: "w-4 h-4 text-red-500 shrink-0",
                                }),
                                s.jsx("p", {
                                  className: "text-xs text-red-700 font-bold",
                                  children:
                                    "البلاغات الطارئة تُعالج خلال ٢ ساعة كحد أقصى",
                                }),
                              ],
                            }),
                        ],
                      }),
                      s.jsx("button", {
                        onClick: () => i(1),
                        className:
                          "w-full py-4 text-base font-black text-white bg-teal-600 hover:bg-teal-700 rounded-2xl transition-colors shadow-md",
                        children: "التالي — إضافة التفاصيل والصور",
                      }),
                    ],
                  }),
                a === 1 &&
                  s.jsxs("div", {
                    className: "space-y-6",
                    children: [
                      s.jsxs("div", {
                        className:
                          "bg-white rounded-2xl border border-slate-100 shadow-sm p-6 space-y-5",
                        children: [
                          s.jsx("h2", {
                            className: "font-black text-slate-800",
                            children: "وصف المشكلة",
                          }),
                          s.jsxs("div", {
                            children: [
                              s.jsx("label", {
                                className:
                                  "block text-sm font-black text-slate-700 mb-2",
                                children: "اشرح المشكلة بالتفصيل",
                              }),
                              s.jsx("textarea", {
                                rows: 4,
                                placeholder:
                                  "مثال: توجد حفرة كبيرة في منتصف الطريق أمام المدرسة تُشكّل خطراً على المارة والسيارات، خاصةً في الليل...",
                                className:
                                  "w-full border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-700 placeholder-slate-400 focus:outline-none focus:border-teal-500 resize-none",
                              }),
                              s.jsxs("div", {
                                className: "flex justify-between mt-1",
                                children: [
                                  s.jsx("p", {
                                    className: "text-xs text-slate-400",
                                    children: "وصف تفصيلي يسرّع المعالجة",
                                  }),
                                  s.jsx("p", {
                                    className: "text-xs text-slate-400",
                                    children: "٠ / ٥٠٠",
                                  }),
                                ],
                              }),
                            ],
                          }),
                          s.jsxs("div", {
                            children: [
                              s.jsx("label", {
                                className:
                                  "block text-sm font-black text-slate-700 mb-2",
                                children: "هل تتكرر هذه المشكلة؟",
                              }),
                              s.jsx("div", {
                                className: "flex gap-3",
                                children: [
                                  "نعم، متكررة",
                                  "لأول مرة",
                                  "غير متأكد",
                                ].map((p) =>
                                  s.jsx(
                                    "button",
                                    {
                                      className:
                                        "flex-1 py-2 border border-slate-200 rounded-xl text-xs font-bold text-slate-600 hover:border-teal-400 hover:text-teal-700 transition-colors",
                                      children: p,
                                    },
                                    p,
                                  ),
                                ),
                              }),
                            ],
                          }),
                        ],
                      }),
                      s.jsxs("div", {
                        className:
                          "bg-white rounded-2xl border border-slate-100 shadow-sm p-6",
                        children: [
                          s.jsxs("div", {
                            className: "flex justify-between items-center mb-4",
                            children: [
                              s.jsx("h2", {
                                className: "font-black text-slate-800",
                                children: "الصور والمرفقات",
                              }),
                              s.jsx("span", {
                                className: "text-xs text-slate-400 font-bold",
                                children: "اختياري (يُنصح به)",
                              }),
                            ],
                          }),
                          s.jsxs("div", {
                            className:
                              "border-2 border-dashed border-slate-200 rounded-2xl p-8 text-center hover:border-teal-400 transition-colors cursor-pointer mb-4 group",
                            children: [
                              s.jsx("div", {
                                className:
                                  "w-14 h-14 bg-teal-50 rounded-2xl flex items-center justify-center mx-auto mb-3 group-hover:bg-teal-100 transition-colors",
                                children: s.jsx(Ar, {
                                  className: "w-7 h-7 text-teal-600",
                                }),
                              }),
                              s.jsx("p", {
                                className:
                                  "text-sm font-black text-slate-700 mb-1",
                                children: "التقط صورة أو ارفع من الاستوديو",
                              }),
                              s.jsx("p", {
                                className: "text-xs text-slate-400",
                                children: "PNG, JPG, HEIC — حتى ١٠ ميجابايت",
                              }),
                            ],
                          }),
                          s.jsxs("div", {
                            className: "grid grid-cols-3 gap-2",
                            children: [
                              [
                                {
                                  color: "from-slate-700 to-slate-900",
                                  label: "صورة ١",
                                },
                                {
                                  color: "from-teal-800 to-slate-800",
                                  label: "صورة ٢",
                                },
                              ].map((p, h) =>
                                s.jsxs(
                                  "div",
                                  {
                                    className: `relative h-20 rounded-xl bg-gradient-to-br ${p.color} overflow-hidden group`,
                                    children: [
                                      s.jsx("div", {
                                        className:
                                          "absolute inset-0 flex items-center justify-center",
                                        children: s.jsx(ep, {
                                          className: "w-6 h-6 text-white/40",
                                        }),
                                      }),
                                      s.jsx("button", {
                                        className:
                                          "absolute top-1.5 left-1.5 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity",
                                        children: s.jsx(Or, {
                                          className: "w-3 h-3 text-white",
                                        }),
                                      }),
                                    ],
                                  },
                                  h,
                                ),
                              ),
                              s.jsx("div", {
                                className:
                                  "h-20 rounded-xl border-2 border-dashed border-slate-200 flex items-center justify-center cursor-pointer hover:border-teal-400 transition-colors",
                                children: s.jsx("span", {
                                  className: "text-2xl text-slate-300",
                                  children: "+",
                                }),
                              }),
                            ],
                          }),
                        ],
                      }),
                      s.jsxs("div", {
                        className: "flex gap-3",
                        children: [
                          s.jsx("button", {
                            onClick: () => i(0),
                            className:
                              "px-6 py-4 border border-slate-200 rounded-2xl text-sm font-black text-slate-600 hover:bg-slate-50 transition-colors",
                            children: "رجوع",
                          }),
                          s.jsx("button", {
                            onClick: () => i(2),
                            className:
                              "flex-1 py-4 text-base font-black text-white bg-teal-600 hover:bg-teal-700 rounded-2xl transition-colors shadow-md",
                            children: "التالي — مراجعة البلاغ",
                          }),
                        ],
                      }),
                    ],
                  }),
                a === 2 &&
                  s.jsxs("div", {
                    className: "space-y-5",
                    children: [
                      s.jsxs("div", {
                        className:
                          "bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden",
                        children: [
                          s.jsx("div", {
                            className: "bg-teal-700 p-5 text-white",
                            children: s.jsxs("div", {
                              className: "flex justify-between items-start",
                              children: [
                                s.jsxs("div", {
                                  children: [
                                    s.jsx("p", {
                                      className:
                                        "text-teal-200 text-xs font-bold mb-1",
                                      children: "رقم البلاغ المتوقع",
                                    }),
                                    s.jsx("h3", {
                                      className: "text-2xl font-black",
                                      children: "#C-٩٠١",
                                    }),
                                  ],
                                }),
                                s.jsx("span", {
                                  className:
                                    "bg-amber-400 text-amber-900 text-xs font-black px-3 py-1 rounded-full",
                                  children: "أولوية هامة",
                                }),
                              ],
                            }),
                          }),
                          s.jsx("div", {
                            className: "p-5 space-y-4",
                            children: [
                              { label: "الفئة", value: "طرق وأرصفة" },
                              { label: "الموقع", value: "شارع السيوف، قليوب" },
                              { label: "المركز", value: "قليوب" },
                              { label: "درجة الخطورة", value: "متوسطة" },
                              { label: "الصور المرفقة", value: "٢ صورة" },
                              {
                                label: "الجهة المختصة",
                                value: "أعمال عامة — القليوبية",
                              },
                              {
                                label: "وقت المعالجة المتوقع",
                                value: "١–٣ أيام عمل",
                              },
                            ].map((p) =>
                              s.jsxs(
                                "div",
                                {
                                  className:
                                    "flex justify-between items-center py-2 border-b border-slate-50 last:border-0",
                                  children: [
                                    s.jsx("span", {
                                      className:
                                        "text-sm text-slate-500 font-bold",
                                      children: p.label,
                                    }),
                                    s.jsx("span", {
                                      className:
                                        "text-sm font-black text-slate-800",
                                      children: p.value,
                                    }),
                                  ],
                                },
                                p.label,
                              ),
                            ),
                          }),
                        ],
                      }),
                      s.jsxs("div", {
                        className:
                          "bg-slate-50 border border-slate-200 rounded-2xl p-4 text-sm text-slate-600",
                        children: [
                          s.jsx("p", {
                            className: "font-black text-slate-700 mb-1",
                            children: "تنبيه قبل الإرسال",
                          }),
                          s.jsx("p", {
                            className: "text-xs leading-relaxed",
                            children:
                              "ستتلقى رسالة نصية على رقمك عند قبول البلاغ وعند كل تحديث. البلاغات الكاذبة تعرض صاحبها للمساءلة القانونية وفقاً للتشريعات المصرية.",
                          }),
                        ],
                      }),
                      s.jsxs("div", {
                        className: "flex items-center gap-2 mb-2",
                        children: [
                          s.jsx("input", {
                            type: "checkbox",
                            id: "agree",
                            className: "w-4 h-4 accent-teal-600",
                            defaultChecked: !0,
                          }),
                          s.jsx("label", {
                            htmlFor: "agree",
                            className: "text-xs font-bold text-slate-600",
                            children:
                              "أقرّ بصحة المعلومات وأوافق على شروط الاستخدام",
                          }),
                        ],
                      }),
                      s.jsxs("div", {
                        className: "flex gap-3",
                        children: [
                          s.jsx("button", {
                            onClick: () => i(1),
                            className:
                              "px-6 py-4 border border-slate-200 rounded-2xl text-sm font-black text-slate-600",
                            children: "تعديل",
                          }),
                          s.jsx("button", {
                            onClick: () => b(!0),
                            className:
                              "flex-1 py-4 text-base font-black text-white bg-teal-600 hover:bg-teal-700 rounded-2xl transition-colors shadow-md shadow-teal-100",
                            children: "إرسال البلاغ نهائياً",
                          }),
                        ],
                      }),
                    ],
                  }),
              ],
            }),
            s.jsx("div", {
              className:
                "fixed bottom-0 right-0 left-0 bg-white border-t border-slate-100 px-6 py-3",
              children: s.jsxs("div", {
                className:
                  "max-w-3xl mx-auto flex items-center justify-between",
                children: [
                  s.jsxs("div", {
                    className: "flex items-center gap-2 text-xs text-slate-500",
                    children: [
                      s.jsx(wa, { className: "w-4 h-4 text-teal-600" }),
                      s.jsxs("span", {
                        children: [
                          "البلاغات الدقيقة تُحل أسرع بنسبة ",
                          s.jsx("span", {
                            className: "font-black text-teal-700",
                            children: "٤٠٪",
                          }),
                        ],
                      }),
                    ],
                  }),
                  s.jsxs("p", {
                    className: "text-xs font-black text-slate-400",
                    children: ["الخطوة ", a + 1, " من ٣"],
                  }),
                ],
              }),
            }),
          ],
        })
  );
}
const Ww = [
    {
      id: "#C-٩٠١",
      title: "حفرة في طريق المدرسة",
      location: "شارع السيوف، قليوب",
      category: "طرق وأرصفة",
      status: "in_progress",
      progress: 65,
      date: "منذ يومين",
      image: "/images/report-pothole.png",
    },
    {
      id: "#C-٨٨٩",
      title: "كسر في ماسورة مياه",
      location: "شارع الجيش، بنها",
      category: "مياه وصرف",
      status: "open",
      progress: 15,
      date: "منذ ٤ ساعات",
      image: null,
    },
    {
      id: "#C-٨٤٢",
      title: "تراكم قمامة أمام العمارة",
      location: "ميدان القناطر الخيرية",
      category: "نظافة",
      status: "resolved",
      progress: 100,
      date: "منذ ٥ أيام",
      image: null,
    },
    {
      id: "#C-٨١٧",
      title: "إضاءة طريق معطلة",
      location: "حي الزهور، شبرا الخيمة",
      category: "كهرباء",
      status: "assigned",
      progress: 35,
      date: "منذ أسبوع",
      image: null,
    },
  ],
  Iw = {
    open: {
      label: "مفتوح",
      color: "text-slate-600",
      bg: "bg-slate-100",
      dot: "bg-slate-400",
    },
    assigned: {
      label: "تم التعيين",
      color: "text-blue-700",
      bg: "bg-blue-50",
      dot: "bg-blue-500",
    },
    in_progress: {
      label: "قيد التنفيذ",
      color: "text-amber-700",
      bg: "bg-amber-50",
      dot: "bg-amber-500",
    },
    resolved: {
      label: "تم الحل",
      color: "text-emerald-700",
      bg: "bg-emerald-50",
      dot: "bg-emerald-500",
    },
  };
function e4() {
  const [a, i] = j.useState("dashboard"),
    [, c] = vn();
  return s.jsxs("div", {
    dir: "rtl",
    className: "min-h-screen bg-slate-50 flex",
    children: [
      s.jsxs("aside", {
        className:
          "w-60 bg-white border-l border-slate-100 flex flex-col shadow-sm shrink-0",
        children: [
          s.jsx("div", {
            className: "p-5 border-b border-slate-100",
            children: s.jsxs("div", {
              className: "flex items-center gap-3",
              children: [
                s.jsx("div", {
                  className:
                    "w-9 h-9 bg-teal-600 rounded-xl flex items-center justify-center text-white font-black text-sm shadow",
                  children: "CP",
                }),
                s.jsxs("div", {
                  children: [
                    s.jsx("span", {
                      className:
                        "font-black text-teal-900 block leading-tight text-sm",
                      children: "CityPulse",
                    }),
                    s.jsx("span", {
                      className: "text-[10px] text-slate-400",
                      children: "محافظة القليوبية",
                    }),
                  ],
                }),
              ],
            }),
          }),
          s.jsx("div", {
            className: "p-4 border-b border-slate-100",
            children: s.jsxs("div", {
              className: "flex items-center gap-3",
              children: [
                s.jsxs("div", {
                  className: "relative",
                  children: [
                    s.jsx("img", {
                      src: "/images/avatar-ahmed.png",
                      alt: "أحمد",
                      className:
                        "w-11 h-11 rounded-full object-cover border-2 border-teal-100",
                      onError: (o) => {
                        o.target.style.display = "none";
                      },
                    }),
                    s.jsx("div", {
                      className:
                        "absolute bottom-0 left-0 w-3 h-3 bg-emerald-400 rounded-full border-2 border-white",
                    }),
                  ],
                }),
                s.jsxs("div", {
                  children: [
                    s.jsx("p", {
                      className: "font-black text-slate-800 text-sm",
                      children: "أحمد محمد السيد",
                    }),
                    s.jsx("p", {
                      className: "text-xs text-teal-600 font-bold",
                      children: "مواطن نشط",
                    }),
                  ],
                }),
              ],
            }),
          }),
          s.jsx("nav", {
            className: "flex-1 p-3 space-y-1",
            children: [
              {
                id: "dashboard",
                icon: s.jsx(C2, { className: "w-4 h-4" }),
                label: "لوحتي",
              },
              {
                id: "reports",
                icon: s.jsx(wa, { className: "w-4 h-4" }),
                label: "بلاغاتي",
                badge: "٤",
              },
              {
                id: "map",
                icon: s.jsx(Na, { className: "w-4 h-4" }),
                label: "الخريطة",
              },
              {
                id: "alerts",
                icon: s.jsx(Tr, { className: "w-4 h-4" }),
                label: "الإشعارات",
                badge: "٣",
              },
              {
                id: "profile",
                icon: s.jsx(sp, { className: "w-4 h-4" }),
                label: "ملفي",
              },
            ].map((o) =>
              s.jsxs(
                "button",
                {
                  onClick: () => i(o.id),
                  className: `w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-bold transition-all text-right ${a === o.id ? "bg-teal-600 text-white shadow-sm" : "text-slate-600 hover:bg-slate-50"}`,
                  children: [
                    o.icon,
                    s.jsx("span", { className: "flex-1", children: o.label }),
                    o.badge &&
                      s.jsx("span", {
                        className: `text-[10px] font-black px-2 py-0.5 rounded-full ${a === o.id ? "bg-white/20 text-white" : "bg-teal-100 text-teal-700"}`,
                        children: o.badge,
                      }),
                  ],
                },
                o.id,
              ),
            ),
          }),
          s.jsx("div", {
            className: "p-3 border-t border-slate-100",
            children: s.jsxs(Ye, {
              href: "/",
              className:
                "w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-bold text-red-500 hover:bg-red-50 transition-colors",
              children: [s.jsx(z2, { className: "w-4 h-4" }), " تسجيل الخروج"],
            }),
          }),
        ],
      }),
      s.jsxs("main", {
        className: "flex-1 flex flex-col overflow-hidden",
        children: [
          s.jsxs("header", {
            className:
              "h-14 bg-white border-b border-slate-100 flex items-center justify-between px-6 shrink-0 shadow-sm",
            children: [
              s.jsxs("div", {
                children: [
                  s.jsx("h1", {
                    className: "font-black text-slate-800 text-sm",
                    children: "أهلاً، أحمد",
                  }),
                  s.jsx("p", {
                    className: "text-xs text-slate-400",
                    children: "الاثنين، ١٢ مايو ٢٠٢٥",
                  }),
                ],
              }),
              s.jsxs(Ye, {
                href: "/report",
                className:
                  "flex items-center gap-2 px-4 py-2 text-sm font-black text-white bg-teal-600 hover:bg-teal-700 rounded-xl transition-colors shadow-sm",
                children: [s.jsx(cr, { className: "w-4 h-4" }), " بلاغ جديد"],
              }),
            ],
          }),
          s.jsxs("div", {
            className: "flex-1 overflow-y-auto p-6 space-y-6",
            children: [
              s.jsx("div", {
                className: "grid grid-cols-3 gap-4",
                children: [
                  {
                    label: "إجمالي بلاغاتي",
                    value: "١١",
                    icon: s.jsx(wa, { className: "w-5 h-5" }),
                    color: "bg-blue-50 text-blue-600",
                  },
                  {
                    label: "تم حلها",
                    value: "٨",
                    icon: s.jsx(xn, { className: "w-5 h-5" }),
                    color: "bg-emerald-50 text-emerald-600",
                  },
                  {
                    label: "قيد المعالجة",
                    value: "٢",
                    icon: s.jsx(pn, { className: "w-5 h-5" }),
                    color: "bg-amber-50 text-amber-600",
                  },
                ].map((o, d) =>
                  s.jsxs(
                    "div",
                    {
                      className:
                        "bg-white rounded-2xl p-5 border border-slate-100 shadow-sm",
                      children: [
                        s.jsx("div", {
                          className: `w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${o.color}`,
                          children: o.icon,
                        }),
                        s.jsx("div", {
                          className: "text-3xl font-black text-slate-800",
                          children: o.value,
                        }),
                        s.jsx("div", {
                          className: "text-xs font-black text-slate-500 mt-1",
                          children: o.label,
                        }),
                      ],
                    },
                    d,
                  ),
                ),
              }),
              s.jsxs("div", {
                className:
                  "bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden",
                children: [
                  s.jsxs("div", {
                    className:
                      "p-5 border-b border-slate-50 flex justify-between items-center",
                    children: [
                      s.jsx("h2", {
                        className: "font-black text-slate-800",
                        children: "بلاغاتي الأخيرة",
                      }),
                      s.jsxs("button", {
                        className:
                          "text-xs font-black text-teal-600 hover:text-teal-700 flex items-center gap-1",
                        children: [
                          "عرض الكل ",
                          s.jsx(As, { className: "w-3.5 h-3.5" }),
                        ],
                      }),
                    ],
                  }),
                  s.jsx("div", {
                    className: "divide-y divide-slate-50",
                    children: Ww.map((o) => {
                      const d = Iw[o.status];
                      return s.jsx(
                        "div",
                        {
                          onClick: () => c("/reports/1"),
                          className:
                            "p-4 hover:bg-slate-50 transition-colors cursor-pointer",
                          children: s.jsxs("div", {
                            className: "flex items-center gap-3",
                            children: [
                              o.image
                                ? s.jsx("img", {
                                    src: o.image,
                                    alt: "",
                                    className:
                                      "w-14 h-14 rounded-xl object-cover shrink-0 border border-slate-100",
                                    onError: (f) => {
                                      ((f.target.className =
                                        "w-14 h-14 rounded-xl bg-slate-100 shrink-0"),
                                        (f.target.src = ""));
                                    },
                                  })
                                : s.jsx("div", {
                                    className:
                                      "w-14 h-14 rounded-xl bg-slate-100 flex items-center justify-center shrink-0",
                                    children: s.jsx(Ar, {
                                      className: "w-5 h-5 text-slate-400",
                                    }),
                                  }),
                              s.jsxs("div", {
                                className: "flex-1 min-w-0",
                                children: [
                                  s.jsxs("div", {
                                    className:
                                      "flex items-center justify-between gap-2 mb-1",
                                    children: [
                                      s.jsxs("div", {
                                        className: "min-w-0",
                                        children: [
                                          s.jsx("span", {
                                            className:
                                              "text-[10px] text-slate-400 font-black ml-1",
                                            children: o.id,
                                          }),
                                          s.jsx("p", {
                                            className:
                                              "font-black text-sm text-slate-800 truncate",
                                            children: o.title,
                                          }),
                                        ],
                                      }),
                                      s.jsxs("span", {
                                        className: `shrink-0 flex items-center gap-1 text-[10px] font-black px-2.5 py-1 rounded-full ${d.bg} ${d.color}`,
                                        children: [
                                          s.jsx("span", {
                                            className: `w-1.5 h-1.5 rounded-full ${d.dot}`,
                                          }),
                                          d.label,
                                        ],
                                      }),
                                    ],
                                  }),
                                  s.jsxs("p", {
                                    className:
                                      "text-xs text-slate-400 flex items-center gap-1 mb-2",
                                    children: [
                                      s.jsx(Na, { className: "w-3 h-3" }),
                                      o.location,
                                    ],
                                  }),
                                  s.jsxs("div", {
                                    className: "flex items-center gap-2",
                                    children: [
                                      s.jsx("div", {
                                        className:
                                          "flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden",
                                        children: s.jsx("div", {
                                          className: `h-full rounded-full ${o.status === "resolved" ? "bg-emerald-500" : o.status === "in_progress" ? "bg-amber-500" : o.status === "assigned" ? "bg-blue-500" : "bg-slate-300"}`,
                                          style: { width: `${o.progress}%` },
                                        }),
                                      }),
                                      s.jsxs("span", {
                                        className:
                                          "text-[10px] font-black text-slate-500 shrink-0",
                                        children: [o.progress, "٪"],
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                            ],
                          }),
                        },
                        o.id,
                      );
                    }),
                  }),
                ],
              }),
              s.jsxs("div", {
                className: "grid grid-cols-2 gap-4",
                children: [
                  s.jsxs(Ye, {
                    href: "/report",
                    className:
                      "block bg-teal-600 hover:bg-teal-700 text-white rounded-2xl p-5 text-right transition-colors shadow-sm",
                    children: [
                      s.jsx(cr, { className: "w-6 h-6 mb-2" }),
                      s.jsx("p", {
                        className: "font-black",
                        children: "بلاغ جديد",
                      }),
                      s.jsx("p", {
                        className: "text-teal-200 text-xs mt-0.5",
                        children: "سجّل مشكلة في منطقتك",
                      }),
                    ],
                  }),
                  s.jsxs(Ye, {
                    href: "/heatmap",
                    className:
                      "block bg-white hover:bg-slate-50 border border-slate-200 rounded-2xl p-5 text-right transition-colors shadow-sm",
                    children: [
                      s.jsx(Na, { className: "w-6 h-6 mb-2 text-teal-600" }),
                      s.jsx("p", {
                        className: "font-black text-slate-800",
                        children: "خريطة البلاغات",
                      }),
                      s.jsx("p", {
                        className: "text-slate-400 text-xs mt-0.5",
                        children: "شاهد بلاغات منطقتك",
                      }),
                    ],
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
    ],
  });
}
const Im = [
    {
      status: "تم الإغلاق",
      time: "١٢ مايو ٢٠٢٥، ٢:٣٠ م",
      desc: "تم إغلاق البلاغ بعد التحقق من الإصلاح وتقييم المواطن.",
      actor: "النظام",
      dot: "bg-emerald-500",
      line: "bg-emerald-200",
      done: !0,
    },
    {
      status: "تم الإصلاح",
      time: "١١ مايو ٢٠٢٥، ١١:٠٠ ص",
      desc: "أنهى الفريق أعمال الإصلاح ورفع تقرير الإتمام.",
      actor: "م. عمرو فاروق",
      dot: "bg-teal-500",
      line: "bg-teal-200",
      done: !0,
    },
    {
      status: "قيد التنفيذ",
      time: "١٠ مايو ٢٠٢٥، ٨:٠٠ ص",
      desc: "بدأ فريق الطرق أعمال الإصلاح في الموقع.",
      actor: "فريق الطرق — قليوب",
      dot: "bg-blue-500",
      line: "bg-blue-200",
      done: !0,
    },
    {
      status: "تم التعيين",
      time: "٩ مايو ٢٠٢٥، ٢:١٥ م",
      desc: "تم تعيين البلاغ لفريق الطرق والأرصفة في مركز قليوب.",
      actor: "م. خالد حسن",
      dot: "bg-purple-500",
      line: "bg-purple-200",
      done: !0,
    },
    {
      status: "مفتوح",
      time: "٨ مايو ٢٠٢٥، ٦:٤٢ م",
      desc: "تم استلام البلاغ وتسجيله في النظام بنجاح.",
      actor: "النظام",
      dot: "bg-slate-400",
      line: "bg-slate-200",
      done: !0,
    },
  ],
  t4 = [
    {
      sender: "أحمد محمد",
      role: "مواطن",
      avatar: "أم",
      text: "الحفرة كبيرة جداً وتعرّض لها أكثر من عجلة سيارة — أرجو التدخل السريع.",
      time: "٨ مايو، ٦:٤٥ م",
      isAdmin: !1,
    },
    {
      sender: "م. خالد حسن",
      role: "مدير العمليات",
      avatar: "خح",
      text: "شكراً على الإبلاغ. سنرسل فريقاً خلال ٢٤ ساعة لمعاينة الموقع.",
      time: "٨ مايو، ٧:١٥ م",
      isAdmin: !0,
    },
    {
      sender: "م. عمرو فاروق",
      role: "رئيس فريق الطرق",
      avatar: "عف",
      text: "زرنا الموقع وأكدنا وجود الحفرة. سنبدأ الإصلاح غداً صباحاً.",
      time: "٩ مايو، ٣:٣٠ م",
      isAdmin: !0,
    },
    {
      sender: "أحمد محمد",
      role: "مواطن",
      avatar: "أم",
      text: "ممتاز! أتمنى أن يكون الإصلاح دائماً هذه المرة، الحفرة موجودة من ٣ أشهر.",
      time: "٩ مايو، ٤:٠٠ م",
      isAdmin: !1,
    },
  ];
function l4() {
  const [a, i] = j.useState(""),
    [c, o] = j.useState(4);
  return (
    vn(),
    s.jsxs("div", {
      dir: "rtl",
      className: "min-h-screen bg-slate-50",
      children: [
        s.jsx("header", {
          className:
            "bg-white border-b border-slate-100 sticky top-0 z-20 shadow-sm",
          children: s.jsxs("div", {
            className: "max-w-5xl mx-auto px-4 h-16 flex items-center gap-4",
            children: [
              s.jsx("button", {
                onClick: () => window.history.back(),
                className:
                  "w-9 h-9 flex items-center justify-center text-slate-500 hover:text-slate-800 bg-slate-100 rounded-xl hover:bg-slate-200 transition-colors",
                children: s.jsx(As, { className: "w-5 h-5" }),
              }),
              s.jsxs("div", {
                className: "flex-1",
                children: [
                  s.jsxs("div", {
                    className:
                      "flex items-center gap-2 text-xs text-slate-400 font-bold mb-0.5",
                    children: [
                      s.jsx("span", { children: "بلاغاتي" }),
                      s.jsx(As, { className: "w-3 h-3" }),
                      s.jsx("span", {
                        className: "text-slate-700",
                        children: "#C-٩٠١",
                      }),
                    ],
                  }),
                  s.jsx("h1", {
                    className: "font-black text-slate-900 text-sm",
                    children: "حفرة في طريق المدرسة — شارع السيوف، قليوب",
                  }),
                ],
              }),
              s.jsxs("div", {
                className: "flex items-center gap-2",
                children: [
                  s.jsx("button", {
                    className:
                      "w-9 h-9 flex items-center justify-center text-slate-400 hover:text-slate-700 bg-slate-100 rounded-xl hover:bg-slate-200 transition-colors",
                    children: s.jsx(F2, { className: "w-4 h-4" }),
                  }),
                  s.jsx("button", {
                    className:
                      "w-9 h-9 flex items-center justify-center text-slate-400 hover:text-slate-700 bg-slate-100 rounded-xl hover:bg-slate-200 transition-colors",
                    children: s.jsx(hn, { className: "w-4 h-4" }),
                  }),
                ],
              }),
            ],
          }),
        }),
        s.jsx("div", {
          className: "max-w-5xl mx-auto px-4 py-6",
          children: s.jsxs("div", {
            className: "grid grid-cols-1 lg:grid-cols-3 gap-6",
            children: [
              s.jsxs("div", {
                className: "lg:col-span-2 space-y-5",
                children: [
                  s.jsxs("div", {
                    className:
                      "bg-emerald-600 rounded-2xl p-5 text-white flex items-center justify-between",
                    children: [
                      s.jsxs("div", {
                        className: "flex items-center gap-3",
                        children: [
                          s.jsx("div", {
                            className:
                              "w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center",
                            children: s.jsx(xn, { className: "w-6 h-6" }),
                          }),
                          s.jsxs("div", {
                            children: [
                              s.jsx("p", {
                                className: "text-emerald-100 text-xs font-bold",
                                children: "حالة البلاغ",
                              }),
                              s.jsx("p", {
                                className: "font-black text-xl",
                                children: "تم الحل وإغلاق البلاغ",
                              }),
                            ],
                          }),
                        ],
                      }),
                      s.jsxs("div", {
                        className: "text-left",
                        children: [
                          s.jsx("p", {
                            className: "text-emerald-200 text-xs",
                            children: "وقت الإصلاح",
                          }),
                          s.jsx("p", {
                            className: "font-black text-lg",
                            children: "٣ أيام",
                          }),
                        ],
                      }),
                    ],
                  }),
                  s.jsx("div", {
                    className:
                      "bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden",
                    children: s.jsxs("div", {
                      className:
                        "relative h-48 bg-gradient-to-br from-slate-800 to-teal-900",
                      children: [
                        s.jsxs("svg", {
                          viewBox: "0 0 640 192",
                          className: "w-full h-full",
                          style: {
                            background:
                              "linear-gradient(135deg,#1e293b,#0f2027)",
                          },
                          children: [
                            s.jsxs("g", {
                              opacity: "0.15",
                              children: [
                                [
                                  64, 128, 192, 256, 320, 384, 448, 512, 576,
                                ].map((d) =>
                                  s.jsx(
                                    "line",
                                    {
                                      x1: d,
                                      y1: "0",
                                      x2: d,
                                      y2: "192",
                                      stroke: "white",
                                      strokeWidth: "0.5",
                                    },
                                    d,
                                  ),
                                ),
                                [32, 64, 96, 128, 160].map((d) =>
                                  s.jsx(
                                    "line",
                                    {
                                      x1: "0",
                                      y1: d,
                                      x2: "640",
                                      y2: d,
                                      stroke: "white",
                                      strokeWidth: "0.5",
                                    },
                                    d,
                                  ),
                                ),
                              ],
                            }),
                            s.jsx("rect", {
                              x: "80",
                              y: "40",
                              width: "120",
                              height: "50",
                              fill: "#0f2027",
                              rx: "3",
                            }),
                            s.jsx("rect", {
                              x: "240",
                              y: "20",
                              width: "80",
                              height: "35",
                              fill: "#0f2027",
                              rx: "3",
                            }),
                            s.jsx("rect", {
                              x: "380",
                              y: "60",
                              width: "100",
                              height: "70",
                              fill: "#0f2027",
                              rx: "3",
                            }),
                            s.jsx("rect", {
                              x: "500",
                              y: "30",
                              width: "80",
                              height: "45",
                              fill: "#0f2027",
                              rx: "3",
                            }),
                            s.jsx("line", {
                              x1: "0",
                              y1: "96",
                              x2: "640",
                              y2: "96",
                              stroke: "#334155",
                              strokeWidth: "8",
                            }),
                            s.jsx("line", {
                              x1: "320",
                              y1: "0",
                              x2: "320",
                              y2: "192",
                              stroke: "#334155",
                              strokeWidth: "6",
                            }),
                            s.jsx("circle", {
                              cx: "320",
                              cy: "96",
                              r: "18",
                              fill: "#ef4444",
                              opacity: "0.9",
                            }),
                            s.jsx("circle", {
                              cx: "320",
                              cy: "96",
                              r: "28",
                              fill: "#ef4444",
                              opacity: "0.2",
                            }),
                            s.jsx("circle", {
                              cx: "320",
                              cy: "96",
                              r: "40",
                              fill: "#ef4444",
                              opacity: "0.08",
                            }),
                            s.jsx("text", {
                              x: "320",
                              y: "100",
                              textAnchor: "middle",
                              fill: "white",
                              fontSize: "10",
                              fontWeight: "bold",
                              children: "!",
                            }),
                          ],
                        }),
                        s.jsxs("div", {
                          className:
                            "absolute bottom-3 right-3 bg-white/90 rounded-xl px-3 py-1.5 text-xs font-black text-slate-700 flex items-center gap-1 shadow",
                          children: [
                            s.jsx(tp, { className: "w-3 h-3 text-teal-600" }),
                            "شارع السيوف، قليوب",
                          ],
                        }),
                        s.jsxs("button", {
                          className:
                            "absolute top-3 left-3 bg-white/90 rounded-xl px-3 py-1.5 text-xs font-black text-teal-700 flex items-center gap-1 shadow hover:bg-white transition-colors",
                          children: [
                            s.jsx(Na, { className: "w-3 h-3" }),
                            " فتح الخريطة",
                          ],
                        }),
                      ],
                    }),
                  }),
                  s.jsxs("div", {
                    className:
                      "bg-white rounded-2xl border border-slate-100 shadow-sm p-5",
                    children: [
                      s.jsxs("h2", {
                        className:
                          "font-black text-slate-800 mb-4 flex items-center gap-2",
                        children: [
                          s.jsx(Ar, { className: "w-4 h-4 text-slate-500" }),
                          " صور البلاغ",
                        ],
                      }),
                      s.jsxs("div", {
                        className: "grid grid-cols-2 gap-3",
                        children: [
                          s.jsx("div", {
                            className:
                              "aspect-video rounded-xl overflow-hidden bg-slate-100",
                            children: s.jsx("img", {
                              src: "/images/report-pothole.png",
                              alt: "صورة الحفرة",
                              className: "w-full h-full object-cover",
                              onError: (d) => {
                                const f = d.target;
                                f.style.display = "none";
                                const x = f.parentElement;
                                x &&
                                  (x.classList.add(
                                    "flex",
                                    "items-center",
                                    "justify-center",
                                    "bg-slate-100",
                                  ),
                                  (x.innerHTML = `<div class="text-center text-slate-400"><svg xmlns='http://www.w3.org/2000/svg' class='w-8 h-8 mx-auto mb-1' fill='none' viewBox='0 0 24 24' stroke='currentColor'><path stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z' /></svg><p class='text-xs font-bold'>صورة البلاغ</p></div>`));
                              },
                            }),
                          }),
                          s.jsx("div", {
                            className:
                              "aspect-video rounded-xl bg-gradient-to-br from-slate-700 to-slate-900 flex items-center justify-center",
                            children: s.jsxs("div", {
                              className: "text-center text-slate-400",
                              children: [
                                s.jsx(ep, {
                                  className: "w-8 h-8 mx-auto mb-1",
                                }),
                                s.jsx("p", {
                                  className: "text-xs font-bold",
                                  children: "صورة ٢",
                                }),
                              ],
                            }),
                          }),
                        ],
                      }),
                    ],
                  }),
                  s.jsxs("div", {
                    className:
                      "bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden",
                    children: [
                      s.jsxs("div", {
                        className:
                          "p-5 border-b border-slate-50 flex items-center gap-2",
                        children: [
                          s.jsx(Y2, { className: "w-4 h-4 text-slate-500" }),
                          s.jsx("h2", {
                            className: "font-black text-slate-800",
                            children: "المحادثة",
                          }),
                          s.jsx("span", {
                            className:
                              "text-xs bg-slate-100 text-slate-600 font-black px-2 py-0.5 rounded-full",
                            children: "٤",
                          }),
                        ],
                      }),
                      s.jsx("div", {
                        className: "p-5 space-y-4 max-h-64 overflow-y-auto",
                        children: t4.map((d, f) =>
                          s.jsxs(
                            "div",
                            {
                              className: `flex gap-3 ${d.isAdmin ? "" : "flex-row-reverse"}`,
                              children: [
                                s.jsx("div", {
                                  className: `w-8 h-8 rounded-xl flex items-center justify-center text-[10px] font-black shrink-0 ${d.isAdmin ? "bg-teal-100 text-teal-700" : "bg-blue-100 text-blue-700"}`,
                                  children: d.avatar,
                                }),
                                s.jsxs("div", {
                                  className: `flex-1 ${d.isAdmin ? "" : "items-end flex flex-col"}`,
                                  children: [
                                    s.jsxs("div", {
                                      className: "flex items-center gap-2 mb-1",
                                      children: [
                                        s.jsx("span", {
                                          className:
                                            "text-xs font-black text-slate-700",
                                          children: d.sender,
                                        }),
                                        s.jsx("span", {
                                          className:
                                            "text-[10px] text-slate-400",
                                          children: d.role,
                                        }),
                                        s.jsx("span", {
                                          className:
                                            "text-[10px] text-slate-300 mr-auto",
                                          children: d.time,
                                        }),
                                      ],
                                    }),
                                    s.jsx("div", {
                                      className: `rounded-2xl px-4 py-3 text-sm leading-relaxed ${d.isAdmin ? "bg-slate-50 text-slate-700 rounded-tr-sm" : "bg-teal-600 text-white rounded-tl-sm"}`,
                                      children: d.text,
                                    }),
                                  ],
                                }),
                              ],
                            },
                            f,
                          ),
                        ),
                      }),
                      s.jsx("div", {
                        className: "p-4 border-t border-slate-50",
                        children: s.jsxs("div", {
                          className: "flex gap-2",
                          children: [
                            s.jsx("input", {
                              value: a,
                              onChange: (d) => i(d.target.value),
                              placeholder: "اكتب رسالة أو استفساراً...",
                              className:
                                "flex-1 border border-slate-200 rounded-xl px-4 py-2.5 text-sm font-bold text-slate-700 placeholder-slate-400 focus:outline-none focus:border-teal-500",
                            }),
                            s.jsx("button", {
                              className:
                                "w-10 h-10 bg-teal-600 hover:bg-teal-700 rounded-xl flex items-center justify-center text-white transition-colors shrink-0",
                              children: s.jsx(P2, {
                                className: "w-4 h-4 rotate-180",
                              }),
                            }),
                          ],
                        }),
                      }),
                    ],
                  }),
                  s.jsxs("div", {
                    className:
                      "bg-gradient-to-l from-teal-50 to-emerald-50 border-2 border-teal-100 rounded-2xl p-6 text-center",
                    children: [
                      s.jsx(xn, {
                        className: "w-10 h-10 text-emerald-500 mx-auto mb-3",
                      }),
                      s.jsx("h2", {
                        className: "font-black text-slate-800 mb-1",
                        children: "قيّم تجربتك",
                      }),
                      s.jsx("p", {
                        className: "text-slate-500 text-sm mb-4",
                        children: "مدى رضاك عن جودة وسرعة الاستجابة؟",
                      }),
                      s.jsx("div", {
                        className: "flex justify-center gap-2 mb-4",
                        children: [1, 2, 3, 4, 5].map((d) =>
                          s.jsx(
                            "button",
                            {
                              onClick: () => o(d),
                              className: "transition-transform hover:scale-110",
                              children: s.jsx(or, {
                                className: `w-8 h-8 transition-colors ${d <= c ? "text-amber-400 fill-amber-400" : "text-slate-200 fill-slate-100"}`,
                              }),
                            },
                            d,
                          ),
                        ),
                      }),
                      s.jsx("button", {
                        className:
                          "px-8 py-2.5 bg-teal-600 text-white font-black text-sm rounded-xl hover:bg-teal-700 transition-colors",
                        children: "إرسال التقييم",
                      }),
                    ],
                  }),
                ],
              }),
              s.jsxs("div", {
                className: "space-y-5",
                children: [
                  s.jsxs("div", {
                    className:
                      "bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden",
                    children: [
                      s.jsx("div", {
                        className: "bg-slate-800 p-4 text-white",
                        children: s.jsxs("div", {
                          className: "flex justify-between items-start",
                          children: [
                            s.jsxs("div", {
                              children: [
                                s.jsx("p", {
                                  className:
                                    "text-slate-400 text-[10px] font-bold mb-0.5",
                                  children: "رقم البلاغ",
                                }),
                                s.jsx("p", {
                                  className: "font-black text-lg",
                                  children: "#C-٩٠١",
                                }),
                              ],
                            }),
                            s.jsx("span", {
                              className:
                                "bg-emerald-500 text-white text-[10px] font-black px-2.5 py-1 rounded-full",
                              children: "مغلق",
                            }),
                          ],
                        }),
                      }),
                      s.jsx("div", {
                        className: "p-4 space-y-3",
                        children: [
                          {
                            label: "الفئة",
                            value: "طرق وأرصفة",
                            icon: s.jsx(rr, {
                              className: "w-3.5 h-3.5 text-orange-500",
                            }),
                          },
                          {
                            label: "الأولوية",
                            value: "هام",
                            icon: s.jsx(E2, {
                              className: "w-3.5 h-3.5 text-amber-500",
                            }),
                          },
                          {
                            label: "الموقع",
                            value: "شارع السيوف، قليوب",
                            icon: s.jsx(Na, {
                              className: "w-3.5 h-3.5 text-teal-600",
                            }),
                          },
                          {
                            label: "تاريخ الرفع",
                            value: "٨ مايو ٢٠٢٥",
                            icon: s.jsx(s2, {
                              className: "w-3.5 h-3.5 text-slate-400",
                            }),
                          },
                          {
                            label: "وقت الحل",
                            value: "٣ أيام",
                            icon: s.jsx(pn, {
                              className: "w-3.5 h-3.5 text-blue-500",
                            }),
                          },
                        ].map((d) =>
                          s.jsxs(
                            "div",
                            {
                              className:
                                "flex items-center gap-3 py-2 border-b border-slate-50 last:border-0",
                              children: [
                                s.jsx("div", {
                                  className: "w-6 flex justify-center",
                                  children: d.icon,
                                }),
                                s.jsx("span", {
                                  className:
                                    "text-xs text-slate-400 font-bold flex-1",
                                  children: d.label,
                                }),
                                s.jsx("span", {
                                  className:
                                    "text-xs font-black text-slate-800",
                                  children: d.value,
                                }),
                              ],
                            },
                            d.label,
                          ),
                        ),
                      }),
                    ],
                  }),
                  s.jsxs("div", {
                    className:
                      "bg-white rounded-2xl border border-slate-100 shadow-sm p-5",
                    children: [
                      s.jsxs("h3", {
                        className:
                          "font-black text-slate-800 text-sm mb-4 flex items-center gap-2",
                        children: [
                          s.jsx(Cs, { className: "w-4 h-4 text-slate-400" }),
                          " الفريق المعيّن",
                        ],
                      }),
                      s.jsxs("div", {
                        className: "flex items-center gap-3 mb-4",
                        children: [
                          s.jsx("div", {
                            className:
                              "w-11 h-11 rounded-xl bg-orange-100 flex items-center justify-center text-orange-600",
                            children: s.jsx(rr, { className: "w-5 h-5" }),
                          }),
                          s.jsxs("div", {
                            children: [
                              s.jsx("p", {
                                className: "font-black text-slate-800 text-sm",
                                children: "فريق الطرق والأرصفة",
                              }),
                              s.jsx("p", {
                                className: "text-xs text-slate-400",
                                children: "مركز قليوب",
                              }),
                            ],
                          }),
                        ],
                      }),
                      s.jsxs("div", {
                        className:
                          "flex items-center gap-3 p-3 bg-slate-50 rounded-xl",
                        children: [
                          s.jsx("div", {
                            className:
                              "w-9 h-9 rounded-xl bg-teal-100 flex items-center justify-center text-teal-700 font-black text-xs",
                            children: "عف",
                          }),
                          s.jsxs("div", {
                            className: "flex-1",
                            children: [
                              s.jsx("p", {
                                className: "text-sm font-black text-slate-800",
                                children: "م. عمرو فاروق",
                              }),
                              s.jsx("p", {
                                className: "text-xs text-slate-400",
                                children: "رئيس الفريق",
                              }),
                            ],
                          }),
                          s.jsxs("div", {
                            className: "flex items-center gap-1",
                            children: [
                              s.jsx(or, {
                                className:
                                  "w-3 h-3 text-amber-400 fill-amber-400",
                              }),
                              s.jsx("span", {
                                className: "text-xs font-black text-slate-600",
                                children: "٤.٨",
                              }),
                            ],
                          }),
                        ],
                      }),
                    ],
                  }),
                  s.jsxs("div", {
                    className:
                      "bg-white rounded-2xl border border-slate-100 shadow-sm p-5",
                    children: [
                      s.jsxs("h3", {
                        className:
                          "font-black text-slate-800 text-sm mb-5 flex items-center gap-2",
                        children: [
                          s.jsx(pn, { className: "w-4 h-4 text-slate-400" }),
                          " سجل المراحل",
                        ],
                      }),
                      s.jsx("div", {
                        className: "space-y-0",
                        children: Im.map((d, f) =>
                          s.jsxs(
                            "div",
                            {
                              className: "flex gap-3",
                              children: [
                                s.jsxs("div", {
                                  className: "flex flex-col items-center",
                                  children: [
                                    s.jsx("div", {
                                      className: `w-3 h-3 rounded-full shrink-0 mt-1 border-2 border-white shadow-sm z-10 ${d.dot}`,
                                    }),
                                    f < Im.length - 1 &&
                                      s.jsx("div", {
                                        className: `w-0.5 flex-1 mt-1 ${d.line}`,
                                        style: { minHeight: "40px" },
                                      }),
                                  ],
                                }),
                                s.jsxs("div", {
                                  className: "pb-5",
                                  children: [
                                    s.jsx("p", {
                                      className:
                                        "text-xs font-black text-slate-800",
                                      children: d.status,
                                    }),
                                    s.jsx("p", {
                                      className:
                                        "text-[10px] text-slate-400 mt-0.5",
                                      children: d.time,
                                    }),
                                    s.jsx("p", {
                                      className:
                                        "text-[10px] text-slate-500 mt-1 leading-relaxed",
                                      children: d.desc,
                                    }),
                                    s.jsx("p", {
                                      className:
                                        "text-[10px] text-teal-600 font-bold mt-0.5",
                                      children: d.actor,
                                    }),
                                  ],
                                }),
                              ],
                            },
                            f,
                          ),
                        ),
                      }),
                    ],
                  }),
                ],
              }),
            ],
          }),
        }),
      ],
    })
  );
}
const lr = [
  {
    name: "شبرا الخيمة",
    reports: 342,
    risk: 92,
    riskLabel: "حرج",
    color: "#ef4444",
    glow: "#ef444430",
    cx: 185,
    cy: 88,
    rx: 62,
    ry: 52,
    polygon:
      "110,30 248,25 272,68 278,115 258,148 205,158 155,152 120,128 100,85 105,48",
  },
  {
    name: "الخانكة",
    reports: 198,
    risk: 71,
    riskLabel: "عالٍ",
    color: "#f97316",
    glow: "#f9731625",
    cx: 360,
    cy: 82,
    rx: 58,
    ry: 48,
    polygon:
      "268,28 405,22 435,62 440,112 418,148 358,155 268,150 260,110 265,65",
  },
  {
    name: "بنها",
    reports: 156,
    risk: 58,
    riskLabel: "متوسط",
    color: "#f59e0b",
    glow: "#f59e0b20",
    cx: 185,
    cy: 215,
    rx: 55,
    ry: 48,
    polygon:
      "115,168 250,162 272,195 275,248 252,282 205,292 160,288 128,265 112,232 112,195",
  },
  {
    name: "قليوب",
    reports: 134,
    risk: 45,
    riskLabel: "متوسط",
    color: "#eab308",
    glow: "#eab30820",
    cx: 348,
    cy: 218,
    rx: 60,
    ry: 48,
    polygon:
      "272,162 395,158 448,175 455,228 438,272 378,285 278,282 268,245 268,198",
  },
  {
    name: "القناطر الخيرية",
    reports: 89,
    risk: 28,
    riskLabel: "منخفض",
    color: "#22c55e",
    glow: "#22c55e18",
    cx: 175,
    cy: 348,
    rx: 58,
    ry: 50,
    polygon:
      "105,302 232,298 265,308 268,355 245,398 195,412 148,408 112,385 98,348 100,315",
  },
  {
    name: "كفر شكر",
    reports: 67,
    risk: 22,
    riskLabel: "آمن",
    color: "#16a34a",
    glow: "#16a34a18",
    cx: 68,
    cy: 358,
    rx: 45,
    ry: 42,
    polygon:
      "28,318 98,312 118,338 122,385 100,418 62,428 30,412 18,375 22,338",
  },
  {
    name: "طوخ",
    reports: 45,
    risk: 15,
    riskLabel: "آمن",
    color: "#15803d",
    glow: "#15803d15",
    cx: 372,
    cy: 348,
    rx: 58,
    ry: 48,
    polygon:
      "268,302 402,298 448,312 455,360 432,398 378,412 280,405 265,362 265,318",
  },
];
function a4() {
  const [a, i] = j.useState("الكل"),
    [c, o] = j.useState(lr[0]),
    [d, f] = j.useState("heat"),
    [x, b] = j.useState(!0);
  vn();
  const p = ["الكل", "طرق", "مياه", "كهرباء", "نظافة"];
  return s.jsxs("div", {
    dir: "rtl",
    className: "flex h-screen bg-slate-100 overflow-hidden",
    children: [
      s.jsxs("aside", {
        className: `${x ? "w-64" : "w-0"} transition-all duration-300 overflow-hidden bg-slate-900 text-slate-300 flex flex-col h-full shrink-0`,
        children: [
          s.jsxs("div", {
            className:
              "p-5 flex items-center gap-3 border-b border-slate-800 shrink-0",
            children: [
              s.jsx("div", {
                className:
                  "w-8 h-8 bg-teal-600 rounded-lg flex items-center justify-center text-white font-black",
                children: "CP",
              }),
              s.jsxs("div", {
                children: [
                  s.jsx("h1", {
                    className: "font-black text-white text-sm leading-none",
                    children: "CityPulse",
                  }),
                  s.jsx("p", {
                    className: "text-[10px] text-slate-400 mt-0.5",
                    children: "محافظة القليوبية",
                  }),
                ],
              }),
            ],
          }),
          s.jsx("nav", {
            className: "flex-1 py-4 px-3 space-y-1 overflow-y-auto",
            children: [
              {
                icon: s.jsx(Cr, { className: "w-4 h-4" }),
                label: "نظرة عامة",
                href: "/admin",
              },
              {
                icon: s.jsx(wa, { className: "w-4 h-4" }),
                label: "إدارة البلاغات",
                badge: "١٢",
                href: "/admin",
              },
              {
                icon: s.jsx(Hu, { className: "w-4 h-4" }),
                label: "الخريطة الحرارية",
                active: !0,
                href: "/heatmap",
              },
              {
                icon: s.jsx(Cs, { className: "w-4 h-4" }),
                label: "فرق العمل",
                href: "/admin/teams",
              },
              {
                icon: s.jsx(qu, { className: "w-4 h-4" }),
                label: "الإعدادات",
                href: "#",
              },
            ].map((h, v) =>
              s.jsxs(
                Ye,
                {
                  href: h.href,
                  className: `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-bold transition-colors ${h.active ? "bg-teal-600/20 text-teal-400" : "hover:bg-slate-800 hover:text-white"}`,
                  children: [
                    h.icon,
                    s.jsx("span", { className: "flex-1", children: h.label }),
                    h.badge &&
                      s.jsx("span", {
                        className:
                          "bg-teal-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full",
                        children: h.badge,
                      }),
                  ],
                },
                v,
              ),
            ),
          }),
          s.jsx("div", {
            className: "p-4 border-t border-slate-800 shrink-0",
            children: s.jsxs("div", {
              className: "flex items-center gap-3",
              children: [
                s.jsx("div", {
                  className:
                    "w-9 h-9 rounded-full bg-slate-700 flex items-center justify-center text-sm font-black text-slate-300",
                  children: "خ",
                }),
                s.jsxs("div", {
                  children: [
                    s.jsx("p", {
                      className: "text-sm font-black text-white",
                      children: "م. خالد حسن",
                    }),
                    s.jsx("p", {
                      className: "text-xs text-teal-400",
                      children: "مدير غرفة العمليات",
                    }),
                  ],
                }),
              ],
            }),
          }),
        ],
      }),
      s.jsxs("main", {
        className: "flex-1 flex flex-col overflow-hidden",
        children: [
          s.jsxs("header", {
            className:
              "h-14 bg-white border-b border-slate-200 flex items-center justify-between px-5 z-10 shrink-0 shadow-sm",
            children: [
              s.jsxs("div", {
                className: "flex items-center gap-3",
                children: [
                  s.jsx("button", {
                    onClick: () => b(!x),
                    className:
                      "text-slate-500 hover:text-slate-800 p-1.5 rounded-lg hover:bg-slate-100 transition-colors",
                    children: s.jsx(k2, { className: "w-5 h-5" }),
                  }),
                  s.jsx("div", { className: "h-5 w-px bg-slate-200" }),
                  s.jsx("h2", {
                    className: "font-black text-slate-800 text-sm",
                    children: "الخريطة الحرارية للبلاغات",
                  }),
                  s.jsx("span", {
                    className:
                      "text-xs font-bold text-slate-400 hidden sm:inline",
                    children: "— محافظة القليوبية",
                  }),
                ],
              }),
              s.jsxs("div", {
                className: "flex items-center gap-3",
                children: [
                  s.jsxs("div", {
                    className: "relative hidden md:block",
                    children: [
                      s.jsx(Lu, {
                        className:
                          "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400",
                      }),
                      s.jsx("input", {
                        placeholder: "ابحث عن منطقة...",
                        className:
                          "bg-slate-100 border border-slate-200 rounded-xl px-4 py-2 pr-9 text-sm font-bold text-slate-700 placeholder-slate-400 focus:outline-none focus:border-teal-500 w-44",
                      }),
                    ],
                  }),
                  s.jsxs("button", {
                    className:
                      "relative text-slate-500 hover:text-slate-800 p-1.5",
                    children: [
                      s.jsx(Tr, { className: "w-5 h-5" }),
                      s.jsx("span", {
                        className:
                          "absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full border border-white",
                      }),
                    ],
                  }),
                  s.jsx("span", {
                    className:
                      "text-xs font-bold text-slate-500 hidden lg:inline",
                    children: "الاثنين، ١٢ مايو ٢٠٢٥",
                  }),
                ],
              }),
            ],
          }),
          s.jsxs("div", {
            className: "flex flex-1 overflow-hidden",
            children: [
              s.jsxs("div", {
                className: "flex-1 relative overflow-hidden",
                style: { background: "#0a1628" },
                children: [
                  s.jsx("div", {
                    className:
                      "absolute top-4 right-4 z-10 flex items-center gap-2 flex-wrap",
                    children: p.map((h) =>
                      s.jsx(
                        "button",
                        {
                          onClick: () => i(h),
                          className: `px-3 py-1.5 rounded-full text-xs font-black transition-all shadow-lg ${a === h ? "bg-teal-500 text-white shadow-teal-900/50" : "bg-slate-800/90 text-slate-300 hover:bg-slate-700 border border-slate-700"}`,
                          children: h,
                        },
                        h,
                      ),
                    ),
                  }),
                  s.jsx("div", {
                    className:
                      "absolute top-4 left-4 z-10 bg-slate-800/90 border border-slate-700 rounded-xl shadow-lg p-1 flex gap-1",
                    children: [
                      { id: "heat", label: "حراري" },
                      { id: "district", label: "مناطق" },
                    ].map((h) =>
                      s.jsx(
                        "button",
                        {
                          onClick: () => f(h.id),
                          className: `px-3 py-1.5 rounded-lg text-xs font-black transition-all ${d === h.id ? "bg-teal-600 text-white" : "text-slate-400 hover:text-white"}`,
                          children: h.label,
                        },
                        h.id,
                      ),
                    ),
                  }),
                  s.jsxs("div", {
                    className:
                      "absolute top-16 left-4 z-10 bg-red-600 text-white rounded-xl px-3 py-1.5 text-xs font-black shadow-lg shadow-red-900/50 flex items-center gap-2",
                    children: [
                      s.jsx("span", {
                        className:
                          "w-2 h-2 bg-white rounded-full animate-pulse",
                      }),
                      "١٢ بلاغ نشط الآن",
                    ],
                  }),
                  s.jsx("div", {
                    className:
                      "absolute bottom-20 left-4 z-10 flex flex-col gap-1.5",
                    children: [
                      s.jsx(dj, { className: "w-4 h-4" }),
                      s.jsx(hj, { className: "w-4 h-4" }),
                      s.jsx(g2, { className: "w-4 h-4" }),
                    ].map((h, v) =>
                      s.jsx(
                        "button",
                        {
                          className:
                            "w-9 h-9 bg-slate-800/90 border border-slate-700 rounded-xl shadow-lg flex items-center justify-center text-slate-300 hover:text-white hover:bg-slate-700 transition-colors",
                          children: h,
                        },
                        v,
                      ),
                    ),
                  }),
                  s.jsxs("svg", {
                    viewBox: "0 0 560 460",
                    className: "w-full h-full",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: [
                      s.jsxs("defs", {
                        children: [
                          s.jsx("pattern", {
                            id: "dots",
                            x: "0",
                            y: "0",
                            width: "20",
                            height: "20",
                            patternUnits: "userSpaceOnUse",
                            children: s.jsx("circle", {
                              cx: "1",
                              cy: "1",
                              r: "0.8",
                              fill: "#1e3a5f",
                              opacity: "0.6",
                            }),
                          }),
                          lr.map((h) =>
                            s.jsxs(
                              "radialGradient",
                              {
                                id: `heat-${h.name.replace(/\s/g, "")}`,
                                cx: "50%",
                                cy: "50%",
                                r: "50%",
                                children: [
                                  s.jsx("stop", {
                                    offset: "0%",
                                    stopColor: h.color,
                                    stopOpacity: "0.55",
                                  }),
                                  s.jsx("stop", {
                                    offset: "45%",
                                    stopColor: h.color,
                                    stopOpacity: "0.28",
                                  }),
                                  s.jsx("stop", {
                                    offset: "100%",
                                    stopColor: h.color,
                                    stopOpacity: "0",
                                  }),
                                ],
                              },
                              `grad-${h.name}`,
                            ),
                          ),
                          s.jsxs("filter", {
                            id: "glow",
                            x: "-50%",
                            y: "-50%",
                            width: "200%",
                            height: "200%",
                            children: [
                              s.jsx("feGaussianBlur", {
                                stdDeviation: "3",
                                result: "blur",
                              }),
                              s.jsxs("feMerge", {
                                children: [
                                  s.jsx("feMergeNode", { in: "blur" }),
                                  s.jsx("feMergeNode", { in: "SourceGraphic" }),
                                ],
                              }),
                            ],
                          }),
                          s.jsxs("filter", {
                            id: "softglow",
                            x: "-30%",
                            y: "-30%",
                            width: "160%",
                            height: "160%",
                            children: [
                              s.jsx("feGaussianBlur", {
                                stdDeviation: "6",
                                result: "blur",
                              }),
                              s.jsxs("feMerge", {
                                children: [
                                  s.jsx("feMergeNode", { in: "blur" }),
                                  s.jsx("feMergeNode", { in: "blur" }),
                                  s.jsx("feMergeNode", { in: "SourceGraphic" }),
                                ],
                              }),
                            ],
                          }),
                        ],
                      }),
                      s.jsx("rect", {
                        width: "560",
                        height: "460",
                        fill: "#0a1628",
                      }),
                      s.jsx("rect", {
                        width: "560",
                        height: "460",
                        fill: "url(#dots)",
                      }),
                      s.jsxs("g", {
                        opacity: "0.12",
                        stroke: "#4a90d9",
                        strokeWidth: "0.6",
                        fill: "none",
                        children: [
                          s.jsx("line", {
                            x1: "0",
                            y1: "158",
                            x2: "560",
                            y2: "158",
                          }),
                          s.jsx("line", {
                            x1: "0",
                            y1: "298",
                            x2: "560",
                            y2: "298",
                          }),
                          s.jsx("line", {
                            x1: "0",
                            y1: "92",
                            x2: "560",
                            y2: "92",
                          }),
                          s.jsx("line", {
                            x1: "130",
                            y1: "0",
                            x2: "130",
                            y2: "460",
                          }),
                          s.jsx("line", {
                            x1: "270",
                            y1: "0",
                            x2: "270",
                            y2: "460",
                          }),
                          s.jsx("line", {
                            x1: "450",
                            y1: "0",
                            x2: "450",
                            y2: "460",
                          }),
                          s.jsx("line", {
                            x1: "0",
                            y1: "220",
                            x2: "560",
                            y2: "320",
                            opacity: "0.6",
                          }),
                        ],
                      }),
                      s.jsx("path", {
                        d: "M 105,0 C 108,55 100,110 103,170 C 106,230 98,285 102,345 C 106,400 98,440 100,460",
                        fill: "none",
                        stroke: "#1d4ed8",
                        strokeWidth: "14",
                        strokeLinecap: "round",
                        opacity: "0.35",
                      }),
                      s.jsx("path", {
                        d: "M 105,0 C 108,55 100,110 103,170 C 106,230 98,285 102,345 C 106,400 98,440 100,460",
                        fill: "none",
                        stroke: "#3b82f6",
                        strokeWidth: "5",
                        strokeLinecap: "round",
                        opacity: "0.5",
                      }),
                      s.jsx("path", {
                        d: "M 107,0 C 110,55 102,110 105,170 C 108,230 100,285 104,345 C 108,400 100,440 102,460",
                        fill: "none",
                        stroke: "#93c5fd",
                        strokeWidth: "1.5",
                        strokeLinecap: "round",
                        opacity: "0.3",
                        strokeDasharray: "8,12",
                      }),
                      s.jsx("path", {
                        d: "M 103,170 C 130,162 165,158 195,145 C 225,132 250,128 285,125",
                        fill: "none",
                        stroke: "#1d4ed8",
                        strokeWidth: "7",
                        strokeLinecap: "round",
                        opacity: "0.3",
                      }),
                      s.jsx("path", {
                        d: "M 103,170 C 130,162 165,158 195,145 C 225,132 250,128 285,125",
                        fill: "none",
                        stroke: "#3b82f6",
                        strokeWidth: "2.5",
                        strokeLinecap: "round",
                        opacity: "0.45",
                      }),
                      s.jsx("ellipse", {
                        cx: "82",
                        cy: "420",
                        rx: "38",
                        ry: "22",
                        fill: "#1d4ed8",
                        opacity: "0.2",
                      }),
                      s.jsx("ellipse", {
                        cx: "82",
                        cy: "420",
                        rx: "28",
                        ry: "14",
                        fill: "#3b82f6",
                        opacity: "0.15",
                      }),
                      lr.map((h) => {
                        const v = c?.name === h.name;
                        return s.jsxs(
                          "g",
                          {
                            onClick: () => o(v ? null : h),
                            className: "cursor-pointer",
                            children: [
                              s.jsx("polygon", {
                                points: h.polygon,
                                fill: h.color,
                                opacity:
                                  d === "district" ? (v ? 0.45 : 0.18) : 0.12,
                                stroke: h.color,
                                strokeWidth: v ? "1.8" : "0.8",
                                strokeOpacity: v ? "0.9" : "0.4",
                              }),
                              d === "heat" &&
                                s.jsx("ellipse", {
                                  cx: h.cx,
                                  cy: h.cy,
                                  rx: h.rx * 1.15,
                                  ry: h.ry * 1.15,
                                  fill: `url(#heat-${h.name.replace(/\s/g, "")})`,
                                }),
                              v &&
                                s.jsx("polygon", {
                                  points: h.polygon,
                                  fill: "none",
                                  stroke: h.color,
                                  strokeWidth: "2.5",
                                  strokeOpacity: "0.9",
                                  filter: "url(#glow)",
                                  strokeDasharray: "6,3",
                                }),
                              s.jsxs("g", {
                                children: [
                                  s.jsx("rect", {
                                    x: h.cx - h.name.length * 3.6,
                                    y: h.cy - 6.5,
                                    width: h.name.length * 7.2,
                                    height: "13",
                                    fill: v ? h.color : "rgba(0,0,0,0.72)",
                                    rx: "3.5",
                                    opacity: v ? "0.95" : "0.85",
                                  }),
                                  s.jsx("text", {
                                    x: h.cx,
                                    y: h.cy + 4,
                                    textAnchor: "middle",
                                    fill: "white",
                                    fontSize: "5.8",
                                    fontWeight: "bold",
                                    fontFamily: "Cairo, sans-serif",
                                    children: h.name,
                                  }),
                                ],
                              }),
                              s.jsxs("g", {
                                filter: "url(#glow)",
                                children: [
                                  s.jsx("circle", {
                                    cx: h.cx + h.rx - 4,
                                    cy: h.cy - h.ry + 6,
                                    r: "9",
                                    fill: h.color,
                                    opacity: "0.95",
                                  }),
                                  s.jsx("text", {
                                    x: h.cx + h.rx - 4,
                                    y: h.cy - h.ry + 9.5,
                                    textAnchor: "middle",
                                    fill: "white",
                                    fontSize: "4.5",
                                    fontWeight: "bold",
                                    fontFamily: "Cairo",
                                    children:
                                      h.reports > 200
                                        ? "+٣٠٠"
                                        : h.reports > 100
                                          ? "+١٠٠"
                                          : h.reports > 50
                                            ? "+٥٠"
                                            : "+٤٥",
                                  }),
                                ],
                              }),
                              h.risk > 70 &&
                                s.jsx("circle", {
                                  cx: h.cx,
                                  cy: h.cy,
                                  r: "4",
                                  fill: h.color,
                                  opacity: "0.8",
                                  filter: "url(#softglow)",
                                }),
                            ],
                          },
                          h.name,
                        );
                      }),
                      [
                        { cx: 190, cy: 72, c: "#ef4444" },
                        { cx: 172, cy: 98, c: "#ef4444" },
                        { cx: 355, cy: 65, c: "#f97316" },
                        { cx: 185, cy: 210, c: "#f59e0b" },
                        { cx: 345, cy: 222, c: "#eab308" },
                        { cx: 168, cy: 352, c: "#22c55e" },
                      ].map((h, v) =>
                        s.jsxs(
                          "g",
                          {
                            children: [
                              s.jsx("circle", {
                                cx: h.cx,
                                cy: h.cy,
                                r: "5",
                                fill: h.c,
                                opacity: "0.15",
                              }),
                              s.jsx("circle", {
                                cx: h.cx,
                                cy: h.cy,
                                r: "2.5",
                                fill: h.c,
                                opacity: "0.9",
                              }),
                            ],
                          },
                          v,
                        ),
                      ),
                      s.jsx("text", {
                        x: "8",
                        y: "452",
                        fill: "#374151",
                        fontSize: "5",
                        fontFamily: "Cairo",
                        opacity: "0.6",
                        children: "محافظة القليوبية — بيانات افتراضية للعرض",
                      }),
                    ],
                  }),
                  s.jsxs("div", {
                    className:
                      "absolute bottom-5 right-5 bg-slate-900/95 backdrop-blur border border-slate-700/60 rounded-2xl p-4 text-xs font-bold shadow-xl",
                    children: [
                      s.jsx("p", {
                        className: "text-slate-400 mb-3 font-black text-[11px]",
                        children: "مستوى الخطر",
                      }),
                      s.jsx("div", {
                        className: "space-y-2",
                        children: [
                          { color: "#ef4444", label: "حرج", range: "٨٠٪+" },
                          { color: "#f97316", label: "عالٍ", range: "٦٠–٧٩٪" },
                          { color: "#f59e0b", label: "متوسط", range: "٤٠–٥٩٪" },
                          { color: "#22c55e", label: "منخفض", range: "٢٠–٣٩٪" },
                          {
                            color: "#15803d",
                            label: "آمن",
                            range: "أقل من ٢٠٪",
                          },
                        ].map((h) =>
                          s.jsxs(
                            "div",
                            {
                              className: "flex items-center gap-2.5",
                              children: [
                                s.jsx("div", {
                                  className: "w-3 h-3 rounded-full shadow-sm",
                                  style: { background: h.color },
                                }),
                                s.jsx("span", {
                                  className: "text-slate-300 w-12",
                                  children: h.label,
                                }),
                                s.jsx("span", {
                                  className: "text-slate-500 text-[10px]",
                                  children: h.range,
                                }),
                              ],
                            },
                            h.label,
                          ),
                        ),
                      }),
                      s.jsxs("div", {
                        className:
                          "mt-3 pt-3 border-t border-slate-700/60 flex items-center gap-2",
                        children: [
                          s.jsx("div", {
                            className: "w-10 h-2 rounded",
                            style: {
                              background:
                                "linear-gradient(to left, #3b82f6, #1e3a5f)",
                            },
                          }),
                          s.jsx("span", {
                            className: "text-slate-400 text-[10px]",
                            children: "نهر النيل",
                          }),
                        ],
                      }),
                    ],
                  }),
                ],
              }),
              s.jsxs("div", {
                className:
                  "w-72 bg-white border-r border-slate-200 flex flex-col overflow-hidden shadow-sm",
                children: [
                  s.jsxs("div", {
                    className: "p-4 border-b border-slate-100 shrink-0",
                    children: [
                      s.jsxs("div", {
                        className: "flex justify-between items-center mb-3",
                        children: [
                          s.jsx("h3", {
                            className: "font-black text-slate-800 text-sm",
                            children: "مؤشر الخطر العمراني",
                          }),
                          s.jsx("button", {
                            className:
                              "text-xs text-teal-600 font-black hover:underline",
                            children: "تقرير كامل",
                          }),
                        ],
                      }),
                      s.jsx("div", {
                        className: "grid grid-cols-2 gap-2",
                        children: [
                          {
                            val: "١,٠٣١",
                            label: "إجمالي البلاغات",
                            c: "text-slate-800",
                          },
                          {
                            val: "٨٩٪",
                            label: "معدل الحل",
                            c: "text-emerald-600",
                          },
                        ].map((h) =>
                          s.jsxs(
                            "div",
                            {
                              className:
                                "bg-slate-50 rounded-xl p-3 text-center border border-slate-100",
                              children: [
                                s.jsx("div", {
                                  className: `text-xl font-black ${h.c}`,
                                  children: h.val,
                                }),
                                s.jsx("div", {
                                  className:
                                    "text-[10px] text-slate-400 font-bold mt-0.5",
                                  children: h.label,
                                }),
                              ],
                            },
                            h.label,
                          ),
                        ),
                      }),
                    ],
                  }),
                  s.jsx("div", {
                    className: "flex-1 overflow-y-auto p-3 space-y-1.5",
                    children: lr.map((h) =>
                      s.jsxs(
                        "button",
                        {
                          onClick: () => o(c?.name === h.name ? null : h),
                          className: `w-full text-right p-3 rounded-xl border-2 transition-all ${c?.name === h.name ? "border-opacity-60 bg-slate-50" : "border-transparent hover:bg-slate-50"}`,
                          style: {
                            borderColor:
                              c?.name === h.name
                                ? h.color + "60"
                                : "transparent",
                          },
                          children: [
                            s.jsxs("div", {
                              className:
                                "flex items-center justify-between mb-2",
                              children: [
                                s.jsxs("div", {
                                  className: "flex items-center gap-2",
                                  children: [
                                    s.jsx("div", {
                                      className:
                                        "w-3 h-3 rounded-full shrink-0 shadow-sm",
                                      style: { background: h.color },
                                    }),
                                    s.jsx("span", {
                                      className:
                                        "font-black text-sm text-slate-800",
                                      children: h.name,
                                    }),
                                  ],
                                }),
                                s.jsxs("div", {
                                  className: "flex items-center gap-1",
                                  children: [
                                    s.jsxs("span", {
                                      className: "text-xs font-black",
                                      style: { color: h.color },
                                      children: [h.risk, "٪"],
                                    }),
                                    h.risk > 60
                                      ? s.jsx(Ss, {
                                          className: "w-3 h-3 text-red-500",
                                        })
                                      : s.jsx(np, {
                                          className: "w-3 h-3 text-emerald-500",
                                        }),
                                  ],
                                }),
                              ],
                            }),
                            s.jsx("div", {
                              className:
                                "w-full bg-slate-100 rounded-full h-1.5 mb-1.5",
                              children: s.jsx("div", {
                                className: "h-1.5 rounded-full transition-all",
                                style: {
                                  width: `${h.risk}%`,
                                  background: h.color,
                                },
                              }),
                            }),
                            s.jsxs("div", {
                              className: "flex justify-between",
                              children: [
                                s.jsxs("span", {
                                  className:
                                    "text-[10px] text-slate-400 font-bold",
                                  children: [h.reports, " بلاغ"],
                                }),
                                s.jsx("span", {
                                  className: "text-[10px] font-black",
                                  style: { color: h.color },
                                  children: h.riskLabel,
                                }),
                              ],
                            }),
                          ],
                        },
                        h.name,
                      ),
                    ),
                  }),
                  c &&
                    s.jsxs("div", {
                      className: "border-t border-slate-100 p-4 shrink-0",
                      style: { background: c.color + "08" },
                      children: [
                        s.jsxs("div", {
                          className: "flex justify-between items-center mb-3",
                          children: [
                            s.jsxs("h4", {
                              className:
                                "font-black text-slate-800 text-sm flex items-center gap-2",
                              children: [
                                s.jsx("div", {
                                  className: "w-3 h-3 rounded-full",
                                  style: { background: c.color },
                                }),
                                c.name,
                              ],
                            }),
                            s.jsx("button", {
                              onClick: () => o(null),
                              className:
                                "text-slate-400 hover:text-slate-600 p-1 rounded-lg hover:bg-slate-100",
                              children: s.jsx(Or, { className: "w-3.5 h-3.5" }),
                            }),
                          ],
                        }),
                        s.jsx("div", {
                          className: "space-y-2 text-xs mb-3",
                          children: [
                            {
                              label: "إجمالي البلاغات",
                              value: c.reports.toString(),
                            },
                            {
                              label: "مؤشر الخطر",
                              value: `${c.risk}٪ — ${c.riskLabel}`,
                            },
                            { label: "الجهة المختصة", value: "أعمال عامة" },
                            { label: "أحدث بلاغ", value: "منذ ٤٥ دقيقة" },
                          ].map((h) =>
                            s.jsxs(
                              "div",
                              {
                                className: "flex justify-between",
                                children: [
                                  s.jsx("span", {
                                    className: "text-slate-500 font-bold",
                                    children: h.label,
                                  }),
                                  s.jsx("span", {
                                    className: "font-black text-slate-800",
                                    children: h.value,
                                  }),
                                ],
                              },
                              h.label,
                            ),
                          ),
                        }),
                        s.jsxs("button", {
                          className:
                            "w-full py-2.5 text-xs font-black text-white rounded-xl transition-colors",
                          style: { background: c.color },
                          children: ["عرض بلاغات ", c.name],
                        }),
                      ],
                    }),
                ],
              }),
            ],
          }),
        ],
      }),
    ],
  });
}
var n4 = Symbol.for("react.lazy"),
  xr = Eu[" use ".trim().toString()];
function s4(a) {
  return typeof a == "object" && a !== null && "then" in a;
}
function lb(a) {
  return (
    a != null &&
    typeof a == "object" &&
    "$$typeof" in a &&
    a.$$typeof === n4 &&
    "_payload" in a &&
    s4(a._payload)
  );
}
function ab(a) {
  const i = r4(a),
    c = j.forwardRef((o, d) => {
      let { children: f, ...x } = o;
      lb(f) && typeof xr == "function" && (f = xr(f._payload));
      const b = j.Children.toArray(f),
        p = b.find(o4);
      if (p) {
        const h = p.props.children,
          v = b.map((w) =>
            w === p
              ? j.Children.count(h) > 1
                ? j.Children.only(null)
                : j.isValidElement(h)
                  ? h.props.children
                  : null
              : w,
          );
        return s.jsx(i, {
          ...x,
          ref: d,
          children: j.isValidElement(h) ? j.cloneElement(h, void 0, v) : null,
        });
      }
      return s.jsx(i, { ...x, ref: d, children: f });
    });
  return ((c.displayName = `${a}.Slot`), c);
}
var i4 = ab("Slot");
function r4(a) {
  const i = j.forwardRef((c, o) => {
    let { children: d, ...f } = c;
    if (
      (lb(d) && typeof xr == "function" && (d = xr(d._payload)),
      j.isValidElement(d))
    ) {
      const x = d4(d),
        b = u4(f, d.props);
      return (
        d.type !== j.Fragment && (b.ref = o ? Ru(o, x) : x),
        j.cloneElement(d, b)
      );
    }
    return j.Children.count(d) > 1 ? j.Children.only(null) : null;
  });
  return ((i.displayName = `${a}.SlotClone`), i);
}
var c4 = Symbol("radix.slottable");
function o4(a) {
  return (
    j.isValidElement(a) &&
    typeof a.type == "function" &&
    "__radixId" in a.type &&
    a.type.__radixId === c4
  );
}
function u4(a, i) {
  const c = { ...i };
  for (const o in i) {
    const d = a[o],
      f = i[o];
    /^on[A-Z]/.test(o)
      ? d && f
        ? (c[o] = (...b) => {
            const p = f(...b);
            return (d(...b), p);
          })
        : d && (c[o] = d)
      : o === "style"
        ? (c[o] = { ...d, ...f })
        : o === "className" && (c[o] = [d, f].filter(Boolean).join(" "));
  }
  return { ...a, ...c };
}
function d4(a) {
  let i = Object.getOwnPropertyDescriptor(a.props, "ref")?.get,
    c = i && "isReactWarning" in i && i.isReactWarning;
  return c
    ? a.ref
    : ((i = Object.getOwnPropertyDescriptor(a, "ref")?.get),
      (c = i && "isReactWarning" in i && i.isReactWarning),
      c ? a.props.ref : a.props.ref || a.ref);
}
const f4 = Uu(
    "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 hover-elevate active-elevate-2",
    {
      variants: {
        variant: {
          default:
            "bg-primary text-primary-foreground border border-primary-border",
          destructive:
            "bg-destructive text-destructive-foreground shadow-sm border-destructive-border",
          outline:
            " border [border-color:var(--button-outline)] shadow-xs active:shadow-none ",
          secondary:
            "border bg-secondary text-secondary-foreground border border-secondary-border ",
          ghost: "border border-transparent",
          link: "text-primary underline-offset-4 hover:underline",
        },
        size: {
          default: "min-h-9 px-4 py-2",
          sm: "min-h-8 rounded-md px-3 text-xs",
          lg: "min-h-10 rounded-md px-8",
          icon: "h-9 w-9",
        },
      },
      defaultVariants: { variant: "default", size: "default" },
    },
  ),
  Jl = j.forwardRef(
    ({ className: a, variant: i, size: c, asChild: o = !1, ...d }, f) => {
      const x = o ? i4 : "button";
      return s.jsx(x, {
        className: $e(f4({ variant: i, size: c, className: a })),
        ref: f,
        ...d,
      });
    },
  );
Jl.displayName = "Button";
const h4 = Uu(
  "whitespace-nowrap inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 hover-elevate ",
  {
    variants: {
      variant: {
        default:
          "border-transparent bg-primary text-primary-foreground shadow-xs",
        secondary: "border-transparent bg-secondary text-secondary-foreground",
        destructive:
          "border-transparent bg-destructive text-destructive-foreground shadow-xs",
        outline: "text-foreground border [border-color:var(--badge-outline)]",
      },
    },
    defaultVariants: { variant: "default" },
  },
);
function Ns({ className: a, variant: i, ...c }) {
  return s.jsx("div", { className: $e(h4({ variant: i }), a), ...c });
}
function nb(a, i = []) {
  let c = [];
  function o(f, x) {
    const b = j.createContext(x);
    b.displayName = f + "Context";
    const p = c.length;
    c = [...c, x];
    const h = (w) => {
      const { scope: E, children: R, ...k } = w,
        A = E?.[a]?.[p] || b,
        _ = j.useMemo(() => k, Object.values(k));
      return s.jsx(A.Provider, { value: _, children: R });
    };
    h.displayName = f + "Provider";
    function v(w, E) {
      const R = E?.[a]?.[p] || b,
        k = j.useContext(R);
      if (k) return k;
      if (x !== void 0) return x;
      throw new Error(`\`${w}\` must be used within \`${f}\``);
    }
    return [h, v];
  }
  const d = () => {
    const f = c.map((x) => j.createContext(x));
    return function (b) {
      const p = b?.[a] || f;
      return j.useMemo(() => ({ [`__scope${a}`]: { ...b, [a]: p } }), [b, p]);
    };
  };
  return ((d.scopeName = a), [o, m4(d, ...i)]);
}
function m4(...a) {
  const i = a[0];
  if (a.length === 1) return i;
  const c = () => {
    const o = a.map((d) => ({ useScope: d(), scopeName: d.scopeName }));
    return function (f) {
      const x = o.reduce((b, { useScope: p, scopeName: h }) => {
        const w = p(f)[`__scope${h}`];
        return { ...b, ...w };
      }, {});
      return j.useMemo(() => ({ [`__scope${i.scopeName}`]: x }), [x]);
    };
  };
  return ((c.scopeName = i.scopeName), c);
}
var x4 = [
    "a",
    "button",
    "div",
    "form",
    "h2",
    "h3",
    "img",
    "input",
    "label",
    "li",
    "nav",
    "ol",
    "p",
    "select",
    "span",
    "svg",
    "ul",
  ],
  Ds = x4.reduce((a, i) => {
    const c = ab(`Primitive.${i}`),
      o = j.forwardRef((d, f) => {
        const { asChild: x, ...b } = d,
          p = x ? c : i;
        return (
          typeof window < "u" && (window[Symbol.for("radix-ui")] = !0),
          s.jsx(p, { ...b, ref: f })
        );
      });
    return ((o.displayName = `Primitive.${i}`), { ...a, [i]: o });
  }, {}),
  Iu = "Progress",
  ed = 100,
  [p4] = nb(Iu),
  [b4, g4] = p4(Iu),
  sb = j.forwardRef((a, i) => {
    const {
      __scopeProgress: c,
      value: o = null,
      max: d,
      getValueLabel: f = v4,
      ...x
    } = a;
    (d || d === 0) && !ex(d) && console.error(y4(`${d}`, "Progress"));
    const b = ex(d) ? d : ed;
    o !== null && !tx(o, b) && console.error(j4(`${o}`, "Progress"));
    const p = tx(o, b) ? o : null,
      h = pr(p) ? f(p, b) : void 0;
    return s.jsx(b4, {
      scope: c,
      value: p,
      max: b,
      children: s.jsx(Ds.div, {
        "aria-valuemax": b,
        "aria-valuemin": 0,
        "aria-valuenow": pr(p) ? p : void 0,
        "aria-valuetext": h,
        role: "progressbar",
        "data-state": cb(p, b),
        "data-value": p ?? void 0,
        "data-max": b,
        ...x,
        ref: i,
      }),
    });
  });
sb.displayName = Iu;
var ib = "ProgressIndicator",
  rb = j.forwardRef((a, i) => {
    const { __scopeProgress: c, ...o } = a,
      d = g4(ib, c);
    return s.jsx(Ds.div, {
      "data-state": cb(d.value, d.max),
      "data-value": d.value ?? void 0,
      "data-max": d.max,
      ...o,
      ref: i,
    });
  });
rb.displayName = ib;
function v4(a, i) {
  return `${Math.round((a / i) * 100)}%`;
}
function cb(a, i) {
  return a == null ? "indeterminate" : a === i ? "complete" : "loading";
}
function pr(a) {
  return typeof a == "number";
}
function ex(a) {
  return pr(a) && !isNaN(a) && a > 0;
}
function tx(a, i) {
  return pr(a) && !isNaN(a) && a <= i && a >= 0;
}
function y4(a, i) {
  return `Invalid prop \`max\` of value \`${a}\` supplied to \`${i}\`. Only numbers greater than 0 are valid max values. Defaulting to \`${ed}\`.`;
}
function j4(a, i) {
  return `Invalid prop \`value\` of value \`${a}\` supplied to \`${i}\`. The \`value\` prop must be:
  - a positive number
  - less than the value passed to \`max\` (or ${ed} if no \`max\` prop is set)
  - \`null\` or \`undefined\` if the progress is indeterminate.

Defaulting to \`null\`.`;
}
var ob = sb,
  N4 = rb;
const fn = j.forwardRef(({ className: a, value: i, ...c }, o) =>
  s.jsx(ob, {
    ref: o,
    className: $e(
      "relative h-2 w-full overflow-hidden rounded-full bg-primary/20",
      a,
    ),
    ...c,
    children: s.jsx(N4, {
      className: "h-full w-full flex-1 bg-primary transition-all",
      style: { transform: `translateX(-${100 - (i || 0)}%)` },
    }),
  }),
);
fn.displayName = ob.displayName;
function w4() {
  return ix.useSyncExternalStore(
    S4,
    () => !0,
    () => !1,
  );
}
function S4() {
  return () => {};
}
var td = "Avatar",
  [E4] = nb(td),
  [T4, ub] = E4(td),
  db = j.forwardRef((a, i) => {
    const { __scopeAvatar: c, ...o } = a,
      [d, f] = j.useState("idle");
    return s.jsx(T4, {
      scope: c,
      imageLoadingStatus: d,
      onImageLoadingStatusChange: f,
      children: s.jsx(Ds.span, { ...o, ref: i }),
    });
  });
db.displayName = td;
var fb = "AvatarImage",
  hb = j.forwardRef((a, i) => {
    const {
        __scopeAvatar: c,
        src: o,
        onLoadingStatusChange: d = () => {},
        ...f
      } = a,
      x = ub(fb, c),
      b = A4(o, f),
      p = gl((h) => {
        (d(h), x.onImageLoadingStatusChange(h));
      });
    return (
      Gt(() => {
        b !== "idle" && p(b);
      }, [b, p]),
      b === "loaded" ? s.jsx(Ds.img, { ...f, ref: i, src: o }) : null
    );
  });
hb.displayName = fb;
var mb = "AvatarFallback",
  xb = j.forwardRef((a, i) => {
    const { __scopeAvatar: c, delayMs: o, ...d } = a,
      f = ub(mb, c),
      [x, b] = j.useState(o === void 0);
    return (
      j.useEffect(() => {
        if (o !== void 0) {
          const p = window.setTimeout(() => b(!0), o);
          return () => window.clearTimeout(p);
        }
      }, [o]),
      x && f.imageLoadingStatus !== "loaded"
        ? s.jsx(Ds.span, { ...d, ref: i })
        : null
    );
  });
xb.displayName = mb;
function lx(a, i) {
  return a
    ? i
      ? (a.src !== i && (a.src = i),
        a.complete && a.naturalWidth > 0 ? "loaded" : "loading")
      : "error"
    : "idle";
}
function A4(a, { referrerPolicy: i, crossOrigin: c }) {
  const o = w4(),
    d = j.useRef(null),
    f = o ? (d.current || (d.current = new window.Image()), d.current) : null,
    [x, b] = j.useState(() => lx(f, a));
  return (
    Gt(() => {
      b(lx(f, a));
    }, [f, a]),
    Gt(() => {
      const p = (w) => () => {
        b(w);
      };
      if (!f) return;
      const h = p("loaded"),
        v = p("error");
      return (
        f.addEventListener("load", h),
        f.addEventListener("error", v),
        i && (f.referrerPolicy = i),
        typeof c == "string" && (f.crossOrigin = c),
        () => {
          (f.removeEventListener("load", h), f.removeEventListener("error", v));
        }
      );
    }, [f, c, i]),
    x
  );
}
var pb = db,
  bb = hb,
  gb = xb;
const vb = j.forwardRef(({ className: a, ...i }, c) =>
  s.jsx(pb, {
    ref: c,
    className: $e(
      "relative flex h-10 w-10 shrink-0 overflow-hidden rounded-full",
      a,
    ),
    ...i,
  }),
);
vb.displayName = pb.displayName;
const C4 = j.forwardRef(({ className: a, ...i }, c) =>
  s.jsx(bb, { ref: c, className: $e("aspect-square h-full w-full", a), ...i }),
);
C4.displayName = bb.displayName;
const yb = j.forwardRef(({ className: a, ...i }, c) =>
  s.jsx(gb, {
    ref: c,
    className: $e(
      "flex h-full w-full items-center justify-center rounded-full bg-muted",
      a,
    ),
    ...i,
  }),
);
yb.displayName = gb.displayName;
function O4() {
  return (
    vn(),
    s.jsxs("div", {
      dir: "rtl",
      className: "min-h-screen bg-slate-100 flex text-slate-900",
      children: [
        s.jsxs("aside", {
          className:
            "w-64 bg-slate-900 text-slate-300 flex flex-col hidden md:flex h-screen sticky top-0",
          children: [
            s.jsxs("div", {
              className:
                "p-6 flex items-center gap-3 border-b border-slate-800",
              children: [
                s.jsx("div", {
                  className:
                    "w-8 h-8 bg-teal-600 rounded flex items-center justify-center text-white font-bold text-xl",
                  children: "C",
                }),
                s.jsxs("div", {
                  children: [
                    s.jsx("h1", {
                      className:
                        "font-bold text-white leading-tight tracking-wide",
                      children: "نبض المدينة",
                    }),
                    s.jsx("p", {
                      className:
                        "text-[10px] text-slate-400 uppercase tracking-wider",
                      children: "لوحة القيادة",
                    }),
                  ],
                }),
              ],
            }),
            s.jsxs("nav", {
              className: "flex-1 py-6 px-3 space-y-1",
              children: [
                s.jsxs(Ye, {
                  href: "/admin",
                  className:
                    "flex items-center gap-3 px-3 py-2.5 rounded-lg bg-teal-600/10 text-teal-400 font-bold",
                  children: [s.jsx(Cr, { className: "w-5 h-5" }), "نظرة عامة"],
                }),
                s.jsxs(Ye, {
                  href: "/admin",
                  className:
                    "flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-slate-800 hover:text-white transition-colors",
                  children: [
                    s.jsx(wa, { className: "w-5 h-5" }),
                    "إدارة البلاغات",
                    s.jsx(Ns, {
                      className: "mr-auto bg-teal-600 hover:bg-teal-600",
                      children: "١٢",
                    }),
                  ],
                }),
                s.jsxs(Ye, {
                  href: "/heatmap",
                  className:
                    "flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-slate-800 hover:text-white transition-colors",
                  children: [
                    s.jsx(Hu, { className: "w-5 h-5" }),
                    "الخريطة الحية",
                  ],
                }),
                s.jsxs(Ye, {
                  href: "/admin/teams",
                  className:
                    "flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-slate-800 hover:text-white transition-colors",
                  children: [s.jsx(Cs, { className: "w-5 h-5" }), "فرق العمل"],
                }),
                s.jsxs(Ye, {
                  href: "#",
                  className:
                    "flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-slate-800 hover:text-white transition-colors",
                  children: [s.jsx(qu, { className: "w-5 h-5" }), "الإعدادات"],
                }),
              ],
            }),
            s.jsx("div", {
              className: "p-4 border-t border-slate-800",
              children: s.jsxs("div", {
                className: "flex items-center gap-3",
                children: [
                  s.jsx(vb, {
                    className: "w-10 h-10 border border-slate-700",
                    children: s.jsx(yb, {
                      className: "bg-slate-800 text-slate-300",
                      children: "م",
                    }),
                  }),
                  s.jsxs("div", {
                    children: [
                      s.jsx("p", {
                        className: "text-sm font-bold text-white",
                        children: "م. خالد حسن",
                      }),
                      s.jsx("p", {
                        className: "text-xs text-slate-400",
                        children: "مدير غرفة العمليات",
                      }),
                    ],
                  }),
                ],
              }),
            }),
          ],
        }),
        s.jsxs("main", {
          className: "flex-1 flex flex-col overflow-hidden",
          children: [
            s.jsxs("header", {
              className:
                "h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6 sticky top-0 z-10",
              children: [
                s.jsxs("div", {
                  className: "flex items-center gap-4",
                  children: [
                    s.jsx("h2", {
                      className: "text-xl font-bold text-slate-800",
                      children: "محافظة القليوبية",
                    }),
                    s.jsxs("div", {
                      className:
                        "hidden lg:flex items-center gap-2 px-3 py-1.5 bg-slate-100 rounded-md",
                      children: [
                        s.jsx(Lu, { className: "w-4 h-4 text-slate-400" }),
                        s.jsx("input", {
                          type: "text",
                          placeholder: "بحث برقم البلاغ، المنطقة...",
                          className:
                            "bg-transparent border-none outline-none text-sm w-64 placeholder:text-slate-400 text-slate-700",
                        }),
                      ],
                    }),
                  ],
                }),
                s.jsxs("div", {
                  className: "flex items-center gap-4",
                  children: [
                    s.jsxs(Jl, {
                      variant: "ghost",
                      size: "icon",
                      className: "relative text-slate-500",
                      children: [
                        s.jsx(Tr, { className: "w-5 h-5" }),
                        s.jsx("span", {
                          className:
                            "absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border border-white",
                        }),
                      ],
                    }),
                    s.jsx("div", { className: "h-8 w-px bg-slate-200" }),
                    s.jsx("p", {
                      className: "text-sm font-bold text-slate-600",
                      children: "الثلاثاء، ١٥ مايو ٢٠٢٤",
                    }),
                  ],
                }),
              ],
            }),
            s.jsxs("div", {
              className: "p-6 overflow-y-auto h-[calc(100vh-4rem)]",
              children: [
                s.jsxs("div", {
                  className:
                    "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8",
                  children: [
                    s.jsx(Fl, {
                      className: "border-0 shadow-sm",
                      children: s.jsxs(Wl, {
                        className: "p-6",
                        children: [
                          s.jsxs("div", {
                            className: "flex justify-between items-start",
                            children: [
                              s.jsxs("div", {
                                children: [
                                  s.jsx("p", {
                                    className:
                                      "text-sm font-bold text-slate-500 mb-1",
                                    children: "إجمالي البلاغات",
                                  }),
                                  s.jsx("h3", {
                                    className:
                                      "text-3xl font-black text-slate-800",
                                    children: "١,٢٨٤",
                                  }),
                                ],
                              }),
                              s.jsx("div", {
                                className:
                                  "w-12 h-12 rounded-lg bg-blue-50 flex items-center justify-center text-blue-600",
                                children: s.jsx(wa, { className: "w-6 h-6" }),
                              }),
                            ],
                          }),
                          s.jsxs("div", {
                            className: "mt-4 flex items-center text-sm",
                            children: [
                              s.jsx(Ss, {
                                className: "w-4 h-4 text-emerald-500 ml-1",
                              }),
                              s.jsx("span", {
                                className: "text-emerald-600 font-bold",
                                children: "+١٢٪",
                              }),
                              s.jsx("span", {
                                className: "text-slate-400 mr-2",
                                children: "مقارنة بالشهر الماضي",
                              }),
                            ],
                          }),
                        ],
                      }),
                    }),
                    s.jsx(Fl, {
                      className: "border-0 shadow-sm",
                      children: s.jsxs(Wl, {
                        className: "p-6",
                        children: [
                          s.jsxs("div", {
                            className: "flex justify-between items-start",
                            children: [
                              s.jsxs("div", {
                                children: [
                                  s.jsx("p", {
                                    className:
                                      "text-sm font-bold text-slate-500 mb-1",
                                    children: "بلاغات معلقة",
                                  }),
                                  s.jsx("h3", {
                                    className:
                                      "text-3xl font-black text-amber-600",
                                    children: "١٥٦",
                                  }),
                                ],
                              }),
                              s.jsx("div", {
                                className:
                                  "w-12 h-12 rounded-lg bg-amber-50 flex items-center justify-center text-amber-600",
                                children: s.jsx(Bu, { className: "w-6 h-6" }),
                              }),
                            ],
                          }),
                          s.jsxs("div", {
                            className: "mt-4 flex items-center text-sm",
                            children: [
                              s.jsx(Ss, {
                                className: "w-4 h-4 text-red-500 ml-1",
                              }),
                              s.jsx("span", {
                                className: "text-red-600 font-bold",
                                children: "+٣٪",
                              }),
                              s.jsx("span", {
                                className: "text-slate-400 mr-2",
                                children: "تتطلب تدخل سريع",
                              }),
                            ],
                          }),
                        ],
                      }),
                    }),
                    s.jsx(Fl, {
                      className: "border-0 shadow-sm",
                      children: s.jsxs(Wl, {
                        className: "p-6",
                        children: [
                          s.jsxs("div", {
                            className: "flex justify-between items-start",
                            children: [
                              s.jsxs("div", {
                                children: [
                                  s.jsx("p", {
                                    className:
                                      "text-sm font-bold text-slate-500 mb-1",
                                    children: "تم الحل (هذا الأسبوع)",
                                  }),
                                  s.jsx("h3", {
                                    className:
                                      "text-3xl font-black text-emerald-600",
                                    children: "٣٤٢",
                                  }),
                                ],
                              }),
                              s.jsx("div", {
                                className:
                                  "w-12 h-12 rounded-lg bg-emerald-50 flex items-center justify-center text-emerald-600",
                                children: s.jsx(xn, { className: "w-6 h-6" }),
                              }),
                            ],
                          }),
                          s.jsxs("div", {
                            className: "mt-4 flex items-center text-sm",
                            children: [
                              s.jsx("span", {
                                className: "text-slate-600 font-bold",
                                children: "٨٩٪",
                              }),
                              s.jsx("span", {
                                className: "text-slate-400 mr-2",
                                children: "معدل إنجاز المهام",
                              }),
                            ],
                          }),
                        ],
                      }),
                    }),
                    s.jsx(Fl, {
                      className: "border-0 shadow-sm",
                      children: s.jsxs(Wl, {
                        className: "p-6",
                        children: [
                          s.jsxs("div", {
                            className: "flex justify-between items-start",
                            children: [
                              s.jsxs("div", {
                                children: [
                                  s.jsx("p", {
                                    className:
                                      "text-sm font-bold text-slate-500 mb-1",
                                    children: "متوسط وقت الاستجابة",
                                  }),
                                  s.jsxs("h3", {
                                    className:
                                      "text-3xl font-black text-slate-800",
                                    children: [
                                      "٢.٤ ",
                                      s.jsx("span", {
                                        className:
                                          "text-lg font-bold text-slate-500",
                                        children: "ساعة",
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                              s.jsx("div", {
                                className:
                                  "w-12 h-12 rounded-lg bg-purple-50 flex items-center justify-center text-purple-600",
                                children: s.jsx(pn, { className: "w-6 h-6" }),
                              }),
                            ],
                          }),
                          s.jsxs("div", {
                            className: "mt-4 flex items-center text-sm",
                            children: [
                              s.jsx(Ss, {
                                className:
                                  "w-4 h-4 text-emerald-500 ml-1 rotate-180",
                              }),
                              s.jsx("span", {
                                className: "text-emerald-600 font-bold",
                                children: "-١٥٪",
                              }),
                              s.jsx("span", {
                                className: "text-slate-400 mr-2",
                                children: "أسرع من المعدل المستهدف",
                              }),
                            ],
                          }),
                        ],
                      }),
                    }),
                  ],
                }),
                s.jsxs("div", {
                  className: "grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8",
                  children: [
                    s.jsxs(Fl, {
                      className: "col-span-1 border-0 shadow-sm",
                      children: [
                        s.jsxs(Nu, {
                          className: "pb-2",
                          children: [
                            s.jsx(wu, {
                              className: "text-lg font-bold text-slate-800",
                              children: "مؤشر الخطر العمراني",
                            }),
                            s.jsx(Su, {
                              children:
                                "تصنيف المراكز حسب تراكم البلاغات والأولوية",
                            }),
                          ],
                        }),
                        s.jsx(Wl, {
                          children: s.jsxs("div", {
                            className: "space-y-5 mt-4",
                            children: [
                              s.jsxs("div", {
                                children: [
                                  s.jsxs("div", {
                                    className:
                                      "flex justify-between text-sm mb-1.5",
                                    children: [
                                      s.jsx("span", {
                                        className: "font-bold text-slate-700",
                                        children: "شبرا الخيمة",
                                      }),
                                      s.jsx("span", {
                                        className: "text-red-600 font-bold",
                                        children: "عالي جداً",
                                      }),
                                    ],
                                  }),
                                  s.jsx(fn, {
                                    value: 85,
                                    className:
                                      "h-2 [&>div]:bg-red-500 bg-slate-100",
                                  }),
                                ],
                              }),
                              s.jsxs("div", {
                                children: [
                                  s.jsxs("div", {
                                    className:
                                      "flex justify-between text-sm mb-1.5",
                                    children: [
                                      s.jsx("span", {
                                        className: "font-bold text-slate-700",
                                        children: "بنها",
                                      }),
                                      s.jsx("span", {
                                        className: "text-amber-600 font-bold",
                                        children: "متوسط",
                                      }),
                                    ],
                                  }),
                                  s.jsx(fn, {
                                    value: 60,
                                    className:
                                      "h-2 [&>div]:bg-amber-500 bg-slate-100",
                                  }),
                                ],
                              }),
                              s.jsxs("div", {
                                children: [
                                  s.jsxs("div", {
                                    className:
                                      "flex justify-between text-sm mb-1.5",
                                    children: [
                                      s.jsx("span", {
                                        className: "font-bold text-slate-700",
                                        children: "قليوب",
                                      }),
                                      s.jsx("span", {
                                        className: "text-amber-600 font-bold",
                                        children: "متوسط",
                                      }),
                                    ],
                                  }),
                                  s.jsx(fn, {
                                    value: 45,
                                    className:
                                      "h-2 [&>div]:bg-amber-500 bg-slate-100",
                                  }),
                                ],
                              }),
                              s.jsxs("div", {
                                children: [
                                  s.jsxs("div", {
                                    className:
                                      "flex justify-between text-sm mb-1.5",
                                    children: [
                                      s.jsx("span", {
                                        className: "font-bold text-slate-700",
                                        children: "القناطر الخيرية",
                                      }),
                                      s.jsx("span", {
                                        className: "text-emerald-600 font-bold",
                                        children: "منخفض",
                                      }),
                                    ],
                                  }),
                                  s.jsx(fn, {
                                    value: 25,
                                    className:
                                      "h-2 [&>div]:bg-emerald-500 bg-slate-100",
                                  }),
                                ],
                              }),
                              s.jsxs("div", {
                                children: [
                                  s.jsxs("div", {
                                    className:
                                      "flex justify-between text-sm mb-1.5",
                                    children: [
                                      s.jsx("span", {
                                        className: "font-bold text-slate-700",
                                        children: "كفر شكر",
                                      }),
                                      s.jsx("span", {
                                        className: "text-emerald-600 font-bold",
                                        children: "آمن",
                                      }),
                                    ],
                                  }),
                                  s.jsx(fn, {
                                    value: 10,
                                    className:
                                      "h-2 [&>div]:bg-emerald-500 bg-slate-100",
                                  }),
                                ],
                              }),
                            ],
                          }),
                        }),
                      ],
                    }),
                    s.jsxs(Fl, {
                      className:
                        "col-span-1 lg:col-span-2 border-0 shadow-sm flex flex-col",
                      children: [
                        s.jsxs(Nu, {
                          className:
                            "pb-4 border-b border-slate-100 flex flex-row items-center justify-between",
                          children: [
                            s.jsxs("div", {
                              children: [
                                s.jsx(wu, {
                                  className: "text-lg font-bold text-slate-800",
                                  children: "أحدث البلاغات",
                                }),
                                s.jsx(Su, {
                                  children: "البلاغات الواردة التي تتطلب إجراء",
                                }),
                              ],
                            }),
                            s.jsxs("div", {
                              className: "flex gap-2",
                              children: [
                                s.jsxs(Jl, {
                                  variant: "outline",
                                  size: "sm",
                                  className:
                                    "h-9 border-slate-200 text-slate-600",
                                  children: [
                                    s.jsx(Ix, { className: "w-4 h-4 ml-2" }),
                                    "تصفية",
                                  ],
                                }),
                                s.jsx(Jl, {
                                  size: "sm",
                                  className:
                                    "h-9 bg-teal-600 hover:bg-teal-700 text-white",
                                  children: "تصدير التقرير",
                                }),
                              ],
                            }),
                          ],
                        }),
                        s.jsx(Wl, {
                          className: "p-0 flex-1 overflow-auto",
                          children: s.jsxs("table", {
                            className: "w-full text-sm text-right",
                            children: [
                              s.jsx("thead", {
                                className:
                                  "bg-slate-50 text-slate-500 font-bold sticky top-0",
                                children: s.jsxs("tr", {
                                  children: [
                                    s.jsx("th", {
                                      className:
                                        "px-6 py-4 border-b border-slate-100",
                                      children: "رقم",
                                    }),
                                    s.jsx("th", {
                                      className:
                                        "px-6 py-4 border-b border-slate-100",
                                      children: "الفئة",
                                    }),
                                    s.jsx("th", {
                                      className:
                                        "px-6 py-4 border-b border-slate-100",
                                      children: "الموقع",
                                    }),
                                    s.jsx("th", {
                                      className:
                                        "px-6 py-4 border-b border-slate-100",
                                      children: "الأولوية",
                                    }),
                                    s.jsx("th", {
                                      className:
                                        "px-6 py-4 border-b border-slate-100",
                                      children: "الجهة المسؤولة",
                                    }),
                                    s.jsx("th", {
                                      className:
                                        "px-6 py-4 border-b border-slate-100",
                                      children: "الحالة",
                                    }),
                                    s.jsx("th", {
                                      className:
                                        "px-6 py-4 border-b border-slate-100",
                                    }),
                                  ],
                                }),
                              }),
                              s.jsxs("tbody", {
                                className: "divide-y divide-slate-100",
                                children: [
                                  s.jsxs("tr", {
                                    className:
                                      "hover:bg-slate-50 transition-colors",
                                    children: [
                                      s.jsx("td", {
                                        className:
                                          "px-6 py-4 font-mono text-slate-600",
                                        children: "#C-892",
                                      }),
                                      s.jsx("td", {
                                        className:
                                          "px-6 py-4 font-bold text-slate-800",
                                        children: "كسر ماسورة مياه",
                                      }),
                                      s.jsx("td", {
                                        className: "px-6 py-4 text-slate-600",
                                        children: "شارع الجيش، بنها",
                                      }),
                                      s.jsx("td", {
                                        className: "px-6 py-4",
                                        children: s.jsx(Ns, {
                                          className:
                                            "bg-red-50 text-red-700 border-red-200",
                                          children: "عاجل",
                                        }),
                                      }),
                                      s.jsx("td", {
                                        className: "px-6 py-4 text-slate-600",
                                        children: "مياه القليوبية",
                                      }),
                                      s.jsx("td", {
                                        className: "px-6 py-4",
                                        children: s.jsxs("span", {
                                          className:
                                            "flex items-center gap-1.5 text-amber-600 font-bold",
                                          children: [
                                            s.jsx("div", {
                                              className:
                                                "w-2 h-2 rounded-full bg-amber-500",
                                            }),
                                            "قيد المعالجة",
                                          ],
                                        }),
                                      }),
                                      s.jsx("td", {
                                        className: "px-6 py-4",
                                        children: s.jsx(Jl, {
                                          variant: "ghost",
                                          size: "icon",
                                          className:
                                            "h-8 w-8 text-slate-400 hover:text-teal-600",
                                          children: s.jsx(hn, {
                                            className: "w-4 h-4",
                                          }),
                                        }),
                                      }),
                                    ],
                                  }),
                                  s.jsxs("tr", {
                                    className:
                                      "hover:bg-slate-50 transition-colors",
                                    children: [
                                      s.jsx("td", {
                                        className:
                                          "px-6 py-4 font-mono text-slate-600",
                                        children: "#C-891",
                                      }),
                                      s.jsx("td", {
                                        className:
                                          "px-6 py-4 font-bold text-slate-800",
                                        children: "تراكم قمامة",
                                      }),
                                      s.jsx("td", {
                                        className: "px-6 py-4 text-slate-600",
                                        children: "شارع السيوف، قليوب",
                                      }),
                                      s.jsx("td", {
                                        className: "px-6 py-4",
                                        children: s.jsx(Ns, {
                                          className:
                                            "bg-slate-100 text-slate-700 border-slate-200",
                                          children: "عادي",
                                        }),
                                      }),
                                      s.jsx("td", {
                                        className: "px-6 py-4 text-slate-600",
                                        children: "النظافة",
                                      }),
                                      s.jsx("td", {
                                        className: "px-6 py-4",
                                        children: s.jsxs("span", {
                                          className:
                                            "flex items-center gap-1.5 text-blue-600 font-bold",
                                          children: [
                                            s.jsx("div", {
                                              className:
                                                "w-2 h-2 rounded-full bg-blue-500",
                                            }),
                                            "مفتوح",
                                          ],
                                        }),
                                      }),
                                      s.jsx("td", {
                                        className: "px-6 py-4",
                                        children: s.jsx(Jl, {
                                          variant: "ghost",
                                          size: "icon",
                                          className:
                                            "h-8 w-8 text-slate-400 hover:text-teal-600",
                                          children: s.jsx(hn, {
                                            className: "w-4 h-4",
                                          }),
                                        }),
                                      }),
                                    ],
                                  }),
                                  s.jsxs("tr", {
                                    className:
                                      "hover:bg-slate-50 transition-colors bg-teal-50/30",
                                    children: [
                                      s.jsx("td", {
                                        className:
                                          "px-6 py-4 font-mono text-slate-600",
                                        children: "#C-889",
                                      }),
                                      s.jsx("td", {
                                        className:
                                          "px-6 py-4 font-bold text-slate-800",
                                        children: "انقطاع تيار كهربائي",
                                      }),
                                      s.jsx("td", {
                                        className: "px-6 py-4 text-slate-600",
                                        children: "حي الزهور، شبرا",
                                      }),
                                      s.jsx("td", {
                                        className: "px-6 py-4",
                                        children: s.jsx(Ns, {
                                          className:
                                            "bg-red-50 text-red-700 border-red-200",
                                          children: "عاجل",
                                        }),
                                      }),
                                      s.jsx("td", {
                                        className: "px-6 py-4 text-slate-600",
                                        children: "كهرباء القليوبية",
                                      }),
                                      s.jsx("td", {
                                        className: "px-6 py-4",
                                        children: s.jsxs("span", {
                                          className:
                                            "flex items-center gap-1.5 text-emerald-600 font-bold",
                                          children: [
                                            s.jsx("div", {
                                              className:
                                                "w-2 h-2 rounded-full bg-emerald-500",
                                            }),
                                            "تم الحل",
                                          ],
                                        }),
                                      }),
                                      s.jsx("td", {
                                        className: "px-6 py-4",
                                        children: s.jsx(Jl, {
                                          variant: "ghost",
                                          size: "icon",
                                          className:
                                            "h-8 w-8 text-slate-400 hover:text-teal-600",
                                          children: s.jsx(hn, {
                                            className: "w-4 h-4",
                                          }),
                                        }),
                                      }),
                                    ],
                                  }),
                                  s.jsxs("tr", {
                                    className:
                                      "hover:bg-slate-50 transition-colors",
                                    children: [
                                      s.jsx("td", {
                                        className:
                                          "px-6 py-4 font-mono text-slate-600",
                                        children: "#C-888",
                                      }),
                                      s.jsx("td", {
                                        className:
                                          "px-6 py-4 font-bold text-slate-800",
                                        children: "حفرة في الطريق",
                                      }),
                                      s.jsx("td", {
                                        className: "px-6 py-4 text-slate-600",
                                        children: "طريق مصر الإسكندرية الزراعي",
                                      }),
                                      s.jsx("td", {
                                        className: "px-6 py-4",
                                        children: s.jsx(Ns, {
                                          className:
                                            "bg-amber-50 text-amber-700 border-amber-200",
                                          children: "هام",
                                        }),
                                      }),
                                      s.jsx("td", {
                                        className: "px-6 py-4 text-slate-600",
                                        children: "أعمال عامة",
                                      }),
                                      s.jsx("td", {
                                        className: "px-6 py-4",
                                        children: s.jsxs("span", {
                                          className:
                                            "flex items-center gap-1.5 text-blue-600 font-bold",
                                          children: [
                                            s.jsx("div", {
                                              className:
                                                "w-2 h-2 rounded-full bg-blue-500",
                                            }),
                                            "مفتوح",
                                          ],
                                        }),
                                      }),
                                      s.jsx("td", {
                                        className: "px-6 py-4",
                                        children: s.jsx(Jl, {
                                          variant: "ghost",
                                          size: "icon",
                                          className:
                                            "h-8 w-8 text-slate-400 hover:text-teal-600",
                                          children: s.jsx(hn, {
                                            className: "w-4 h-4",
                                          }),
                                        }),
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                            ],
                          }),
                        }),
                      ],
                    }),
                  ],
                }),
              ],
            }),
          ],
        }),
      ],
    })
  );
}
const R4 = [
    {
      id: "roads",
      name: "الطرق والأرصفة",
      icon: s.jsx(rr, { className: "w-5 h-5" }),
      color: "bg-orange-500",
      light: "bg-orange-50 text-orange-600 border-orange-200",
      lead: "م. عمرو فاروق",
      members: 8,
      active: 12,
      resolved: 89,
      avgTime: "١.٨ يوم",
      performance: 87,
      trend: "up",
    },
    {
      id: "water",
      name: "مياه وصرف صحي",
      icon: s.jsx(Wx, { className: "w-5 h-5" }),
      color: "bg-blue-500",
      light: "bg-blue-50 text-blue-600 border-blue-200",
      lead: "م. كريم سلامة",
      members: 6,
      active: 8,
      resolved: 67,
      avgTime: "٢.٣ يوم",
      performance: 74,
      trend: "up",
    },
    {
      id: "electric",
      name: "الكهرباء والإنارة",
      icon: s.jsx(Gu, { className: "w-5 h-5" }),
      color: "bg-amber-500",
      light: "bg-amber-50 text-amber-600 border-amber-200",
      lead: "م. هاني البسيوني",
      members: 10,
      active: 15,
      resolved: 143,
      avgTime: "٤.١ ساعة",
      performance: 94,
      trend: "up",
    },
    {
      id: "clean",
      name: "النظافة والتجميل",
      icon: s.jsx(ap, { className: "w-5 h-5" }),
      color: "bg-green-500",
      light: "bg-green-50 text-green-600 border-green-200",
      lead: "أ. سمير الدمرداش",
      members: 14,
      active: 22,
      resolved: 201,
      avgTime: "١٨ ساعة",
      performance: 91,
      trend: "down",
    },
    {
      id: "infra",
      name: "البنية التحتية العامة",
      icon: s.jsx(Jx, { className: "w-5 h-5" }),
      color: "bg-purple-500",
      light: "bg-purple-50 text-purple-600 border-purple-200",
      lead: "م. محمود النجار",
      members: 5,
      active: 6,
      resolved: 34,
      avgTime: "٣.٢ يوم",
      performance: 68,
      trend: "down",
    },
  ],
  M4 = [
    {
      name: "م. عمرو فاروق",
      dept: "الطرق",
      role: "رئيس الفريق",
      assigned: 5,
      resolved: 42,
      rating: 4.8,
      status: "online",
      avatar: "عف",
    },
    {
      name: "م. كريم سلامة",
      dept: "المياه",
      role: "رئيس الفريق",
      assigned: 3,
      resolved: 29,
      rating: 4.6,
      status: "online",
      avatar: "كس",
    },
    {
      name: "أ. ياسمين حسن",
      dept: "النظافة",
      role: "مشرفة",
      assigned: 7,
      resolved: 58,
      rating: 4.9,
      status: "online",
      avatar: "يح",
    },
    {
      name: "م. هاني البسيوني",
      dept: "الكهرباء",
      role: "رئيس الفريق",
      assigned: 8,
      resolved: 97,
      rating: 4.7,
      status: "busy",
      avatar: "هب",
    },
    {
      name: "أ. طارق عبد العزيز",
      dept: "الطرق",
      role: "فني أول",
      assigned: 4,
      resolved: 31,
      rating: 4.4,
      status: "online",
      avatar: "طع",
    },
    {
      name: "أ. نهى مصطفى",
      dept: "البنية التحتية",
      role: "مهندسة",
      assigned: 2,
      resolved: 18,
      rating: 4.5,
      status: "offline",
      avatar: "نم",
    },
    {
      name: "م. أحمد الشيمي",
      dept: "الكهرباء",
      role: "فني كهرباء",
      assigned: 6,
      resolved: 44,
      rating: 4.3,
      status: "busy",
      avatar: "أش",
    },
    {
      name: "أ. سمير الدمرداش",
      dept: "النظافة",
      role: "رئيس الفريق",
      assigned: 9,
      resolved: 73,
      rating: 4.6,
      status: "online",
      avatar: "سد",
    },
  ],
  ax = {
    online: "bg-emerald-400",
    busy: "bg-amber-400",
    offline: "bg-slate-300",
  },
  _4 = { online: "متاح", busy: "مشغول", offline: "غير متصل" };
function k4() {
  const [a, i] = j.useState(null),
    [c, o] = j.useState("departments");
  return s.jsxs("div", {
    dir: "rtl",
    className: "flex h-screen bg-slate-100 overflow-hidden",
    children: [
      s.jsxs("aside", {
        className:
          "w-64 bg-slate-900 text-slate-300 flex flex-col h-full shrink-0",
        children: [
          s.jsxs("div", {
            className: "p-5 flex items-center gap-3 border-b border-slate-800",
            children: [
              s.jsx("div", {
                className:
                  "w-8 h-8 bg-teal-600 rounded-lg flex items-center justify-center text-white font-black",
                children: "CP",
              }),
              s.jsxs("div", {
                children: [
                  s.jsx("h1", {
                    className: "font-black text-white text-sm",
                    children: "CityPulse",
                  }),
                  s.jsx("p", {
                    className: "text-[10px] text-slate-400",
                    children: "لوحة القيادة الإدارية",
                  }),
                ],
              }),
            ],
          }),
          s.jsx("nav", {
            className: "flex-1 py-4 px-3 space-y-1",
            children: [
              {
                icon: s.jsx(Cr, { className: "w-4 h-4" }),
                label: "نظرة عامة",
                href: "/admin",
              },
              {
                icon: s.jsx(wa, { className: "w-4 h-4" }),
                label: "البلاغات",
                badge: "١٢",
                href: "/admin",
              },
              {
                icon: s.jsx(Hu, { className: "w-4 h-4" }),
                label: "الخريطة الحرارية",
                href: "/heatmap",
              },
              {
                icon: s.jsx(Cs, { className: "w-4 h-4" }),
                label: "الفرق والموظفون",
                active: !0,
                href: "/admin/teams",
              },
              {
                icon: s.jsx(lp, { className: "w-4 h-4" }),
                label: "الصلاحيات",
                href: "#",
              },
              {
                icon: s.jsx(qu, { className: "w-4 h-4" }),
                label: "الإعدادات",
                href: "#",
              },
            ].map((d, f) =>
              s.jsxs(
                Ye,
                {
                  href: d.href,
                  className: `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-bold transition-colors ${d.active ? "bg-teal-600/20 text-teal-400" : "hover:bg-slate-800 hover:text-white"}`,
                  children: [
                    d.icon,
                    s.jsx("span", { className: "flex-1", children: d.label }),
                    d.badge &&
                      s.jsx("span", {
                        className:
                          "bg-teal-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full",
                        children: d.badge,
                      }),
                  ],
                },
                f,
              ),
            ),
          }),
          s.jsx("div", {
            className: "p-4 border-t border-slate-800",
            children: s.jsxs("div", {
              className: "flex items-center gap-3",
              children: [
                s.jsx("div", {
                  className:
                    "w-9 h-9 rounded-xl bg-slate-700 flex items-center justify-center text-sm font-black text-white",
                  children: "خ",
                }),
                s.jsxs("div", {
                  children: [
                    s.jsx("p", {
                      className: "text-sm font-black text-white",
                      children: "م. خالد حسن",
                    }),
                    s.jsx("p", {
                      className: "text-xs text-teal-400",
                      children: "مدير العمليات",
                    }),
                  ],
                }),
              ],
            }),
          }),
        ],
      }),
      s.jsxs("main", {
        className: "flex-1 flex flex-col overflow-hidden",
        children: [
          s.jsxs("header", {
            className:
              "h-14 bg-white border-b border-slate-200 flex items-center justify-between px-6 shrink-0",
            children: [
              s.jsxs("div", {
                className: "flex items-center gap-3",
                children: [
                  s.jsx("h2", {
                    className: "font-black text-slate-800",
                    children: "إدارة الفرق والموظفين",
                  }),
                  s.jsx("span", {
                    className: "text-xs text-slate-400",
                    children: "— محافظة القليوبية",
                  }),
                ],
              }),
              s.jsxs("div", {
                className: "flex items-center gap-3",
                children: [
                  s.jsxs("div", {
                    className: "relative hidden md:block",
                    children: [
                      s.jsx(Lu, {
                        className:
                          "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400",
                      }),
                      s.jsx("input", {
                        type: "text",
                        placeholder: "ابحث عن موظف...",
                        className:
                          "bg-slate-100 rounded-xl px-4 py-2 pr-9 text-sm font-bold text-slate-700 placeholder-slate-400 focus:outline-none w-44 border border-slate-200 focus:border-teal-500",
                      }),
                    ],
                  }),
                  s.jsxs("button", {
                    className:
                      "flex items-center gap-2 px-4 py-2 bg-teal-600 text-white text-sm font-black rounded-xl hover:bg-teal-700 transition-colors",
                    children: [
                      s.jsx(cr, { className: "w-4 h-4" }),
                      " إضافة موظف",
                    ],
                  }),
                ],
              }),
            ],
          }),
          s.jsxs("div", {
            className: "flex-1 overflow-y-auto p-6",
            children: [
              s.jsx("div", {
                className: "grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6",
                children: [
                  {
                    label: "إجمالي الموظفين",
                    value: "٤٣",
                    icon: s.jsx(Cs, { className: "w-5 h-5" }),
                    color: "bg-blue-50 text-blue-600",
                  },
                  {
                    label: "متاحون الآن",
                    value: "٢٨",
                    icon: s.jsx(sj, { className: "w-5 h-5" }),
                    color: "bg-emerald-50 text-emerald-600",
                  },
                  {
                    label: "مشغولون",
                    value: "١١",
                    icon: s.jsx(pn, { className: "w-5 h-5" }),
                    color: "bg-amber-50 text-amber-600",
                  },
                  {
                    label: "معدل الأداء العام",
                    value: "٨٣٪",
                    icon: s.jsx(t2, { className: "w-5 h-5" }),
                    color: "bg-purple-50 text-purple-600",
                  },
                ].map((d, f) =>
                  s.jsxs(
                    "div",
                    {
                      className:
                        "bg-white rounded-2xl p-5 border border-slate-100 shadow-sm",
                      children: [
                        s.jsx("div", {
                          className: `w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${d.color}`,
                          children: d.icon,
                        }),
                        s.jsx("div", {
                          className: "text-3xl font-black text-slate-800",
                          children: d.value,
                        }),
                        s.jsx("div", {
                          className: "text-xs font-black text-slate-500 mt-1",
                          children: d.label,
                        }),
                      ],
                    },
                    f,
                  ),
                ),
              }),
              s.jsx("div", {
                className: "flex items-center gap-3 mb-5",
                children: ["departments", "staff"].map((d) =>
                  s.jsx(
                    "button",
                    {
                      onClick: () => o(d),
                      className: `px-5 py-2 rounded-xl text-sm font-black transition-all ${c === d ? "bg-teal-600 text-white shadow-sm" : "bg-white text-slate-600 border border-slate-200 hover:border-teal-300"}`,
                      children: d === "departments" ? "الأقسام" : "الموظفون",
                    },
                    d,
                  ),
                ),
              }),
              c === "departments" &&
                s.jsxs("div", {
                  className:
                    "grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-5",
                  children: [
                    R4.map((d) =>
                      s.jsxs(
                        "div",
                        {
                          onClick: () => i(a === d.id ? null : d.id),
                          className: `bg-white rounded-2xl border-2 shadow-sm cursor-pointer transition-all hover:shadow-md ${a === d.id ? "border-teal-400" : "border-slate-100 hover:border-teal-200"}`,
                          children: [
                            s.jsxs("div", {
                              className: "p-5 border-b border-slate-50",
                              children: [
                                s.jsxs("div", {
                                  className:
                                    "flex items-start justify-between mb-3",
                                  children: [
                                    s.jsx("div", {
                                      className: `w-11 h-11 rounded-xl flex items-center justify-center text-white ${d.color}`,
                                      children: d.icon,
                                    }),
                                    s.jsxs("div", {
                                      className:
                                        "flex items-center gap-1 text-xs font-black",
                                      children: [
                                        d.trend === "up"
                                          ? s.jsx(Ss, {
                                              className:
                                                "w-3.5 h-3.5 text-emerald-500",
                                            })
                                          : s.jsx(np, {
                                              className:
                                                "w-3.5 h-3.5 text-red-500",
                                            }),
                                        s.jsxs("span", {
                                          className:
                                            d.trend === "up"
                                              ? "text-emerald-600"
                                              : "text-red-500",
                                          children: [d.performance, "٪"],
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                                s.jsx("h3", {
                                  className: "font-black text-slate-800 mb-1",
                                  children: d.name,
                                }),
                                s.jsxs("p", {
                                  className: "text-xs text-slate-500",
                                  children: [
                                    "المشرف: ",
                                    s.jsx("span", {
                                      className: "font-bold text-slate-700",
                                      children: d.lead,
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            s.jsxs("div", {
                              className:
                                "p-5 grid grid-cols-3 gap-3 text-center",
                              children: [
                                s.jsxs("div", {
                                  children: [
                                    s.jsx("div", {
                                      className:
                                        "text-xl font-black text-slate-800",
                                      children: d.members,
                                    }),
                                    s.jsx("div", {
                                      className:
                                        "text-[10px] text-slate-400 font-bold",
                                      children: "عضو",
                                    }),
                                  ],
                                }),
                                s.jsxs("div", {
                                  children: [
                                    s.jsx("div", {
                                      className:
                                        "text-xl font-black text-amber-600",
                                      children: d.active,
                                    }),
                                    s.jsx("div", {
                                      className:
                                        "text-[10px] text-slate-400 font-bold",
                                      children: "بلاغ نشط",
                                    }),
                                  ],
                                }),
                                s.jsxs("div", {
                                  children: [
                                    s.jsx("div", {
                                      className:
                                        "text-xl font-black text-emerald-600",
                                      children: d.resolved,
                                    }),
                                    s.jsx("div", {
                                      className:
                                        "text-[10px] text-slate-400 font-bold",
                                      children: "محلول",
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            s.jsxs("div", {
                              className: "px-5 pb-5",
                              children: [
                                s.jsxs("div", {
                                  className:
                                    "flex justify-between text-xs mb-1.5",
                                  children: [
                                    s.jsx("span", {
                                      className: "font-bold text-slate-500",
                                      children: "معدل الإنجاز",
                                    }),
                                    s.jsxs("span", {
                                      className: "font-black text-slate-700",
                                      children: ["متوسط ", d.avgTime],
                                    }),
                                  ],
                                }),
                                s.jsx("div", {
                                  className:
                                    "h-2 bg-slate-100 rounded-full overflow-hidden",
                                  children: s.jsx("div", {
                                    className: `h-full rounded-full ${d.performance >= 90 ? "bg-emerald-500" : d.performance >= 75 ? "bg-teal-500" : d.performance >= 60 ? "bg-amber-500" : "bg-red-400"}`,
                                    style: { width: `${d.performance}%` },
                                  }),
                                }),
                              ],
                            }),
                          ],
                        },
                        d.id,
                      ),
                    ),
                    s.jsxs("div", {
                      className:
                        "bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl p-8 flex flex-col items-center justify-center cursor-pointer hover:border-teal-400 hover:bg-teal-50/30 transition-all group",
                      children: [
                        s.jsx("div", {
                          className:
                            "w-12 h-12 rounded-2xl bg-white border border-slate-200 flex items-center justify-center mb-3 group-hover:border-teal-400 transition-colors",
                          children: s.jsx(cr, {
                            className:
                              "w-6 h-6 text-slate-400 group-hover:text-teal-600",
                          }),
                        }),
                        s.jsx("p", {
                          className:
                            "text-sm font-black text-slate-500 group-hover:text-teal-700",
                          children: "إضافة قسم جديد",
                        }),
                      ],
                    }),
                  ],
                }),
              c === "staff" &&
                s.jsxs("div", {
                  className:
                    "bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden",
                  children: [
                    s.jsxs("div", {
                      className:
                        "p-4 border-b border-slate-100 flex items-center gap-3",
                      children: [
                        s.jsxs("button", {
                          className:
                            "flex items-center gap-2 px-3 py-2 border border-slate-200 rounded-xl text-xs font-black text-slate-600 hover:bg-slate-50",
                          children: [
                            s.jsx(Ix, { className: "w-3.5 h-3.5" }),
                            " تصفية",
                          ],
                        }),
                        s.jsxs("button", {
                          className:
                            "flex items-center gap-2 px-3 py-2 border border-slate-200 rounded-xl text-xs font-black text-slate-600 hover:bg-slate-50",
                          children: [
                            "القسم ",
                            s.jsx(Om, { className: "w-3.5 h-3.5" }),
                          ],
                        }),
                        s.jsxs("button", {
                          className:
                            "flex items-center gap-2 px-3 py-2 border border-slate-200 rounded-xl text-xs font-black text-slate-600 hover:bg-slate-50",
                          children: [
                            "الحالة ",
                            s.jsx(Om, { className: "w-3.5 h-3.5" }),
                          ],
                        }),
                        s.jsx("span", {
                          className: "text-xs text-slate-400 font-bold mr-auto",
                          children: "٨ موظفين",
                        }),
                      ],
                    }),
                    s.jsxs("table", {
                      className: "w-full text-sm text-right",
                      children: [
                        s.jsx("thead", {
                          className:
                            "bg-slate-50 text-slate-500 font-black text-xs",
                          children: s.jsxs("tr", {
                            children: [
                              s.jsx("th", {
                                className:
                                  "px-5 py-3.5 border-b border-slate-100",
                                children: "الموظف",
                              }),
                              s.jsx("th", {
                                className:
                                  "px-5 py-3.5 border-b border-slate-100",
                                children: "القسم",
                              }),
                              s.jsx("th", {
                                className:
                                  "px-5 py-3.5 border-b border-slate-100",
                                children: "المهام المعيّنة",
                              }),
                              s.jsx("th", {
                                className:
                                  "px-5 py-3.5 border-b border-slate-100",
                                children: "المحلولة",
                              }),
                              s.jsx("th", {
                                className:
                                  "px-5 py-3.5 border-b border-slate-100",
                                children: "التقييم",
                              }),
                              s.jsx("th", {
                                className:
                                  "px-5 py-3.5 border-b border-slate-100",
                                children: "الحالة",
                              }),
                              s.jsx("th", {
                                className:
                                  "px-5 py-3.5 border-b border-slate-100",
                              }),
                            ],
                          }),
                        }),
                        s.jsx("tbody", {
                          className: "divide-y divide-slate-50",
                          children: M4.map((d, f) =>
                            s.jsxs(
                              "tr",
                              {
                                className:
                                  "hover:bg-slate-50 transition-colors",
                                children: [
                                  s.jsx("td", {
                                    className: "px-5 py-4",
                                    children: s.jsxs("div", {
                                      className: "flex items-center gap-3",
                                      children: [
                                        s.jsxs("div", {
                                          className: "relative",
                                          children: [
                                            s.jsx("div", {
                                              className:
                                                "w-9 h-9 rounded-xl bg-teal-100 flex items-center justify-center text-teal-700 font-black text-xs",
                                              children: d.avatar,
                                            }),
                                            s.jsx("div", {
                                              className: `absolute bottom-0 left-0 w-2.5 h-2.5 rounded-full border-2 border-white ${ax[d.status]}`,
                                            }),
                                          ],
                                        }),
                                        s.jsxs("div", {
                                          children: [
                                            s.jsx("p", {
                                              className:
                                                "font-black text-slate-800 text-sm",
                                              children: d.name,
                                            }),
                                            s.jsx("p", {
                                              className:
                                                "text-xs text-slate-400",
                                              children: d.role,
                                            }),
                                          ],
                                        }),
                                      ],
                                    }),
                                  }),
                                  s.jsx("td", {
                                    className:
                                      "px-5 py-4 text-slate-600 font-bold text-xs",
                                    children: d.dept,
                                  }),
                                  s.jsx("td", {
                                    className: "px-5 py-4",
                                    children: s.jsxs("div", {
                                      className: "flex items-center gap-2",
                                      children: [
                                        s.jsx("div", {
                                          className:
                                            "flex-1 h-1.5 bg-slate-100 rounded-full max-w-[60px]",
                                          children: s.jsx("div", {
                                            className:
                                              "h-full bg-amber-400 rounded-full",
                                            style: {
                                              width: `${(d.assigned / 10) * 100}%`,
                                            },
                                          }),
                                        }),
                                        s.jsx("span", {
                                          className:
                                            "font-black text-slate-700 text-xs",
                                          children: d.assigned,
                                        }),
                                      ],
                                    }),
                                  }),
                                  s.jsx("td", {
                                    className:
                                      "px-5 py-4 font-black text-emerald-600",
                                    children: d.resolved,
                                  }),
                                  s.jsx("td", {
                                    className: "px-5 py-4",
                                    children: s.jsxs("div", {
                                      className: "flex items-center gap-1",
                                      children: [
                                        s.jsx(or, {
                                          className:
                                            "w-3.5 h-3.5 text-amber-400 fill-amber-400",
                                        }),
                                        s.jsx("span", {
                                          className:
                                            "font-black text-slate-700 text-xs",
                                          children: d.rating,
                                        }),
                                      ],
                                    }),
                                  }),
                                  s.jsx("td", {
                                    className: "px-5 py-4",
                                    children: s.jsxs("span", {
                                      className: `inline-flex items-center gap-1.5 text-[10px] font-black px-2.5 py-1 rounded-full ${d.status === "online" ? "bg-emerald-50 text-emerald-700" : d.status === "busy" ? "bg-amber-50 text-amber-700" : "bg-slate-100 text-slate-500"}`,
                                      children: [
                                        s.jsx("span", {
                                          className: `w-1.5 h-1.5 rounded-full ${ax[d.status]}`,
                                        }),
                                        _4[d.status],
                                      ],
                                    }),
                                  }),
                                  s.jsx("td", {
                                    className: "px-5 py-4",
                                    children: s.jsx("button", {
                                      className:
                                        "w-8 h-8 flex items-center justify-center text-slate-400 hover:text-teal-600 hover:bg-teal-50 rounded-lg transition-colors",
                                      children: s.jsx(hn, {
                                        className: "w-4 h-4",
                                      }),
                                    }),
                                  }),
                                ],
                              },
                              f,
                            ),
                          ),
                        }),
                      ],
                    }),
                  ],
                }),
            ],
          }),
        ],
      }),
    ],
  });
}
const D4 = new Qy();
function z4() {
  return s.jsxs(gy, {
    children: [
      s.jsx(xl, { path: "/", component: Pw }),
      s.jsx(xl, { path: "/auth", component: $w }),
      s.jsx(xl, { path: "/report", component: Fw }),
      s.jsx(xl, { path: "/dashboard", component: e4 }),
      s.jsx(xl, { path: "/reports/:id", component: l4 }),
      s.jsx(xl, { path: "/heatmap", component: a4 }),
      s.jsx(xl, { path: "/admin", component: O4 }),
      s.jsx(xl, { path: "/admin/teams", component: k4 }),
      s.jsx(xl, { component: Vw }),
    ],
  });
}
function U4() {
  return s.jsx(Ky, {
    client: D4,
    children: s.jsxs(Bw, {
      children: [
        s.jsx(xx, { base: "/".replace(/\/$/, ""), children: s.jsx(z4, {}) }),
        s.jsx(iN, {}),
      ],
    }),
  });
}
Wv.createRoot(document.getElementById("root")).render(s.jsx(U4, {}));
